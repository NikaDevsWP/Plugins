<?php
/**
 * Mega Menu
 *
 * @package NikaDevs
 * @subpackage Berserk Shortcodes
 * @since 1.0.0
 */

/**
 * Nav Menu Enqueue Scripts
 */
function berserk_mega_menu_admin_enqueue_scripts( $hook ) {
	if( $hook == 'nav-menus.php') {
		wp_enqueue_script( 'berserk-mega-menu', BERSERK_SHORTCODES_URL . 'assets/js/berserk-mega-menu.js', array( 'jquery' ), '1.0.0', true );
		wp_enqueue_style( 'berserk-mega-menu', BERSERK_SHORTCODES_URL . 'assets/css/berserk-mega-menu.css', array( 'jquery' ), '1.0.0' );
	}
}
add_action( 'admin_enqueue_scripts', 'berserk_mega_menu_admin_enqueue_scripts' );

/**
 * Setup nav menu item
 */
function berserk_wp_setup_nav_menu_item( $post ) { 
	//print_r($post);
	$post->mega_menu = get_post_meta( $post->ID, '_menu_item_mega_menu', true);
	if( $post->type == 'mega_menu_item' ){
		$post->type_label = esc_html__('Mega Menu Item','berserk');
		$post->url = '#';
	}
	if( $post->type == 'mega_menu_column' ){
		$post->type_label = esc_html__('Mega Menu Column','berserk');
		$post->url = '#';
	}
	if( $post->type == 'mega_menu_shortcode' ){
		$post->type_label = esc_html__('Shortcode','berserk');
		$post->url = '#';
	}
	
	return $post; 
}; 
add_filter( 'wp_setup_nav_menu_item', 'berserk_wp_setup_nav_menu_item', 10, 1 ); 


/**
 * Mega Menu
 */
 function berserk_mega_menu_nav_menus() {
	add_meta_box( 'add-mega-menu-items', esc_html__( 'Mega Menu', 'nikadevstest' ), 'nika_devs_test_menu_metabox', 'nav-menus', 'side');
}
add_action( 'admin_head-nav-menus.php', 'berserk_mega_menu_nav_menus' );

/**
 * Displays a menu metabox
 */
function nika_devs_test_menu_metabox( $object, $args ) {
	
	global $nav_menu_selected_id;
	// Create an array of objects that imitate Post objects
	$my_items = array(
		(object) array(
			'ID' => 1,
			'db_id' => 001,
			'menu_item_parent' => 0,
			'object_id' => 1,
			'post_parent' => 0,
			'type' => 'mega_menu_item',
			'object' => 'mega_menu_item',
			'type_label' => 'Mega Menu Item',
			'title' => esc_html__('Mega Menu Item', 'berserk' ),
			'url' => '#',
			'target' => '',
			'attr_title' => '',
			'description' => '',
			'classes' => array(),
			'xfn' => '',
		),
		(object) array(
			'ID' => 2,
			'db_id' => 002,
			'menu_item_parent' => 0,
			'object_id' => 2,
			'post_parent' => 0,
			'type' => 'mega_menu_column',
			'object' => 'mega_menu_column', 
			'type_label' => 'Column',
			'title' => esc_html__('Column', 'berserk' ),
			'url' => '#',
			'target' => '',
			'attr_title' => '',
			'description' => '',
			'classes' => array(),
			'xfn' => '',
		),
		(object) array(
			'ID' => 3,
			'db_id' => 003,
			'menu_item_parent' => 0,
			'object_id' => 3,
			'post_parent' => 0,
			'type' => 'mega_menu_shortcode',
			'object' => 'mega_menu_shortcode', 
			'type_label' => 'Shortcode',
			'title' => esc_html__('Shortcode', 'berserk' ),
			'url' => '#',
			'target' => '',
			'attr_title' => '',
			'description' => '',
			'classes' => array(),
			'xfn' => '',
		),
	);
	$db_fields = false;
	// If your links will be hieararchical, adjust the $db_fields array bellow
	if ( false ) {
		$db_fields = array( 'parent' => 'parent', 'id' => 'post_parent' );
	}
	$walker = new Walker_Nav_Menu_Checklist( $db_fields );
	//print_r($args);
	?>
	<div id="megamenudiv" class="megamenudiv">
		<div id="tabs-panel-mega-menu" class="tabs-panel tabs-panel-active">
		<ul id="megamenuchecklist" class="categorychecklist form-no-clear" >
			<?php echo walk_nav_menu_tree( array_map( 'wp_setup_nav_menu_item', $my_items ), 0, (object) array( 'walker' => $walker ) ); ?>
		</ul>
		<p class="button-controls">
			<span class="add-to-menu">
				<input type="submit"<?php wp_nav_menu_disabled_check( $nav_menu_selected_id ); ?> class="button-secondary submit-add-to-menu right" value="<?php esc_attr_e( 'Add to Menu', 'berserk' ); ?>" name="add-mega-menu-item" id="submit-megamenudiv" />
				<span class="spinner"></span>
			</span>
		</p>
		<?php /*
		<p class="button-controls">
			<span class="add-to-menu">
				<a href="#" class="button-secondary submit-add-to-mega-menu right" name="add-mega-menu-item" id="submit-megamenudiv"><?php esc_attr_e( 'Add to Mega Menu' ); ?></a>
				<span class="spinner"></span>
			</span>
		</p>
		
		<p class="button-controls">
			<span class="add-to-menu">
				<a href="#" class="button-secondary submit-custom-mega-menu right" name="add-mega-menu-item" id="submit-megamenudiv"><?php esc_attr_e( 'Custom Mega Menu' ); ?></a>
				<span class="spinner"></span>
			</span>
		</p>
		*/?>

	</div>
	
	<?php
}

/**
 * Mega Menu Edit
 */
require_once BERSERK_SHORTCODES_PATH . '/functions/mega-menu/mega-menu-edit.php';

/**
 * Mega Menu Custom Fields
 */
require_once BERSERK_SHORTCODES_PATH . '/functions/mega-menu/mega-menu-custom-fields.php';

/**
 * Remove one or more icon types
 */
function berserk_remove_menu_icons_type( $types ) {
	// Font Awesome
	//unset( $types['fa'] );
	unset( $types['dashicons'] );
	unset( $types['elusive'] );
	unset( $types['foundation-icons'] );
	unset( $types['genericon'] );
	unset( $types['svg'] );
	unset( $types['image'] );
	return $types;
}
add_filter( 'menu_icons_types', 'berserk_remove_menu_icons_type' );

add_filter( 'menu_icons_disable_settings', '__return_true' );

/**
 * Override menu item markup
 */
function berserk_menu_icons_item_title( $markup, $id, $meta, $title ) {
	// Do your thing.
	$markup = '<span class="brk-header-list__icon">';
	$markup .= '<i class="' . $meta['type'] . ' ' . $meta['icon'] . '" aria-hidden="true"></i>';
	$markup .= '</span>';
	$markup .= $title;
	return $markup;
}
add_filter( 'menu_icons_item_title', 'berserk_menu_icons_item_title', 10, 4 );