<?php
/**
 * Mega Menu Edit
 *
 * @package NikaDevs
 * @subpackage Berserk Shortcodes
 * @since 1.0.0
 */

function berserk_walker_nav_menu_edit(){

	/**
	 * Custom Walker for Nav Menu Editor
	 */
	class Menu_Item_Custom_Fields_Walker extends Walker_Nav_Menu_Edit {
	
		/**
		 * Start the element output.
		 */
		function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {
			$item_output = '';
	
			parent::start_el( $item_output, $item, $depth, $args, $id );
	
			$output .= preg_replace(
				// NOTE: Check this regex from time to time!
				'/(?=<(fieldset|p)[^>]+class="[^"]*field-move)/',
				$this->get_fields( $item, $depth, $args ),
				$item_output
			);
		}
	
		/**
		 * Get custom fields
		 */
		protected function get_fields( $item, $depth, $args = array(), $id = 0 ) {
			ob_start();
	
			/**
			 * Get menu item custom fields from plugins/themes
			 */
			do_action( 'wp_nav_menu_item_custom_fields', $item->ID, $item, $depth, $args, $id );
	
			return ob_get_clean();
		}
	}
}
 
/**
 * Menu Item Custom Fields
 */

if ( ! class_exists( 'Menu_Item_Custom_Fields' ) ) :
	/**
	* Menu Item Custom Fields Loader
	*/
	class Menu_Item_Custom_Fields {

		/**
		* Add filter
		*
		* @wp_hook action wp_loaded
		*/
		public static function load() {
			add_filter( 'wp_edit_nav_menu_walker', array( __CLASS__, '_filter_walker' ), 99 );
		}

		/**
		* Replace default menu editor walker with ours
		*/
		public static function _filter_walker( $walker ) {
			$walker = 'Menu_Item_Custom_Fields_Walker';
			if ( ! class_exists( $walker ) ) {
				berserk_walker_nav_menu_edit();
				//require_once dirname( __FILE__ ) . '/walker-nav-menu-edit.php';
			}

			return $walker;
		}
	}
	add_action( 'wp_loaded', array( 'Menu_Item_Custom_Fields', 'load' ), 9 );
endif; // class_exists( 'Menu_Item_Custom_Fields' )