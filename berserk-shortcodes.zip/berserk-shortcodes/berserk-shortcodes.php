<?php
/*
Plugin Name: Berserk Shortcodes
Plugin URI: http://nikadevs.com
Description: A part of Berserk theme
Version: 1.1.1
Author: Nikadevs Team
Author URI: http://nikadevs.com
Text Domain: berserk_shortcodes
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

define( 'BERSERK_SHORTCODES_PATH', plugin_dir_path( __FILE__ ) );
define( 'BERSERK_SHORTCODES_URL', plugin_dir_url( __FILE__ ) );
define( 'BERSERK_IS_PLUGIN_ACTIVE', true );

define( 'BRK_DATA_IMAGE', 'data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==' );

class Berserk_Shortcodes {

	/**
	 * Hold an instance of Berserk_Shortcodes class.
	 * @var Berserk_Shortcodes
	 */
	protected static $instance = null;

	/**
	 * [$params description]
	 * @var array
	 */
	public $params = array();

	/**
	 * Main Berserk_Shortcodes instance.
	 *
	 * @return Berserk_Shortcodes - Main instance.
	 */
	public static function instance() {

		if ( null == self::$instance ) {
			self::$instance = new Berserk_Shortcodes();
		}

		return self::$instance;
	}

	/**
	 * [__construct description]
	 * @method __construct
	 */
	public function __construct() {

		$this->includes();
		$this->add_action( 'plugins_loaded', 'load_plugin_textdomain' );
		$this->add_action( 'admin_notices', 'activate_theme_notice' );
		$this->add_filter( 'wp_kses_allowed_html', 'wp_kses_allowed_html', 10, 2 );

		add_action( 'wp_ajax_posts_get_more', array( 'Shortcodes_Helper', 'posts_get_more' ) );
		add_action( 'wp_ajax_nopriv_posts_get_more', array( 'Shortcodes_Helper', 'posts_get_more' ) );

		add_action( 'wp_ajax_check_if_posts_exist', array( 'Shortcodes_Helper', 'check_if_posts_exist' ) );
		add_action( 'wp_ajax_nopriv_check_if_posts_exist', array( 'Shortcodes_Helper', 'check_if_posts_exist' ) );

		add_action( 'wp_ajax_portfolio_year_filter', array( 'Berserk_Portfolio', 'portfolio_year_filter' ) );
		add_action( 'wp_ajax_nopriv_portfolio_year_filter', array( 'Berserk_Portfolio', 'portfolio_year_filter' ) );

		add_action( 'wp_ajax_add_post_image_like', array( 'Shortcodes_Helper', 'add_post_image_like' ) );
		add_action( 'wp_ajax_nopriv_add_post_image_like', array( 'Shortcodes_Helper', 'add_post_image_like' ) );

		//add_action('wp_ajax_get_folio_item', array('Berserk_Portfolio', 'get_folio_item'));
		//add_action('wp_ajax_nopriv_get_folio_item', array('Berserk_Portfolio', 'get_folio_item'));

		add_action( 'wp_ajax_cfa_submit', array( 'BRS_Send_Mail', 'cfa_submit' ) );
		add_action( 'wp_ajax_nopriv_cfa_submit', array( 'BRS_Send_Mail', 'cfa_submit' ) );

		add_action( 'wp_ajax_add_to_wishlist', array( 'BRS_Woocommerce', 'add_to_wishlist' ) );
		add_action( 'wp_ajax_nopriv_add_to_wishlist', array( 'BRS_Woocommerce', 'add_to_wishlist' ) );

		add_action( 'wp_ajax_remove_from_wishlist', array( 'BRS_Woocommerce', 'remove_from_wishlist' ) );
		add_action( 'wp_ajax_nopriv_remove_from_wishlist', array( 'BRS_Woocommerce', 'remove_from_wishlist' ) );

		add_action( 'wp_ajax_add_to_compare', array( 'BRS_Woocommerce', 'add_to_compare' ) );
		add_action( 'wp_ajax_nopriv_add_to_compare', array( 'BRS_Woocommerce', 'add_to_compare' ) );

		add_action( 'wp_ajax_remove_from_compare', array( 'BRS_Woocommerce', 'remove_from_compare' ) );
		add_action( 'wp_ajax_nopriv_remove_from_compare', array( 'BRS_Woocommerce', 'remove_from_compare' ) );

		add_action( 'wp_ajax_get_all_products', array( 'BRS_Woocommerce', 'get_all_products' ) );

		add_action( 'wp_ajax_add_json_encode', array( 'BRS_Shortcodes_VCParams', 'add_json_encode' ) );

		add_action( 'wp_ajax_add_live_mode', array( 'BRS_Shortcodes_VCParams', 'add_live_mode' ) );

		add_action( 'wp_ajax_get_posts_to_add', array( 'BRS_Shortcodes_VCParams', 'get_posts_to_add' ) );

		add_action( 'wp_ajax_get_post_taxonomies', array( 'BRS_Shortcodes_VCParams', 'get_post_taxonomies' ) );
		add_action( 'wp_ajax_get_post_terms', array( 'BRS_Shortcodes_VCParams', 'get_post_terms' ) );
		add_action( 'wp_ajax_brk_pagination', 'brk_shortcode_pagination_ajax' );
		add_action( 'wp_ajax_nopriv_brk_pagination', 'brk_shortcode_pagination_ajax' );

		add_action('wp_ajax_add_gallery_item', array('Berserk_Gallery', 'add_gallery_item'));

		add_action( 'wp_ajax_product_filter', array( 'BRS_Woocommerce', 'product_filter' ) );
		add_action( 'wp_ajax_nopriv_product_filter', array( 'BRS_Woocommerce', 'product_filter' ) );

		add_action( 'wp_ajax_brs_woo_get_variable_id', array( 'BRS_Woocommerce', 'brs_woo_get_variable_id' ) );
		add_action( 'wp_ajax_nopriv_brs_woo_get_variable_id', array( 'BRS_Woocommerce', 'brs_woo_get_variable_id' ) );

		add_action( 'wp_ajax_product_remove', array('BRS_Woocommerce', 'warp_ajax_product_remove'));
		add_action( 'wp_ajax_nopriv_product_remove', array('BRS_Woocommerce', 'warp_ajax_product_remove'));

		add_action( 'wp_ajax_cart_add_product_quantity', array('BRS_Woocommerce', 'cart_add_product_quantity'));
		add_action( 'wp_ajax_nopriv_cart_add_product_quantity', array('BRS_Woocommerce', 'cart_add_product_quantity'));

	}

	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		load_plugin_textdomain( 'berserk_shortcodes', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
	}


	/**
	 * [includes description]
	 * @method includes
	 *
	 * @return [type]   [description]
	 */
	public function includes() {

		include_once $this->plugin_dir() . '/extensions/core-functions.php';
		include_once $this->plugin_dir() . '/extensions/options-framework/options-framework.php';
		include_once $this->plugin_dir() . '/extensions/class-presscore-template-manager.php';
		include_once $this->plugin_dir() . '/extensions/brs_templates/brs_templates.php';
		include_once $this->plugin_dir() . '/extensions/brs_staff/brs_staff.php';
		include_once $this->plugin_dir() . '/extensions/brs_faq/brs_faq.php';
		include_once $this->plugin_dir() . '/extensions/brs_testimonials/brs_testimonials.php';
		include_once $this->plugin_dir() . '/extensions/brs_portfolio/brs_portfolio.php';
		include_once $this->plugin_dir() . '/extensions/brs_header/brs_header.php';
		include_once $this->plugin_dir() . '/extensions/brs_footer/brs_footer.php';
		include_once $this->plugin_dir() . '/extensions/brs_gallery/brs_gallery.php';
		include_once $this->plugin_dir() . '/extensions/brs_woocommerce/woocommerce-functions.php';
		include_once $this->plugin_dir() . '/extensions/brs_forum/brs_forum.php';
		include_once $this->plugin_dir() . '/extensions/brs_post_format/brs_post_format.php';

		//include_once $this->plugin_dir() . '/shortcodes/vc-extensions.php';
		require_once $this->plugin_dir() . '/shortcodes/shortcodes-helpers.php';
		require_once $this->plugin_dir() . '/shortcodes/brk-shortcodes.php';

		include_once $this->plugin_dir() . '/mods/compatibility/compatibility.php';
		//require_once $this->plugin_dir() . '/mods/compatibility/class-compatibility-vc.php';

		include_once $this->plugin_dir() . '/helpers/main-helpers.php';
		include_once $this->plugin_dir() . '/helpers/sanitize-functions.php';
		include_once $this->plugin_dir() . '/classes/font.php';
		include_once $this->plugin_dir() . '/classes/Send_Mail.php';
		include_once $this->plugin_dir() . '/shortcodes/load-shortcodes.php';
		include_once $this->plugin_dir() . '/functions/mega-menu/mega-menu.php';
	}


	public function activate_theme_notice() {

		?>
		<div class="updated not-h2">
			<p>
				<strong><?php esc_html_e( 'Please activate the Berserk theme to use Berserk Shortcodes plugin.', 'infinite-addons' ); ?></strong>
			</p>
			<?php
			$screen = get_current_screen();
			if ( $screen->base != 'themes' ):
				?>
				<p>
					<a href="<?php echo esc_url( admin_url( 'themes.php' ) ); ?>"><?php esc_html_e( 'Activate theme', 'infinite-addons' ); ?></a>
				</p>
			<?php endif; ?>
		</div>
		<?php
	}


	/**
	 * Plugin activation
	 */
	public static function activate() {
		flush_rewrite_rules();
	}

	/**
	 * Plugin deactivation
	 */
	public static function deactivate() {
		flush_rewrite_rules();
	}

	public function plugin_uri() {
		return plugin_dir_url( __FILE__ );
	}

	public function plugin_dir() {
		return BERSERK_SHORTCODES_PATH;
	}

	public function add_action( $hook, $function_to_add, $priority = 10, $accepted_args = 1 ) {
		add_action( $hook, array( &$this, $function_to_add ), $priority, $accepted_args );
	}

	public function add_filter( $tag, $function_to_add, $priority = 10, $accepted_args = 1 ) {
		add_filter( $tag, array( &$this, $function_to_add ), $priority, $accepted_args );
	}

	public function wp_kses_allowed_html( $tags, $context ) {

		if ( 'post' !== $context ) {
			return $tags;
		}

		$tags['style'] = array( 'types' => array() );

		return $tags;
	}
}

/**
 * Main instance of Berserk Theme.
 *
 * Returns the main instance of Berserk Theme to prevent the need to use globals.
 *
 * @return Berdserk Theme
 */
function berserk_shortcodes() {
	return Berserk_Shortcodes::instance();
}

berserk_shortcodes(); // init

register_activation_hook( __FILE__, array( 'Berserk_Shortcodes', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'Berserk_Shortcodes', 'deactivate' ) );
