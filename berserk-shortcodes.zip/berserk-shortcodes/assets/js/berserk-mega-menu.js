/**
 * Berserk Administration Navigation Menu
 */

( function( $ ) {
	'use strict';
	
	var api,
		menu;

	api  = wpNavMenu;
	menu = $('#menu-to-edit');
	//console.log(wpNavMenu); //addMenuItemToTop
	
	/**
	 * Disable Sortable Column
	 */
	menu.on( 'sortcreate', function( event, ui ) {
		//menu.sortable( 'option', { cancel: '.menu-item-mega_menu_column' } );
	} );
	
	// Remove children on remove parent
	$( menu ).on( 'click', '.submitdelete', function( event ){
		console.log($(this));
		var parent   = $(this).parents('.menu-item-mega_menu_item');
		var children = parent.nextUntil('.menu-item-depth-0');
		api.removeMenuItem( children );
	});
	
	// Toggle parent axis: y, false
	/*$('.menu-item-mega_menu_item').on('mousedown', function( event ){
		menu.sortable( 'option', { axis:'y' } );
		$(this).on('mouseup', function( event ){
			menu.sortable( 'option', { axis: false } );
		});
	});	
	*/
	
	/*
	menu.on( 'sortstop', function( event, ui ) {
		var uiItem = ui.item;
		if($( uiItem ).hasClass('menu-item-mega_menu_item')){
			var dept = uiItem.menuItemDepth()
			uiItem.shiftHorizontally( -dept );
			console.log(dept);
		}
	} );
	*/
	
	$('.submit-add-to-mega-menu').on('click',function( e ){
		e.preventDefault();
		//api.removeMenuItem( $('#menu-item-3425') );
	});
	
	/**
	
	api.addMenuItemToMegaMenu = function( menuMarkup ) {
		var $menuMarkup = $( menuMarkup );
		$menuMarkup.hideAdvancedMenuItemFields().insertAfter('#menu-item-3419');
		api.refreshKeyboardAccessibility();
		api.refreshAdvancedAccessibility();
		$( document ).trigger( 'menu-item-added', [ $menuMarkup ] );
	};
	
	$('.submit-custom-mega-menu').on('click',function( e ){
		e.preventDefault();
		$('#megamenudiv').addSelectedToMenu( api.addMenuItemToMegaMenu );
		uiItem.shiftHorizontally( -dept );
		//api.removeMenuItem( $('#menu-item-3425') );
	});
	
	*/
	
	


	
	
	
	/* ======================================= */
	/* Global info */
	/*
	// remove menu item by id
	api.removeMenuItem( $('#menu-item-3425') );
	// move horizintaly on dept 1,
	$('#menu-item-3425').shiftHorizontally(1); // -1
	// get current dept 
	$('#menu-item-3425').menuItemDepth()
	*/
	

})( jQuery );