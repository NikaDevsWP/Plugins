<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit();
}
if ( ! class_exists( 'Berserk_Portfolio' ) ) {

	class Berserk_Portfolio {
		protected static $post_type = 'brs_portfolio';
		static protected $instance;

		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new Berserk_Portfolio();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_action( 'init', array( $this, 'init' ) );
			add_action( 'add_meta_boxes', array( $this, 'init_meta_boxes' ) );
			add_action( 'save_post', array( $this, "save_post" ) );
		}

		public function init() {
			$this->createPostType();
		}

		public static function postType() {
			return self::$post_type;
		}

		function createPostType() {
			/*
			register_taxonomy( "skills", array( self::postType() ), array(
				"hierarchical"  => true,
				"labels"        => array(
					'name'               => __( 'Skills', 'berserk' ),
					'singular_name'      => __( 'Skill', 'berserk' ),
					'add_new'            => __( 'Add New', 'berserk' ),
					'add_new_item'       => __( 'Add New Skill', 'berserk' ),
					'edit_item'          => __( 'Edit Skill', 'berserk' ),
					'new_item'           => __( 'New Skill', 'berserk' ),
					'view_item'          => __( 'View Skill', 'berserk' ),
					'search_items'       => __( 'Search Skills', 'berserk' ),
					'not_found'          => __( 'No Skills found', 'berserk' ),
					'not_found_in_trash' => __( 'No Skills found in Trash', 'berserk' ),
					'parent_item_colon'  => ''
				),
				"show_tagcloud" => true,
				'query_var'     => true,
				'rewrite'       => true,
				'show_in_menu'  => true,
				'capabilities'  => array( 'manage_terms' ),
				'show_ui'       => true
			) );
			*/
			register_taxonomy( "folio-category", array( self::postType() ), array(
				"hierarchical"  => true,
				"labels"        => array(
					'name'               => __( 'Portfolio Categories', 'berserk' ),
					'singular_name'      => __( 'Category', 'berserk' ),
					'add_new'            => __( 'Add New', 'berserk' ),
					'add_new_item'       => __( 'Add New Category', 'berserk' ),
					'edit_item'          => __( 'Edit Category', 'berserk' ),
					'new_item'           => __( 'New Category', 'berserk' ),
					'view_item'          => __( 'View Category', 'berserk' ),
					'search_items'       => __( 'Search Categories', 'berserk' ),
					'not_found'          => __( 'No Categories found', 'berserk' ),
					'not_found_in_trash' => __( 'No Categories found in Trash', 'berserk' ),
					'parent_item_colon'  => ''
				),
				"show_tagcloud" => true,
				'query_var'     => true,
				'rewrite'       => true,
				'show_in_menu'  => true,
				'capabilities'  => array( 'manage_terms' ),
				'show_ui'       => true
			) );


			register_post_type( self::postType(), array(
				'labels'              => self::getPostTypesLabels(),
				'public'              => true,
				'archive'             => true,
				'exclude_from_search' => false,
				'publicly_queryable'  => true,
				'show_ui'             => true,
				'query_var'           => true,
				'capability_type'     => 'post',
				'map_meta_cap'        => true,
				'has_archive'         => true,
				'hierarchical'        => true,
				'menu_position'       => null,
				'supports'            => array(
					'title',
					'editor',
					'thumbnail',
					'excerpt',
					'tags',
					//'comments',
					'post-formats'
				),
				'rewrite'             => array( 'slug' => self::postType() ),
				'show_in_admin_bar'   => true,
				'show_in_menu'        => true,
				'taxonomies'          => array( 'folio-category' ),
				'menu_icon'           => 'dashicons-portfolio'
			) );

		}

		public static function getPostTypesLabels() {
			return array(
				'name'               => __( 'Portfolios', 'berserk' ),
				'singular_name'      => __( 'Portfolio', 'berserk' ),
				'add_new'            => __( 'Add New', 'berserk' ),
				'add_new_item'       => __( 'Add New Portfolio', 'berserk' ),
				'edit_item'          => __( 'Edit Portfolio', 'berserk' ),
				'new_item'           => __( 'New Portfolio', 'berserk' ),
				'view_item'          => __( 'View Portfolio', 'berserk' ),
				'search_items'       => __( 'Search Portfolios', 'berserk' ),
				'not_found'          => __( 'No Portfolios found', 'berserk' ),
				'not_found_in_trash' => __( 'No Portfolios found in Trash', 'berserk' ),
				'parent_item_colon'  => ''
			);
		}

		public static function postMeta() {
			$meta = array(
				'email'     => array(
					'label'  => 'Email',
					'group'  => 'socials',
					'icon'   => 'email',
					'prefix' => 'mailto:',
					'type'  => 'text'
				),
				'instagram' => array(
					'label' => 'Instagram',
					'group' => 'socials',
					'icon'  => 'instagram',
					'type'  => 'text'
				),
				'google'    => array(
					'label' => 'Google',
					'group' => 'socials',
					'icon'  => 'google-plus',
					'type'  => 'text'
				),
				'youtube'   => array(
					'label' => 'Youtube',
					'group' => 'socials',
					'icon'  => 'youtube',
					'type'  => 'text'
				),
				'vimeo'     => array(
					'label' => 'Vimeo',
					'group' => 'socials',
					'icon'  => 'vimeo',
					'type'  => 'text'
				),
				'vk'        => array(
					'label' => 'Vk',
					'group' => 'socials',
					'icon'  => 'vk',
					'type'  => 'text'
				),
				'linkedin'  => array(
					'label' => 'LinkedIn',
					'group' => 'socials',
					'icon'  => 'linkedin',
					'type'  => 'text'
				),
				'dribbble'  => array(
					'label' => 'Dribbble',
					'group' => 'socials',
					'icon'  => 'dribbble',
					'type'  => 'text'
				),
				'skype'     => array(
					'label' => 'Skype',
					'group' => 'socials',
					'icon'  => 'skype',
					'pefix' => 'skype:',
					'type'  => 'text'
				),
				'phone'     => array(
					'label' => 'Phone',
					'group' => 'socials',
					'icon'  => 'phone',
					'pefix' => 'tel:',
					'type'  => 'text'
				),
			);

			return $meta;
		}

		public static function get_folio_article( $id, $folio_type, $pagination_type = '', $folio_columns='', $folio_type_layout ) {

			$post_format = get_post_format( $id ) ? get_post_format( $id ) : 'standard';
			include( locate_template( 'templates/template-parts/portfolio/portfolio-' . $folio_type . '.php' ) );

		}

		public static function portfolio_year_filter() {
			$min_year   = $_REQUEST['min_year'];
			$max_year   = $_REQUEST['max_year'];
			$folio_type = $_REQUEST['folio_type'];

			$posts = array();

			$post_type = self::postType();

			$args = array(
				'post_type'      => $post_type,
				'posts_per_page' => '-1'
			);

			$args['meta_query'] = array(
				array(
					'key'     => 'folio-date',
					'compare' => 'EXISTS'
				),
			);
			$query              = new WP_Query( $args );
			$found_posts        = $query->posts;

			foreach ( $found_posts as $post ) {
				$year = '';
				$date = get_post_meta( $post->ID, "folio-date", true );
				if ( ! empty( $date ) ) {
					$year = explode( '/', $date );
					$year = $year['2'];
				}

				if ( $year <= $max_year && $year >= $min_year ) {
					$posts[] = $post;
				}
			}

			$html     = '';
			$response = array();

			foreach ( $posts as $post ) {
				ob_start();
				Berserk_Portfolio::get_folio_article( $post->ID, $folio_type );
				$html .= ob_get_clean();
			}

			$response['html'] = $html;
			wp_die( json_encode( $response ) );

			//dpm( $posts );
			die();
		}

		public static function get_folio_categories() {
			$categories = array();

			return $categories;
		}

		public static function get_meta_data( $post_id ) {
			$data   = array();
			$custom = get_post_custom( $post_id );

			$meta = self::postMeta();
			foreach ( $meta as $key => $field ) {
				$data[ $key ] = @$custom[ $key ][0];
			}

			return $data;
		}

		public static function init_meta_boxes() {
			add_meta_box( "credits_meta", esc_html__( 'Portfolio social links', 'berserk' ), array(
				__CLASS__,
				'credits_meta'
			), self::postType(), "normal", "low" );
		}

		public static function credits_meta() {
			global $post;

			$data['meta'] = self::get_meta_data( $post->ID );
			$data['options'] = self::postMeta();

			echo BRS_Options_Framework::draw_html( 'views/credits_meta', $data );
		}

		public static function save_post() {
			global $post;
			if ( is_object( $post ) ) {
				if ( isset( $_POST ) AND ! empty( $_POST ) AND $post->post_type == self::postType() ) {
					$meta = self::postMeta();
					foreach ( $meta as $key => $field ) {
						update_post_meta( $post->ID, $key, @$_POST[ $key ] );
					}
				}
			}
		}


	}

	Berserk_Portfolio::get_instance();
}
