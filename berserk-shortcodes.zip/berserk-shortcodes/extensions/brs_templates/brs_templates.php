<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit();
}
if ( ! class_exists( 'BRS_Templates' ) ) {

	class BRS_Templates {
		protected static $post_type = 'brs_templates';
		static protected $instance;
		protected static $template_type = 'brs_templates';

		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Templates();
			}

			return self::$instance;
		}

		protected function __construct() {

			add_action( 'init', array( $this, 'init' ) );
		}

		public function init() {
			$this->registerTaxonomy();
			$this->createPostType();
			$this->migrate_templates();

			if ( $this->isValidPostType() ) {
				$pt_array = get_option( 'wpb_js_content_types' );
				if ( ! is_array( $pt_array ) || empty( $pt_array ) ) {
					$pt_array = array(
						self::postType(),
						'page',
					);
					update_option( 'wpb_js_content_types', $pt_array );
				} elseif ( ! in_array( self::postType(), $pt_array ) ) {
					$pt_array[] = self::postType();
					update_option( 'wpb_js_content_types', $pt_array );
				}
				vc_set_default_editor_post_types( array(
					'page',
					'brs_templates',
				) );
				vc_editor_set_post_types( vc_editor_post_types() + array( 'brs_templates' ) );

				add_filter( 'vc_role_access_with_post_types_get_state', '__return_true' );
				add_filter( 'vc_role_access_with_backend_editor_get_state', '__return_true' );
				add_filter( 'vc_role_access_with_frontend_editor_get_state', '__return_true' );
				add_filter( 'vc_check_post_type_validation', '__return_true' );
			}

			add_filter( 'vc_get_all_templates', array(
				$this,
				'brs_addTemplatesTab',
			), 1, 1 );

			add_action( 'vc_frontend_editor_enqueue_js_css', array(
				$this,
				'assetsFe',
			) );
			add_action( 'vc_backend_editor_enqueue_js_css', array(
				$this,
				'assetsBe',
			) );

			add_filter( 'vc_templates_render_category', array(
				$this,
				'brs_renderTemplateBlock',
			), 1 );

			add_filter( 'vc_templates_render_template', array(
				$this,
				'renderTemplateWindow',
			), 1, 2 );

			add_action( 'wp_ajax_vc_brs_save_template', array(
				$this,
				'saveTemplate',
			) );

			add_action( 'wp_ajax_vc_brs_backend_load_template', array(
				$this,
				'renderBackendTemplate',
			) );


		}

		public static function postType() {
			return self::$post_type;
		}

		public function assetsFe() {
			if ( $this->isValidPostType() && ( vc_user_access()->part( 'frontend_editor' )->can()->get() ) ) {
				//$this->addGridScripts();
				$dependency = array( 'vc-frontend-editor-min-js' );
				wp_register_script( 'vc_plugin_inline_templates', BERSERK_SHORTCODES_URL . '/extensions/brs_templates/assets/js/templates_panels.js', $dependency, WPB_VC_VERSION, true );
				wp_localize_script( 'vc_plugin_templates', 'VcTemplateI18nLocale', array(
					'please_enter_templates_name' => __( 'Please enter template name', 'brs_templates' ),
				) );

				wp_enqueue_style( 'vc_plugin_template_css' );
				$this->addTemplateraJs();
			}
		}

		public function assetsBe() {
			if ( $this->isValidPostType() && ( vc_user_access()->part( 'backend_editor' )->can()->get() || $this->isSamePostType() ) ) {
				//$this->addGridScripts();
				$dependency = array( 'vc-backend-min-js' );
				wp_register_script( 'vc_plugin_inline_templates', BERSERK_SHORTCODES_URL . '/extensions/brs_templates/assets/js/templates_panels.js', $dependency, WPB_VC_VERSION, true );
				wp_localize_script( 'vc_plugin_templates', 'VcTemplateI18nLocale', array(
					'please_enter_templates_name' => __( 'Please enter template name', 'brs_templates' ),
				) );

				wp_enqueue_style( 'vc_plugin_template_css' );
				$this->addTemplateraJs();
			}
		}


		function registerTaxonomy() {
			register_taxonomy( "templates_category", 'post', array(
				"hierarchical"      => true,
				"labels"            => array(
					'name'               => __( 'Template Category', 'berserk' ),
					'singular_name'      => __( 'Template Category', 'berserk' ),
					'add_new'            => __( 'Add New', 'berserk' ),
					'add_new_item'       => __( 'Add New Template Category', 'berserk' ),
					'edit_item'          => __( 'Edit Template Category', 'berserk' ),
					'new_item'           => __( 'New Template Category', 'berserk' ),
					'view_item'          => __( 'View Template Category', 'berserk' ),
					'search_items'       => __( 'Search Templates Category', 'berserk' ),
					'not_found'          => __( 'No Templates Category found', 'berserk' ),
					'not_found_in_trash' => __( 'No Templates Category found in Trash', 'berserk' ),
					'parent_item_colon'  => ''
				),
				"show_tagcloud"     => true,
				'query_var'         => true,
				'rewrite'           => true,
				'show_in_nav_menus' => false,
				'capabilities'      => array( 'manage_terms' ),
				'show_ui'           => true
			) );
		}

		function createPostType() {
			register_post_type( self::postType(), array(
				'labels'              => self::getPostTypesLabels(),
				'public'              => false,
				'has_archive'         => false,
				'show_in_nav_menus'   => true,
				'exclude_from_search' => true,
				'publicly_queryable'  => false,
				'show_ui'             => true,
				'query_var'           => true,
				'capability_type'     => 'post',
				'hierarchical'        => false,
				'menu_position'       => null,
				'show_in_menu'        => true,
				'supports'            => array( 'title', 'editor', 'thumbnail' ),
				'taxonomies'          => array( 'templates_category' ),

			) );
		}

		public static function getPostTypesLabels() {
			return array(
				'add_new_item'       => __( 'Add template', 'brs_templates' ),
				'name'               => __( 'Templates', 'brs_templates' ),
				'singular_name'      => __( 'Template', 'brs_templates' ),
				'edit_item'          => __( 'Edit Template', 'brs_templates' ),
				'view_item'          => __( 'View Template', 'brs_templates' ),
				'search_items'       => __( 'Search Templates', 'brs_templates' ),
				'not_found'          => __( 'No Templates found', 'brs_templates' ),
				'not_found_in_trash' => __( 'No Templates found in Trash', 'brs_templates' ),
			);
		}

		public static function migrate_templates() {
			$migrated = get_option( 'brs_migrate_templates' );
			if ( 'yes' !== $migrated ) {
				$templates = (array) get_option( 'wpb_js_templates' );
				foreach ( $templates as $template ) {
					self::create( $template['name'], $template['template'] );
				}
				update_option( 'brs_migrate_templates', 'yes' );
			}
		}

		public function brs_addTemplatesTab( $data ) {

			$newCategory = array(
				'category'        => 'brs_templates',
				'category_name'   => __( 'Berserk Templates', 'js_composer' ),
				'category_weight' => 1,
				'templates'       => $this->getTemplates(),
			);
			$data[]      = $newCategory;

			return $data;
		}

		public function brs_renderTemplateBlock( $category ) {
			if ( 'brs_templates' === $category['category'] ) {

				$category['output'] = '<div class="vc_col-md-2 brs-sorting-container">';
				$category['output'] .= $this->get_template_categories();
				$category['output'] .= '</div>';
				$category['output'] .= '
					<div class="vc_column vc_col-sm-12 brs-templates-container">
						<div class="vc_ui-template-list vc_templates-list-default_templates vc_ui-list-bar" data-vc-action="collapseAll" data-ref="mixitup-container">';
				if ( ! empty( $category['templates'] ) ) {
					foreach ( $category['templates'] as $template ) {
						$category['output'] .= $this->renderTemplateListItem( $template );
					}
				}
				$category['output'] .= '
					</div>
				</div>';
			}

			return $category;
		}

		protected function get_template_categories() {
			$output = '';

			$args  = array(
				'taxonomy'   => 'templates_category',
				'hide_empty' => false,
			);
			$terms = get_terms( $args );

			$output .= '<div class="sortable_templates">';
			$output .= '<ul>';
			$i = 0;

			$count_posts = wp_count_posts( self::postType() )->publish;

			$first_term        = new stdClass();
			$first_term->slug  = 'all';
			$first_term->name  = 'All';
			$first_term->count = $count_posts;

			array_unshift( $terms, $first_term );

			foreach ( $terms as $key => $value ) {
				$i ++;
				$active = ( $i == 1 ) ? 'class="active"' : '';
				$slug   = $value->slug;
				if ( $slug != 'all' ) {
					$slug = '.' . $slug;
				}
				$output .= '<li ' . $active . ' data-filter="' . $slug . '">' . $value->name . ' <span class="count">' . $value->count . '</span></li>';
			}
			$output .= '</ul>';
			$output .= '</div>';

			return $output;

		}

		public function getTemplates() {
			$posts     = get_posts( 'post_type=' . $this->postType() . '&numberposts=-1' );
			$templates = array();
			if ( ! empty( $posts ) ) {
				foreach ( $posts as $post ) {
					$id                  = get_post_meta( $post->ID, '_' . $this->postType() . '-id', true );
					$template            = array();
					$template['title']   = $post->post_title;
					$template['version'] = get_post_meta( $post->ID, '_' . $this->postType() . '-version', true );
					$template['id']      = $id;
					$template['post_id'] = $post->ID;
					$template['name']    = $post->post_title;
					$template['type']    = 'brs_templates';
					//$template['unique_id'] = $id;
					$template['unique_id'] = $post->ID;
					$template['image']     = get_the_post_thumbnail_url( $post->ID, 'full' );
					$templates[]           = $template;
				}
			}

			return $templates;
		}

		function renderTemplateWindow( $template_name, $template_data ) {

			if ( 'brs_templates' === $template_data['type'] ) {
				return $this->renderTemplateWindowBrsTemplates( $template_name, $template_data );
			}

			return $template_name;
		}

		public function renderTemplateWindowBrsTemplates( $template_name, $template_data ) {
			ob_start();
			$template_id            = esc_attr( $template_data['unique_id'] );
			$template_id_hash       = md5( $template_id ); // needed for jquery target for TTA
			$template_name          = esc_html( $template_name );
			$preview_template_title = esc_attr( 'Preview template', 'berserk' );
			$add_template_title     = esc_attr( 'Add template', 'berserk' );

			echo <<<HTML
		<button type="button" class="vc_ui-list-bar-item-trigger" title="$add_template_title"
			data-template-handler=""
			data-vc-ui-element="template-title">$template_name</button>
		<div class="vc_ui-list-bar-item-actions">
			<button type="button" class="vc_general vc_ui-control-button" title="$add_template_title"
					data-template-handler="">
				<i class="vc-composer-icon vc-c-icon-add"></i>
			</button>
		</div>
HTML;

			return ob_get_clean();
		}


		public function renderTemplateListItem( $template ) {
			$name                = isset( $template['name'] ) ? esc_html( $template['name'] ) : esc_html( __( 'No title', 'berserk' ) );
			$template_id         = esc_attr( $template['unique_id'] );
			$template_id_hash    = md5( $template_id ); // needed for jquery target for TTA
			$template_name       = esc_html( $name );
			$template_name_lower = esc_attr( vc_slugify( $template_name ) );
			$template_type       = esc_attr( isset( $template['type'] ) ? $template['type'] : 'custom' );
			//$custom_class        = esc_attr( isset( $template['custom_class'] ) ? $template['custom_class'] : '' );
			$terms        = get_the_terms( $template_id, 'templates_category' );
			$custom_class = array();
			if ( $terms ) {
				foreach ( $terms as $term ) {
					$custom_class[] = $term->slug;
				}
			}
			$custom_class = implode( ' ', $custom_class );

			//echo "<pre>";
			//print_r($custom_class);
			//echo "</pre>";
			$template_image     = esc_attr( isset( $template['image'] ) ? $template['image'] : '' );
			$template_sort_name = esc_attr( isset( $template['sort_name'] ) ? $template['sort_name'] : '' );

			$output = <<<HTML
					<div class="vc_ui-template vc_templates-template-type-default_templates $custom_class"
						data-ref="mixitup-target"
						data-template_id="$template_id"
						data-template_id_hash="$template_id_hash"
						data-category="$template_type"
						data-template_unique_id="$template_id"
						data-template_name="$template_name_lower"
						data-template_type="default_templates"
						data-vc-content=".vc_ui-template-content">
						<div class="vc_ui-list-bar-item">
HTML;
			$output .= '<div class="brs-template-preview"><img src="' . $template_image . '" alt="' . esc_attr( $name ) . '" width="300" height="200" /></div>';
			$output .= apply_filters( 'vc_templates_render_template', $name, $template );
			$output .= '<span class="brs-template-categories">' . esc_html( $template_sort_name ) . '</span>';
			$output .= <<<HTML
						</div>
						<div class="vc_ui-template-content" data-js-content>
						</div>
					</div>
HTML;

			return $output;
		}

		public function renderBackendTemplate() {

			$template_id   = vc_post_param( 'template_unique_id' );
			$template_type = vc_post_param( 'template_type' );

			if ( ! isset( $template_id, $template_type ) || '' === $template_id || '' === $template_type ) {
				die( 'Error: Vc_BRS_Templates::renderBackendTemplate:1' );
			}
			WPBMap::addAllMappedShortcodes();
			$this->getBackendDefaultTemplate();
			die();
		}

		public function getBackendDefaultTemplate( $return = false ) {

			$template_index = (int) vc_request_param( 'template_unique_id' );

			$data = get_post( $template_index );

			if ( ! $data ) {
				die( 'Error: Vc_Templates_Panel_Editor::getBackendDefaultTemplate:1' );
			}
			if ( $return ) {
				return trim( $data->post_content );
			} else {
				echo trim( $data->post_content );
				die();
			}
		}

		protected static function create( $title, $content ) {
			return wp_insert_post( array(
				'post_title'   => $title,
				'post_content' => $content,
				'post_status'  => 'publish',
				'post_type'    => self::postType(),
			) );
		}

		public function saveTemplate() {
			if ( ! vc_verify_admin_nonce() || ( ! current_user_can( 'edit_posts' ) && ! current_user_can( 'edit_pages' ) ) ) {
				die();
			}
			$title          = vc_post_param( 'template_name' );
			$content        = vc_post_param( 'template' );
			$template_id    = $this->create( $title, $content );
			$template_title = get_the_title( $template_id );

			echo visual_composer()->templatesPanelEditor()->renderTemplateListItem( array(
				'name'      => $template_title,
				'unique_id' => $template_id,
				//'type' => self::$template_type,
				'type'      => 'my_templates',
			) );

			die();
		}

		public function isValidPostType() {
			$type            = get_post_type();
			$post            = ( isset( $_GET['post'] ) && $this->compareType( get_post_type( $_GET['post'] ) ) );
			$post_type       = ( isset( $_GET['post_type'] ) && $this->compareType( $_GET['post_type'] ) );
			$post_type_id    = ( isset( $_GET['post_id'] ) && $this->compareType( get_post_type( (int) $_GET['post_id'] ) ) );
			$post_vc_type_id = ( isset( $_GET['vc_post_id'] ) && $this->compareType( get_post_type( (int) $_GET['vc_post_id'] ) ) );

			return ( ( $type && $this->compareType( $type ) ) || ( $post ) || ( $post_type ) || ( $post_type_id ) || ( $post_vc_type_id ) );
		}

		public function compareType( $type ) {
			return in_array( $type, array_merge( vc_editor_post_types(), array( 'brs_templates' ) ) );
		}


		public function addTemplateraJs() {
			wp_enqueue_script( 'vc_plugin_inline_templates' );
		}
	}

	BRS_Templates::get_instance();
}
