<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit();
}
if ( ! class_exists( 'Berserk_Header' ) ) {

	class Berserk_Header {
		protected static $post_type = 'brs_header';
		static protected $instance;

		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new Berserk_Header();
			}

			return self::$instance;
		}

		protected function __construct() {
			//add_action( 'init', array( $this, 'init' ) );
			add_action( 'after_setup_theme', array( $this, 'init' ) );
			//add_action( 'brk_header_setup', array( $this, 'init' ) );
		}

		public function init() {
			$this->createPostType();
		}

		public static function postType() {
			return self::$post_type;
		}

		function createPostType() {

			register_post_type( self::postType(), array(
				'labels'              => self::getPostTypesLabels(),
				'public'              => true,
				'archive'             => true,
				'exclude_from_search' => false,
				'publicly_queryable'  => true,
				'show_ui'             => true,
				'query_var'           => true,
				'capability_type'     => 'post',
				'map_meta_cap'        => true,
				'has_archive'         => false,
				'hierarchical'        => false,
				'menu_position'       => null,
				'supports'            => array('title', 'editor', 'thumbnail', 'post-formats'),
				'rewrite'             => array( 'slug' => self::postType() ),
				'show_in_admin_bar'   => true,
				'show_in_menu'        => true,
				'show_in_nav_menus'   => false,
				'menu_icon'           => 'dashicons-editor-alignleft'
			) );

		}

		public static function getPostTypesLabels() {
			return array(
				'name'               => __( 'Headers', 'berserk' ),
				'singular_name'      => __( 'Header', 'berserk' ),
				'add_new'            => __( 'Add New', 'berserk' ),
				'add_new_item'       => __( 'Add New Header', 'berserk' ),
				'edit_item'          => __( 'Edit Header', 'berserk' ),
				'new_item'           => __( 'New Header', 'berserk' ),
				'view_item'          => __( 'View Header', 'berserk' ),
				'search_items'       => __( 'Search Headers', 'berserk' ),
				'not_found'          => __( 'No Headers found', 'berserk' ),
				'not_found_in_trash' => __( 'No Headers found in Trash', 'berserk' ),
				'parent_item_colon'  => ''
			);
		}

	}

	Berserk_Header::get_instance();
}
