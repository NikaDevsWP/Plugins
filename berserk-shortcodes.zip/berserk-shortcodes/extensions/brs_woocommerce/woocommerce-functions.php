<?php

class BRS_Woocommerce {
	static protected $instance;
	protected static $post_type = 'product';

	public static function get_instance() {

		if ( ! self::$instance ) {
			self::$instance = new BRS_Woocommerce();
		}

		return self::$instance;
	}

	public static function postType() {
		return self::$post_type;
	}

	protected function __construct() {
		//add_action( 'admin_init', array( $this, 'register_params' ), 15 );
		add_action( 'init', array( $this, 'custom_taxonomy_type' ) );

		add_action( 'add_meta_boxes', array( $this, 'init_meta_boxes' ) );
		add_action( 'save_post', array( $this, "save_post" ) );

	}

	function custom_taxonomy_type() {
		$labels = array(
			'name'                       => 'Product Label',
			'singular_name'              => 'Label',
			'menu_name'                  => 'Label',
			'all_items'                  => 'All Labels',
			'parent_item'                => 'Parent Label',
			'parent_item_colon'          => 'Parent Label:',
			'new_item_name'              => 'New Label Name',
			'add_new_item'               => 'Add New Label',
			'edit_item'                  => 'Edit Label',
			'update_item'                => 'Update Label',
			'separate_items_with_commas' => 'Separate Label with commas',
			'search_items'               => 'Search Labels',
			'add_or_remove_items'        => 'Add or remove Label',
			'choose_from_most_used'      => 'Choose from the most used Labels',
		);
		$args   = array(
			'labels'            => $labels,
			'hierarchical'      => true,
			'public'            => true,
			'show_ui'           => true,
			'show_admin_column' => true,
			'show_in_nav_menus' => true,
			'show_tagcloud'     => true,
		);
		register_taxonomy( 'brs_product_type', 'product', $args );
		register_taxonomy_for_object_type( 'brs_product_type', 'product' );
	}


	public static function postMeta() {
		$meta = array(
			'product-video-review-link'   => array(
				'label' => esc_html__( 'Video review link', 'berserk' ),
				'type'  => 'text'
			),
		);

		return $meta;
	}

	public static function get_meta_data( $post_id ) {
		$data   = array();
		$custom = get_post_custom( $post_id );

		$meta = self::postMeta();
		foreach ( $meta as $key => $field ) {
			$data[ $key ] = @$custom[ $key ][0];
		}

		return $data;
	}

	public static function init_meta_boxes() {
		add_meta_box( "credits_meta", __( "Products settings", 'berserk' ), array(
			__CLASS__,
			'credits_meta'
		), self::postType(), "normal", "low" );
	}

	public static function credits_meta() {
		global $post;
		$data['meta'] = self::get_meta_data( $post->ID );
		$data['options'] = self::postMeta();
		echo BRS_Options_Framework::draw_html( 'views/credits_meta', $data );
	}

	public static function save_post() {
		global $post;
		if ( is_object( $post ) ) {
			if ( isset( $_POST ) AND ! empty( $_POST ) AND $post->post_type == self::postType() ) {
				$meta = self::postMeta();
				foreach ( $meta as $key => $field ) {
					update_post_meta( $post->ID, $key, @$_POST[ $key ] );
				}
			}
		}
	}


	public static function add_to_wishlist() {
		$id     = $_REQUEST['id'];
		$update = update_post_meta( $id, 'wishlist', 'true' );
		echo $update;
		die();
	}

	public static function remove_from_wishlist() {
		$id     = $_REQUEST['id'];
		$update = update_post_meta( $id, 'wishlist', 'false' );
		echo $update;
		die();
	}

	public static function add_to_compare() {
		$id     = $_REQUEST['id'];
		$update = update_post_meta( $id, 'compare', 'true' );
		echo $update;
		die();
	}

	public static function remove_from_compare() {
		$id     = $_REQUEST['id'];
		$update = update_post_meta( $id, 'compare', 'false' );
		echo $update;
		die();
	}

	public static function get_all_products() {
		$products = wc_get_products( array(
			'status'  => array( 'publish' ),
			'limit'   => - 1,
			'orderby' => array(
				'menu_order' => 'ASC',
				'ID'         => 'DESC',
			),
			'return'  => 'objects',
		) );

		$html = "<ul class='slider_item_list_popup'>";

		foreach ( $products as $product ) {
			$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $product->id ), 'single-post-thumbnail' );
			$html .= '<li data-id="' . $product->id . '" class="slider_item"><div class="gallery_thumb" style="background-image: url(' . $image_url[0] . '); width:185px; height:180px; background-size: cover;"></div>
							<div class="slider_item_title">
					            <h3>' . $product->name . '</h3>
					        </div>
						</li>';
		}
		$html .= "</ul>";
		echo $html;
		die();
	}

	public static function product_filter() {
		$min_price             = ( isset( $_REQUEST['min_price'] ) ) ? $_REQUEST['min_price'] : '';
		$max_price             = ( isset( $_REQUEST['max_price'] ) ) ? $_REQUEST['max_price'] : '';
		$filter_orderby        = ( isset( $_REQUEST['filter_orderby'] ) ) ? $_REQUEST['filter_orderby'] : '';
		$filter_items_per_page = ( isset( $_REQUEST['filter_items_per_page'] ) ) ? $_REQUEST['filter_items_per_page'] : '';
		$filter_category       = ( isset( $_REQUEST['filter_category'] ) ) ? $_REQUEST['filter_category'] : '';
		$filter_color          = ( isset( $_REQUEST['filter_color'] ) ) ? $_REQUEST['filter_color'] : '';
		$filter_brand          = ( isset( $_REQUEST['filter_brand'] ) ) ? $_REQUEST['filter_brand'] : '';

		$atts   = $_POST['atts'];
		$layout = $atts['layout'];

		$response = array();

		$args = array();
		$args = array_merge( $args, berserk_shortcodes_dynamic_filter_process( $atts['filters'], $atts['orderby'], $atts['order_direction'] ) );

		if ( isset( $atts['items_per_page'] ) ) {
			$args['numberposts'] = $atts['items_per_page'];
		}

		if ( ! empty( $min_price ) && ! empty( $max_price ) ) {
			$args['meta_query'] = array(
				array(
					'key'     => '_price',
					'value'   => array( $min_price, $max_price ),
					'compare' => 'BETWEEN',
					'type'    => 'NUMERIC'
				),
			);
		}

		if ( ! empty( $filter_category ) ) {
			if ( $filter_category == 'all' ) {
				$filter_category = array();
				$terms           = get_terms( 'product_cat' );
				foreach ( $terms as $term ) {
					$filter_category[] = $term->slug;
				}
			}
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'product_cat',
					'field'    => 'slug',
					'terms'    => $filter_category
				)
			);
		}

		if ( ! empty( $filter_color ) ) {

			if ( $filter_color == 'all' ) {
				$filter_color = array();
				$terms        = get_terms( 'pa_color' );
				foreach ( $terms as $term ) {
					$filter_color[] = $term->slug;
				}
			}


			$args['tax_query'][] =
				array(
					'taxonomy' => 'pa_color',
					'field'    => 'slug',
					'terms'    => $filter_color

				);

			$args['tax_query']['relation'] = 'OR';
		}

		if ( ! empty( $filter_brand ) ) {

			if ( $filter_brand == 'all' ) {
				$filter_brand = array();
				$terms        = get_terms( 'pa_brand' );
				foreach ( $terms as $term ) {
					$filter_brand[] = $term->slug;
				}
			}

			$args['tax_query'][] =
				array(
					'taxonomy' => 'pa_brand',
					'field'    => 'slug',
					'terms'    => $filter_brand

				);

			$args['tax_query']['relation'] = 'OR';
		}

		if ( ! empty( $filter_orderby ) ) {
			$args['orderby'] = $filter_orderby;
		}
		if ( ! empty( $filter_items_per_page ) ) {
			$args['numberposts'] = $filter_items_per_page;
		}

		$posts = get_posts( $args );

		$posts_count = count( $posts );


		//echo 'posts_count='.$posts_count;

		$posts_html             = self::get_products_output( $posts, $layout );
		$response['posts_html'] = $posts_html;


		//Sitting up new filter values

		$atts['posts_count'] = $posts_count;

		if ( ! empty( $min_price ) && ! empty( $max_price ) ) {

			$atts['filters']['price'] = array(
				'filter_type' => 'price',
				'min_price'   => $min_price,
				'max_price'   => $max_price,
			);
		}

		if ( ! empty( $filter_color ) ) {
			$atts['filters']['color'] = array(
				'filter_type' => 'color',
				'color'       => $filter_color,
			);
			if ( $filter_color == 'all' ) {
				unset( $atts['filters']['color'] );
			}
		}

		if ( ! empty( $filter_brand ) ) {
			$atts['filters']['brand'] = array(
				'filter_type' => 'brand',
				'brand'       => $filter_brand,
			);
			if ( $filter_brand == 'all' ) {
				unset( $atts['filters']['brand'] );
			}
		}


		if ( ! empty( $filter_orderby ) ) {
			$atts['orderby'] = $filter_orderby;
		}

		if ( ! empty( $filter_items_per_page ) ) {
			$atts['items_per_page'] = $filter_items_per_page;
		}

		if ( ! empty( $filter_category ) ) {

			if ( $filter_category == 'all' ) {
				$filter_category = array();
				$terms           = get_terms( 'product_cat' );
				foreach ( $terms as $term ) {
					$filter_category[] = $term->slug;
				}
			}

			$atts['filters']['tax'] = array(
				'filter_type'     => 'taxonomies',
				'taxonomies'      => 'product_cat',
				'taxonomy_values' => $filter_category
			);
		}


		$brk_atts             = berserk_shortcodes_dynamic_filter_data( $atts );
		$response['brk_atts'] = $brk_atts;

		wp_die( json_encode( $response ) );

		die();
	}

	public static function shortcode_woocommerce( $atts ) {
		$args = array();
		$args = array_merge( $args, berserk_shortcodes_dynamic_filter_process( $atts['filters'], $atts['orderby'], $atts['order_direction'] ) );

		//dpm( $args );

		$posts  = get_posts( $args );
		$layout = $atts['layout'];


		$output = '<div class="brk-js-parent">
				<div class="brk-js-append">';

		$output .= self::get_products_output( $posts, $layout );

		$output .= '</div>';

		$output .= '<div class="col-12">
						<div class="text-center mt-110 mb-80">
							<a href="#"
							   class="icon__btn icon__btn-anim icon__btn-md icon__btn-invert brk-shortcode-pagination-ajax"
							   data-shortcode="woocommerce" data-numberposts="' . $atts["items_per_load"] . '">
								<span class="before"></span>
								<i class="fa fa-refresh" aria-hidden="true"></i>
								<span class="after"></span>
								<span class="bg"></span>
							</a>
							' . berserk_shortcodes_dynamic_filter_data( $atts ) . '
						</div>
					</div>';

		$output .= '</div>';

		echo $output;
		die();
	}

	public static function get_products_output( $posts, $layout ) {
		$output = '';

		ob_start();

		foreach ( $posts as $post ) {

			$product = wc_get_product( $post->ID );

			switch ( $layout ) {
				case "grid":
					?>
					<div class="col-12 col-md-6 col-xl-4">
						<?php include( locate_template( 'woocommerce/template-parts/product-grid.php' ) ); ?>
					</div>
					<?php
					break;
				case "list":
					?>
					<div class="col-12">
						<?php include( locate_template( 'woocommerce/template-parts/product-list.php' ) ); ?>
					</div>
					<?php
					break;

			}
		}
		$output = ob_get_clean();


		return $output;
	}

	public static function brs_woo_get_variable_id() {

		$color      = $_REQUEST['color'];
		$size       = $_REQUEST['size'];
		$product_id = $_REQUEST['product_id'];

		$product = wc_get_product( $product_id );

		$available_variations = $product->get_available_variations();

		$variation_id = $product_id;

		foreach ( $available_variations as $variation ) {

			if ( $variation['attributes']['attribute_pa_color'] == $color && $variation['attributes']['attribute_pa_size'] == $size ) {

				$variation_id = $variation['variation_id'];
			}
		}

		echo $variation_id;
		die();
	}

	// Remove product in the cart using ajax
	function warp_ajax_product_remove() {
		// Get mini cart
		ob_start();

		foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
			if ( $cart_item['product_id'] == $_POST['product_id'] && $cart_item_key == $_POST['cart_item_key'] ) {
				WC()->cart->remove_cart_item( $cart_item_key );
			}
		}

		WC()->cart->calculate_totals();
		WC()->cart->maybe_set_cart_cookies();

		woocommerce_mini_cart();

		$mini_cart = ob_get_clean();

		// Fragments and mini cart are returned
		$data = array(
			'fragments'           => apply_filters( 'woocommerce_add_to_cart_fragments', array(
					'div.brk-mini-cart__menu' => '<div class="brk-mini-cart__menu">' . $mini_cart . '</div>'
				)
			),
			'cart_hash'           => apply_filters( 'woocommerce_add_to_cart_hash', WC()->cart->get_cart_for_session() ? md5( json_encode( WC()->cart->get_cart_for_session() ) ) : '', WC()->cart->get_cart_for_session() ),
			'cart_contents_count' => WC()->cart->cart_contents_count
		);

		wp_send_json( $data );

		die();
	}

	function cart_add_product_quantity() {

		global $woocommerce;

		$product_id = $_POST['product_id'];
		$quantity   = $_POST['quantity'];

		//$woocommerce->cart->add_to_cart( $product_id, $quantity );

		// correct quantity
		// Get it's unique ID within the Cart
		$prod_unique_id = $woocommerce->cart->generate_cart_id( $product_id );
		// Remove it from the cart by un-setting it
		unset( $woocommerce->cart->cart_contents[ $prod_unique_id ] );
		$woocommerce->cart->add_to_cart( $product_id, $quantity );

		WC()->cart->calculate_totals();

		$data = array(
			'cart_contents_count' => WC()->cart->cart_contents_count
		);
		wp_send_json( $data );

		die();
	}

}

BRS_Woocommerce::get_instance();

// Edit term page
function brs_product_cat_edit_meta_field( $term ) {

	// put the term ID into a variable
	$t_id = $term->term_id;

	// retrieve the existing value(s) for this meta field. This returns an array
	$term_meta = get_option( "taxonomy_$t_id" ); ?>
	<tr class="form-field">
		<th scope="row" valign="top"><label
				for="term_meta[product_cat_label]"><?php _e( 'Label', 'berserk' ); ?></label></th>
		<td>
			<input type="text" name="term_meta[product_cat_label]" id="term_meta[product_cat_label]"
			       value="<?php echo esc_attr( $term_meta['product_cat_label'] ) ? esc_attr( $term_meta['product_cat_label'] ) : ''; ?>">
			<p class="description"><?php _e( 'Enter a value for this field', 'berserk' ); ?></p>
		</td>
	</tr>
	<?php
}

add_action( 'product_cat_edit_form_fields', 'brs_product_cat_edit_meta_field', 10, 2 );

// Save extra taxonomy fields callback function.
function save_taxonomy_custom_meta( $term_id ) {
	if ( isset( $_POST['term_meta'] ) ) {
		$t_id      = $term_id;
		$term_meta = get_option( "taxonomy_$t_id" );
		$cat_keys  = array_keys( $_POST['term_meta'] );
		foreach ( $cat_keys as $key ) {
			if ( isset ( $_POST['term_meta'][ $key ] ) ) {
				$term_meta[ $key ] = $_POST['term_meta'][ $key ];
			}
		}
		// Save the option array.
		update_option( "taxonomy_$t_id", $term_meta );
	}
}

add_action( 'edited_product_cat', 'save_taxonomy_custom_meta', 10, 2 );
add_action( 'create_product_cat', 'save_taxonomy_custom_meta', 10, 2 );