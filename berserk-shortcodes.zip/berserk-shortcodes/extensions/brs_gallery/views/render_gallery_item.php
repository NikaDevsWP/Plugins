<?php if ( ! defined( 'ABSPATH' ) ) {
	die( 'No direct access allowed' );
} ?>
<?php
$unique_id = uniqid();
?>
<li id="slide_item_<?php echo $unique_id ?>" class="gallery_item"
    style="background-image: url(<?php echo esc_url( $imgurl ) ?>)">

	<input type="hidden" name="<?php echo $key ?>[<?php echo $unique_id ?>][imgurl]"
	       value="<?php echo esc_attr( $imgurl ); ?>"/>

	<a href="#" class="delete_gallery_item" slide-id="<?php echo esc_attr( $unique_id ); ?>"
	   title="<?php esc_attr_e( "Delete Item", 'berserk' ) ?>"><?php esc_html_e( "Delete Item", 'berserk' ); ?></a>

</li>