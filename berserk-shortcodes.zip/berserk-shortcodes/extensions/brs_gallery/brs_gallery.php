<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit();
}
if ( ! class_exists( 'Berserk_Gallery' ) ) {

	class Berserk_Gallery {
		protected static $post_type = 'brs_gallery';
		static protected $instance;

		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new Berserk_Gallery();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_action( 'init', array( $this, 'init' ) );

			add_action( 'add_meta_boxes', array( $this, 'init_meta_boxes' ) );
			add_action( 'save_post', array( $this, "save_post" ) );

			add_filter( "manage_gall_posts_columns", array( __CLASS__, "show_edit_columns" ) );
			add_action( "manage_gall_posts_custom_column", array( __CLASS__, "show_edit_columns_content" ) );
		}

		public function init() {
			$this->createPostType();
		}

		public static function postType() {
			return self::$post_type;
		}

		function createPostType() {

			register_post_type( self::postType(), array(
				'labels'              => self::getPostTypesLabels(),
				'public'              => true,
				'archive'             => true,
				'exclude_from_search' => false,
				'publicly_queryable'  => true,
				'show_ui'             => true,
				'query_var'           => true,
				'capability_type'     => 'post',
				'map_meta_cap'        => true,
				'has_archive'         => true,
				'hierarchical'        => true,
				'menu_position'       => null,
				'supports'            => array(
					'title',
					'editor',
					'thumbnail',
					'excerpt',
					'tags',
					//'comments',
					//'post-formats'
				),
				'rewrite'             => array( 'slug' => self::postType() ),
				'show_in_admin_bar'   => true,
				'show_in_menu'        => true,
				'taxonomies'          => array(),
				'menu_icon'           => 'dashicons-portfolio'
			) );

		}

		public static function getPostTypesLabels() {
			return array(
				'name'               => __( 'Gallerys', 'berserk' ),
				'singular_name'      => __( 'Gallery', 'berserk' ),
				'add_new'            => __( 'Add New', 'berserk' ),
				'add_new_item'       => __( 'Add New Gallery', 'berserk' ),
				'edit_item'          => __( 'Edit Gallery', 'berserk' ),
				'new_item'           => __( 'New Gallery', 'berserk' ),
				'view_item'          => __( 'View Gallery', 'berserk' ),
				'search_items'       => __( 'Search Gallerys', 'berserk' ),
				'not_found'          => __( 'No Gallerys found', 'berserk' ),
				'not_found_in_trash' => __( 'No Gallerys found in Trash', 'berserk' ),
				'parent_item_colon'  => ''
			);
		}

		public static function postMeta() {
			$meta = array(
				'berserk_gallery' => array(
					'type'     => 'gallery',
					'label'    => esc_html__( 'Gallery Slider', 'berserk' ),
					'subtitle' => esc_html__( 'Upload images or add from media library.', 'berserk' ),
				)
			);

			return $meta;
		}

		public static function get_meta_data( $post_id ) {
			$data   = array();
			$custom = get_post_custom( $post_id );

			$meta = self::postMeta();
			foreach ( $meta as $key => $field ) {
				$data[ $key ] = @$custom[ $key ][0];
			}

			return $data;
		}

		public static function init_meta_boxes() {
			add_meta_box( "gallery_meta", __( "Gallery images", 'berserk' ), array(
				__CLASS__,
				'gallery_meta'
			), self::postType(), "normal", "low" );
		}

		/*
		public static function gallery_meta() {
			global $post;
			$data = array();
			$data['brs_gallery'] = get_post_meta($post->ID, 'berserk_gallery', true);
			$data['layout'] = get_post_meta($post->ID, 'layout', true);
			echo self::draw_html('views/credits_meta', $data);
		}*/

		public static function gallery_meta( $post, $metabox ) {
			//$sections = self::get_post_format_meta_boxes();

			$data['meta'] = self::get_meta_data( $post->ID );
			//$data['options'] = $sections[ $metabox['id'] ]['fields'];
			$data['options'] = self::postMeta();

			echo BRS_Options_Framework::draw_html( 'views/credits_meta', $data );
		}

		public static function draw_html( $view, $data = array(), $key ) {
			@extract( $data );
			ob_start();
			include( BERSERK_SHORTCODES_PATH . '/extensions/brs_gallery/' . $view . '.php' );

			return ob_get_clean();
		}

		public static function save_post() {
			global $post;
			if ( is_object( $post ) ) {
				if ( isset( $_POST ) AND ! empty( $_POST ) AND $post->post_type == self::postType() ) {
					$meta = self::postMeta();
					foreach ( $meta as $key => $field ) {
						update_post_meta( $post->ID, $key, @$_POST[ $key ] );
					}


				}
			}
		}

		public static function show_edit_columns_content( $column ) {
			global $post;

			switch ( $column ) {
				case "image":
					echo '<img width="200" alt="" src="' . self::get_post_featured_image( $post->ID, '200*200' ) . '"/>';
					break;
				case "image_count":
					$custom      = get_post_custom( $post->ID );
					$brs_gallery = unserialize( @$custom["berserk_gallery"][0] );
					if ( empty( $brs_gallery ) ) {
						$brs_gallery = array();
					}
					echo count( $brs_gallery );
					break;
			}
		}

		public static function show_edit_columns( $columns ) {
			$columns = array(
				"cb"          => "<input type=\"checkbox\" />",
				"title"       => __( "Title", 'berserk' ),
				"image"       => __( "Cover", 'berserk' ),
				"image_count" => __( "Image count", 'berserk' ),
				"date"        => __( "Date", 'berserk' )
			);

			return $columns;
		}

		public static function get_post_featured_image( $post_id, $alias, $show_cap = true ) {
			$img_src = wp_get_attachment_image_src( get_post_thumbnail_id( $post_id ), 'single-post-thumbnail' );
			$img_src = $img_src[0];

			return $img_src;
		}

		//for ajax
		public static function add_gallery_item() {
			$data           = array();
			$data['imgurl'] = $_REQUEST['imgurl'];
			$key            = $_REQUEST['key'];
			echo self::draw_html( 'views/render_gallery_item', $data, $key );
			exit;
		}

		public static function render_gallery_item( $data, $key ) {
			echo self::draw_html( 'views/render_gallery_item', $data, $key );
		}

	}

	Berserk_Gallery::get_instance();
}
