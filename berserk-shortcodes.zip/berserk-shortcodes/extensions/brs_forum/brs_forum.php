<?php

class BRS_Forum {
	static protected $instance;
	protected static $post_type = 'forum';

	public static function get_instance() {

		if ( ! self::$instance ) {
			self::$instance = new BRS_Forum();
		}

		return self::$instance;
	}

	public static function postType() {
		return self::$post_type;
	}

	protected function __construct() {
		add_action( 'add_meta_boxes', array( $this, 'init_meta_boxes' ) );
		add_action( 'save_post', array( $this, "save_post" ) );

	}

	public static function postMeta() {
		$meta = array(
			'forum-color' => array(
				'label' => esc_html__( 'Forum category color', 'berserk' ),
				'type'=> 'select',
				'options' => array(
					'blue'   => 'blue',
					'green'  => 'green',
					'cyan'   => 'cyan',
					'orange' => 'orange',
					'brown'  => 'brown'
				),

			),
		);

		return $meta;
	}

	public static function get_meta_data( $post_id ) {
		$data   = array();
		$custom = get_post_custom( $post_id );

		$meta = self::postMeta();
		foreach ( $meta as $key => $field ) {
			$data[ $key ] = @$custom[ $key ][0];
		}

		return $data;
	}

	public static function init_meta_boxes() {
		add_meta_box( "credits_meta", __( "Forum settings", 'berserk' ), array(
			__CLASS__,
			'credits_meta'
		), self::postType(), "normal", "low" );
	}

	public static function credits_meta() {
		global $post;
		$data['meta'] = self::get_meta_data( $post->ID );
		$data['options'] = self::postMeta();
		echo BRS_Options_Framework::draw_html( 'views/credits_meta', $data );
	}

	public static function save_post() {
		global $post;
		if ( is_object( $post ) ) {
			if ( isset( $_POST ) AND ! empty( $_POST ) AND $post->post_type == self::postType() ) {
				$meta = self::postMeta();
				foreach ( $meta as $key => $field ) {
					update_post_meta( $post->ID, $key, @$_POST[ $key ] );
				}
			}
		}
	}
}

BRS_Forum::get_instance();