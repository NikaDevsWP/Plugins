<?php

class Berserk_Post_Format {
	protected static $post_types = array( 'post', 'brs_portfolio' );
	static protected $instance;

	public static function get_instance() {
		if ( ! self::$instance ) {
			self::$instance = new Berserk_Post_Format();
		}

		return self::$instance;
	}

	public static function postType() {
		return self::$post_types;
	}

	protected function __construct() {

		add_action( 'add_meta_boxes', array( $this, 'init_meta_boxes' ) );
		add_action( 'save_post', array( $this, "save_post" ) );
		//add_filter( 'postbox_classes_post_'.$key,'add_metabox_classes' );
	}

	public static function get_meta_data( $post_id ) {
		$data   = array();
		$custom = get_post_custom( $post_id );
		$sections = self::get_post_format_meta_boxes();
		$meta     = array();
		foreach ( $sections as $section ) {
			$meta += $section['fields'];
		}

		foreach ( $meta as $key => $field ) {
			$data[ $key ] = @$custom[ $key ][0];
		}

		return $data;
	}

	public static function get_post_format_meta_boxes() {
		$sections = array();

		// Standard
		$sections['brk_standard'] = array(
			'box_title'   => esc_html__( 'Standard', 'berserk' ),
			'post_types'  => array( 'post' ),
			'post_format' => array( '0' ),
			'icon'        => 'el-icon-screen',
			'fields'      => array(
				'post-map-address' => array(
					'type'     => 'text',
					'label'    => esc_html__( 'Google Map Address', 'berserk' ),
				),
			)
		);

		// Audio
		$sections['brk_audio'] = array(
			'box_title'   => esc_html__( 'Audio', 'berserk' ),
			'post_types'  => array( 'post', 'brs_portfolio' ),
			'post_format' => array( 'audio' ),
			'icon'        => 'el-icon-screen',
			'fields'      => array(
				'post-audio' => array(
					'id'    => 'post-audio',
					'type'  => 'text',
					'label' => esc_html__( 'Audio URL', 'berserk' ),
					'desc'  => esc_html__( 'Audio file URL in format: mp3, ogg, wav.', 'berserk' )
				)
			)
		);

		// Gallery

		$sections['brk_gallery'] = array(
			'box_title'   => esc_html__( 'Gallery', 'berserk' ),
			'post_types'  => array( 'post', 'brs_portfolio' ),
			'post_format' => array( 'gallery' ),
			'icon'        => 'el-icon-screen',
			'fields'      => array(
				'post-gallery' => array(
					'type'     => 'gallery',
					'label'    => esc_html__( 'Gallery Slider', 'berserk' ),
					'desc' => esc_html__( 'Upload images or add from media library.', 'berserk' ),
				)
			)
		);

		// Video
		$sections['brk_video'] = array(
			'box_title'   => esc_html__( 'Video', 'berserk' ),
			'post_types'  => array( 'post', 'brs_portfolio' ),
			'post_format' => array( 'video' ),
			'icon'        => 'el-icon-screen',
			'fields'      => array(

				'post-video-url' => array(
					'type'        => 'video_upload',
					'upload_type' => 'video',
					'label'       => esc_html__( 'Video URL / Upload', 'berserk' ),
					'description' => 'Examples: http://www.youtube.com/embed/AFtUpMTs4vI https://player.vimeo.com/video/49072365 or upload self hosted video',
				),

				'video-custom-title' => array(
					//'id'    => 'video-custom-title',
					'type'  => 'text',
					'label' => esc_html__( 'Video label', 'berserk' ),
					'desc'  => esc_html__( '', 'berserk' ),
				)
			)
		);

		return $sections;
	}

	public static function init_meta_boxes() {

		$sections = self::get_post_format_meta_boxes();

		foreach ( $sections as $key => $section ) {
			add_meta_box( $key, $section['box_title'], array(
				__CLASS__,
				'credits_meta'
			), $section['post_types'], "normal", "high" );

			add_filter( 'postbox_classes_post_'.$key, array('Berserk_Post_Format', 'add_metabox_classes') );
			add_filter( 'postbox_classes_brs_portfolio_'.$key, array('Berserk_Post_Format', 'add_metabox_classes') );
		}
	}

	public static function add_metabox_classes($classes) {
		array_push($classes,'brk_post_format_metabox');
		return $classes;
	}

	public static function credits_meta( $post, $metabox ) {
		$sections = self::get_post_format_meta_boxes();

		$data['meta']    = self::get_meta_data( $post->ID );
		$data['options'] = $sections[ $metabox['id'] ]['fields'];

		echo BRS_Options_Framework::draw_html( 'views/credits_meta', $data );
	}

	public static function save_post() {
		global $post;
		if ( is_object( $post ) ) {
			//if ( isset( $_POST ) AND ! empty( $_POST ) AND $post->post_type == self::postType() ) {
			if ( isset( $_POST ) AND ! empty( $_POST ) ) {

				$sections = self::get_post_format_meta_boxes();
				$meta     = array();
				foreach ( $sections as $section ) {
					$meta += $section['fields'];
				}
				foreach ( $meta as $key => $field ) {
					update_post_meta( $post->ID, $key, @$_POST[ $key ] );
				}
			}
		}
	}
}

Berserk_Post_Format::get_instance();