<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit();
}
if ( ! class_exists( 'BRS_Staff' ) ) {

	class BRS_Staff {
		protected static $post_type = 'brs_staff';
		public static $slug = 'staff-page';
		static protected $instance;

		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Staff();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_action( 'init', array( $this, 'init' ) );
			add_action( 'add_meta_boxes', array( $this, 'init_meta_boxes' ) );
			add_action( 'save_post', array( $this, "save_post" ) );
		}

		public function init() {
			$this->createPostType();
		}

		public static function postType() {
			return self::$post_type;
		}

		public static function postMeta() {
			$meta = array(
				'email'     => array(
					'label'  => 'Email',
					'group'  => 'socials',
					'icon'   => 'email',
					'prefix' => 'mailto:',
					'type'  => 'text'
				),
				'instagram' => array(
					'label' => 'Instagram',
					'group' => 'socials',
					'icon'  => 'instagram',
					'type'  => 'text'
				),
				'google'    => array(
					'label' => 'Google',
					'group' => 'socials',
					'icon'  => 'google-plus',
					'type'  => 'text'
				),
				'youtube'   => array(
					'label' => 'Youtube',
					'group' => 'socials',
					'icon'  => 'youtube',
					'type'  => 'text'
				),
				'vimeo'     => array(
					'label' => 'Vimeo',
					'group' => 'socials',
					'icon'  => 'vimeo',
					'type'  => 'text'
				),
				'vk'        => array(
					'label' => 'Vk',
					'group' => 'socials',
					'icon'  => 'vk',
					'type'  => 'text'
				),
				'linkedin'  => array(
					'label' => 'LinkedIn',
					'group' => 'socials',
					'icon'  => 'linkedin',
					'type'  => 'text'
				),
				'dribbble'  => array(
					'label' => 'Dribbble',
					'group' => 'socials',
					'icon'  => 'dribbble',
					'type'  => 'text'
				),
				'skype'     => array(
					'label' => 'Skype',
					'group' => 'socials',
					'icon'  => 'skype',
					'pefix' => 'skype:',
					'type'  => 'text'
				),
				'phone'     => array(
					'label' => 'Phone',
					'group' => 'socials',
					'icon'  => 'phone',
					'pefix' => 'tel:',
					'type'  => 'text'
				),
			);

			return $meta;
		}

		function createPostType() {

			register_taxonomy( "position", array( self::postType() ), array(
				"hierarchical"      => true,
				"labels"            => array(
					'name'               => __( 'Position', 'berserk' ),
					'singular_name'      => __( 'Position', 'berserk' ),
					'add_new'            => __( 'Add New', 'berserk' ),
					'add_new_item'       => __( 'Add New Position', 'berserk' ),
					'edit_item'          => __( 'Edit Position', 'berserk' ),
					'new_item'           => __( 'New Position', 'berserk' ),
					'view_item'          => __( 'View Position', 'berserk' ),
					'search_items'       => __( 'Search GPosition', 'berserk' ),
					'not_found'          => __( 'No Position found', 'berserk' ),
					'not_found_in_trash' => __( 'No Position found in Trash', 'berserk' ),
					'parent_item_colon'  => ''
				),
				"singular_label"    => __( "Position", 'berserk' ),
				"rewrite"           => true,
				'show_in_nav_menus' => false,
			) );

			register_post_type( self::postType(), array(
				'labels'              => self::getPostTypesLabels(),
				'public'              => true,
				'archive'             => true,
				'exclude_from_search' => false,
				'publicly_queryable'  => true,
				'show_ui'             => true,
				'query_var'           => true,
				'capability_type'     => 'page',
				'map_meta_cap'        => true,
				'has_archive'         => true,
				'hierarchical'        => true,
				'menu_position'       => null,
				'supports'            => array( 'title', 'thumbnail', 'excerpt', 'editor' ),
				'rewrite'             => array( 'slug' => self::postType() ),
				'show_in_admin_bar'   => true,
				'taxonomies'          => array( 'position' ), // this is IMPORTANT
				'menu_icon'           => 'dashicons-businessman'
			) );

		}

		public static function getPostTypesLabels() {
			return array(
				'name'               => __( 'Staff', 'berserk' ),
				'singular_name'      => __( 'Staff', 'berserk' ),
				'add_new'            => __( 'Add New', 'berserk' ),
				'add_new_item'       => __( 'Add New Staff', 'berserk' ),
				'edit_item'          => __( 'Edit Staff', 'berserk' ),
				'new_item'           => __( 'New Staff', 'berserk' ),
				'view_item'          => __( 'View Staff', 'berserk' ),
				'search_items'       => __( 'Search In Staff', 'berserk' ),
				'not_found'          => __( 'Nothing found', 'berserk' ),
				'not_found_in_trash' => __( 'Nothing found in Trash', 'berserk' ),
				'parent_item_colon'  => ''
			);
		}

		public static function get_meta_data( $post_id ) {
			$data   = array();
			$custom = get_post_custom( $post_id );

			$meta = self::postMeta();
			foreach ( $meta as $key => $field ) {
				$data[ $key ] = @$custom[ $key ][0];
			}

			return $data;
		}

		public static function init_meta_boxes() {
			add_meta_box( "credits_meta", esc_html__( 'Staff attributes', 'berserk' ), array(
				__CLASS__,
				'credits_meta'
			), self::postType(), "normal", "low" );
		}

		public static function credits_meta() {
			global $post;

			$data['meta'] = self::get_meta_data( $post->ID );
			$data['options'] = self::postMeta();

			echo BRS_Options_Framework::draw_html( 'views/credits_meta', $data );
		}

		public static function save_post() {
			global $post;
			if ( is_object( $post ) ) {
				if ( isset( $_POST ) AND ! empty( $_POST ) AND $post->post_type == self::postType() ) {
					$meta = self::postMeta();
					foreach ( $meta as $key => $field ) {
						update_post_meta( $post->ID, $key, @$_POST[ $key ] );
					}
				}
			}
		}

	}

	BRS_Staff::get_instance();
}
