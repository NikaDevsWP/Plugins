<?php if ( ! defined( 'ABSPATH' ) ) {
	die( 'No direct access allowed' );
} ?>
<?php
wp_enqueue_style( 'brk_admin_meta_css', BERSERK_SHORTCODES_URL . '/shortcodes/css/admin/admin-meta.css' );
wp_enqueue_script( 'brk_admin_meta_js', BERSERK_SHORTCODES_URL . '/shortcodes/js/admin/admin-meta.js' );
?>
<input type="hidden" value="1" name="brs_meta_saving"/>

<table class="form-table staff-postbox">
	<tbody>
	<?php

	$meta    = $data['options'];
	$default = $data['meta'];
	foreach ( $meta as $key => $meta ) { ?>
		<tr>
			<th>
				<label for="<?php print $key ?>">
					<strong><?php _e( $meta['label'], 'berserk' ); ?></strong>
					<span></span>
				</label>
			</th>
			<td>
				<?php
				switch ( $meta['type'] ) {
					case "text":
						?>
						<input type="text" size="30"
						       value="<?php echo isset( $default[ $key ] ) ? esc_attr( $default[ $key ] ) : '' ?>"
						       id="<?php print $key ?>" name="<?php print $key ?>">
						<?php
						break;
					case "select":
						?>
						<select name="<?php print $key ?>">
							<?php
							foreach ( $meta['options'] as $option ) {
								$selected = ( isset( $default[ $key ] ) && $option == $default[ $key ] ) ? 'selected' : '';
								?>
								<option <?php echo $selected ?>
									value="<?php echo $option ?>"><?php echo $option ?></option>
								<?php
							}
							?>
						</select>
						<?php
						break;
					case "video_upload":
						?>
						<input type="text" size="30" id=""
						       value="<?php echo isset( $default[ $key ] ) ? esc_attr( $default[ $key ] ) : '' ?>"
						       class="data-input data-upload" name="<?php print $key ?>">
						<a title="" class="button brs_button_upload"
						   data-type="<?php echo esc_attr( $meta['upload_type'] ); ?>" href="#">
							<?php esc_html_e( 'Browse', 'berserk' ); ?>
						</a><br>
						<span class="preset_description"><?php echo esc_html( $meta['description'] ); ?></span>

						<?php
						break;
					case "gallery":
						?>
						<div class="gallery-meta-container">
							<div class="gallery_layout">
								<p><a href="#" data-key="<?php echo $key ?>"
								      class="js_inpost_gallery_add_slide button button-primary"><?php esc_html_e( 'Add images', 'berserk' ); ?></a>
								</p>
							</div>
							<?php
							$gallery_data = unserialize( $default[ $key ] );
							?>
							<ul id="gallery_item_list">
								<?php if ( ! empty( $gallery_data ) ) {
									foreach ( $gallery_data as $value ) {
										if ( ! empty( $value['imgurl'] ) ) {
											Berserk_Gallery::render_gallery_item( $value, $key );
										}
									}
								} ?>
							</ul>
							<div class="clear"></div>
						</div>
						<?php
						break;
				} ?>

			</td>
		</tr>
	<?php } ?>
	</tbody>
</table>
