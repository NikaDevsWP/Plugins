<?php
/**
 * Register Post Type FAQ
 *
 * @package NikaDevs
 * @subpackage Berserk Shortcodes
 * @since 1.0.0
 */

function brk_register_post_type_faq() {

	$labels = array(
		'name'                  => esc_html__( 'FAQ', 'berserk' ),
		'singular_name'         => esc_html__( 'FAQ', 'berserk' ),
		'menu_name'             => esc_html__( 'FAQ', 'berserk' ),
		'name_admin_bar'        => esc_html__( 'FAQ', 'berserk' ),
		'archives'              => esc_html__( 'FAQ Arhives', 'berserk' ),
		'all_items'             => esc_html__( 'All FAQs', 'berserk' ),
		'add_new_item'          => esc_html__( 'Add new FAQ', 'berserk' ),
		'add_new'               => esc_html__( 'Add New', 'berserk' ),
		'new_item'              => esc_html__( 'New FAQ', 'berserk' ),
		'edit_item'             => esc_html__( 'Edit FAQ', 'berserk' ),
		'update_item'           => esc_html__( 'Update FAQ', 'berserk' ),
		'view_item'             => esc_html__( 'View FAQ', 'berserk' ),
		'search_items'          => esc_html__( 'Search FAQ', 'berserk' ),
	);
	$args = array(
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor' ),
		'taxonomies'            => array( 'faq_cat' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 20,
		'menu_icon'             => 'dashicons-welcome-learn-more',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => true,
		'publicly_queryable'    => true,
		'capability_type'       => 'post',
	);
	register_post_type( 'brs_faq', $args );

}
add_action( 'init', 'brk_register_post_type_faq' );

/**
 * Register Faq Category
 */

function brk_register_taxonomy_faq_cat() {

	$labels = array(
		'name'                       => esc_html__( 'FAQ Categories', 'berserk' ),
		'singular_name'              => esc_html__( 'Category', 'berserk' ),
		'menu_name'                  => esc_html__( 'Categories', 'berserk' ),
		'all_items'                  => esc_html__( 'All Categories', 'berserk' ),
		'new_item_name'              => esc_html__( 'New Category', 'berserk' ),
		'add_new_item'               => esc_html__( 'Add New Category', 'berserk' ),
		'edit_item'                  => esc_html__( 'Edit Category', 'berserk' ),
		'update_item'                => esc_html__( 'Update Category', 'berserk' ),
		'view_item'                  => esc_html__( 'View Category', 'berserk' ),
		'separate_items_with_commas' => esc_html__( 'Separate items with commas', 'berserk' ),
		'add_or_remove_items'        => esc_html__( 'Add or remove Categories', 'berserk' ),
		'choose_from_most_used'      => esc_html__( 'Choose from the most used', 'berserk' ),
		'popular_items'              => esc_html__( 'Popular Categories', 'berserk' ),
		'search_items'               => esc_html__( 'Search Categories', 'berserk' ),
		'not_found'                  => esc_html__( 'Not Found', 'berserk' ),
		'no_terms'                   => esc_html__( 'No items', 'berserk' ),
		'items_list'                 => esc_html__( 'Categories list', 'berserk' ),
		'items_list_navigation'      => esc_html__( 'Categories list navigation', 'berserk' ),
	);
	/*$rewrite = array(
		'slug'                       => 'faq-category',
		'with_front'                 => true,
		'hierarchical'               => false,
	);*/
	$args = array(
		'labels'                     => $labels,
		'hierarchical'               => true,
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'show_in_nav_menus'          => true,
		'show_tagcloud'              => true,
		//'rewrite'                    => $rewrite,
	);
	register_taxonomy( 'faq_cat', array( 'brs_faq' ), $args );

}
add_action( 'init', 'brk_register_taxonomy_faq_cat' );