<?php
/* Basic plugin definitions */

define( 'OPTIONS_FRAMEWORK_VERSION', '1.0' );
define( 'OPTIONS_FRAMEWORK_URL', trailingslashit( get_template_directory_uri() . '/inc/extensions/' . basename( dirname( __FILE__ ) ) ) );
define( 'OPTIONS_FRAMEWORK_DIR', trailingslashit( dirname( __FILE__ ) ) );

/* Make sure we don't expose any info if called directly */

if ( ! function_exists( 'add_action' ) ) {
	echo "Hi there!  I'm just a little plugin, don't mind me.";
	exit;
}

/**
 * Get Option.
 *
 * Helper function to return the theme option value.
 * If no value has been saved, it returns $default.
 * Needed because options are saved as serialized strings.
 */

if ( ! function_exists( 'of_get_option' ) ) :

	function of_get_option( $name, $default = false ) {
		if ( false === ( $saved_options = wp_cache_get( 'saved_options', 'optionsframework' ) ) ) {

			$saved_options = optionsframework_get_options();
			$saved_options = apply_filters( 'brs_of_get_option_static', $saved_options );

			wp_cache_set( 'saved_options', $saved_options, 'optionsframework' );
		}

		$options = apply_filters( 'brs_of_get_option', $saved_options, $name );

		if ( isset( $options[ $name ] ) ) {
			return apply_filters( "brs_of_get_option-{$name}", $options[ $name ] );
		}

		if ( false === $default && null !== ( $def_val = _optionsframework_get_option_default_value( $name ) ) ) {
			return $def_val;
		}

		return $default;
	}

endif;

/**
 * Description here.
 *
 */
function optionsframework_get_options() {
	$config_id = optionsframework_get_options_id();
	$config    = get_option( 'optionsframework' );
	if ( ! isset( $config['knownoptions'] ) || ! in_array( $config_id, $config['knownoptions'] ) ) {
		return null;
	}

	return get_option( $config_id );
}


/**
 * Get options id.
 *
 */
function optionsframework_get_options_id() {
	return preg_replace( "/\W/", "", strtolower( wp_get_theme()->Name ) );
}

class BRS_Options_Framework {
	static protected $instance;

	public static function get_instance() {
		if ( ! self::$instance ) {
			self::$instance = new BRS_Options_Framework();
		}

		return self::$instance;
	}

	public static function draw_html( $view, $data = array() ) {
		@extract( $data );
		ob_start();
		include( BERSERK_SHORTCODES_PATH . '/extensions/' . $view . '.php' );
		return ob_get_clean();
	}

}

BRS_Options_Framework::get_instance();