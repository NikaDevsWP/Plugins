<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit();
}
if ( ! class_exists( 'Berserk_Footer' ) ) {

	class Berserk_Footer {
		protected static $post_type = 'brs_footer';
		static protected $instance;

		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new Berserk_Footer();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_action( 'init', array( $this, 'init' ) );
		}

		public function init() {
			$this->createPostType();
		}

		public static function postType() {
			return self::$post_type;
		}

		function createPostType() {

			register_post_type( self::postType(), array(
				'labels'              => self::getPostTypesLabels(),
				'public'              => true,
				'archive'             => false,
				'exclude_from_search' => true,
				'publicly_queryable'  => false,
				'show_ui'             => true,
				'query_var'           => true,
				'capability_type'     => 'post',
				'map_meta_cap'        => true,
				'has_archive'         => false,
				'hierarchical'        => false,
				'menu_position'       => null,
				'supports'            => array( 'title', 'editor'),
				'show_in_admin_bar'   => false,
				'show_in_menu'        => true,
				'show_in_nav_menus'   => false,
				'map_meta_cap'        => true,
				'menu_icon'           => 'dashicons-tagcloud',
			) );

		}

		public static function getPostTypesLabels() {
			return array(
				'name'               => esc_html__( 'Footers', 'berserk' ),
				'singular_name'      => esc_html__( 'Footer', 'berserk' ),
				'add_new'            => esc_html__( 'Add New', 'berserk' ),
				'add_new_item'       => esc_html__( 'Add New Footer', 'berserk' ),
				'edit_item'          => esc_html__( 'Edit Footer', 'berserk' ),
				'new_item'           => esc_html__( 'New Footer', 'berserk' ),
				'view_item'          => esc_html__( 'View Footer', 'berserk' ),
				'search_items'       => esc_html__( 'Search Footer', 'berserk' ),
				'not_found'          => esc_html__( 'No Footer found', 'berserk' ),
				'not_found_in_trash' => esc_html__( 'No Footer found in Trash', 'berserk' ),
			);
		}

	}

	Berserk_Footer::get_instance();
}
