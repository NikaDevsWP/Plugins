<?php

/**
 * Nice dump for variables
 */
function brs_add_libraries( $libraries ) {

	$base = array(
		'font_awesome__5'                      => array(
			'js' => array(
				'//use.fontawesome.com/releases/v5.0.1/js/all.js'
			)
		),
		'slider__slick'                        => array(
			'css' => array(
				'vendor/slickCarousel/css/slick.css',
			),
			'js'  => array(
				'vendor/slickCarousel/js/slick.min.js',
				'js/assets/sliders-skin.js'
			)
		),
		'slider__slick_with_component_sliders' => array(
			'dependency' => array(
				'component__sliders',
				'slider__slick'
			),
		),
		'slider__rotator'                      => array(
			'js' => array(
				'js/assets/rotation-slider.js',
			)
		),
		'isotope'                              => array(
			'js' => array(
				'vendor/isotope/js/isotope.pkgd.min.js'
			)
		),
		'autocomplete' => array(
			'js'=> array(
				'vendor/jqueryAutocomplete/js/jquery-ui.min.js'
			)
		),
		'scrollbar'                            => array(
			'css' => array(
				'vendor/jquery.scrollbar/css/jquery.scrollbar.css'
			),
			'js'  => array(
				'vendor/jquery.scrollbar/js/jquery.scrollbar.min.js'
			),
		),
		'uitotop'                              => array(
			'js' => array(
				'vendor/uiToTop/js/jquery.ui.totop.min.js',
			),
		),
		'assets_particleground'                => array(
			'js' => array(
				'js/assets/jquery.particleground.min.js'
			)
		),
		'assets_fss'                           => array(
			'js' => array(
				'js/assets/fss.min.js',
				'js/assets/fss-init.js'
			)
		),
		'assets_skrollr'                       => array(
			'js' => array(
				'js/assets/skrollr.min.js'
			)
		),
		'paper'                                => array(
			'js' => array(
				'vendor/paper/js/paper-full.js'
			)
		),
		'anime'                                => array(
			'js' => array(
				'vendor/animejs/js/anime.min.js',
				'js/assets/brk-hover3d.js'
			)
		),
		'wow'                                  => array(
			'css' => array(
				'vendor/animate/css/animate.min.css',
			),
			'js'  => array(
				'vendor/wow/js/wow.min.js',
			)
		),
		'fancybox'                             => array(
			'css' => array(
				'vendor/fancybox/css/jquery.fancybox.min.css'
			),
			'js'  => array(
				'vendor/fancybox/js/jquery.fancybox.min.js',
				//'js/assets/fancybox.js',
			)
		),
		'odometer'                             => array(
			'js' => array(
				'vendor/odometer/js/odometer.min.js',
			)
		),
		'twitter_init'                             => array(
			'js' => array(
				'js/assets/twitter-init.js',
			)
		),
		/*'assets__variables'                    => array(
			'js' => array(
				'js/assets/variables.js'
			)
		),*/
		'assets__counter'                      => array(
			'js' => array(
				'js/assets/counter.js'
			)
		),
		'assets__typing_rotator'               => array(
			'js' => array(
				'js/assets/typing-rotator.js'
			)
		),
		'assets__image_caption'                => array(
			'dependency' => array(
				'anime'
			),
			'js'         => array(
				'js/components/image-caption-parallax.js'
			)
		),
		'component__accordions'                => array(
			'css' => array(
				'css/components/accordions.css'
			),
			'js'  => array(
				'js/components/accordions.js'
			),
		),
		'component__social_links'              => array(
			'css' => array(
				'css/components/social-links.css'
			),
		),
		'component__breadcrumbs'               => array(
			'css' => array(
				'css/components/breadcrumbs.css'
			),
			'js'  => array(
				'vendor/jquerySlider/js/jquery-ui.min.js',
				//'js/components/breadcrumbs.js'
			),
		),/*
		'assets_preloader'                     => array(
			'css' => array(
				'css/assets/brk-preloader.css',
			),
		),*/
		'component__sliders'                   => array(
			'js'         => array(
				'js/components/sliders.js',
			),
			'dependency' => array(
				'component__sliders_css'
			)
		),
		'component__sliders_css'               => array(
			'css' => array(
				'css/components/sliders.css',
			),
			'dependency' => array(
				'slider__slick',
			)
		),
		'component__team'                      => array(
			'css' => array(
				'css/components/team.css',
			),
			'js'  => array(
				'js/components/team.js'
			)
		),
		'component__social_block'              => array(
			'css' => array(
				'css/components/social.css',
			),
		),
		'component__flip_box'                  => array(
			'css' => array(
				'css/components/flip-boxes.css',
			),
		),
		'component__app_showcase'              => array(
			'css' => array(
				'css/components/flip-boxes.css',
			),
		),
		'component__typing_rotator'            => array(
			'css' => array(
				'css/components/typing-rotator.css',
			),
		),
		'component__dividers'                  => array(
			'css' => array(
				'css/components/dividers.css',
			),
		),
		'component__progress_circle'           => array(
			/*'dependency' => array(
				'assets__variables'
			),*/
			'css' => array(
				'css/components/progress-circles.css',
			),
			'js'  => array(
				'js/components/progress-circles.js'
			)
		),
		'component__counter'                   => array(
			'css' => array(
				'css/components/counter.css',
			),
			'js'  => array(
				'js/components/counter.js'
			)
		),
		'component__button'                    => array(
			'css' => array(
				'css/components/buttons.css',
			),
			'js'  => array(
				'js/components/buttons.js'
			)
		),
		'component__alert'                     => array(
			'css' => array(
				'css/components/alerts.css',
			),
			'js'  => array(
				'js/components/alerts.js'
			)
		),
		'component__form'                      => array(
			'css' => array(
				'css/components/form-controls.css'
			),
			'js'  => array(
				'vendor/formStyler/js/jquery.formstyler.min.js',
				'js/components/form-controls.js',
			)
		),
		'component__forum_post'                => array(
			'css' => array(
				'css/components/forum-post.css'
			),
		),
		'component__forum_main'                => array(
			'css' => array(
				'css/components/forum-main.css'
			),
		),
		'component__forum_author'              => array(
			'css' => array(
				'css/components/forum-author.css'
			),
		),
		'component__countdown'                 => array(
			'css' => array(
				'css/components/countdown.css',
			),
			'js'  => array(
				'vendor/jqueryCountdown/js/jquery.countdown.min.js',
				'vendor/underscore/js/underscore-min.js',
				'js/components/countdown.js'
			)
		),
		'component__parallax'                  => array(
			'css' => array(
				'css/components/parallax.css',
			),
			'js'  => array(
				'vendor/paraxify/js/paraxify.min.js',
				'js/components/parallax.js'
			)
		),

		'component__parallax_video'      => array(
			'css'        => array(
				'css/components/parallax-video.css',
			),
			'js'         => array(
				'js/components/parallax-video.js'
			),
			'dependency' => array(
				'component__ytplayer',
				'component__vimeoplayer'
			)
		),
		'component__ytplayer'             => array(
			'js' => array(
				'vendor/jqueryMbYT_player/js/jquery.mb.YTPlayer.min.js'
			)
		),
		'component__vimeoplayer'             => array(
			'js' => array(
				'vendor/jqueryMbVimeo_player/js/jquery.mb.vimeo_player.min.js'
			)
		),
		'component__image_frames'        => array(
			'css' => array(
				'css/components/image-frames.css'
			),
		),
		'component__call_to_action'      => array(
			'css' => array(
				'css/components/CFA.css'
			),
			'js' => array(
				'js/components/CFA.js'
			),
		),
		'component__list'                => array(
			'css' => array(
				'css/components/lists.css'
			),
		),
		'component__map'                 => array(
			'css' => array(
				'css/components/google-maps.css'
			),
			/*'js'  => array(
				'//maps.googleapis.com/maps/api/js?key=' . ( class_exists( 'berserk_helper' ) ? get_theme_mod( 'brs-google-maps-api-key' ) : '' ),
				'js/components/google-maps.js'
			)*/
		),
		'component__panel'               => array(
			'css' => array(
				'css/components/panels.css'
			),
		),
		'component__pricing_table'       => array(
			'css' => array(
				'css/components/pricing-tables.css'
			),
		),
		'component__blog'                => array(
			'css'        => array(
				'css/components/blog.css'
			),
			'js'         => array(
				'js/components/blog.js'
			),
			'dependency' => array(
				'slider__slick'
			)
		),
		'component__blog_page'           => array(
			'css'        => array(
				'css/components/blog-page.css'
			),
			'js'         => array(
				'js/components/blog-page.js'
			),
			'dependency' => array(
				'component__social_links',
				'component__blog'
			)
		),
		'component__index_page' => array(
			'css' => array(
				'css/components/index.css'
			),
			'js'=> array(
				'js/components/index.js'
			),
			'dependency' => array(
				'isotope',
				'autocomplete'
			)
		),
		'component__widgets'             => array(
			'css'        => array(
				'css/components/widgets.css'
			),
			'js'         => array(
				'js/components/widgets.js'
			),
			'dependency' => array(
				'slider__slick'
			)
		),
		'component__media_embeds'        => array(
			'css' => array(
				'css/components/media-embeds.css'
			),
			'js'  => array(
				'js/components/media-embeds.js'
			),
		),
		'component__pagination'          => array(
			'css' => array(
				'css/components/pagination.css'
			),
			'js'  => array(
				'js/components/pagination.js'
			),
		),
		'component__team_page'           => array(
			'css'        => array(
				'css/components/team-member.css'
			),
			/*'js'         => array(
				'js/components/team-member.js'
			),*/
			'dependency' => array(
				'component__social_links',
				'slider__slick_with_component_sliders'
			)
		),
		'component__portfolio_page'      => array(
			'css'        => array(
				'css/components/portfolio-page.css'
			),
			'js'         => array(
				//'js/components/portfolio-page.js'
				//'js/components/portfolio.js'
			),
			'dependency' => array(
				'anime',
				//'slider__slick'
				'slider__slick_with_component_sliders'

			)
		),
		'component__portfolio_list'      => array(
			'css' => array(
				'css/components/portfolio-list.css'
			),
		),
		'component__portfolio_grid'      => array(
			'css'        => array(
				//'css/components/portfolio.css'
			),
			'js'         => array(
				//'js/components/portfolio.js',
			),
			'dependency' => array(
				'anime',
			),
		),
		'component__portfolio_row'       => array(
			'css'        => array(
				'css/components/portfolio-rows.css'
			),
			'js'         => array(
				'js/components/portfolio-rows.js',
			),
			'dependency' => array(
				'isotope',
				'anime',
			),
		),
		'component__portfolio_isotope'   => array(
			'css'        => array(
				'css/components/portfolio-isotope.css'
			),
			'js'         => array(
				'js/components/portfolio-isotope.js',
			),
			'dependency' => array(
				'isotope',
				'anime',
			),
		),
		'component__portfolio_masonry'   => array(
			'css' => array(
				'css/components/portfolio-masonry.css'
			),
			'js'  => array(
				'js/components/portfolio-masonry.js'
			),
		),
		'component__portfolio_category'  => array(
			'css'        => array(
				'css/components/portfolio-categories.css',
			),
			'js'         => array(
				'js/components/portfolio-categories.js',
			),
			'dependency' => array(
				'slider__slick_with_component_sliders'
			)
		),
		'component__portfolio_galleries' => array(
			'css' => array(
				'css/components/portfolio-galleries.css',
			),

		),
		'component__progress_bar'        => array(
			/*'dependency' => array(
				'assets__counter'
			),*/
			'css' => array(
				'css/components/progress-bars.css',
			),
			'js'  => array(
				'js/components/progress-bars.js',
			)
		),
		'component__sequence'            => array(
			'css' => array(
				'css/components/sequence.css'
			),
		),
		'component__services'            => array(
			'css' => array(
				'css/components/services.css'
			),
		),
		'component__shape_box'           => array(
			'css' => array(
				'css/components/shape-box.css',
			),
			'js'  => array(
				'js/components/shape-box.js',
			)
		),
		'component__steps'               => array(
			'css' => array(
				'css/components/steps.css'
			),
			'js'  => array(
				'js/components/steps.js',
			)
		),
		'component__tabs'                => array(
			'css' => array(
				'css/components/tabs.css'
			),
			'js'  => array(
				'js/components/tabs.js',
			)
		),
		'component__tabbed_contents'     => array(
			'css' => array(
				'css/components/tabbed-contents.css'
			)
		),
		'component__testimonials'        => array(
			'css'        => array(
				'css/components/testimonials.css'
			),
			'js'         => array(
				'js/components/testimonials.js',
			),
			'dependency' => array(
				//'anime',
				'slider__slick_with_component_sliders'
			)
		),
		'component__tiles'               => array(
			'css' => array(
				'css/components/tiles.css',
			),
			/*'js'  => array(
				'js/components/tiles.js',
			)
			*/
		),
		'component__title_section'       => array(
			'css' => array(
				'css/components/section-titles.css',
			),
		),
		'component__title'                     => array(
			'css'        => array(
				'css/components/titles.css',
			),
			'dependency' => array(
				'assets__typing_rotator',
				//'component__title_section',
			)
		),
		'component__delimiters'          => array(
			'css' => array(
				'css/components/delimiters.css',
			),
		),
		'component__backgrounds_css'     => array(
			'css' => array(
				'css/components/backgrounds.css',
			),
		),
		'component__backgrounds'         => array(
			'js'         => array(//'js/components/backgrounds.js'
			),
			'dependency' => array(
				'component__backgrounds_css',
				'assets_particleground',
				'assets_skrollr',
				'assets_fss',
				//'paper',
			)
		),
		'component__image_caption'       => array(
			'css' => array(
				'css/components/image-caption-parallax.css',
			),
		),
		'component__tags'                => array(
			'css' => array(
				'css/components/tags.css',
			),
		),
		'component__tags_js'             => array(
			'js' => array(
				'js/components/tags.js',
			),
		),
		'component__content_slider'            => array(
			'css' => array(
				'css/components/content-sliders.css',
			),
		),
		'component__timelines'           => array(
			'css'        => array(
				'css/components/timelines.css',
			),
			'dependency' => array(
				'component__content_slider'
			)
		),
		'component__timelines_js'        => array(
			'js' => array(
				'js/components/timelines.js'
			),
		),
		'component__gallery_sliders'     => array(
			'css'        => array(
				'css/components/gallery-sliders.css',
			),
			'js'         => array(
				'js/components/gallery-sliders.js'
			),
			'dependency' => array(
				'slider__slick_with_component_sliders'
			)
		),

		'component__tables'   => array(
			'css' => array(
				'css/components/tables.css',
			),
			'js'  => array(
				'js/components/tables.js'
			),
		),
		'component__shop_row' => array(
			'css' => array(
				'css/components/shop-components-row.css',
			),
		),

		'component__shop_tiles'             => array(
			'css'        => array(
				'css/components/shop-components-tiles.css',
			),
			'js'         => array(
				'js/components/shop-components-tiles.js'
			),
			'dependency' => array(
				'slider__slick_with_component_sliders',
				'component__shop_row'
			)
		),
		'component__shop_masonry'           => array(
			'css'        => array(
				'css/components/shop-components-masonry.css',
			),
			'dependency' => array(
				'slider__slick_with_component_sliders',
				'component__shop_row'
			)
		),
		'component__shop_grid_filter'       => array(
			'css'        => array(
				'css/components/shop-components-grid-filter.css',
			),
			'js'         => array(
				'js/components/shop-components-grid-filter.js'
			),
			'dependency' => array(
				'isotope',
			)
		),
		'component__shop_honeycomb'         => array(
			'css'        => array(
				'css/components/shop-components-honeycomb.css',
			),
			'dependency' => array(
				'wow'
			)
		),
		'component__shop_product_row'       => array(
			'css'        => array(
				'css/components/shop-components-row.css',
			),
			/*'js'         => array(
				'js/components/shop-components-row.js'
			),*/
			'dependency' => array(
				'wow'
			)
		),
		/*'component__shop_grid'              => array(
			'css'        => array(
				'css/components/shop-components-grid.css',
			),
			'dependency' => array(
				'component__flip_box'
			)
		),*/
		'component__shop_list'              => array(
			'css' => array(
				'css/components/shop-components-cards.css',
			),
		),
		'component__shop_flip'              => array(
			'css'        => array(
				'css/components/shop-components-flip.css',
			),
			'js'         => array(
				'js/components/shop-components-flip.js',
			),
			'dependency' => array(
				'scrollbar'
			)
		),
		'component__shop_item_page'         => array(
			'css' => array(
				'css/components/shop-components-item-page.css',
			),
			'js'  => array(
				'js/components/shop-components-item-page.js'
			)
		),
		'component__shop_item_page_sidebar' => array(
			'css' => array(
				'css/components/shop-components-item-sidebar.css',
			),
			'js'  => array(//'js/components/shop-components-item-sidebar.js'
			)
		),
		'component__elements'               => array(
			'css' => array(
				'css/components/elements.css',
			),
		),
		'component__header'                 => array(
			'css' => array(
				'css/assets/brk-header-elements.css',
			),
			'js'  => array(
				'js/assets/brk-header.js'
			),
		),
		'component__footer'                 => array(
			'css' => array(
				'css/components/footer.css',
			),
			'js'  => array(
				'js/components/footer.js'
			),
		),
		'component__svg_pattern'            => array(
			'css' => array(
				'css/components/svg-pattern.css',
			),
		),
		/*'component__header_skin_1'          => array(
			'css' => array(
				'css/components/header-1.css"',
			),
		),*/
		'component__gallery'                => array(
			'css'        => array(
				'css/components/gallery-cols.css',
			),
			'dependency' => array(
				'fancybox'
			)
		),
		'component__image_map'              => array(
			'css'        => array(
				'css/components/image-map.css',
			),
			'dependency' => array(
				'component__title',
				'wow',
			)
		),
		'component__info_box'               => array(
			'css' => array(
				'css/components/info-box.css',
			),
			'js'  => array(
				'js/components/info-box.js'
			),
			'dependency' => array(
				'wow'
			)
		),
		'component__checkout'               => array(
			'css' => array(
				'css/components/checkout.css',
			),
			'js'  => array(
				'js/components/checkout.js',
			),
		),
		'slider__swiper'                    => array(
			'dependency' => array(
				'component__sliders_css'
			),
			'css'        => array(
				'vendor/swiper/css/swiper.min.css',
			),
			'js'         => array(
				'vendor/swiper/js/swiper.min.js',
				'js/assets/swiper-skin.js'
			)
		),

	);

	$libraries = is_array( $libraries ) ? $libraries : array( $libraries );
	foreach ( $libraries as $library ) {
		brs_add_libraries_enqueue( $base, $library );
	}

}

function brs_add_libraries_enqueue( $base, $library ) {
	if ( isset( $base[ $library ]['dependency'] ) ) {
		foreach ( $base[ $library ]['dependency'] as $dependency ) {
			brs_add_libraries_enqueue( $base, $dependency );
		}
	}
	if ( isset( $base[ $library ]['css'] ) ) {
		foreach ( $base[ $library ]['css'] as $id => $path ) {
			wp_enqueue_style( 'brs-' . $library . '-' . $id, BERSERK_SHORTCODES_URL . 'shortcodes/' . $path );
		}
	}
	if ( isset( $base[ $library ]['js'] ) ) {
		foreach ( $base[ $library ]['js'] as $id => $path ) {
			if ( strpos( $path, '//' ) !== false ) {
				wp_enqueue_script( 'brs-' . $library . '-' . $id, $path, false );
			} else {
				wp_enqueue_script( 'brs-' . $library . '-' . $id, BERSERK_SHORTCODES_URL . 'shortcodes/' . $path, array( 'jquery' ), false, true );
			}
		}
	}
}

/**
 * Nice dump for variables
 */
function dpm( $d ) {
	$backtrace = debug_backtrace();
	print '<h4> Called in: ' . $backtrace[1]['function'] . '</h4>';
	print '<pre>';
	print_r( $d );
	print '</pre>';
}


/**
 * HTML helpers.
 */
if ( ! function_exists( 'brs_hex2rgb' ) ) :

	function brs_hex2rgb( $hex ) {
		$hex = str_replace( "#", "", $hex );

		if ( strlen( $hex ) == 3 ) {
			$r = hexdec( substr( $hex, 0, 1 ) . substr( $hex, 0, 1 ) );
			$g = hexdec( substr( $hex, 1, 1 ) . substr( $hex, 1, 1 ) );
			$b = hexdec( substr( $hex, 2, 1 ) . substr( $hex, 2, 1 ) );
		} else {
			$r = hexdec( substr( $hex, 0, 2 ) );
			$g = hexdec( substr( $hex, 2, 2 ) );
			$b = hexdec( substr( $hex, 4, 2 ) );
		}
		//$rgb = array( $r, $g, $b );

		$rgb = $r . ',' . $g . ',' . $b;

		return $rgb;
	}

endif;


function brk_shortcode_pagination_ajax() {
	$atts              = $_POST['atts'];
	$atts['filters'][] = array( 'filter_type' => 'offset', 'offset' => $_POST['offset'] );
	$atts['filters'][] = array( 'filter_type' => 'numberposts', 'numberposts' => $_POST['numberposts'] );

	$shortcode = $_POST['shortcode'];

	$object   = 'BRS_' . ucfirst( $shortcode );
	$fun_name = 'shortcode_' . $_POST['shortcode'];

	$posts = $object::$fun_name( $atts );
	print $posts;

	wp_die();
}