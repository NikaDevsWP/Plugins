<?php

class BRS_Send_Mail {
	public static function cfa_submit(){
		$errors = array();
		parse_str($_REQUEST['values'], $data);

		$email = sanitize_email( get_bloginfo('admin_email') );
		$subject = '';
		$messagebody = __("Email: ", 'berserk').$data['email'];
		$result = self::send_email($email, $subject, $messagebody, $errors);

		echo json_encode($result);

		die();
	}

	public static function send_email($email, $subject, $messagebody, $errors){

		$pre_messagebody_info = "";
		$headers = "";

		/* check errors */
		if (!empty($errors)) {
			$result['is_errors'] = 1;
			$result['hash'] = md5(time());
			$result['info'] = $errors;
			echo json_encode($result);
			exit;
		}

		/* check subject */
		if (empty($subject)) {
			$subject = __("Email from Call to Action form", 'berserk');
		}

		/* set message */
		$after_message = "\r\n<br />--------------------------------------------------------------------------------------------------\r\n<br /> " . __('This mail was sent via', 'berserk') . " " . site_url() . " " . __('Call to Action form', 'berserk');
		$messagebody = $pre_messagebody_info . nl2br($messagebody) . $after_message;

		/* set admin email  */

		$admin_mail = sanitize_email( get_bloginfo('admin_email') );

		/* set headers */
		if($admin_mail) {
			$headers .= 'From: '. $admin_mail . "\r\n";
		}

		add_filter('wp_mail_content_type', array(__CLASS__, 'set_html_content_type'));
		add_filter('wp_mail_from_name', array(__CLASS__, 'set_mail_from_name'));

		/* send email */
		if (wp_mail($email, $subject, $messagebody, $headers)) {
			$result["info"] = __("The mail has been sent successfully", 'berserk');
		} else {
			$result["info"] = __("Server Fail", 'berserk');
		}

		remove_filter('wp_mail_content_type', array(__CLASS__, 'set_html_content_type'));
		remove_filter('wp_mail_from_name', array(__CLASS__, 'set_mail_from_name'));


		$result['hash'] = md5(time());
		return $result;

	}
}