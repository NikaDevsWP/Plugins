<?php
/**
 * Visual Composer extensions.
 *
 */

/**
 * Class BRS_Shortcodes_VCParams adds custom params vor VC shortcodes interface.
 */
class BRS_Shortcodes_VCParams {

	/**
	 * BRS_Shortcodes_VCParams constructor.
	 */
	public function __construct() {
		add_action( 'admin_init', array( $this, 'register_params' ), 15 );
	}

	static public function get_term_names( $post_id, $term_name ) {
		$terms      = get_the_terms( $post_id, $term_name );
		$term_names = array();
		if ( $terms && ! is_wp_error( $terms ) ) {
			foreach ( $terms as $term ) {
				$term_names[] = $term->name;
			}
		}

		return $term_names;
	}

	public static function get_taxonomies( $post_type ) {
		$tax_arr    = array();
		$taxonomies = get_object_taxonomies( $post_type, 'objects' );
		foreach ( $taxonomies as $key => $taxonomy ) {
			$tax_arr[ $taxonomy->label ] = $key;
		}

		return $tax_arr;
	}

	public static function get_terms( $term ) {
		$terms_arr = array();
		$terms     = get_terms( array(
			'taxonomy'   => array( $term ),
			'hide_empty' => false,
		) );
		foreach ( $terms as $term ) {
			$terms_arr[ $term->name ] = $term->slug;
		}

		$terms_arr = array_merge( array( 'All' => 'all' ), $terms_arr );

		return $terms_arr;
	}

	public static function get_post_statuses() {
		$statuses_arr  = array();
		$post_statuses = get_post_statuses();
		foreach ( $post_statuses as $key => $statuse ) {
			$statuses_arr[ $statuse ] = $key;
		}

		return $statuses_arr;
	}

	public static function get_orderby_values() {
		$orderby = array(
			'ID'         => 'ID',
			'Title'      => 'title',
			'Date'       => 'date',
			'Modified'   => 'modified',
			'Menu Order' => 'menu_order'
		);

		return $orderby;
	}

	public static function get_content_title( $title_val, $post ) {
		$title = '';
		switch ( $title_val ) {
			case "post_title":
				$title = $post->post_title;
				break;
			case "post_date":
				$title = $post->post_date;
				break;
			case "post_author":
				$title = the_author_meta( 'display_name', $post->post_author );
				break;
		}

		return $title;
	}

	public static function get_content_description( $description_val, $post ) {
		$description = '';
		switch ( $description_val ) {
			case "post_title":
				$description = $post->post_title;
				break;
			case "post_date":
				$description = $post->post_date;
				break;
			case "post_author":
				$description = get_the_author_meta( 'nickname', $post->post_author );
				break;
			case "post_content":
				//$description = apply_filters( 'the_content', $post->post_content );;
				$description = $post->post_content;
				break;
			case "post_excerpt":
				$description = $post->post_excerpt;
				break;
		}

		return $description;
	}

	public static function resize_image( $img, $width, $height ) {
		$img_editor = wp_get_image_editor( $img );
		$crop       = false;

		if ( is_wp_error( $img_editor ) || is_wp_error( $img_editor->resize( $width, $height, $crop ) ) ) {
			return array(
				'url'    => '',
				'width'  => '',
				'height' => '',
			);
		}

		$new_img_path = $img_editor->generate_filename();


		if ( is_wp_error( $img_editor->save( $new_img_path ) ) ) {
			return array(
				'url'    => '',
				'width'  => '',
				'height' => '',
			);
		}
		if ( ! is_string( $new_img_path ) ) {
			return array(
				'url'    => '',
				'width'  => '',
				'height' => '',
			);
		}

		$new_img_size = getimagesize( $new_img_path );
		$new_img      = str_replace( basename( $image_src[0] ), basename( $new_img_path ), $image_src[0] );

		// resized output
		$vt_image = array(
			'url'    => $new_img,
			'width'  => $new_img_size[0],
			'height' => $new_img_size[1],
		);

		return $vt_image;
	}

	public static function get_image_sizes_names() {
		$image_sizes = self::get_all_image_sizes();
		foreach ( $image_sizes as $key => $size ) {
			$size_name[ $key . ' ( ' . $size['width'] . 'X' . $size['height'] . ')' ] = $key;
		}
		$r         = array( "Original" => "full" );
		$size_name = $r + $size_name;

		return $size_name;
	}

	public static function get_all_image_sizes() {
		global $_wp_additional_image_sizes;

		$default_image_sizes = get_intermediate_image_sizes();

		foreach ( $default_image_sizes as $size ) {
			$image_sizes[ $size ]['width']  = intval( get_option( "{$size}_size_w" ) );
			$image_sizes[ $size ]['height'] = intval( get_option( "{$size}_size_h" ) );
			$image_sizes[ $size ]['crop']   = get_option( "{$size}_crop" ) ? get_option( "{$size}_crop" ) : false;
		}

		if ( isset( $_wp_additional_image_sizes ) && count( $_wp_additional_image_sizes ) ) {
			$image_sizes = array_merge( $image_sizes, $_wp_additional_image_sizes );
		}

		return $image_sizes;
	}

	public static function get_woo_products() {
		$products = array();
		$args     = array(
			'post_type'   => 'product',
			'post_status' => 'publish',
			'numberposts' => - 1
		);
		$posts    = get_posts( $args );

		foreach ( $posts as $post ) {
			$products[ $post->ID ] = $post->ID;
		}

		return $products;
	}

	public static function get_wpcf7() {
		$forms = array();
		$args  = array(
			'post_type'   => 'wpcf7_contact_form',
			'post_status' => 'publish',
			'numberposts' => - 1
		);
		$posts = get_posts( $args );

		foreach ( $posts as $post ) {
			$forms[ $post->post_name ] = $post->ID;
		}

		return $forms;

	}

	public static function get_image_map_shortcodes() {

		$admin_options_name = 'image-map-pro-wordpress-admin-options';
		$options            = get_option( $admin_options_name );
		$list               = array();

		if ( ! empty( $options ) ) {
			foreach ( $options['saves'] as $id => $save ) {
				$list[ $save['meta']['name'] ] = $save['meta']['shortcode'];
			}
		}
		$begin_list = array( esc_html__( 'No Image Map', 'berserk' ) => '' );
		$list       = $begin_list + $list;

		return $list;

	}

	public static function get_paddings_value() {
		$value = range( 0, 260, 10 );
		array_unshift( $value, "" );

		return $value;
	}

	public static function get_margin_top() {
		$value = range( - 80, 240, 5 );
		array_unshift( $value, "" );

		return $value;
	}

	public static function get_font_size() {
		$value = range( 10, 120 );
		array_unshift( $value, "" );

		return $value;
	}

	public static function get_font_weight() {
		$values = array(
			'Initial'         => 'initial',
			'Thin 100'        => 'thin',
			'Ultra Light 200' => 'ultralight',
			'Light 300'       => 'light',
			'Normal 400'      => 'normal',
			'Medium 500'      => 'medium',
			'Semibold 600'    => 'semibold',
			'Bold 700'        => 'bold',
			'Extrabold 800'   => 'extrabold',
			'Black 900'       => 'black',
		);

		return $values;
	}

	public static function get_line_height() {
		$value = range( 20, 72, 2 );

		array_unshift( $value, "", 14 );

		return $value;
	}

	public static function get_grayscale_values() {
		$values = range( 10, 100, 10 );

		array_unshift( $values, 'none' );

		return $values;
	}

	public static function get_letter_spacing() {
		$value = range( 20, 300, 10 );
		array_unshift( $value, "-1" );
		array_unshift( $value, "" );

		return $value;
	}

	public static function get_border_radius() {
		$values = array(
			'none' => 'none',
			'0'    => 0,
			'5'    => 5,
			'10'   => 10,
			'25'   => 25,
			'30'   => 30,
			'50'   => 50,
		);

		return $values;
	}

	public static function get_text_colors() {
		$values = array(
			'default'      => 'default',
			'text-primary' => 'text-primary',
			'text-dark'    => 'text-dark',
			'text-white'   => 'text-white',
			'text-blue'    => 'text-blue',
			/*'text-light-blue' => 'text-light-blue',
			'text-gray'       => 'text-gray',
			'text-gray-light' => 'text-gray-light',
			'text-soft'       => 'text-soft',
			'text-light-soft' => 'text-light-soft',
			'text-blue-1'     => 'text-blue-1',
			'text-blue-2'     => 'text-blue-2',
			'text-blue-3'     => 'text-blue-3',
			'brk-dark-font-color' => 'brk-dark-font-color',
			'brk-dark-blur-font-color' => 'brk-dark-blur-font-color',*/
		);

		return $values;
	}

	public static function get_gradients() {
		$values = array(
			'Default'                   => 'brk-bg-grad',
			'Base Gradient 0deg'        => 'brk-bg-gradient-0deg-90',
			'Base Gradient right'       => 'brk-base-bg-gradient-right',
			'Base Gradient 30deg'       => 'brk-base-bg-gradient--30deg',
			'Base Gradient 40deg'       => 'brk-bg-gradient-40deg-92',
			'Base Gradient 90deg'       => 'brk-base-bg-gradient-90deg',
			'Base Gradient 16'          => 'brk-base-bg-gradient-16',
			'Base Gradient Pink'        => 'brk-base-bg-gradient-19',
			'Pink to purple'            => 'brk-base-bg-gradient-pink-purple',
			'Base Gradient Right Blue'  => 'brk-base-bg-gradient-13',
			'Base Gradient Left Blue'   => 'brk-base-bg-gradient-left-blue',
			'Base Gradient Light Blue'  => 'brk-base-bg-light-blue',
			'Light Gradient'            => 'brk-light-gradient-0deg-100',
			'Base blue gradient'        => 'brk-base-bg-gradient-15',
			'Base Gradient 33'          => 'brk-base-gradient-33',
			'Base Gradinet 50deg 28'    => 'brk-base-bg-gradient-50deg-opacity-28',
			'Base Gradinet 50deg 92'    => 'brk-base-bg-gradient-50deg-92',
			'Base Gradient 10'          => 'brk-base-bg-gradient-10',
			'Base 17 gradient'          => 'brk-base-bg-gradient-17',
			'Background Gradient Brown' => 'brk-base-bg-gradient-brown',
		);

		return $values;
	}

	public static function get_bg_colors() {
		$values = array(
			'Bg Primary'          => 'brk-bg-primary',
			'Bg Whihe'            => 'bg-white',
			'Overlay White'       => 'brk-bg-light-white-2',
			'Overlay Dark'        => 'brk-bg-black',
			'Primary 92'          => 'brk-primary-92-overlay',
			'Base green gradient' => 'brk-base-bg-green',
			'Color dark'          => 'brk-bg-color-dark-6',
			'Bg Yellow'           => 'brk-base-bg-yellow',
			'Base light dark'     => 'brk-base-bg-light-dark',
			'Base light gray'     => 'brk-bg-light-gray',
		);

		return $values;
	}

	public static function get_text_transform() {
		$values = array(
			esc_html( 'Default', 'berserk' )          => 'default',
			esc_html( 'lowercased text', 'berserk' )  => 'text-lowercase',
			esc_html( 'UPPERCASED TEXT', 'berserk' )  => 'text-uppercase',
			esc_html( 'CapiTaliZed Text', 'berserk' ) => 'text-capitalize',
		);

		return $values;
	}

	public static function get_video_type( $source_url ) {
		if ( strpos( $source_url, 'youtu' ) > 0 ) {
			return 'youtube';
		} elseif ( strpos( $source_url, 'vimeo' ) > 0 ) {
			return 'vimeo';
		} elseif ( strpos( $source_url, 'mp4' ) > 0 ) {
			return 'mp4';
		} elseif ( strpos( $source_url, 'ogv' ) > 0 ) {
			return 'ogv';
		} elseif ( strpos( $source_url, 'webm' ) > 0 ) {
			return 'webm';
		}
	}

	public static function render_html( $pagepath, $data = array() ) {
		$pagepath = self::get_application_path() . ' / ' . $pagepath . ' . php';
		@extract( $data );
		ob_start();
		include( $pagepath );

		return ob_get_clean();
	}

	public static function add_json_encode() {
		$val   = $_REQUEST['result_code'];
		$val   = array( 'val' => $val );
		$value = urlencode( json_encode( $val ) );
		echo $value;
		die();
	}

	public static function get_post_taxonomies() {
		$post_type  = $_REQUEST['post_type'];
		$tax_arr    = array();
		$html       = '';
		$taxonomies = get_object_taxonomies( $post_type, 'objects' );
		foreach ( $taxonomies as $key => $taxonomy ) {
			$tax_arr[ $taxonomy->label ] = $key;
			$html .= '<option class="' . $key . '" value="' . $key . '">' . $taxonomy->label . '</option>';
		}
		echo $html;
		die();
	}

	public static function get_post_terms() {
		$term      = $_REQUEST['tax'];
		$html      = '';
		$terms_arr = array();
		$terms     = get_terms( array(
			'taxonomy'   => array( $term ),
			'hide_empty' => false,
		) );
		foreach ( $terms as $term ) {
			$terms_arr[ $term->name ] = $term->slug;
			$html .= '<option class="' . $term->slug . '" value="' . $term->slug . '">' . $term->name . '</option>';
		}
		echo $html;
		die();
	}

	public static function get_posts_to_add() {
		$data              = array();
		$data['post_type'] = $_REQUEST['post_type'];

		if ( isset( $data['post_type'] ) ) {
			$args      = array(
				'post_type'        => $data['post_type'],
				'posts_per_page'   => - 1,
				'post_status'      => 'any',
				'suppress_filters' => false
			);
			$postslist = get_posts( $args );

			$html = '';

			//$html = "<ul class='slider_item_list_popup'>";
			foreach ( $postslist as $id => $post ) {
				$img_src        = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' );
				$data['imgurl'] = ( isset( $img_src[0] ) ) ? $img_src[0] : 'http://placehold.it/185x185&text=IMAGE';
				$data['title']  = $post->post_title;
				$data['author'] = $post->post_author;

				$data['date'] = array(
					'j_M_Y'           => mysql2date( 'j M Y', $post->post_date ),
					'F_j_Y_g_i'       => mysql2date( 'F j, Y g:i', $post->post_date ),
					'F_j_Y'           => mysql2date( 'F j, Y', $post->post_date ),
					'F_Y'             => mysql2date( 'F, Y', $post->post_date ),
					'l_F_jS_Y'        => mysql2date( 'l, F jS, Y', $post->post_date ),
					'M_j_Y_G_i'       => mysql2date( 'M j, Y @ G:i', $post->post_date ),
					'Y_m_d_a_t_g_i_A' => mysql2date( 'Y / m / d \a\t g:i A', $post->post_date ),
					'Y_m_d_a_t_g_ia'  => mysql2date( 'Y / m / d \a\t g:ia', $post->post_date ),
					'Y_m_d_g_i_s_A'   => mysql2date( 'Y / m / d g:i:s A', $post->post_date ),
					'Y_m_d'           => mysql2date( 'Y / m / d', $post->post_date )
				);

				$data['excerpt'] = $post->post_excerpt;
				$data['guid']    = get_permalink( $post->ID );

				//foreach ( $products as $product ) {
				$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' );
				$html .= '<li data-id="' . $post->ID . '" class="slider_item" >
							<div class="gallery_thumb" style = "background-image: url(' . $data['imgurl'] . '); width:185px; height:180px; background-size: cover;"></div>
							<div class="slider_item_title">
					            <h3> ' . $data['title'] . ' </h3>
					        </div>
						</li> ';
				//}


				//echo self::render_html( 'views / admin / render_item_from_post_type', $data );
			};
			//$html .= "</ul>";
			echo $html;
		};
		exit;
	}

	public function radio_settings( $settings, $value ) {
		$value_arr = $value_inner = $value;

		$dependency = '';

		//$dependency = vc_generate_dependencies_attributes( $settings );
		//$dependency = function_exists('vc_generate_dependencies_attributes') ? vc_generate_dependencies_attributes($settings) : '';

		$html = '';
		//$st = '<div class="brs-radio-wrapper"><input type="hidden" name="' . esc_attr( $settings['param_name'] ) . '" class="wpb_vc_param_value brs-radio ' . esc_attr( $settings['param_name'] ) . ' ' . $settings['type'] . '_field" value="' . esc_attr( $value_inner ) . '" ' . $dependency . ' />';
		$st = '<div class="brs-radio-wrapper"><input type="hidden" name="' . esc_attr( $settings['param_name'] ) . '" class="wpb_vc_param_value brs-radio ' . esc_attr( $settings['param_name'] ) . ' ' . $settings['type'] . '_field" value="' . esc_attr( $value_inner ) . '"' . $dependency . '/>';


		$meta  = $value;
		$field = array(
			'options'    => $settings['value'],
			'param_name' => $settings['param_name'],
			'images'     => $settings['images'],
			'images_dim' => $settings['images_dim']
		);

		$html .= BRS_Radio_Field::html( $html, $meta, $field );

		$html = $st . $html . '</div>';

		return $html;
	}

	// Get Font Weight

	public function images_settings_field( $settings, $value ) {
		$html             = "";
		$admin_images_uri = BERSERK_SHORTCODES_URL . '/shortcodes/images/';
		$images           = $settings['images'];
		$label            = '';
		foreach ( $images as $image ) {
			$label .= '<div class="vc_col-sm-2 vc_column"><label><img src="' . esc_url( $admin_images_uri . 'blank.gif' ) . '"  width="' . $settings['images_dim']['w'] . '" height="' . $settings['images_dim']['h'] . '" style="' . "background-image:url('" . esc_url( $admin_images_uri . $image ) . "');" . '"></label></div>';
		}
		$html .= "<div class='brs-images-wrapper'>" . $label . "</div>";

		return $html;
	}

	public function brk_devices_field( $settings, $value ) {
		$html             = "";
		$admin_images_uri = BERSERK_SHORTCODES_URL . 'shortcodes/images/';
		$images           = $settings['images'];
		$label            = '';
		foreach ( $images as $image ) {
			$label .= '<div class="vc_col-sm-2 vc_col-sm-five vc_column"><label><img src="' . esc_url( $admin_images_uri . 'blank.gif' ) . '"  width="' . $settings['images_dim']['w'] . '" height="' . $settings['images_dim']['h'] . '" style="' . "background-image:url('" . esc_url( $admin_images_uri . $image ) . "');" . '"></label></div>';
		}
		$html .= "<div class='brs-images-wrapper'>" . $label . "</div>";

		return $html;
	}

	public function color_scheme( $settings, $value ) {
		$value_arr = $value_inner = $value;
		$html      = "";
		$colors    = $settings['colors'];
		$label     = '';
		foreach ( $colors as $color ) {
			$current = '';
			if ( $color == $value_inner ) {
				$current = ' current-item';
			}
			$label .= '<div data-color="' . $color . '" class="color ' . $color . $current . '"><div class="media-modal-icon"></div></div>';
		}
		$html .= '<div class="brs-colors-wrapper">' . $label . '<input type="hidden" name="' . esc_attr( $settings['param_name'] ) . '" class="wpb_vc_param_value brs-color-scheme ' . esc_attr( $settings['param_name'] ) . ' ' . $settings['type'] . '_field" value="' . esc_attr( $value_inner ) . '"  /></div>';

		return $html;
	}

	public function video_upload( $settings, $value ) {
		$value_arr = $value_inner = $value;
		$html      = '<input type="text" name="' . esc_attr( $settings['param_name'] ) . '" class="wpb_vc_param_value brs-video-upload ' . esc_attr( $settings['param_name'] ) . ' ' . $settings['type'] . '_field" value="' . esc_attr( $value_inner ) . '" />
				<a title="" class="button brs_button_upload" data-type="video" href="#">
					' . __( "Browse", "berserk" ) . '
				</a>
				';

		return $html;
	}

	public function title_settings_field( $settings, $value ) {

		if ( ! empty( $settings['heading'] ) ) {
			return '<input type="hidden" name="' . $settings['param_name'] . '" class="wpb_vc_param_value" value="" />';
		}

	}

	// Get text colors

	public function notice_settings_field( $settings, $value ) {

		if ( ! empty( $settings['heading'] ) ) {
			return '<input type="hidden" name="' . $settings['param_name'] . '" class="wpb_vc_param_value" value="" />';
		}

	}

	// Get Gradients

	public function btn_settings_field( $settings, $value ) {

		if ( ! empty( $settings['heading'] ) ) {

			//$val = array('val'=>$value);

			//$value = urlencode( json_encode($val));

			return "<a href='javascript:' id='lievo-add-button' class='button brs_lievo_add' title='Add LivIcon'><span class='lievo-add-button-icon'></span>Add LivIcon</a><br><br><input type='text' name='" . $settings['param_name'] . "' class='wpb_vc_param_value' value='" . $value . "' />";
		}

	}

	// Get Background Colors

	public function add_product( $settings, $value ) {

		if ( ! empty( $settings['heading'] ) ) {
			$html = "";
			$html .= "<a href='#' id='brs-add-product' class='button' title='Add Product'>" . esc_html( 'Add Product', 'berserk' ) . "</a><input type='hidden' name='" . $settings['param_name'] . "' class='wpb_vc_param_value' value='" . esc_attr( $value ) . "' />";

			return $html;
		}

	}

	public function add_product_multiple( $settings, $value ) {

		if ( ! empty( $settings['heading'] ) ) {
			$html = "";
			$html .= "<a href='#' id='brs-add-product-multiple' class='button' title='Add Products'>" . esc_html( 'Add Products', 'berserk' ) . "</a><input type='hidden' name='" . $settings['param_name'] . "' class='wpb_vc_param_value' value='" . esc_attr( $value ) . "' />";

			return $html;
		}

	}

	public function add_custom_post_type( $settings, $value ) {

		if ( ! empty( $settings['heading'] ) ) {
			$html        = "";
			$types_array = self::get_all_post_types();

			$html .= "<a href='javascript:brs_vc_admin_custom_post.add_custom_post_type(\"add_slide_post_type_popup\");void(0);' id='brs-add-custom-post' class='button' title='Add Custom Post'>" . esc_html( 'Add Custom Post', 'berserk' ) . "</a><input type='hidden' name='" . $settings['param_name'] . "' class='wpb_vc_param_value' value='" . esc_attr( $value ) . "' />
			<div id=\"add_slide_post_type_popup\" style=\"display: none;\">
				<input type=\"hidden\" id=\"popupseclevel\" value=\"1\"/>";
			$html .= "<select class='select_item_post_type'>";
			foreach ( $types_array as $key => $type ) {
				$html .= "<option value='" . $type . "'>" . $key . "</option>";
			}
			$html .= "</select>";
			$html .= "<a class=\"fenix_grid_load_posts button button-secondary\" href=\"#\">" . esc_html( 'Load Posts', 'berserk' ) . "</a>
				<a class=\"fenix_grid_remove_posts button button-secondary\"
				   href=\"#\">" . esc_html( 'Remove All Loaded Posts', 'berserk' ) . "</a>
				<ul class='slider_item_list_popup'></ul>
				<div class=\"clear\"></div>
			</div>";

			return $html;
		}

	}

	public static function get_all_post_types() {
		$types_array = array();
		$post_types  = get_post_types( array(), 'object' );
		foreach ( $post_types as $post_type ) {
			if ( ( $post_type->name != 'nav_menu_item' ) && ( $post_type->name != 'revision' ) && ( $post_type->name != 'attachment' ) ) {
				$types_array[ $post_type->label ] = $post_type->name;
			}
		}

		return $types_array;
	}

	//ajax

	public function post_filters( $settings, $value ) {
		$html = '';

		// Post types
		$types_array = self::get_all_post_types();
		$html .= '<div class="vc_col-sm-6 vc_column"><div class="wpb_element_label">' . esc_html( 'Post type', 'berserk' ) . '</div>
					<select name="post_type" class="wpb_vc_param_value wpb-input wpb-select post_type dropdown post" data-option="post">';
		foreach ( $types_array as $key => $value ) {
			$html .= '<option class="' . $key . '" value="' . $key . '">' . $value . '</option>';
		}
		$html .= '</select></div>';

		//Taxonomies
		//$taxonomies = get_taxonomies();
		$taxonomies = get_object_taxonomies( 'post', 'objects' );
		$html .= '<div class="vc_col-sm-6 vc_column"><div class="wpb_element_label">' . esc_html( 'Taxonomy', 'berserk' ) . '</div>
					<select name="post_taxonomy" class="wpb_vc_param_value wpb-input wpb-select post_taxonomy dropdown post" data-option="post">';
		foreach ( $taxonomies as $key => $value ) {
			$html .= '<option class="' . $key . '" value="' . $key . '">' . $value->label . '</option>';
		}
		$html .= '</select></div>';

		//Post post_status
		$post_statuses = get_post_statuses();
		$html .= '<div class="vc_col-sm-6 vc_column"><div class="wpb_element_label">' . esc_html( 'Post Status', 'berserk' ) . '</div>
					<select name="post_status" class="wpb_vc_param_value wpb-input wpb-select post_status dropdown post" data-option="post">';
		foreach ( $post_statuses as $key => $value ) {
			$html .= '<option class="' . $key . '" value="' . $key . '">' . $value . '</option>';
		}
		$html .= '</select></div>';

		//Order by
		$orderby = array(
			'ID'       => 'ID',
			'title'    => 'Title',
			'date'     => 'Date',
			'modified' => 'Modified'
		);
		$html .= '<div class="vc_col-sm-6 vc_column"><div class="wpb_element_label">' . esc_html( 'Order by', 'berserk' ) . '</div>
					<select name="orderby" class="wpb_vc_param_value wpb-input wpb-select orderby dropdown ID" data-option="ID">';
		foreach ( $orderby as $key => $value ) {
			$html .= '<option class="' . $key . '" value="' . $key . '">' . $value . '</option>';
		}
		$html .= '</select></div>';

		//Order
		$order = array(
			'ASC'  => 'ASC',
			'DESC' => 'DESC',
		);
		$html .= '<div class="vc_col-sm-6 vc_column"><div class="wpb_element_label">' . esc_html( 'Direction', 'berserk' ) . '</div>
					<select name="order" class="wpb_vc_param_value wpb-input wpb-select orderby dropdown ASC" data-option="ASC">';
		foreach ( $order as $key => $value ) {
			$html .= '<option class="' . $key . '" value="' . $key . '">' . $value . '</option>';
		}
		$html .= '</select></div>';

		//Post with thumb
		$html .= '<div class="vc_col-sm-6 vc_column"><div class="wpb_element_label">' . esc_html( 'Post with Thumbnail', 'berserk' ) . '</div>';
		$settings = array(
			'heading'          => __( 'Posts with Thumbnail', 'berserk' ),
			'param_name'       => 'post_thumb',
			'value'            => 'y',
			'options'          => array(
				'Yes' => 'y',
				'No'  => 'n',
			),
			'edit_field_class' => 'vc_col-sm-6 vc_column'
		);

		$html .= self::switch_param( $settings );


		return $html;

	}

	public function switch_param( $settings, $value ) {
		if ( ! $value ) {
			$value = $settings['value'];
		}

		list( $on, $off ) = array_values( $settings['options'] );
		list( $on_title, $off_title ) = array_keys( $settings['options'] );

		$values_attr = json_encode( array( $on, $off ) );
		$param_name  = $settings['param_name'];
		$id          = 'brs_switch-' . $param_name;

		return '<div class="brs-onoffswitch">'
		       . '<input type="checkbox" id="' . esc_attr( $id ) . '" name="' . esc_attr( $param_name ) . '" data-values="' . esc_attr( $values_attr ) . '" value="' . esc_attr( $value ) . '" class="wpb_vc_param_value brs-onoffswitch-checkbox ' . esc_attr( $param_name ) . ' ' . esc_attr( $settings['type'] ) . '_type" ' . checked( $value, $on, false ) . '>'
		       . '<label class="brs-onoffswitch-label" for="' . esc_attr( $id ) . '">'
		       . '<div class="brs-onoffswitch-inner">'
		       . '<div class="brs-onoffswitch-active">'
		       . '<div class="brs-onoffswitch-switch">' . esc_html( $on_title ) . '</div>'
		       . '</div>'
		       . '<div class="brs-onoffswitch-inactive">'
		       . '<div class="brs-onoffswitch-switch">' . esc_html( $off_title ) . '</div>'
		       . '</div>'
		       . '</div>'
		       . '</label>'
		       . '</div>';
	}

	/**
	 * Register params.
	 */
	public function register_params() {

		$this->compatible_vc_add_shortcode_param( 'brs_radio', array(
			$this,
			'radio_settings'
		), BERSERK_SHORTCODES_URL . '/shortcodes/vc_extend/brs-vc-scripts.js' );

		if ( class_exists( 'VcTemplateManager' ) ) {
			$this->compatible_vc_add_shortcode_param( 'brs_radio_templatera', array(
				$this,
				'radio_settings'
			), BERSERK_SHORTCODES_URL . '/shortcodes/vc_extend/brs-vc-scripts.js' );
		}
		$this->compatible_vc_add_shortcode_param( 'brs_switch', array(
			$this,
			'switch_param'
		), BERSERK_SHORTCODES_URL . '/shortcodes/vc_extend/brs-vc-scripts.js' );

		$this->compatible_vc_add_shortcode_param( 'brs_title', array( $this, 'title_settings_field' ) );
		$this->compatible_vc_add_shortcode_param( 'brs_notice', array( $this, 'notice_settings_field' ) );
		$this->compatible_vc_add_shortcode_param( 'brs_btn_icon', array(
			$this,
			'btn_settings_field'
		), BERSERK_SHORTCODES_URL . '/shortcodes/vc_extend/brs-vc-scripts.js' );

		$this->compatible_vc_add_shortcode_param( 'brs_images', array( $this, 'images_settings_field' ) );

		$this->compatible_vc_add_shortcode_param( 'brk_devices', array( $this, 'brk_devices_field' ) );

		$this->compatible_vc_add_shortcode_param( 'brs_color_scheme', array(
			$this,
			'color_scheme'
		), BERSERK_SHORTCODES_URL . '/shortcodes/vc_extend/brs-vc-scripts.js' );

		$this->compatible_vc_add_shortcode_param( 'brs_video_upload', array(
			$this,
			'video_upload'
		), BERSERK_SHORTCODES_URL . '/shortcodes/vc_extend/brs-vc-scripts.js' );

		$this->compatible_vc_add_shortcode_param( 'brs_add_product', array(
			$this,
			'add_product'
		), BERSERK_SHORTCODES_URL . '/shortcodes/vc_extend/brs-vc-scripts.js' );

		$this->compatible_vc_add_shortcode_param( 'brs_add_product_multiple', array(
			$this,
			'add_product_multiple'
		), BERSERK_SHORTCODES_URL . '/shortcodes/vc_extend/brs-vc-scripts.js' );

		$this->compatible_vc_add_shortcode_param( 'brs_add_custom_post_type', array(
			$this,
			'add_custom_post_type'
		), BERSERK_SHORTCODES_URL . '/shortcodes/vc_extend/brs-vc-custom-post.js' );

		$this->compatible_vc_add_shortcode_param( 'brs_post_filters', array(
			$this,
			'post_filters'
		), BERSERK_SHORTCODES_URL . '/shortcodes/vc_extend/brs-vc-custom-post.js' );

	}

	public function compatible_vc_add_shortcode_param( $name, $form_field_callback, $script_url = null ) {
		if ( defined( 'WPB_VC_VERSION' ) && version_compare( WPB_VC_VERSION, 4.4 ) >= 0 ) {
			if ( function_exists( 'vc_add_shortcode_param' ) ) {
				vc_add_shortcode_param( $name, $form_field_callback, $script_url );
			}
		} else {
			if ( function_exists( 'add_shortcode_param' ) ) {
				add_shortcode_param( $name, $form_field_callback, $script_url );
			}
		}
	}

	public function add_live_mode() {
		$val = $_REQUEST['value'];
		update_option( 'brs_vc_live_mode', $val );
		die();
	}

}

//if ( class_exists( 'WPBakeryShortCode' ) ) {

// Add VC params.
new BRS_Shortcodes_VCParams();

//}