<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Shortcode attributes
 * @var $el_id
 * @var $el_class
 * @var $anchor
 * @var $min_height
 * @var $margin_top
 * @var $margin_bottom
 * @var $full_width
 * @var $full_width_row
 * @var $padding_left
 * @var $padding_right
 * @var $animation
 * @var $type
 * @var $bg_color
 * @var $bg_image
 * @var $bg_position
 * @var $bg_repeat
 * @var $bg_cover
 * @var $bg_attachment
 * @var $padding_top
 * @var $padding_bottom
 * @var $enable_parallax
 * @var $parallax_speed
 * @var $bg_video_src_mp4
 * @var $bg_video_src_ogv
 * @var $bg_video_src_webm
 * @var $content - shortcode content
 * Shortcode class
 * @var $this WPBakeryShortCode_VC_Row
 */
$output = $after_output = $before_output = '';
$el_id  = $el_class = $anchor = $min_height = $margin_top = $margin_bottom = $overlay_output = $svg_pattern_top = $svg_pattern_bottom = $animated_backgrounds_output = $delimiter_before_svg = $trapezoid_type = $before_svg = $delimiter_after_svg = $after_svg = $full_width = $full_width_content = $full_width_row = $padding_left = $padding_right = $animation = $type = $bg_color = $bg_image = $bg_position = $bg_repeat = $bg_cover = $bg_attachment = $padding_top = $padding_bottom = $enable_parallax = $parallax_speed = $bg_video_src_mp4 = $bg_video_src_ogv = $bg_video_src_webm = '';

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

wp_enqueue_script( 'wpb_composer_front_js' );

$el_class = $this->getExtraClass( $el_class );

$css_classes        = array(
	'vc_row',
	'wpb_row', //deprecated
	'vc_row-fluid',
	$el_class,
);
$wrapper_attributes = array();
$wrapper_style      = array();


if ( $type ) {

	$before_classes = array();
	$before_attr    = array();

	if ( is_singular( 'brs_header' ) ) {
		$full_width_content = 'true';
		$full_width         = 'true';
	}

	if ( isset( $row_no_gutter ) && $row_no_gutter == 'true' ) {
		$css_classes[] = 'row-no-gutter';
	}

	if ( $column_padding == 'none' ) {
		$css_classes[] = 'row-no-gutter';
	}

	switch ( $column_padding ) {
		case "none":
			$css_classes[] = 'no-gutters';
			break;
		case "brk-gutters-5":
		case "brk-gutters-10":
			$css_classes[] = $column_padding;
			break;
	}

	if ( $row_visible == 'true' ) {
		$before_classes[] = 'visible';
	}
	if ( $hide_overflow == 'true' ) {
		$before_classes[] = 'overflow-hid';
	}

	if ( $crossing_type !== 'none' ) {
		switch ( $crossing_type ) {
			case "top_triangle":
				$before_classes[] = 'top-triangle';
				break;
			case "top-triangle":
				$before_classes[] = 'brk-top-triangle';
				break;
			case "bottom-triangle":
				$before_classes[] = 'brk-bottom-triangle';
				break;

		}
	}


	if ( $row_wave_hover == 'true' ) {
		$css_classes[] = 'wave-hover';

		$wrapper_attributes[] = 'data-wh-speed="' . esc_attr( $data_speed ) . '"';

		if ( $data_repeat == 'true' ) {
			$wrapper_attributes[] = 'data-wh-repeat="true"';
		}
		if ( isset( $data_delay ) && ! empty( $data_delay ) ) {
			$wrapper_attributes[] = 'data-wh-delay="' . $data_delay . '"';
		}
	}

	if ( $full_width != 'true' && $row_max_width != 'maxw-770' && $row_max_width != 'maxw-970' && $row_max_width != 'maxw-450' ) {
		$before_classes[] = 'container';
	}


	if ( $all_light == 'true' ) {
		$before_classes[] = 'all-light';
	}

	if ( $side_circles == 'true' ) {
		$before_classes[] = 'side-circles';
	}

	if ( $row_max_width != 'none' ) {
		$before_classes[] = $row_max_width;
	}

	// Margin Top
	if ( $screen_margin_top !== '' ) {
		$before_classes[] = 'mt-' . $screen_margin_top;
	}
	if ( $desktop_margin_top !== '' ) {
		$before_classes[] = 'mt-lg-' . $desktop_margin_top;
	}
	if ( $tablet_margin_top !== '' ) {
		$before_classes[] = 'mt-md-' . $tablet_margin_top;
	}
	if ( isset( $tablet_landscape_margin_top ) ) {
		if ( $tablet_landscape_margin_top !== '' ) {
			$before_classes[] = 'mt-md-' . $tablet_landscape_margin_top;
		}
	}
	if ( $mobile_margin_top !== '' ) {
		$before_classes[] = 'mt-sm-' . $mobile_margin_top;
	}
	if ( isset( $mobile_landscape_margin_top ) ) {
		if ( $mobile_landscape_margin_top !== '' ) {
			$before_classes[] = 'mt-xs-' . $mobile_landscape_margin_top;
		}
	}

	// Margin Bottom
	if ( $screen_margin_bottom !== '' ) {
		$before_classes[] = 'mb-' . $screen_margin_bottom;
	}
	if ( $desktop_margin_bottom !== '' ) {
		$before_classes[] = 'mb-lg-' . $desktop_margin_bottom;
	}
	if ( $tablet_margin_bottom !== '' ) {
		$before_classes[] = 'mb-md-' . $tablet_margin_bottom;
	}
	if ( isset( $tablet_landscape_margin_bottom ) ) {
		if ( $tablet_landscape_margin_bottom !== '' ) {
			$before_classes[] = 'mb-md-' . $tablet_landscape_margin_bottom;
		}
	}
	if ( $mobile_margin_bottom !== '' ) {
		$before_classes[] = 'mb-sm-' . $mobile_margin_bottom;
	}
	if ( isset( $mobile_landscape_margin_bottom ) ) {
		if ( $mobile_landscape_margin_bottom !== '' ) {
			$before_classes[] = 'mb-xs-' . $mobile_landscape_margin_bottom;
		}
	}

	// Padding Top
	if ( $screen_padding_top !== '' ) {
		$before_classes[] = 'pt-' . $screen_padding_top;
	}
	if ( $desktop_padding_top !== '' ) {
		$before_classes[] = 'pt-lg-' . $desktop_padding_top;
	}
	if ( $tablet_padding_top !== '' ) {
		$before_classes[] = 'pt-md-' . $tablet_padding_top;
	}
	if ( isset( $tablet_landscape_padding_top ) ) {
		if ( $tablet_landscape_padding_top !== '' ) {
			$before_classes[] = 'pt-md-' . $tablet_landscape_padding_top;
		}
	}
	if ( $mobile_padding_top !== '' ) {
		$before_classes[] = 'pt-sm-' . $mobile_padding_top;
	}
	if ( isset( $mobile_landscape_padding_top ) ) {
		if ( $mobile_landscape_padding_top !== '' ) {
			$before_classes[] = 'pt-xs-' . $mobile_landscape_padding_top;
		}
	}

	// Padding Bottom
	if ( $screen_padding_bottom !== '' ) {
		$before_classes[] = 'pb-' . $screen_padding_bottom;
	}
	if ( $desktop_padding_bottom !== '' ) {
		$before_classes[] = 'pb-lg-' . $desktop_padding_bottom;
	}
	if ( $tablet_padding_bottom !== '' ) {
		$before_classes[] = 'pb-md-' . $tablet_padding_bottom;
	}
	if ( isset( $tablet_landscape_padding_bottom ) ) {
		if ( $tablet_landscape_padding_bottom !== '' ) {
			$before_classes[] = 'pb-md-' . $tablet_landscape_padding_bottom;
		}
	}
	if ( $mobile_padding_bottom !== '' ) {
		$before_classes[] = 'pb-sm-' . $mobile_padding_bottom;
	}
	if ( isset( $mobile_landscape_padding_bottom ) ) {
		if ( $mobile_landscape_padding_bottom !== '' ) {
			$before_classes[] = 'pb-xs-' . $mobile_landscape_padding_bottom;
		}
	}


	$style = array();

	if ( $bg_color ) {
		$style[] = 'background-color: ' . $bg_color;
	}

	if ( $border_radius ) {
		$style[] = 'border-radius:' . esc_attr( $border_radius ) . 'px';

	}

	if ( $custom_css && ! empty( $custom_css ) ) {
		$before_classes[] = $custom_css;
		//$before_classes[] = 'bg__style';
	}

	if ( $bg_type !== 'none' ) {

		if ( $use_custom_background == 'yes' ) {
			$image   = wp_get_attachment_image_src( $bg_image, 'full' );
			$image   = $image[0];
			$style[] = 'background-image: url(' . esc_url( $image ) . ')';
		} else {
			if ( $pattern_type != 'none' && $pattern_type != "brk-bgi-13" ) {
				$before_classes[] = $pattern_type;
			}
			$before_classes[] = 'brk-bg-pattern';
		}

		if(isset( $background_size) && ( $background_size !='none')){
			$before_classes[] = $background_size;
		}
		if(isset( $background_repeat) && ( $background_repeat !='none')){
			$before_classes[] = $background_repeat;
		}
		if(isset( $background_position) && ( $background_position !='none')){
			$before_classes[] = $background_position;
		}
	}

	if ( $bg_type && $bg_type == 'parallax_image' ) {
		$before_classes[] = 'parallax-bg';
		$before_classes[] = 'overflow-hid';
	}

	if ( $row_full_height && $row_full_height == 'true' ) {
		$css_classes[] = 'full-height';
	}

	$content_after = '';
	if ( $row_type && $row_type != 'none' ) {

		$content_after = '<span class="after"></span>';
		brs_add_libraries( 'component__parallax' );

		switch ( $row_type ) {
			case "corner":
				$afrer_class = '';
				$after_style = '';
				switch ( $content_bg ) {
					case "white":
						$afrer_class = 'brk-parallax__bg-color';
						break;
					case "gradient":
						$afrer_class = 'brk-parallax__bg-gradient';
						$after_style = 'background: linear-gradient(to right,' . $row_color_f . ',' . $row_color_s . ');';
						break;
				}
				$content_after = '<span style="' . $after_style . '" class="parallax__bg-shape-lg ' . $afrer_class . '"></span>';

				$css_classes[] = 'scroll-show';
				$css_classes[] = 'corner__wrap';
				break;

			case "circle":
				$afrer_class = '';
				$after_style = '';
				switch ( $content_bg ) {
					case "white":
						$afrer_class = 'brk-parallax__bg-color';
						break;
					case "gradient":
						$afrer_class = 'brk-parallax__bg-gradient';
						$after_style = 'background: linear-gradient(to right,' . $row_color_f . ',' . $row_color_s . ');';
						break;
				}
				$content_after = '<span style="' . $after_style . '" class="parallax__bg-shape-lg ' . $afrer_class . '"></span>';

				$css_classes[] = 'scroll-show';
				$css_classes[] = 'circle__wrap';
				break;

			case "triangle":
				$afrer_class = '';
				$after_style = '';
				switch ( $content_bg ) {
					case "white":
						$afrer_class = 'brk-parallax__bg-color';
						break;
					case "gradient":
						$afrer_class = 'brk-parallax__bg-gradient';
						$after_style = 'background: linear-gradient(to right,' . $row_color_f . ',' . $row_color_s . ');';
						break;
				}
				$content_after = '<span style="' . $after_style . '" class="parallax__bg-shape-lg ' . $afrer_class . '"></span>';

				$css_classes[] = 'scroll-show';
				$css_classes[] = 'triangle__wrap';
				break;

			case "round":


				switch ( $content_bg ) {
					case "white":

						if ( $slide_from == 'left' ) {

							$content_after = '<span class="parallax__bg-shape-lg brk-parallax__bg-color-md">
												  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1787 480" preserveAspectRatio="none">
													<defs><style>.a { fill: #fff; fill-rule: evenodd; }</style></defs>
													<path class="a" d="M1787,480c-132.55,0-240-107.45-240-240S1654.45,0,1787,0H0V480Z" />
												  </svg>
												</span>';

						} elseif ( $slide_from == 'right' ) {
							$content_after = '<span class="parallax__bg-shape-lg brk-parallax__bg-color-md">
												  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1787 480" preserveAspectRatio="none">
													<defs><style>.a { fill: #fff; fill-rule: evenodd; }</style></defs>
													<path class="a" d="M0,480c132.55,0,240-107.45,240-240S132.55,0,0,0H1787V480Z"/>
												  </svg>
												</span>';
						}

						break;
					case "gradient":
						$id = uniqid();

						if ( $slide_from == 'left' ) {
							$content_after = '<span class="parallax__bg-shape-lg brk-parallax__bg-gradient-md">
											  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1787 480">
												<defs><style>.b { fill-rule: evenodd; fill: url(#' . $id . '); }</style>
												  <linearGradient id="' . $id . '" y1="240" x2="1787" y2="240" gradientUnits="userSpaceOnUse">
													<stop offset="0%" stop-color="' . $row_color_f . '"/>
													<stop offset="100%" stop-color="' . $row_color_s . '"/>
												  </linearGradient>
												</defs>
												<path class="b" d="M1787,480c-132.55,0-240-107.45-240-240S1654.45,0,1787,0H0V480Z" />
											  </svg>
											</span>';

						} elseif ( $slide_from == 'right' ) {
							$content_after = '<span class="parallax__bg-shape-lg brk-parallax__bg-gradient-md">
											  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1787 480">
												<defs><style>.b { fill-rule: evenodd; fill: url(#' . $id . '); }</style>
												  <linearGradient id="' . $id . '" y1="240" x2="1787" y2="240" gradientUnits="userSpaceOnUse">
													<stop offset="0%" stop-color="' . $row_color_f . '"/>
													<stop offset="50%" stop-color="' . $row_color_s . '"/>
												  </linearGradient>
												</defs>
												 <path class="b" d="M0,480c132.55,0,240-107.45,240-240S132.55,0,0,0H1787V480Z"/>
											  </svg>
											</span>';

						}


						break;
				}

				$css_classes[] = 'scroll-show';
				$css_classes[] = 'round__wrap';
				break;


			case "wing":
				switch ( $content_bg ) {
					case "white":

						if ( $slide_from == 'left' ) {

							$content_after = '<span class="parallax__bg-shape-lg brk-parallax__bg-color-md">
												  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 790 170" xml:space="preserve" preserveAspectRatio="none" fill="#fff">
													<path d="M793.7,170.08H0V0H793.7ZM793.7,0H396.85c4.2,10.86,27.55,71.05,49.53,115.54,3.4,6.88,9.44,18.8,21.73,28.26,14.05,10.82,28.89,12.76,36.59,13.55,29.41,3,139.45,8.52,289,12.72Z"/>
												  </svg>
												</span>';

						} elseif ( $slide_from == 'right' ) {
							$content_after = '<span class="parallax__bg-shape-lg brk-parallax__bg-color-md">
												  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 790 170" xml:space="preserve" preserveAspectRatio="none" fill="#fff">
													<path d="M0,0H793.7V170.08H0ZM0,170.08c149.56-4.21,259.59-9.69,289-12.72,7.7-.79,22.53-2.73,36.59-13.55,12.29-9.47,18.34-21.39,21.73-28.26C369.3,71.05,392.65,10.86,396.85,0H0Z"/>
												  </svg>
												</span>';

						}

						break;
					case "gradient":
						$id = uniqid();

						if ( $slide_from == 'left' ) {
							$content_after = '<span class="parallax__bg-shape-lg brk-parallax__bg-gradient-md">
												  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 790 170" xml:space="preserve" preserveAspectRatio="none" fill="url(#' . $id . ')">
													<defs>
														<linearGradient id="' . $id . '" x1="0" y1="0" x2="1" y2="0">
														  <stop offset="0%" stop-color="' . $row_color_f . '"/>
														  <stop offset="100%" stop-color="' . $row_color_s . '"/>
														</linearGradient>
													</defs>
													<path d="M793.7,170.08H0V0H793.7ZM793.7,0H396.85c4.2,10.86,27.55,71.05,49.53,115.54,3.4,6.88,9.44,18.8,21.73,28.26,14.05,10.82,28.89,12.76,36.59,13.55,29.41,3,139.45,8.52,289,12.72Z"/>
												  </svg>
												</span>';

						} elseif ( $slide_from == 'right' ) {
							$content_after = '<span class="parallax__bg-shape-lg brk-parallax__bg-gradient-md">
												  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 790 170" xml:space="preserve" preserveAspectRatio="none" fill="url(#' . $id . ')">
													<defs>
														<linearGradient id="' . $id . '" x1="0" y1="0" x2="1" y2="0">
														  <stop offset="0%" stop-color="' . $row_color_f . '"/>
														  <stop offset="100%" stop-color="' . $row_color_s . '"/>
														</linearGradient>
													</defs>
													<path d="M0,0H793.7V170.08H0ZM0,170.08c149.56-4.21,259.59-9.69,289-12.72,7.7-.79,22.53-2.73,36.59-13.55,12.29-9.47,18.34-21.39,21.73-28.26C369.3,71.05,392.65,10.86,396.85,0H0Z"/>
												  </svg>
												</span>';
						}

						break;
				}

				$css_classes[] = 'scroll-show';
				$css_classes[] = 'wing__wrap';

				break;

			case "double_triangle":

				//brs_add_libraries( 'component__parallax' );

				switch ( $content_bg ) {
					case "white":

						$content_after = '<span class="parallax__bg-shape-sm brk-parallax__bg-gradient"></span>';
						$content_after .= '<span class="parallax__bg-shape-lg brk-parallax__bg-color"></span>';

						break;
					case "gradient":

						$content_after = '<span class="parallax__bg-shape-sm brk-parallax__bg-color"></span>';
						$content_after .= '<span class="parallax__bg-shape-lg brk-parallax__bg-gradient"></span>';

						/*$after_style   = 'background: linear-gradient(to right,' . $row_color_f . ',' . $row_color_s . ');';
						$content_after = '<span class="parallax__bg-shape-sm brk-parallax__bg-color"></span>
										<span style="' . $after_style . '" class="parallax__bg-shape-lg brk-parallax__bg-gradient"></span>';*/
						break;
				}

				$css_classes[] = 'scroll-show';
				$css_classes[] = 'triangle__wrap';
				$css_classes[] = 'triangle__wrap-double';

				break;

		}
	}
	if ( $slide_from ) {
		switch ( $slide_from ) {
			case "left":
				$css_classes[] = 'content__side-left';
				break;
			case "right":
				$css_classes[] = 'content__side-right';
				break;
		}
	}

	if ( $delimiter_type ) {
		brs_add_libraries( 'component__delimiters' );
		brs_add_libraries( 'component__svg_pattern' );
		switch ( $delimiter_type ) {
			case "circle":
				$before_classes[] = 'delimiter__circle';
				$before_classes[] = 'position-relative';

				$overlay_output = '<span class="overlay__delimiter-before">
									  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 235.85">
										<defs>
											<style>.a1{fill:#fff; fill-rule:evenodd;}</style>
										</defs>
										<path class="a1" d="M1920,235.85S1576.38,109.42,960,109.42,0,235.85,0,235.85V0H1920Z"/>
									  </svg>
									</span>
									<span class="overlay__delimiter-after brk-base-bg-gradient-50deg-a"></span>';
				break;
			case "angle":
				$before_classes[] = 'delimiter__angle';
				$before_classes[] = 'overlay__gradient';

				$overlay_output = '<span class="overlay__delimiter-before">
									  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 162">
										<defs>
											<style>.a3{fill: url(#a3);}.a3,.b3{fill-rule:evenodd;}.b3{fill:#fff;}</style>
											<linearGradient id="a3" y1="240" x2="1787" y2="240" gradientUnits="userSpaceOnUse">
											  <stop offset="0%" stop-color="var(--brk-base-5)"/>
											  <stop offset="50%" stop-color="var(--brk-base-2)"/>
											</linearGradient>
										</defs>
										<polygon class="a3" points="1548 0 0 103 0 162 1920 162 1920 90.93 1548 0"/>
										<path class="b3" d="M1548,0l372,135v27H0Z"/>
									  </svg>
									</span>
									<span class="overlay__delimiter-after brk-base-bg-gradient-2"></span>';

				break;
			case "curve":
				$before_classes[] = 'delimiter__curve';
				$before_classes[] = 'overlay__gradient';

				$overlay_output = '<span class="overlay__delimiter-before">
									  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 197.02">
										<defs>
											<style>.a5{fill: url(#a5);}.a5,.b5{fill-rule:evenodd;}.b5{fill:#fff;}</style>
											<linearGradient id="a5" y1="240" x2="1787" y2="240" gradientUnits="userSpaceOnUse">
											  <stop offset="0%" stop-color="#0f85e0"/>
											  <stop offset="80%" stop-color="#8e0cdc"/>
											</linearGradient>
										</defs>
										<path class="a5"
											  d="M1231,109.07C974.2,70.21,708.37,12,477,1.12,258.44-9.18,54.57,54.45,0,78.08V197H1920V31.1S1603.21,165.38,1231,109.07Z"/>
										<path class="b5"
											  d="M1920,131.06s-316.79,72.31-689,16C974.2,108.19,706.37,41,475,30.1,256.44,19.81,54.57,70.55,0,94.18V197H1920Z"/>
									  </svg>
									</span>
									<span class="overlay__delimiter-after brk-base-bg-gradient-50deg-a"></span>';
				break;

			case "trapezoid":
				$before_classes[] = 'delimiter__trapezoid';
				$before_classes[] = 'overlay__gradient';
				$before_classes[] = 'pt-sm-130';
				$before_classes[] = 'pt-50';
				$before_classes[] = 'pb-60';
				$before_classes[] = 'pb-sm-160';
				$before_classes[] = 'mt-80';


				$grad_class = ( $overlay_style == 'overlay__gradient' && ( ! empty( $default_gradient ) ) ) ? $default_gradient : 'brk-base-bg-gradient-1';

				$overlay_output = '<span class="overlay__delimiter-before">
									  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 441" preserveAspectRatio="none">
										<defs>
											<style>.a6{fill:#fff;fill-rule:evenodd;}</style>
										</defs>
										<path class="a6" d="M1920,441V341L0,441ZM0,0,1920,100V0Z"/>
									  </svg>
									</span>
									<span class="overlay__delimiter-after ' . $grad_class . '"></span>';

				break;
			case "trapezoid_alternate":
				$before_classes[] = 'brk-trapezoid-' . $trapezoid_type;
				break;

			case "trapezoid_top":
				if ( $trapezoid_type == 'left' ) {
					$overlay_output = '<span class="brk-svg-pattern-container brk-svg-pattern-container-17 brk-svg-pattern-container_top brk-library-rendered" data-brk-library="component__svg_pattern"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1920 180">
											<g id="path-id-17-1">
												<g>
													<polygon fill="#FFFFFF" points="0,0 1920,180 1920,0"></polygon>
												</g>
											</g>
										</svg></span>';
				}
				if ( $trapezoid_type == 'right' ) {
					$overlay_output = '<span class="brk-svg-pattern-container brk-svg-pattern-container-18 brk-svg-pattern-container_top brk-library-rendered" data-brk-library="component__svg_pattern"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1920 180">
											<g id="path-id-18-1">
												<g>
													<polygon fill="#FFFFFF" points="0 0,1930 0,0 180,0 0"></polygon>
												</g>
											</g>
										</svg></span>';
				}

				break;

			case "trapezoid_gray":
				$before_classes[] = 'brk-testimonials-dash-three';
				$overlay_output   = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 110"><path d="M1920,110H0V0Z" style="fill:#f6f6f6"></path></svg>';

				break;

			case "flexion":
				$before_classes[] = 'brk-testimonials-layered-horizontal';
				$overlay_output   = '<span class="before-layer brk-base-bg-gradient-50deg-a"></span>
									<span class="after-layer"></span>
									<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 137.5"><path d="M0,0A3421.34,3421.34,0,0,0,953,137.49,3421.46,3421.46,0,0,0,1920,0" style="fill:#fff"/></svg>';

				break;
			case "corner":
				$before_classes[] = 'delimiter__corner';
				$before_classes[] = 'overlay__gradient';

				$overlay_output = '<span class="overlay__delimiter-before">
									  <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1920 266.56">
										<defs>
										  <style>.a4,.b4,.e4{fill:none;}.b4{stroke:#fff;stroke-miterlimit:10;stroke-width:0.25px;}.c4,.d4,.e4{fill-rule:evenodd;}.c4{fill:url(#a4);}.d4{fill:#fff;}</style>
										  <pattern id="a4" width="5" height="5" patternUnits="userSpaceOnUse" viewBox="0 0 5 5">
											<rect class="a4" width="5" height="5"/><line class="b4" x1="10" y1="5" x2="5" y2="10"/>
											<line class="b4" x1="5" y1="5" y2="10"/><line class="b4" y1="5" x2="-5" y2="10"/>
											<line class="b4" x1="10" x2="5" y2="5"/><line class="b4" x1="5" y2="5"/>
											<line class="b4" x2="-5" y2="5"/><line class="b4" x1="10" y1="-5" x2="5"/>
											<line class="b4" x1="5" y1="-5"/><line class="b4" y1="-5" x2="-5"/>
										  </pattern>
										</defs>
										<title>delimiter-5_2</title>
										<polygon class="c4" points="1380 93 545 79 0 10 0 155 1920 155 1380 93"/>
										<path class="d4" d="M1375,93,1920,0V266.56H0V155Z"/>
										<path class="e4" d="M1375,93,1920,0V155H0Z"/>
										<path class="e4" d="M1375,93,1920,0V155H0Z"/>
									  </svg>
									</span>
									<span class="overlay__delimiter-after brk-base-bg-gradient-3"></span>';
				break;
			case "rounded":
				$before_classes[] = 'delimiter__rounded';
				$before_classes[] = 'overlay__gradient';

				$overlay_output      = '<span class="overlay__delimiter-after brk-base-bg-gradient-4"></span>';
				$delimiter_after_svg = '<span class="overlay__delimiter-before absolute-bottom">
										  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 365.6">
											<defs>
												<style>.a2{fill: url(#a2);}.a2,.b2{fill-rule:evenodd;}.b2{fill:#fff;}</style>
												<linearGradient id="a2" y1="240" x2="1787" y2="240" gradientUnits="userSpaceOnUse">
												  <stop offset="0%" stop-color="#2775ff" stop-opacity=".5"/>
												  <stop offset="50%" stop-color="#00c6ff" stop-opacity=".5"/>
												</linearGradient>
											</defs>
											<path class="a2" d="M1920,365.6H0V233.21C487.24,89,1095.45-106.63,1920,70.34Z"/>
											<path class="b2" d="M0,343.21V365.6H1920V89.6C1125.22-68.53,13.61,337.23,0,343.21Z"/>
										  </svg>
										</span>';
				break;
			case "curves":

				$overlay_output = '<span class="brk-sc-item-page-section-2__svg-bg">
										<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1922" height="1623"
											 viewBox="0 0 1922 1623">
											<defs>
												<path id="xy8ha" d="M0 2592s411.73-10.8 844-103c640.73-149.29 1076-357 1076-357v1620H0z"/>
												<linearGradient id="xy8hb" x1="960" x2="960" y1="3752" y2="2132" gradientUnits="userSpaceOnUse">
													<stop offset="0" stop-color="#f2fcff"/>
													<stop offset="1" stop-color="#ebf7ff"/>
												</linearGradient>
											</defs>
											<g>
												<g transform="translate(1 -2130)">
													<use fill="red" xlink:href="#xy8ha"/>
													<use fill="url(#xy8hb)" xlink:href="#xy8ha"/>
												</g>
											</g>
										</svg>
									  </span>
									  <span class="brk-sc-item-page-section-2__svg-container">
										  <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="1920px"
										  height="277px" viewBox="0 0 1920 277" enable-background="new 0 0 1920 277" xml:space="preserve">
											   <g id="Shape_10_1_" enable-background="new">
												 <g id="Shape_10">
												   <g>
													 <linearGradient id="SVGID_1_11" gradientUnits="userSpaceOnUse" x1="960.0005" y1="276.999" x2="960.0005" y2="0.7793">
													   <stop  offset="0" style="stop-color:#15BDFF"/>
													   <stop  offset="1" style="stop-color:#00F6FF"/>
													 </linearGradient>
													 <path fill="url(#SVGID_1_11)" d="M1420,170.999c-264.209,81.183-385.061,38.809-895-110C319.539,1.042,140.531-6.536,0,5.783
													   v271.216h1920V60.511C1763.375,73.852,1598.687,116.096,1420,170.999z"/>
												   </g>
												 </g>
											   </g>
											   <g id="Shape_9_1_" enable-background="new">
												 <g id="Shape_9">
												   <g>
													 <path fill="#FFFFFF" d="M1294,149C730.998-17.98,210.142,80.934,0,135.381v141.618h1920v-36.195
													   C1810.955,257.711,1621.742,246.204,1294,149z"/>
												   </g>
												 </g>
											   </g>
											</svg>
									  </span>';

				break;

			case "bottom_curves":

				$before_classes[] = 'position-relative';

				$delimiter_after_svg = '<span class="brk-svg-pattern-container brk-svg-pattern-container-4 brk-svg-pattern-container_bottom brk-library-rendered" data-brk-library="component__svg_pattern">
												<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 1920 277" enable-background="new 0 0 1920 277" space="preserve">
													<g>
														<linearGradient id="path-id-4-1" gradientUnits="userSpaceOnUse" x1="960.0005" y1="276.999" x2="960.0005" y2="0.7793">
															<stop offset="0" style="stop-color:var(--brk-base-2);"></stop>
															<stop offset="1" style="stop-color:var(--brk-base-5);"></stop>
														</linearGradient>
														<path fill="url(#path-id-4-1)" d="M1420,170.999c-264.209,81.183-385.061,38.809-895-110C319.539,1.042,140.531-6.536,0,5.783 v271.216h1920V60.511C1763.375,73.852,1598.687,116.096,1420,170.999z"></path>
													</g>
													<g>
														<path fill="#FFFFFF" d="M1294,149C730.998-17.98,210.142,80.934,0,135.381v141.618h1920v-36.195 C1810.955,257.711,1621.742,246.204,1294,149z"></path>
													</g>
												</svg>
											</span>';

				break;

			case "trapezoid_with_border":
				$before_classes[] = 'bg-norepeat';
				$before_classes[] = 'bg-position_center';
				$before_classes[] = 'bg-cover';
				$before_classes[] = 'position-relative';

				$delimiter_before_svg = '<svg class="brk-before-element-svg" version="1.1" id="Rectangle_63_1_" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="1920px" height="80px" viewBox="0 0 1920 80" enable-background="new 0 0 1920 80" xml:space="preserve">
											<g id="Rectangle_63">
												<g>
													<polygon fill="#FFFFFF" points="0,0 1920,80 1920,0"/>
												</g>
											</g>
										</svg>';

				$delimiter_after_svg = '<svg  class="brk-after-element-svg" version="1.1" id="Rectangle_63_1_" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="1920px" height="80px" viewBox="0 0 1920 80" enable-background="new 0 0 1920 80" xml:space="preserve">
											<g id="Rectangle_63">
												<g>
													<polygon fill="#FFFFFF" points="0,80 1920,80 1920,0"/>
												</g>
											</g>
										</svg>';

				break;

			case "triangle":

				$before_classes[] = 'position-relative';
				$before_classes[] = 'brk-bg-center-cover';

				$overlay_output = '<div class="brk-abs-bg-overlay"></div>
											<span class="brk-svg-pattern-container brk-svg-pattern-container-5 brk-svg-pattern-container_bottom">
											  <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 1920 110" enable-background="new 0 0 1920 110" xml:space="preserve">
												<g>
												  <path fill="#FFFFFF" d="M0,110h961L0,0V110z M961,110h959V0L961,110z"></path>
												</g>
											  </svg>
											</span>';

				$after_svg = '<img src="' . BERSERK_SHORTCODES_URL . '/shortcodes/img/case-1.png" data-src="' . BERSERK_SHORTCODES_URL . '/shortcodes/img/case-1.png" class="position-absolute z-index-1 lazyloaded" style="left: 0; top: 0;" alt="alt">
										<img src="' . BERSERK_SHORTCODES_URL . '/shortcodes/img/case-2.png" data-src="' . BERSERK_SHORTCODES_URL . '/shortcodes/img/case-2.png" class="position-absolute z-index-1 lazyloaded" style="right: 0; bottom: 0" alt="alt">
										<img src="' . BERSERK_SHORTCODES_URL . '/shortcodes/img/case-3.png" data-src="' . BERSERK_SHORTCODES_URL . '/shortcodes/img/case-3.png" class="position-absolute z-index-1 lazyloaded" style="left: 14%; bottom: 0; max-width: 76%" alt="alt">
										<span class="brk-svg-pattern-container brk-svg-pattern-container-6 brk-svg-pattern-container_top">
										  <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 1920 110" enable-background="new 0 0 1920 110" xml:space="preserve">
											<g>
											  <polygon fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" points="0,0 960,110 1920,0"></polygon>
											</g>
										  </svg>
										</span>';
				break;

			case "wave":

				$animated_backgrounds_output = '<span class="brk-svg-pattern-container brk-svg-pattern-container-7-top brk-svg-pattern-container_top">
													  <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1920 144">
														<defs>
														  <path id="svg-pattern-id-1-1" d="M0 657.88s316.8-72.16 689-15.96c256.8 38.77 524.63 105.83 756 116.7 218.56 10.27 420.43-40.37 475-63.95V616H0z"></path>
														</defs>
														<g>
														  <g transform="translate(0 -616)">
															<use fill="#fff" xlink:href="#svg-pattern-id-1-1"></use>
														  </g>
														</g>
													  </svg>
													</span>
													<span class="brk-svg-pattern-container brk-svg-pattern-container-7-bottom brk-svg-pattern-container_bottom">
													  <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1920 144">
														<defs>
														  <path id="svg-pattern-id-1-2" d="M1920 1489.12s-316.8 72.16-689 15.96c-256.8-38.77-524.63-105.83-756-116.7-218.56-10.27-420.43 40.37-475 63.95V1531h1920z"></path>
														</defs>
														<g>
														  <g transform="translate(0 -1387)">
															<use fill="#fff" xlink:href="#svg-pattern-id-1-2"></use>
														  </g>
														</g>
													  </svg>
													</span>';

				break;

			case "wave_top":

				$animated_backgrounds_output = '<span class="brk-svg-pattern-container brk-svg-pattern-container-7-top brk-svg-pattern-container_top brk-library-rendered" data-brk-library="component__svg_pattern">
													<svg xmlns="http://www.w3.org/2000/svg" xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1920 144">
														<defs>
															<path id="svg-pattern-id-6-1" d="M0 657.88s316.8-72.16 689-15.96c256.8 38.77 524.63 105.83 756 116.7 218.56 10.27 420.43-40.37 475-63.95V616H0z"></path>
														</defs>
														<g>
															<g transform="translate(0 -616)">
																<use fill="#fff" href="#svg-pattern-id-6-1"></use>
															</g>
														</g>
													</svg>
												</span>';

				break;

			case "urban":
				$animated_backgrounds_output = '<span class="brk-svg-pattern-container brk-svg-pattern-container-12-top brk-svg-pattern-container_top">
												  <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1920 184" enable-background="new 0 0 1920 184" xml:space="preserve">
													<g>
													  <g>
														<path fill="#FFFFFF" d="M94.6,138.1c-1.4-0.9-1.9-2.3-0.5-3.7c1.4-2.3,0.9-2.8-5.5-2.8c-2.8-0.4-2.8-0.7-3.2-1.2
														  c-0.5-0.7-1.8-0.7-3.7-0.7c-5.1,0.7-10.6,1.2-14.7,2.3c-1.4,0.7-3.2,0.7-5.1,0.9c-2.3,0.4-5.5,0.2-6.5-0.7
														  c-0.4-0.4,0.9-1.4,2.3-1.1c5.1,0.7,8.3-0.7,12-0.7c2.8-0.7,3.2-1.2,2.3-2.3c-0.9-0.7-3.2-0.7-6-0.2c-3.2,0.4-6.9,0.9-9.2,2.5
														  c-1.4,0.5-5.1,0.5-7.4,0c-2.3-0.7,0-1.2,1.4-1.8c1.4-0.2,2.8-0.4,4.2-0.7c0.9-0.5,2.3-0.5,1.8-0.9c-1.8-0.7-4.2,0-6.4,0
														  c-2.8,0-4.6,0.4-4.6,1.2c0,1.1-1.8,1.6-5.1,1.8c-1.8,0-2.8,0.4-4.1,0.4c-1.4,0.5-3.7,0.7-6,0.5c-3.7,0-6,0.7-8.3,1.8
														  c-1.8,0.2-3.2,0.7-6,0.9c-1.8,0.4-2.3,1.2-2.3,1.8c0.4,0.5,2.8,0.5,4.1,0.2c4.2-0.2,6.5,0.2,7.8,1.4c1.4,0.7,2.3,1.4,5.1,2.1
														  c0.5-0.2,1.4-0.2,1.8-0.2c3.2-1.2,8.8-1.2,13.4-1.9c0.4-0.4,1.4,0,1.8,0c3.2,0.7,3.2,1.9,0.4,3c-2.3,0.5-5,1.6-6.9,2.6
														  c-2.8,1.2-1.4,1.8,0.5,2.8c1.8,0.9,4.2,1.2,7.4,0.9c6-0.4,11.5-0.7,16.6,0.5c2.3,0,4.6,0.7,6.9,0c3.7-1.2,7.8-1.2,12-0.5
														  c2.3,0,3.7-0.4,4.6-1.2c1.4-0.2,1.8-0.9,0.4-1.4c-2.8-1.6-2.8-1.6,2.3-2.6C95.6,140.2,96.5,139.5,94.6,138.1z M1783.2,116
														  c-0.9-0.7-1.9-1.4-2.8-2.1c-0.4-0.7-1.8-1.2-4.1-1.6c-3.7-0.2-6.9-0.7-9.2-1.8c-0.9-0.5-2.3-0.7-4.2-0.7c-5.1,0.2-8.8,1.6-7.8,2.8
														  c0.5,0.9,3.2,1.8,2.8,2.8c2.8,0.9,6,1.8,8.3,2.8c3.2,0.9,6.9,2.3,12.4,2.1c5.1-0.5,5.1-1.8,4.6-3V116z M370.6,161.2
														  c-0.5,0-0.9,0-1.4,0.2c0,0.2,0.5,0.9,1.8,0.9c0.9,0,1.4-0.7,1.4-0.7C372.4,161.2,371.5,161.2,370.6,161.2z M1119.7,167.6
														  c-1.9-0.2-4.6-0.2-5.5-0.7c-3.7,0-7.4,0-10.1,1.2h-0.5c0,0,0,0.2,0.5,0.2c5.5,2.5,11,2.5,16.6-0.2
														  C1120.2,168.1,1120.2,168.1,1119.7,167.6z M0,0v74.1c4.7-0.4,9.6-0.5,14.5-0.8C12.2,75.1,8,76.1,4.3,77c-1.5,0.1-3,0.4-4.3,0.7
														  v3.5c3.3-0.3,6.4-0.7,8.9-1.4c4.6-0.9,8.8-1.6,14.3-1.4c3.7,0.5,6.5-0.2,8.8-0.9c2.3-0.7,4.6-1.2,6.9-1.6
														  c5.5-0.2,9.7-1.2,15.2-1.6c1.4-0.4,1.8-0.9,2.3-1.1c5.5,0,8.8,1.4,6.5,2.8c-0.5,0.4-0.9,0.7-0.5,1.2c0.9,1.4,2.3,3,8.8,4.1
														  c2.8,0.2,6,0.9,5.1,2.1c-1.4,1.6-0.4,1.8,5.5,2.3C85,86,88.2,86,90,86.7c1.8,0.7,3.7,0.9,6.5,0.4c2.3-0.2,4.1-0.2,6.4,0
														  c5.1,0.9,11.1,1.6,13.4,2.8c2.8,1.2,6.9,1.6,11,1.9c-5.1,0.4-11.5,1.6-12.4,3c-1.8,2.1-5.1,3.2-10.6,4.1c-2.3,0.5-4.6,0.9-4.6,2.1
														  c3.7-0.2,6.9-0.7,9.7-0.9c2.3,0,3.7-0.4,4.6-1.4c1.8-1.2,3.7-1.4,8.3-0.7c2.3,0.5,4.6,0.5,7.4,0c4.2-0.4,8.3-0.9,12.4-0.7
														  c0.9,0,2.3,0,3.2-0.2c3.7-1.2,7.4-0.7,11.5-0.7c3.7,0,5.5,0.4,6.5,1.4c1.4,0.4,0.9,0.9-1.8,1.1c-1.4,0.2-3.2,0.2-4.2,0.7
														  c-0.9,0.4-1.8,0.7-1.4,0.9c0.5,0.2,1.4,0.2,2.8,0.2c2.3,0,5.5-0.2,7.8-0.7c5.1-1.4,11.1-1.6,16.6-2.5c4.1-0.9,5.5-0.7,7.8,0.4
														  c0.9,0.5,2.3,0.7,4.1,0.7c4.6,0,4.6,0,4.2,1.6c-0.4,0.2-0.4,0.4,0.9,0.7c2.8-0.2,4.2-0.7,6.5-1.2c3.2-0.7,6.9-1.4,10.1-1.8
														  c3.2-0.2,5.5-0.7,7.8-0.2c1.4,0.4,2.8,0.4,3.7,0c1.4-1.2,2.8-2.1,6.9-1.4c0,0,0.4,0,0.9-0.2c2.8-0.9,4.6-0.2,6.9,0.5
														  c2.8,0.4,5.5,0.7,9.2,0.4c4.2-0.4,8.3-0.9,12.9-0.2c2.8,0.7,3.2,0.7,1.4,1.6c-3.2,1.6-7.8,2.8-12.9,3.4c-0.5,0-0.5,0-0.5,0
														  c-3.2-0.2-4.1,0.7-5.1,1.4c-0.9,0.4-2.3,1.2-3.7,1.8c0,0.5-0.9,0.7-1.4,0.9c-0.5,0-0.9,0-1.4,0.2c-0.5,0-0.5,0.2-1.4,0.2
														  c-0.9,0.2-1.4,0.7-0.4,1.1h-0.5c0,0,0-0.2-0.4-0.2c0,0-0.5,0-0.9,0.2c-1.8,0.5-4.2,0.7-6,1.2c-6.9,1.6-13.8,3-21.7,3.9
														  c-3.7,0.5-4.2,0.7-1.8,1.6c0.9,0.4,2.3,0.9,3.7,1.1c4.2,1.2,4.2,1.9,0,3c-1.4,0.5-3.2,1.2-4.2,1.6c-2.3,1.2-1.8,1.2,1.8,1.2
														  c5.5,0.2,5.1,0.7,5.5,2.1c0.4,1.9-3.7,3-8.3,4.2c-2.3,0.7-4.2,1.8-7.8,1.8c-3.2-0.4-5.1,0.2-6,1.2c-0.4,0.5-3.7,1.2-0.9,1.8
														  c2.8,0.7,4.6-0.2,6.5-0.7c2.3-0.7,4.6-1.2,6.4-1.8h3.7c0.9,0.2,0.9,0.7,0.5,0.7c-5.1,2.8-14.3,3.9-23,3c-1.8-0.2-3.2,0-4.6,0.2
														  c-1.8,0.7-3.7,0.9-5.5,1.8c-0.9,0-1.4,0.2-0.9,0.5c0.9,0.4,1.4,0.7,2.3,0c3.2-0.5,5.1,0,6.9,0.7c0.5,0.2,1.4,0.2,2.3,0.2
														  c3.2-0.2,3.7,0.9,3.7,1.4c0,0.2-0.4,0.7-0.4,1.2c-0.9,1.2-0.5,1.4,3.7,1.2c5.5-0.5,11.1-1.2,15.7-2.1c1.4-0.2,2.8-0.5,4.6-0.5
														  c3.2,0.2,5.1-0.2,6.9-1.4c0.9-0.7,1.4-0.9,3.2-1.2c0.9,0,0.9-0.7,1.8-0.7c5.1,0,9.7,0.4,13.4-1.4c1.4-0.4,4.2-1.2,6-0.7
														  c4.2,0.4,9.2,0.9,9.7,2.8c-0.4,0.2-1.4,0.5-1.8,0.5c-3.2,0.7-5.5,1.8-8.8,2.1c-0.4,0.2-0.4,0.2,0,0.2c0.9,0.9,0.5,1.2-0.9,1.8
														  c-2.8,0.5-5.5,1.4-8.3,1.9c-7.4,1.1-14.7,2.3-20.7,4.4c-3.7,0.5-6.5,0.5-10.1,0c-2.8-0.7-5.1-0.7-7.8,0c-1.8,0.5-3.2,1.4-5.5,1.2
														  c-4.6,0-6.5,0.7-9.2,1.6c-2.3,1.2-5.5,1.2-7.4,0.7c-1.8-0.7-3.7-0.5-6-0.5c-7.4,0.5-13.4,1.4-20.3,2.3c-2.8,0.2-3.7,0.9-1.4,1.4
														  c2.3,1.2,1.8,1.8,0.9,3c-0.5,0.5-1.8,1.6-2.3,2.6c17.5,1.1,34.6,1.8,52.1,2.8c5.5-0.9,7.8-2.8,12.4-4.2c3.2-0.7,6.5-1.2,9.7-1.2
														  c2.8,0.2,2.8,1.6,2.3,2.3c-0.4,1.6,2.3,1.6,6.5,1.4c2.3-0.4,4.1-0.7,6.4-0.9c6-1.1,6.4-2.5,0.9-3.9c-4.2-1.1-3.7-1.4,1.8-2.3
														  c4.2-0.7,8.3-0.7,10.6,0.4c1.9,1.2,13.4,1.6,15.7,0.7c4.6-1.9,11.5-2.3,17-3.5c3.2-0.9,6.5-1.2,10.1-1.2c5.1,0,9.2-0.4,11.1-2.3
														  c1.8-0.5,3.2-0.5,5-1.2c1.4,0,2.8-0.2,4.6-0.5c1.8,0.2,3.2,0,5.1-0.7c6.9-1.2,13.8-2.3,22.1-2.5c1.4,0,2.3-0.2,3.7-0.2
														  c7.4-1.2,13.8-2.8,22.1-2.6c0.4,0,0.9,0,1.4-0.2c3.2-1.2,5.1,0,7.8,0.4c-3.2,1.2-6.4,2.3-9.7,3.5c-0.4,0-0.4,0-0.9,0
														  c-1.4,0.4-3.2,1.1-5.5,0.9c0,0.2,0,0.2-0.5,0.2c-3.2,0.5-7.4,1.2-10.1,2.3c-0.9,0.2-2.3,0.5-3.7,0.5c-4.6,0-7.4,0.7-9.7,1.8
														  c-0.9,0.4-2.8,1.2-4.2,1.4c-0.4,0-0.4,0.2-0.4,0.2c-3.2,0.5-5.5,1.2-5.5,2.1c0,0.2,4.1,1.8,5.5,1.8c2.8,0.5,5.1-0.2,7.4-1.2
														  c0.5,0,0.9-0.2,1.4-0.4c1.4-0.7,3.2-1.2,5.5-1.2c6,0,12-0.7,17.5-0.2c2.3,0,3.7,0,4.6,0.7c0.4,0.7,2.3,0.7,4.6,0.7
														  c3.2-0.7,4.2,0.2,6,0.9c1.4-1.8,4.6-2.8,8.8-2.8c4.6-0.5,5.5-0.2,7.4,1.1c0.4,0,0,0,0.4,0c0.5,0.7,1.8,0.7,3.2,0.7
														  c1.4-0.7,0.9-0.7,0-1.2c-2.8-0.7-0.9-1.6,1.8-2.3c3.2-0.9,7.4-1.6,11.1-2.5c5.5-0.9,11.5-1.4,17.1-1.4c4.1,0,7.8-0.2,10.6-1.2
														  c5.1-1.1,10.6-1.1,16.6-1.8c1.4,0,2.3,0.5,2.8,0.7c0.5,0.2,0,0.4-0.9,0.9c-0.5,0.2-1.4,0.2-1.8,0.2c-5.5,0.5-9.2,1.4-13.8,2.3
														  c-4.2,0.2-9.2,0.5-8.8,2.3c0,0.4-0.9,0.7-1.8,0.7c-2.8,0.5-4.6,0.9-6.9,0.7c-1.8-0.2-4.2-0.2-4.2,0.5c-0.5,0.9,2.3,0.2,3.7,0.2
														  c5.5,0.7,6.9,1.1,3.7,3c-0.4,0.2-0.9,0.4-1.4,0.9c-4.6,0.7-7.8,1.8-12.4,2.5c-3.2,0.5-6,0.5-9.2,0.5c-3.2,0-6.9,0.2-8.3,1.6
														  c-0.4,0.7-2.3,0.9-3.7,1.6c-1.4,0.2-2.3,0.2-3.7,0c-0.9-0.4-0.9-1.2-3.2-0.9c-1.8,0-3.2,0.2-4.6,0.5c-1.8,0.7-3.2,0.9-2.8,1.8
														  c0.4,0.4,2.3,0.4,4.1,0.4c6.9,0,6.9,0,7.8,2.3c0.5,0,0.5,0.2,1.4,0.7c1.4,0,2.3-0.4,2.8-0.7c1.4-0.4,2.3-1.2,1.8-1.2
														  c-1.8-1.4,1.4-1.6,3.7-2.3c2.3-0.5,4.1,0,5.5,0.7c1.8,0.4,3.2,0.4,5.5,0c1.4-0.7,3.2-0.7,5.5-0.7c2.8,0.4-0.5,1.1,1.8,1.8
														  c4.6-1.4,11.1-1.2,16.1-1.8c2.3-0.5,3.7,0,5.1,0.4c1.4,0.7-0.4,1.2-1.8,1.4c-3.2,0.4-5.1,1.2-3.7,2.3c0.4,0.2-0.5,0.7-1.8,1.2
														  c-4.6,0.5-7.4,2.1-12.5,2.1c-1.8,0-2.8,0.7-3.7,1.6c-0.4,0.7-0.9,1.4-1.4,2.6c26.7,1.2,52.5,2.8,79.2,3.9c3.2,0.2,6.4,0.2,9.7,0.4
														  c4.6-0.4,8.8-0.9,11.5,0.7c0.5,0,1.4,0,2.3,0.2c12.9,0.7,25.3,1.4,38.2,2.1c2.3-3,6-5.1,16.6-5.8c3.2-0.2,4.2-1.2,3.7-2.3
														  c-0.5-1.4,2.8-2.3,6.9-3.5c3.7-0.4,7.9-0.4,11.5-0.7c6.4-0.2,12.4-0.9,18.9,0c3.7,0.2,8.8,0,12-0.9c4.6-1.4,8.8-1.4,13.8-0.9
														  c3.7,0.7,6.9,0.4,9.7-0.7c1.4-0.7,2.8-1.1,5.1-1.1c0.5-0.7,1.4-0.7,1.8-0.7c1.4-0.4,2.8-0.4,4.2-0.7c5.1-0.5,10.1-0.9,15.2-1.6
														  c2.3-0.5,4.6-1.2,7.8-0.7c1.4,0.2,3.2,0.2,3.7,0.7c0.5,0.7-0.9,0.9-2.3,1.1c-4.6,0.9-6,1.9-1.8,3.5c-6-0.9-8.8,0-12.9,1.2
														  c-5,1.6-9.7,3.9-18.4,3.9c-3.7,0-7.4,0.9-10.1,1.8c-7.8,2.3-16.1,3.9-27.2,4.4c-1.8,0-4.6,0.7-5.5,0.9c-2.8,1.4-6.5,2.8-9.2,4.4
														  c7.8,0.5,15.5,0.7,23.3,1.1h0.3c4.6-0.7,10.5-1.2,13.3-2.8c0.4,0,0.4-0.2,0.4,0c5.5,0.9,8.3-0.7,11.1-1.4
														  c7.4-2.3,15.7-3.9,24.4-5.3c9.2-1.4,19.3-2.5,29-3.2c15.7-1.6,30.9-3.2,45.6-5.6c4.6-0.7,9.2-2.1,15.2-2.3
														  c10.1,0,19.8-1.2,29.9-2.1c3.2-0.2,6.9-0.9,10.1-1.4c1.8-0.2,2.8-1.2,2.3-1.6c-0.4-0.7-2.8-0.7-4.6-0.5c-1.4,0.5-3.2,0.5-4.6-0.2
														  c0.9-0.5,2.8-0.5,4.6-0.5c5.5-0.7,6.5-0.4,5.1,1.4c-1.4,2.5,0,3,8.8,3.7c0.9,0,1.4-0.2,2.3-0.7c-0.5-1.6,3.7-1.2,6.4-1.2
														  c0.5-0.2,1.8-0.5,2.3-0.5c1.4-0.2,3.2-0.2,2.8-1.2c0.5,0,0.5,0,0.5,0c3.2,0.2,5.5-0.4,8.3-1.1c12.4-2.3,24.9-5.1,39.6-6.2
														  c1.4-0.2,2.3-0.7,2.3-1.2c0,0,0,0,0.5,0c1.8,0.5,4.2,0,6.4,0.5c-1.8,1.1-6.9,1.6-8.8,3c-3.2,0.4-6.4,1.1-8.8,2.5
														  c-3.2,2.1-10.1,2.5-13.4,4.8c-5.1,0.5-9.7,1.2-12.4,2.8c-7.9,0.9-15.7,2.3-24.4,2.6c-4.6,0.4-9.7,0.4-13.4,1.1
														  c-5.1,1.4-9.7,2.6-15.7,3.2c-1.4,0.5-2.8,0.5-4.2,1.2c-1.4,0.2-2.8,0.7-0.4,1.4c1.4,0.2,0.4,0.9-0.5,0.9c-5.1,1.2-10.6,2.5-16.6,3
														  c-4.6,0.9-6.9,2.1-9.7,3.2c4.6-0.9,9.7-1.4,14.7-1.8c6.4-0.4,12.9-1.4,18-3c2.3-0.9,6-1.2,9.2-1.2c2.8,0.2,4.6,0,6.5-0.7
														  c2.8-0.7,6.4-1.4,10.1-1.4c3.2-0.2,5.5-0.5,7.8-1.2c1.8-0.5,3.7-0.5,6-1.2c4.6-0.2,9.2-0.5,12-2.1c0.5-0.5,1.4-0.7,2.3-0.7
														  c8.3-1.4,16.6-2.8,23.5-5.1c6.4-1.8,14.7-3.5,22.1-5.1c0.5,0,0.9,0,1.4-0.4c3.2-0.5,6.4-1.4,10.1-1.6c2.3-0.2,5-0.9,6.9-1.4
														  c9.2-3.5,22.1-4.6,33.2-7.2c13.8-3.2,28.6-6,42.8-9.5c0.9,0,1.4-0.4,1.4-0.4c0-0.2,0-0.2,0-0.2c1.8,0.2,2.8,0,4.2-0.4
														  c0.9,0,2.3-0.2,3.2-0.5c0.9,0,1.8,0.2,2.8,0c0.9-0.2,2.3-0.7,2.8-0.9c5,0.9,9.2-0.2,13.4-0.9c1.8,0,4.2-0.9,5.5-0.5
														  c1.9,0.5,1.4,1.4,1.4,2.3c-0.5,0.2-1.4,0.5-0.9,0.9c2.3,0,4.2-0.4,6-0.7c5.1-0.5,9.7-1.6,14.7-1.4c4.2,0.2,7.8,0,12-0.2
														  c0.9-0.4,2.3-0.7,3.2,0c0.5,0.2-0.4,0.7-1.8,0.7c-6.9,2.3-16.6,3.4-24.4,5.8h-1.8c-5.5,0.7-8.8,1.6-10.6,3.4
														  c-0.9,1.2-2.8,1.6-6.5,1.6c-0.9,0-1.4,0.2-1.8,0.7c-1.8,0-2.8,0.5-4.2,0.5c-4.6,0.7-8.3,1.1-12,1.8c-0.9,0.4-2.3,0.4-3.7,1.2
														  c-1.4,0-2.8,0.4-5.1,0.2c-0.4,0.5-1.8,0.7-3.7,0.7c-1.8,0.4-3.7,0.7-4.6,1.6c-1.4,0.7-3.7,0.7-6,0.7c-0.5,0-0.9,0.5-1.4,0.5
														  c-1.4,0.2-2.8,0-4.1,0.2c-1.4,0-1.8,0.2-3.2,0.4h-4.2c-10.6,2.3-21.7,3.2-33.2,4.2c-2.3,0.2-5.1,0.4-6.9,1.4
														  c-4.2,1.2-9.2,1.6-14.7,1.6c-3.7,0-7.4,0.2-9.7,1.4c-5.1,3-11.1,5.6-19.8,7.4c-0.5,0-0.5,0-0.9,0.4c-0.5,0.2-1.4,0.2-1.8,0.2
														  c-7.4,0.9-14.3,2.3-19.8,4.2h-0.5c-0.4,1.6,1.4,2.1,5.5,1.6c4.2-0.7,7.8-1.8,12-2.3c2.3-0.7,6.4-0.7,8.3-1.8
														  c3.2-1.6,10.1-1.6,15.2-2.8c6-1.1,12-1.6,17-3.4c6-1.6,12-3,20.3-2.3h2.3c6.9-0.4,7.4-0.4,6.5,1.4c0,0.4,0.4,0.4,0.9,0.4
														  c3.2,0,6.9-0.4,10.1-0.9c6.9-0.9,13.8-2.1,20.7-2.8c3.7-0.4,8.8-1.2,12.5-0.7c2.8,0.2,3.7,0.2,6-0.2c3.2-0.7,6.4-1.8,11-1.4
														  c0.5,0,1.4-0.4,1.9-0.7c6-0.7,11.5-1.8,16.1-3.4c3.2-0.7,6.5-1.4,9.7-1.8c4.6-0.9,8.8-2.1,14.3-2.6c2.8-0.4,5.5-1.2,8.3-2.1
														  c2.1,0,4.4-0.2,6.6-0.3c1.3-0.2,2.7-0.4,4-0.6l-0.5,0.5c-1.1,0-2.3,0.1-3.5,0.1c-2,0.3-4,0.5-6.2,0.3c-0.5,0-0.5,0-0.5,0
														  c4.2,0.2,7.8,0.9,12.5,0c6.4-1.2,12.9-2.1,18.4-3.4c1.4-0.5,3.2-0.5,5.1-0.7c1.4-0.4,2.8-0.4,3.2,0.2c0.9,0,0.9,0.5,0,1.2
														  c-0.4,0-1.4,0.2-2.3,0.5c-0.5,0.2-1.8,0.7-1.4,0.9c0.9,0.2,2.3,0.2,3.7,0c4.2-0.9,8.3-1.2,12-2.3c3.7-0.5,8.8-0.9,10.6-2.5
														  c0-0.2,2.3-0.7,3.7-0.9c1.4-0.2,2.8-0.5,3.2-1.2c5.5-0.7,10.6-1.8,14.7-3c3.2-0.7,6.5-1.2,9.7-1.8c2.3-0.2,4.6,0,6.9,0.4
														  c0.9,0.2,1.8,0.5,0.9,0.7c-3.7,1.2-3.7,2.6-6.5,4.2c-4.2,1.6-10.6,3.2-13.8,5.6c-2.3-0.2-3.7,0-4.6,0.7c-3.7,1.2-7.4,1.8-12,2.8
														  c-6.9,1.4-12,3.5-18.4,5.1c-2.8,0.7-3.7,1.8-1.4,3c2.8,0.4,5.5,0.2,8.3,0c2.3-0.7,4.2-0.9,5.5-1.6c4.6-1.4,10.1-2.1,15.2-3.2
														  c1.4-0.5,3.2-0.9,6-0.5c-8.3,1.8-15.2,4.2-23.5,5.3c-7.8,0.4-11.5,2.1-15.7,3.9c-0.9,0.4-1.9,1.2-0.9,1.6c0.9,0.2,2.8,0,4.2,0
														  c2.3,0,4.6,0,6.5-0.4c3.2-0.2,6-0.7,5.5,1.2c0,0.4,0.5,0.7,2.8,1.1c1.8-0.4,2.8-0.7,3.7-1.1c6.4-0.9,12.9-2.1,17.5-3.7
														  c2.8-0.4,5.1-0.9,6.4-1.8c2.8-0.7,6-1.8,9.7-2.5h1.8c2.8-0.5,4.2-1.6,6.9-2.3c0.9-1.8,6.5-3,8.3-4.4c0-0.5,0.9-0.5,1.8-0.5
														  c5.5-0.2,9.7-1.6,15.2-2.3c2.3-0.2,3.7-0.7,3.7-1.8c1.4-2.5,4.2-5.1,12-7.4c6.4-0.7,12.9-1.8,18-3.2c2.8-0.9,6-2.3,11.5-1.8
														  c0.9,0.2,1.4,0,2.3-0.7c0.9-0.5,1.8-0.9,3.2-1.2c0.9-0.5,2.3-0.5,3.2-0.2c2.3,0.9,4.6,0.9,7.4,0.2c2.8-0.5,5.1-0.5,4.6,0.7
														  c-0.5,0.5-0.9,1.2-1.9,1.8c-1.8,0.9-0.9,2.1-0.4,2.6c0,0.7,1.4,1.1,2.8,1.1c1.8,0.2,2.3-0.4,3.2-0.4c1.8-0.7,3.2-1.8,6-1.8
														  c3.7,0,6-0.5,8.8-0.7c3.7-0.4,6-1.4,9.2-2.1c7.8-0.9,15.7-1.6,22.1-3.5c0.9,0,2.8,0,4.2-0.4c1.8,0,2.8,0,3.7,0.4
														  c5.5-0.7,10.1-2.3,15.2-2.8c7.6-1.5,14.7-2.8,21.4-4.4c0.1-0.1,0.1-0.1,0.2-0.2c0.9-0.4,1.8-0.9,4.1-0.9c0.3-0.1,0.6-0.2,0.9-0.2
														  c1.8-0.5,2.8-1.2,1.8-1.8c0-0.2,0-0.2,0-0.5c0.9,0.2,1.4,0.5,2.3,0.5c3.2,0.2,3.7,0.7,2.3,1.4c-1.8,0.5-3.7,1.2-6.9,0.7
														  c-0.2,0-0.3,0-0.5,0c-1.4,0.4-2.9,0.8-4.4,1.1c-0.9,0.8,0,1.6,2.6,1.8c2.3,0.7,4.2,1.4,7.8,0.7c1.8,0,3.2-0.2,4.6-0.5
														  c4.2-0.2,8.3-0.4,12.5,0.2c1.4,0.2,3.2,0.2,4.6,0.2c2.8,0,4.2,0.4,6.5,0.7c2.8,0.5,6,1.6,10.6,0.9c2.3,0.2,4.2,0.2,5.5,0.7
														  c2.3,0.7,4.6,0.9,7.4,0.7h5.1c7.4,0,12.4,1.6,10.6,3.4c-0.9,0.7-1.4,1.6,1.4,2.3c-1.4,0.4-3.2,0.7-5.5,0.4
														  c-0.9-0.2-1.4-0.4-2.8-0.4c-1.8,0.2-2.3,0.7-1.4,0.9c3.2,2.3,4.2,2.3,9.7,2.1c2.3,0.7,4.6,1.2,7.4,1.4h4.2c1.4,0,3.2,0.7,4.6,0.7
														  c3.2,0.7,6.9,0.7,11.5,0c-2.8-0.5-5.1,0-6.9-0.7c-0.4,0-0.4,0,0-0.2c0.5-0.2,1.4-0.2,1.8-0.2c1.8,0.4,3.7,0,5.5,0
														  c6,1.6,12.4,2.3,20.3,1.2c2.3-0.7,5.5-0.7,8.3,0c3.2,0,6,0,8.8-0.7c1.4-0.4,3.2-0.4,4.6,0c6.9,1.2,15.7,1.2,23.5,1.4
														  c9.7,0.5,11.5,0.9,12.5,3.2c0.4,2.5,4.6,4.6,14.3,5.3c6,0.7,11.5,1.6,17.1,2.1c3.2,0,5.5,0.9,9.2,0.7c3.2-0.5,6.9-0.7,10.6-0.7
														  c1.4,0,2.3,0,3.2-0.4c1.8-0.5,4.6-0.7,7.4-0.9c2.8-0.2,5.5-0.2,5.1-1.4c0-0.7,2.3-0.9,4.6-0.7c1.4,0,2.8,0.7,3.7,0.9
														  c1.4,0.4,3.2,0.9,5.5,0.2c1.9-0.5,3.7-0.5,5.5,0c1.8,0.7,4.2,0.7,6.9,0c6.4-0.2,12.4-1.2,19.3-0.5c4.2,0.2,5.5,0,7.8-1.2
														  c1.8-0.7,3.7-1.2,5.5-1.8c1.8-0.4,4.1-0.7,6.9-0.4c6.9,1.1,15.2,1.4,22.1,2.5c1.8,0.2,4.6,0.5,6.9,0.9c5.1,0,8.8-0.7,9.7-1.8
														  c0.9-1.2,2.8-1.6,7.8-1.2c2.8,0.7,3.7,0.7,5.1,0c1.4-0.4,2.3-1.2,4.6-1.2c4.2-0.4,6-0.9,7.8-1.8c1.4-0.9,2.8-0.9,6-0.9
														  c5.5,0,5.5,0,7.4-1.4c-0.9-2.1-0.9-2.1,5.5-2.3c0.9,0,1.8,0,2.3-0.2c3.7-0.7,4.6-1.2,3.7-2.1c-0.4-0.4-1.4-1.4-0.9-1.8
														  c-1.4-0.7-2.8-1.2-3.2-1.6c-0.9-1.8-2.3-3.7-3.7-6c-0.5-0.7,0.5-1.4,4.2-1.4c5.5-0.2,6.9-1.2,6.4-2.3c-0.9-2.1-3.2-4.4-5.1-6.7
														  c-2.3-1.8-0.4-3.7,1.4-5.3c0.5-0.9,2.8-1.6,5.5-2.1c2.3-0.5,4.6,0.2,6.9,0.4c4.2,0.2,6.9,0,8.8-1.1c4.6-2.6,11.1-4.9,21.2-6.2
														  c3.2-0.7,5.5-1.2,4.6-2.3c-1.4-1.2,1.4-1.8,5.1-2.3c2.8-0.5,5.5-0.2,8.8-0.5c3.7-0.2,7.8-0.5,8.3-1.6c0-0.5,0.4-0.5,0.4-0.9
														  c1.4-0.9,5.1-1.2,7.4-1.6c7.4-1.4,7.4-2.1,2.8-3.9c-0.9-0.2-1.8-0.7-2.3-0.7c-2.3-0.5-2.8-0.9-4.2-1.4c-3.7-0.7-5.5-1.6-4.6-2.8
														  c0.9-1.4-2.3-2.1-6.4-2.3c4.6-0.4,5.5-1.4,3.2-2.3c-2.3-1.4-1.4-2.3,1.4-3.2c0.5-0.2,0.9-0.2,1.4-0.2c0.4-0.7,0.4-1.6-2.8-1.6
														  c-4.1,0.2-9.2,0.2-12,1.2c-2.3,0.7-5.1,1.4-8.3,1.8c-5.1,0.4-10.1,0.4-12.9,1.8c-1.4,0.5-5.1,0.5-6.9,0.2
														  c-2.3-0.2-4.2-0.7-3.2-1.4c0.9-0.7,0.9-1.6,3.2-2.3c2.8-0.5,3.7-1.9,6.5-2.6c2.3-0.7,5-1.4,5.5-2.3c0.5-0.2,1.4-0.7,3.2-0.7
														  c1.4,0,1.8,0.5,2.3,0.5c0.5,0.2,0.9,0.4,1.4,0.4c0.5,0.5,1.4,0.7,3.2,0.7s2.8-0.5,2.8-0.9c0-0.7,1.4-0.5,3.2-0.5
														  c4.6,0,9.2-0.2,12.9-0.9c7.9-1.4,13.4-3.2,22.1-4.2h0.5c2.3-0.9,6-1.4,10.1-1.4c0.5-0.5,0.9-1.2,1.4-1.4c0.4-0.5,0-0.7-1.4-0.7
														  c-4.2,0-7.4-1.2-11.5-1.2c-2.3-0.2-3.7-0.2-5.1,0.2c-0.9,0.4-3.2,0.4-5.1,0.4h-8.3c-0.9,0-2.3,0.2-3.2-0.2c-0.5-0.2,0-0.4,0.9-0.9
														  c0,0,0.5,0,0.5-0.2c0.9,0,1.8,0,2.3-0.5c5.1-0.5,6.9-1.8,12-2.3c0.9,0,0.9-0.2,1.4-0.7c0.9-0.2,1.4-0.4,0.4-0.7
														  c-0.4,0-0.4,0-0.9,0c1.8-0.5,3.7-0.7,5.1-1.2c0.4-1.8,3.2-2.8,7.8-3.5c3.7-0.7,6.4-1.1,9.7-1.8c0.9-0.4,2.8-0.7,3.2-0.9
														  c1.4-1.8,6.4-3,10.1-4.2c4.6-1.1,9.7-2.3,14.3-4.1c6-1.8,12.4-3.7,16.6-6.2c0.5-0.5,1.8-0.7,2.8-1.2c5.1-0.7,8.8-2.1,12.9-3
														  c2.8-1.2,5.1-2.1,5.5-3.2c0.4-0.9,1.8-1.2,3.7-1.6c2.8-0.9,5.8-1.6,8.3-2.5V0H0z M68.8,71.9c1.8,0.2,3.2,0.7,3.7,0.9
														  C71.6,72.6,70.7,72.2,68.8,71.9z M255.4,144.6c0-0.5-1.4-0.5-2.8-0.5c0.9,0,2.3-0.7,3.2,0C256.3,144.1,256.3,144.6,255.4,144.6z
														   M265.6,132.3c0.4-0.2,0.4-0.2,0.4-0.2h0.5C266,132.3,266,132.1,265.6,132.3z M298.3,100.3c0-0.5-0.4-0.7-0.9-0.9c0,0,0,0,0.5,0
														  C298.7,99.6,298.3,100,298.3,100.3z M337.3,134.8c-0.3,0-0.6,0.1-0.8,0.1c-1.2,0.5-2.6,0.6-4.2,0.7c-1.4,0.5-2.8,0.2-4.1,0
														  c1.3,0,2.7,0.1,4.1,0c0,0,0,0,0,0C333.8,135,335.5,134.9,337.3,134.8c0.8-0.1,1.8-0.1,2.7-0.2
														  C339.1,134.6,338.2,134.7,337.3,134.8z M352.4,133.1c0,0,0,0.1-0.2,0.2c0,0-0.9,0-1.4,0c-0.5,0-0.5,0.2-0.9,0
														  C351.1,133.3,351.6,133.3,352.4,133.1c0,0,0,0,0.2,0C352.6,133.1,352.5,133.1,352.4,133.1z M397.8,146.9c1.4-0.9,2.3-1.2,6-1.2
														  C401,146,399.2,146.4,397.8,146.9z M445.2,133.5c0-0.2,0.4-0.2,0.9-0.4c-0.5,0.2-0.5,0.7-0.5,1.1
														  C445.7,133.7,444.8,133.7,445.2,133.5z M441.6,141.3c0.9-0.4,1.8-0.7,2.8-1.2c1.1,0,2,0.3,3,0.3
														  C445.3,140.7,443.2,140.7,441.6,141.3z M444.8,152.6c-0.9-0.2-0.9-0.7,0-0.9c0,0,0.5,0.9,0.9,1.1
														  C445.2,152.9,445.2,152.6,444.8,152.6z M459.1,157.2c-0.5-0.4-0.9-0.4-1.4-0.4c0.5,0,0.9-0.2,1.4-0.2
														  C459.5,156.8,459.1,156.8,459.1,157.2z M473.8,157.7c0.4,0,0.4-0.2,0.9-0.2c0.4,0,0.9,0.2,1.4,0.2H473.8z M489.9,157.2
														  c0.5,0,0.9-0.4,1.4-0.7c0.9,0.2,1.8,0,2.3,0.2C492.2,156.8,491.3,157.2,489.9,157.2z M505.6,155.2c-0.4,0-0.9-0.2-1.4-0.2h2.3
														  C506.5,154.9,506.1,155.2,505.6,155.2z M505.1,145.5c0-0.2,0-0.2,0.4-0.2c3.7-0.7,7.4-0.2,9.7,0.5
														  C512,145.3,508.8,144.6,505.1,145.5z M531.4,146.6c-0.8,0-1.4,0-2.2-0.1c-0.5,0-1,0-1.5,0.1c0,0,0-0.2,0.4-0.2
														  c0.4,0.1,0.8,0.1,1.1,0.1C530,146.5,530.8,146.6,531.4,146.6c0.1,0,0.3,0,0.4,0c0.7,0,0.8,0.1,1.1,0.2
														  C532.5,146.8,532,146.7,531.4,146.6z M553.5,154.2c-2.3,0.5-4.2,0-5.5-0.4c2.3,0.4,4.6,0.4,6.9,0.4H553.5z M547.7,147.9
														  c-0.4,0.1-0.7,0.1-1.1,0.1C547,148,547.3,147.9,547.7,147.9c0.1,0,0.2-0.1,0.3-0.1c2.3-0.7,4.6-0.7,6.5,0.2
														  c0.4,0.2,1.4,0.2,2.3,0.7C554.2,147.9,551,147.6,547.7,147.9z M575.2,147.8c-0.1,0-0.2,0-0.3,0c-3,0.2-5.9,0.4-8.8,0.4
														  c-2.4,0.4-4.4,0-6.1-0.4c-0.4,0-0.9,0-1.4-0.2c2.5,0.4,5,0.6,7.4,0.6c0.3,0,0.6-0.1,0.8-0.2c2.7-0.2,5.3-0.4,8-0.2
														  c0.9-0.1,1.7-0.1,2.6-0.2C576.7,147.7,575.9,148,575.2,147.8z M601.4,125.9c-0.5,0,0,0,0-0.2c0,0.2,0.4,0.2,0.4,0.2H601.4z
														   M671.5,160.2H671c0.5,0,0.5-0.2,0.9-0.2C671.5,160,671.5,160.2,671.5,160.2z M671.5,141.3c-0.1,0-0.2,0-0.3,0
														  c-1.9,0.3-3.9,0.6-5.8,0.8c-0.7,0.2-1.5,0.4-2.2,0.8c-2.8,0.4-6.9,1.1-10.1,1.1c-0.7-0.1-1.3-0.2-1.9-0.3
														  c-2.1,0.2-4.3,0.4-6.5,0.6c-0.1,0.1-0.2,0.1-0.3,0.2h-1.4c0.6,0,1.1-0.1,1.7-0.2c1.8-0.8,3.7-0.9,6.5-0.6c4.8-0.5,9.6-1,14.3-1.6
														  c1.6-0.4,3.4-0.5,5.8-0.8c3.9-0.6,7.6-1.2,11.3-1.9C678.8,140.2,675.6,141.3,671.5,141.3z M687.6,158.4c1.4,0,2.3-0.7,3.7-0.7h2.8
														  C692.2,157.7,689.9,158.4,687.6,158.4z M694.5,149.9c0-0.5,0-0.7,0-0.7s0.5,0,0.9,0C695.4,149.4,695,149.9,694.5,149.9z
														   M697.2,142.3c-1.8,0.5-3.2,0-3.7-0.4c0,0,0,0,0-0.2c0.9,0.5,1.8,0.7,4.2,0.7C697.2,142.3,697.2,142.3,697.2,142.3z M704.6,140.7
														  c-0.1,0-0.2,0.1-0.5,0.2c-0.1,0-0.2,0-0.3,0c-0.2,0.1-0.4,0.3-0.6,0.4c0-0.3,0.3-0.4,0.6-0.4C704.1,140.8,704.3,140.7,704.6,140.7
														  c0.1,0,0.2,0,0.5,0C704.9,140.6,704.8,140.7,704.6,140.7z M711.5,136.7c-2.9,0.4-5.6,0.4-7.9,1c-0.6,0.3-1.2,0.4-1.7,0.6
														  c0.6-0.2,1.1-0.4,1.7-0.6c0.3-0.2,0.7-0.3,1-0.6c1.8-0.4,4.6-0.4,6.9-1.1C711.5,136.5,711.1,136.7,711.5,136.7z M737.8,138.3
														  c2.3,0.7,4.6,1.2,7.4,1.2C742.4,139.5,739.6,139.3,737.8,138.3z M749.3,151.5c0,0,0-0.7,0.5-0.7h1.8
														  C750.7,151.3,749.8,151.3,749.3,151.5z M782.5,134.4c0-0.2-0.5-0.7-1.4-0.7C782,133.7,783.9,133.7,782.5,134.4z M804.1,148.3
														  c0,0,0.3-0.2,0.2-0.2c0,0-0.1,0-0.2,0c0.1,0,0.1,0,0.2,0C804.6,148.1,804.5,148.3,804.1,148.3z M809.7,126.3c-0.4,0-0.4,0-0.4,0
														  s0,0,0.4-0.2V126.3z M822.6,126.3c0.4-0.2,0-0.4,0.4-0.4c0,0,0.5,0,0.9,0c1.4,0,2.8,0,4.1,0.4
														  C826.2,125.9,824.4,125.9,822.6,126.3z M829.5,133.5c-0.5,0.2-0.5,0.2,0,0.7c0,0-0.5,0-0.9-0.4C828.6,133.7,829,133.7,829.5,133.5
														  z M829.5,138.3c0-0.2,0-0.2,0-0.4h0.4C829.9,138.1,829.5,138.1,829.5,138.3z M846.1,132.8h-0.5c0.5,0,0.9,0,1.4-0.5
														  C846.5,132.8,846.5,132.8,846.1,132.8z M867.2,147.6h-4.1c4.1-0.5,7.4-0.9,10.6-1.6C871.9,146.4,870,147.1,867.2,147.6z
														   M880.1,116c0.9,0,1.8-0.2,2.8-0.2c0.4,0,0.4,0.2,0.9,0.2H880.1z M891.7,133.6C891.7,133.7,891.7,133.7,891.7,133.6l-1.4,0.1
														  C890.9,133.7,891.4,133.7,891.7,133.6c0-0.1,0.1-0.1,0.4-0.1C892,133.6,891.9,133.6,891.7,133.6z M900.9,143.4h-4.2
														  c3.2-0.2,6-0.2,8.3-1.2C904.1,143,903.2,143.2,900.9,143.4z M909.6,150.4c-0.6,0.1-1.2,0.3-1.8,0.4H906
														  C907.2,150.6,908.4,150.5,909.6,150.4c1.3-0.3,2.6-0.5,4.2-0.5C912.5,150.1,911.1,150.2,909.6,150.4z M976.4,132.1v-0.2l0.5,0.2
														  C976.9,132.1,976.9,132.1,976.4,132.1z M980.1,121.3c-0.5-0.5,0-0.9,2.8-1.2C981.1,120.4,980.1,120.8,980.1,121.3z M1005.9,117.4
														  c0.5,0,0.9,0,1.4,0.2c-0.5,0.2-0.9,0.2-1.4,0.2V117.4z M1005,131c1.4,0.2,3.2,0.7,5.1,0.7C1008.7,131.6,1006.8,131.6,1005,131z
														   M1045.6,132.8C1045.5,132.8,1045.5,132.8,1045.6,132.8c-0.9,0-1.8-0.1-2.6-0.2c-0.7,0-1.4,0-2-0.2l0.4-0.2c0.4,0.2,1,0.3,1.6,0.4
														  C1043.8,132.6,1044.7,132.5,1045.6,132.8c0.6,0,1.3,0,1.8,0H1045.6z M1066,130.8c-1,0.1-1.8,0.1-2.4-0.1c-1.4-0.1-2.8-0.2-4.1-0.5
														  c-0.3,0-0.6-0.1-1-0.2c0.3,0.1,0.6,0.1,1,0.2c1.1,0.1,2.1-0.1,3.2,0.3c0.3,0.1,0.6,0.2,0.9,0.2
														  C1064.3,130.8,1065.2,130.8,1066,130.8c0.7-0.1,1.6-0.2,2.6-0.3h3.2C1069.7,130.7,1067.8,130.8,1066,130.8z M1079.6,125.2
														  c-2.3,0-3.7,0-2.8-0.7c0.9,0.5,2.8,0.5,4.6,0.5C1081,125,1080.6,125.2,1079.6,125.2z M1132.2,119.6c-0.5-0.7-1.4-1.2-2.8-1.4
														  c1.4,0,2.3,0,2.8,0.2C1133.1,119,1132.2,119,1132.2,119.6z M1144.2,132.3c-0.5-0.2-0.5-0.4-0.5-0.7c0.5,0.2,1.8,0.5,3.2,0.5
														  C1146,132.1,1145.5,132.8,1144.2,132.3z M1335.8,74l0.4-0.5c0,0,0.5,0,0.5,0.2C1336.7,73.8,1336.3,74,1335.8,74z M1368.1,121.3
														  h-2.3c1.4,0,2.8-0.5,3.7-0.9C1369,120.8,1369,121,1368.1,121.3z M1409.1,124.7c-1.2-0.2-2.4-0.6-2.7-1c-0.2-0.1-0.4-0.1-0.5-0.2
														  h0.5c0,0.1,0,0.1,0.1,0.2c2.2,0.7,4.8,0.3,7.8,0.3C1412.3,124,1410.9,124.7,1409.1,124.7z M1595.6,144.1c-0.7-0.2-0.6-0.5-0.7-0.6
														  c-0.1,0-0.1,0-0.2-0.1c0.1,0,0.1,0,0.2,0.1c1.3,0.4,2.6,0.6,4,0.6H1595.6z M1799.8,73.5h0.4c0,0.1-0.1,0.2-0.3,0.3
														  c0,0.1-0.2,0.2-0.2,0.2c0-0.1,0.1-0.2,0.2-0.2C1800,73.7,1799.9,73.6,1799.8,73.5z M1815.4,27.9c2.8,0,3.7,0.2,1.8,0.9
														  c-0.5-0.5-1.8-0.9-3.7-0.9H1815.4z M1790.5,40.6c0.8-0.3,1.8-0.3,2.6-0.3c0.5,0,0.9-0.1,1.5-0.2c0.4,0,0.4,0.5,0.9,0.5
														  c-0.7-0.1-1.6-0.2-2.4-0.3c-0.7,0.1-1.4,0.1-2.2,0.3C1790.8,40.5,1790.7,40.6,1790.5,40.6c-0.3,0.1-0.6,0.2-0.9,0.4
														  c-0.5,0-0.5,0-0.5,0C1789.8,40.7,1790.2,40.6,1790.5,40.6z M1760.6,63.2c2.8-0.2,5-0.2,7.8-0.2c0.9,0,0.9,0.2,1.4,0.4
														  C1766.6,62.9,1763.8,62.9,1760.6,63.2z M1827.4,42.8c0,0.7-0.9,1.2-1.9,1.6c-2.3,1.4-5.5,2.8-6.9,4.4c-0.9,1.4-3.2,2.3-7.4,3
														  c-3.2,0.7-6,1.4-8.8,2.1c-2.8-0.2-6-0.4-5.1-1.4c0-0.7,0.9-1.1,3.2-1.8c2.8-0.4,5.1-1.2,7.8-1.6c3.2-0.7,3.2-1.4,3.2-2.3
														  c0-0.9-0.9-1.8-3.7-1.8c-2.3-0.4-5.1,0-7.4,0.5c-1.4,0.2-1.8,0.7-3.2,0.7c0,0,0,0,0,0c-1.3,0.2-2.5,0.3-3.9,0.4
														  c-2.3,0.3-4.5,0.6-7.2,0.8c-0.9,0.4-1.8,0.4-3.2,0.4c-7.4,0.5-12.9,1.8-18.9,3c-3.2-0.4-6,0.2-9.2,0.2c1.4-0.2,3.7-0.2,4.6-0.7
														  c2.8-1.2,4.6-2.6,7.4-3.5c5.1,0,9.7,0,14.7-0.4c1.8-0.2,3.7-0.5,6.4-0.2c1.9,0.3,3.7,0.4,5.4,0.4c1.2-0.1,2.5-0.3,3.9-0.4
														  c1.4-0.2,2.8-0.6,4.2-1.2c1.8-0.7,3.2-1.2,5.1-1.4c1.4-0.7,3.2-1.2,5.1-1.4c3.2-0.9,6.9-0.9,11-0.9
														  C1826.5,41.2,1828.3,41.7,1827.4,42.8z M1844.4,37.8c0,0,0,0,0.5,0c0.4,0,0.9,0.2,1.4,0.2C1845.8,38,1844.9,38,1844.4,37.8z
														   M1280.5,133.3c-3.2,0.5-6.4,1.2-9.2,2.3c-1.8,0.5-4.1,1.2-7.4,1.2c-5.1,0.2-7.8,1.6-11.5,2.8c-0.5,0-0.9,0.2,0,0.7h4.6
														  c8.3-1.8,17.5-2.8,24-5.3c0.4-0.2,2.3-0.2,3.2-0.5c0.5-0.2,1.8-0.7,2.8-0.7C1284.7,132.8,1283.7,132.8,1280.5,133.3z"></path>
													  </g>
													</g>
												  </svg>
												</span>';
				$animated_backgrounds_output .= '<span class="brk-svg-pattern-container brk-svg-pattern-container-12-bottom brk-svg-pattern-container_bottom">
													  <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1920 123" enable-background="new 0 0 1920 123;" xml:space="preserve">
														<g>
														  <g>
															<path class="st0" fill="#FFFFFF" d="M1321.2,4.4c0,0.2,0,0.2,0,0.5c0.5-0.2,0.5-0.2,0.9-0.5C1322.1,4.4,1321.6,4.4,1321.2,4.4z M1847.6,54.5h-4.4
																C1844.7,54.6,1846.1,54.6,1847.6,54.5z M11.4,72.7c0.9,0.9,2.3,1.6,3.2,2.8c0.9,0.7,1.8,1.2,5.1,1.4c3.7,0.5,6.9,0.9,9.2,2.1
																c0.9,0.5,2.8,0.7,4.6,0.5c4.6-0.2,7.9-2.1,6.9-3.5c-0.4-1.1-3.2-2.1-3.2-3.4c-3.2-0.9-6.5-1.8-9.2-2.8c-3.2-1.4-6.9-2.8-12.9-2.1
																c-5.1,0.7-4.2,2.5-4.2,3.7C10.9,71.8,11.4,72.3,11.4,72.7z M743.9,43c1.8,0.2,4.6,0.2,6,0.7c3.2,0.2,6.9,0.2,9.7-0.4
																c0.4,0,0.4,0,0.4,0s0-0.2-0.4-0.2c-4.6-2.3-10.1-2.6-16.1-0.5C743.4,42.7,743.9,42.7,743.9,43z M1919.6,87
																c-2.3,1.4-5.5,2.3-10.1,2.8c-1.4,1.2-4.2,1.6-7.4,2.1c-1.8,0.2-3.7,0.2-6,0.7c-6,0.7-7.4,0.2-7.4-1.6c0.4-1.2,0.4-2.5-4.6-3
																c-2.8-0.2-3.2-0.9-1.4-1.8c2.8-1.4,5.5-2.3,10.6-2.3c5.1,0,6.9-1.4,10.6-1.8c2.3-0.2,0.9-0.9,1.4-1.6c1.4-0.7,0.9-1.4,3.2-1.8
																c6-1.6,7.4-3.2,6-5.3c-0.9-0.7-1.9-0.9-4.2-0.4c-4.2,0.4-8.3,0.9-11.5,1.8c-1.4,0.4-2.8,0.9-4.2,0.9c-6.5,0.7-12,1.8-17.1,3
																c-6,1.4-12.9,2.8-20.3,3.7c-3.7,0.2-5.5,0.2-6.5-0.9c-1.4-1.6,0.5-3.2,5.5-4.4c3.2-0.7,6.4-1.1,9.7-1.4c5.1-0.5,6.4-1.2,3.7-2.1
																c-3.2-1.6-3.7-3.2-2.3-4.8c0.5-0.9,0.9-2.1-0.9-3c-0.9-0.2-0.9-0.7-0.9-1.2c1.4-0.9-0.9-1.2-3.2-1.4c-2.3,0-3.7,0.2-6,0.7
																c-5.1,0.9-8.3,0.9-11.5-0.7c-0.9-0.4-1.8-0.7-2.8-1.4c-1.8-0.9-0.9-1.8,3.2-2.3c2.8-0.2,6-0.7,8.8-0.9c2.3-0.7,5.1-0.7,7.4-0.9
																c2.3-0.2,4.2-0.4,4.6-1.4c0.9-1.1,2.8-2.3,4.6-3.4c0.9-0.5,1.4-0.9,0-1.4c-0.9-0.4-2.8-0.2-3.7,0c-5.5,0.5-10.6,1.2-14.7,2.3
																c-1.5,0.5-3.1,0.8-4.8,0.9h0.7c-2.8,0.5-5.1,0.9-7.4,0.7c-2.3,0-4.2-0.2-6-0.2c-1.4,0-2.8,0-3.7-0.2c-0.4,0-0.9-0.2-1.4-0.2h12.4
																c-4.6,0-10.1-0.2-12.4-1.6c-1.4-1.2-3.2-1.2-6.9-1.2c-6,0.4-11.5,0.9-17.1,0c-1.4-0.5-3.2,0-5.1,0c-5,0.2-10.1,1.4-15.7,0.9
																c-0.9,0-2.8,0.2-4.1,0.5c-5.5-0.2-11.1,0-17.1,0.2c-5.5,0.2-9.7-1.6-7.4-3.4c0.5-0.5,0.9-0.7,0.5-1.2c-1.8-1.8-3.2-3.7-9.7-4.6
																c-3.2-0.2-6.5-0.9-5.5-2.6c0.9-2.1,0-2.3-6.4-2.5c-3.2-0.2-6.5-0.2-8.8-1.2c-1.8-0.7-3.7-0.7-6.5-0.5c-1.8,0.5-4.1,0.7-6.4,0.5
																c-5.1-0.7-11.5-1.4-14.3-2.5c-3.7-2.1-8.8-2.8-15.2-2.8c-0.5,0-0.5,0-0.9,0c-4.6-0.2-9.7,0-14.3,0.5c-3.7,0.7-6.9,0.7-11,0.7
																c-0.9,0.2-1.8,0.5-3.2,0.5c-0.9,0.2-2.3,0.2-2.8,0.4c-4.6,1.2-9.2,1.8-15.2,1.8c-2.3,0-4.6,0.5-5.5,1.4h0.4
																c-3.7,0.5-7.4,1.2-11,0.7c-5.1-0.9-11.1-0.9-17.1-1.2c-6.9,0-7.8-0.4-8.3-2.5c0,0,0-0.2,0-0.4c-0.4-0.7-1.8-1.4-4.6-1.4
																c-2.3-0.5-4.6-0.2-6.4,0.4c-1.4,0.5-2.3,1.2-4.2,1.2c-5.1,0.2-10.6,0.9-16.1,0.9c-6-0.2-11.5-1.1-17,0c-0.5,0-0.5,0-0.9,0
																c-6,0-12-0.2-17.5-1.1c-1.4-0.2-2.8-0.2-3.2-0.7c-1.8-1.6-6.5-2.1-11.5-2.1v-1.1h-1.8c-5.5,0.2-9.7,0-10.6-2.1
																c0-0.2-0.9-0.5-1.4-0.7c-4.6-1.6-10.6-1.8-14.3-0.2c-2.3,0.9-5.1,1.1-7.4,1.8c-0.4,0-1.8,0.4-2.8,0c-0.9-0.2-0.9-0.7-0.4-0.9
																c3.2-0.9,0.4-1.4-1.8-1.6c-3.7-0.7-4.6-1.4-3.7-2.8c1.4-1.2,2.3-2.5,5.5-3.7c2.8-1.4,2.3-1.4-1.4-2.3c-3.2-0.7-6.9-0.7-9.7-1.2
																c-3.7-0.9-5.5-0.9-9.2,0.2c-1.8,0.2-2.8,0.9-4.6,1.4c-4.6,1.6-10.1,2.3-16.1,2.8c-3.7,0-4.6-0.5-3.7-1.6c1.4-0.7,3.2-1.4,2.8-2.3
																c-1.4-2.1-0.9-4.4-0.9-6.7c-0.4-2.6-4.6-3.2-12.9-2.1c-6.4,0.9-10.6,0.7-12.9-1.2c-1.9-1.6-5.1-2.5-6.9-3.9
																c-1.4-0.5-2.3-0.9-4.2-0.7c-5.1,0.4-10.1,0.4-14.3,1.6c-4.6,0.9-6.9,0.7-9.2-0.7c-1.8-1.2-3.2-1.4-6.5-0.5
																c-5.1,1.2-12.9,1.4-15.2,3.7c0,0.2-0.5,0.5-0.9,0.5c-4.2,0.4-7.4,1.4-11.5,2.1c-3.2,0.4-6,0.4-8.8,0c-3.2-0.2-5-1.2-8.8-0.9
																c-1.4,0-1.8-0.5-1.8-0.7c0-1.1-2.3-2.3-7.4-2.8c2.8-0.7,4.1-1.6,1.8-2.5c-0.5,0,0-0.5,0-0.7c-0.3-1.2-0.8-1.8-2.7-1.9h-1.3
																c-0.9,0-2,0.1-3.3,0.3h-1.8c-1.8,0-3.2,0.5-2.3,1.2c0.9,1.2-0.9,1.6-4.1,2.1c-3.7,0.4-6.5,1.6-6.9,2.8c-0.5,0.7-1.8,1.2-4.2,1.6
																c-5.1,0.7-8.8,2.1-14.3,2.8c-1.8,0.2-3.2,1.1-5,0.7c-1.8-0.5-1.4-1.2-1.4-1.8c0,0,1.4-0.7,1.4-0.9c2.3-1.8,6-4.2,4.6-6.2
																c0-0.9,1.4-2.1-1.8-2.3c-4.2,0-4.2,1.4-4.6,2.1c-2.3,3-6.9,6-13.8,8.5c-1.4,0.4-2.3,0.9-2.3,1.4c0.9,2.1-4.2,3.5-6.5,5.3
																c-0.4,0.4-4.1,1.2-6,1.8c-0.9,0.2-1.9,0.5-2.8,0c-2.3-0.2-5.5-0.5-7.8-1.2c-3.2-0.7-3.7-1.8-4.1-3c-0.5-0.2-0.5-0.9-2.3-0.9
																c-2.3-0.2-4.6,0.2-5.5,0.7c-0.9,0.2-1.4,0.7-0.9,1.2c0,0.7-1.4,0.9-2.8,0.9c-3.7,0-8.3,0-10.6-0.9c-3.2-0.9-6.9-1.6-8.8-3
																c-1.4-1.2-2.3-2.5-6.4-3c-6-0.7-12.5-0.7-18-1.8c-0.5,0-2.3,0.2-3.2,0.5c-9.2,0.7-18.4,0.7-27.6,0c-5.1-0.5-5.1-0.5-3.7-1.8
																c1.8-1.8-0.5-2.8-6.9-2.6c-2.8,0.2-5.1,0-6.9-0.9c-1.8-0.7-3.2-0.4-4.2,0.5c-2.8,3-10.1,4.1-18.4,4.4c-6.4,0.5-8.3-0.4-6-2.3
																c2.8-2.6,0-3.7-7.8-3.7c-1.8,0-3.2,0.2-4.6,0.5c-3.7,0.4-7.4,0.7-10.6-0.2c-2.8-0.9-6.5-1.2-11.1-0.9c-0.9,0.2-2.8,0.2-3.7,0
																c-3.7-0.4-7.4-0.2-11.5-0.7h-3.7c-0.5,0.4-1.4,0.4-1.4,0.7c1.4,2.3-5,4.2-6.9,6.4c-0.4,0.7-2.8,0.9-5,1.4
																c-12,1.4-20.7,3.9-22.6,8.1c-0.5,0.4-0.5,0.9-1.4,1.2c-4.2,1.6-4.6,3.4-4.2,5.3c0,1.6,0,3.2,0.5,4.6c0.9,1.6-2.3,3.2-6.9,3.4
																c-6.5,0-9.7,1.2-11.5,2.8c-1.4,1.4-4.6,2.6-9.2,3.2c-2.3,0.2-5.1,0.5-6.9,1.2c-3.7,1.2-5.5,1.2-6.9-0.5c-1.8-2.1-5.5-2.1-11.1-0.7
																c-2.8,0.7-5.1,1.4-7.8,2.1c-3.2,0.7-6,1.2-8.8-0.2c-0.9-0.4-2.3-0.9-5.1-0.7c-2.3,0.2-2.8,1.2-2.8,1.8c-0.5,2.3-6,3.2-11.5,4.4
																c-0.9-2.1-7.4-1.6-11.5-1.9c-6.4-0.2-10.6,0.7-13.4,2.6c-2.8,1.6-6.9,2.8-10.6,4.2c-2.8,0.7-6,1.1-9.2,0.7
																c-2.8-0.7-1.4-1.6-0.4-2.3c0.9-0.7,1.4-1.4-0.5-1.8c-1.8-0.4-4.2-0.2-6.4,0c-4.2,0.7-7.8,1.8-11.5,2.8c-2.8,0.5-4.6,0.7-7.8,0.7
																c-6.4,0-12-1.2-18-1.4h-31.3c-1.9,0-3.2,0-4.6,0.5c-1.8,0.9-5.1,1.4-8.8,1.1c-0.7-0.1-1.4-0.1-2.2-0.1c-0.8,0.1-1.6,0.2-2.4,0.3
																c0.7-0.1,1.6-0.2,2.4-0.3c3.3-0.4,6.5-1,9.1-1.6c1.4-0.7,2.3-0.9,1.4-1.4c-0.9-0.4-2.8-0.4-4.2-0.4c-2.3,0.2-4.6,0.2-6.5,0.2
																c-3.2,0.2-6,0.2-5.5-0.9c0.5-0.5,0-0.9-2.3-0.9c-1.8,0-2.8,0.2-3.7,0.4c-3.7,0.5-6.4,1.2-9.7,1.4c-0.9,0-1.4-0.2-2.3-0.2
																c-1.8,0.2-3.2,0.2-4.6-0.2c-2.8-1.4-6-0.9-9.7-0.2c-3.2,0.7-6.5,1.2-9.7,0.5c-1.4-0.5-3.2-0.5-4.6,0c-3.7,0.9-7.4,0.7-10.6,0.2
																c-2.8-0.7-5.1-0.5-7.8,0c-3.2,0.4-5.1,1.4-6,2.3c-0.9,0.7-1.4,1.6-2.8,2.6c-2.8,1.6-2.8,1.8-9.2,1.8c0-0.2,0.9-0.5,1.4-0.7
																c4.2-1.2,3.7-1.9-1.4-2.3c-3.2,0-6-0.7-8.3-1.2c-1.8-0.7-3.7-0.4-5.5,0c-1.4,0.9-3.2,1.4-3.7,2.3c-0.4,0.7-1.8,0.9-3.7,0.4
																c-3.2-0.7-6-0.2-8.8,0.5c-3.2,0.7-6.9,1.4-10.1,2.3c-2.8,0.7-3.7,0.7-6-0.2c-3.7-1.4-7.8-1.6-13.4-0.7h-2.3
																c-8.3,0-14.3,1.4-20.7,3c-2.3,0.5-4.1,1.2-6.9,0.7c-2.3-0.5-6-0.2-7.4-0.9c-2.3-0.9-4.6-0.9-7.4-0.2c-1.8,0.2-2.8,0.7-5.5,0.9
																c-0.4-0.9-0.4-2.3-5.5-2.3c-4.6,0.2-8.8,0-12.9-0.4c-2.3,0-4.6-0.2-6.9-0.2c-6,0.2-11.5,0-17.1-0.5c-4.6-0.2-7.8-3-4.6-3.7
																c4.6-1.4,4.6-2.3,1.8-3.4c-0.5-0.2-0.9-0.7-0.9-0.7c-2.3-2.5-2.3-2.5-10.1-1.8c-0.9,0-1.8,0-3.2,0.5c-2.3,0.2-4.2,0.9-3.2,1.8
																c1.4,1.2-3.2,2.5-1.8,3.9c0,0-0.5,0.2-1.4,0.4c-2.3,0.5-2.8,0.9-1.8,1.9c0.4,0.2-0.5,0.4-1.8,0.7c-4.6,0.7-8.8,1.6-13.8,2.3
																c-2.3,0-3.2,0-4.6-0.7c-2.8-1.2-4.2-3-10.1-3.2c0.4-0.9,2.8-1.4,4.2-2.1c2.3-0.7,1.8-1.2-1.4-1.4c-4.6,0-7.4,0.7-6,2.1
																c0.9,1.4-1.4,2.3-6,2.3c-1.4,0-3.2-0.5-4.2-0.7c-0.9-0.4-2.3-0.7-4.1-0.7c-3.2-0.5-3.7-0.9-2.3-1.6c1.8-0.7,3.7-1.4,6.9-1.4
																c2.8,0,3.7-0.5,4.6-1.2c0.9-0.9,0-1.8-2.8-2.3c-2.3-0.7-4.6-1.4-8.3-0.9c-1.9,0.2-3.2,0.7-4.6,0.9c-4.2,0.7-8.3,1.4-12.4,0.4
																c-1.4-0.4-3.2-0.4-5.1-0.4c-2.8,0.2-4.2,0-6-0.5c-3.2-0.7-6.4-1.6-11.5-0.5c-1.8-0.2-4.2-0.2-5.5-0.7c-2.3-0.4-4.6-0.7-7.4-0.4
																c-1.8,0.2-3.7,0.2-5.5,0.2c-7.4,0.2-12.9-1.6-11.1-3.9c0.9-0.9,0.9-1.8-1.8-2.5c0,0.2-0.5,0.2-0.5,0.2c-1.1,0.4-1.7,0.8-2.4,1.2
																c-0.4,0.3-1,0.6-1.8,0.9c0.8-0.3,1.3-0.6,1.8-0.9c0.8-0.6,1.3-1.2,2.8-1.4c0.9-0.7,2.8-1.4,5.5-0.7c0.9,0.2,1.4,0.7,2.8,0.2
																c1.8-0.2,2.3-0.9,1.4-1.4c-3.7-2.3-4.6-2.6-10.1-1.8c-2.8-0.7-5.1-1.4-7.8-1.6c-1.4,0-2.8,0.2-4.2,0.2c-1.8,0-3.2-0.2-5-0.2
																c-3.2-1.1-6.9-0.9-11.1,0.2c2.3,0.5,4.6,0,6.4,0.5c0.5,0,0.9,0.2,0.5,0.4c-0.5,0-1.4,0.2-1.8,0.2c-2.3-0.2-3.7,0.2-5.5,0.4h-0.4
																c0,0,0.4-0.2,0.4-0.4c-6.4-1.4-12.9-1.8-21.2,0c-2.3,0.4-5.1,0.7-7.8,0.4c-3.7-0.2-6.5,0-8.8,0.9c-1.4,0.4-3.2,0.4-5.1,0.2
																c-7.4-1.6-15.7-0.9-24-0.9c-9.7-0.2-12-0.4-12.9-3.2c-0.9-3-5.5-5.3-15.7-6c-6-0.5-11.5-1.2-17.5-1.4c-3.2-0.2-5.5-1.2-9.2-0.7
																c-3.7,0.7-7.4,0.7-10.6,0.9c-1.4,0-2.8,0.4-3.2,0.7c-1.9,0.9-4.6,1.4-7.8,1.6c-2.8,0.2-5.1,0.7-4.6,1.9c0.5,0.9-1.8,1.1-4.2,0.9
																c-1.8,0-3.2-0.2-4.1-0.7c-1.4-0.9-3.2-0.7-5.5-0.2c-1.8,0.7-3.7,0.9-5.5,0.2c-2.3-0.7-4.6-0.2-7.4,0c-6,0.9-12,2.3-19.3,1.8
																c-4.2-0.2-5.5,0.2-7.8,1.6c-1.4,0.7-3.2,1.8-5.1,2.5c-1.4,0.7-3.7,1.2-6.4,0.7c-7.4-0.9-15.7-1.2-23-2.1c-2.3-0.5-4.6-0.7-7.4-0.7
																c-5.1,0-8.3,0.7-9.2,2.3c-0.9,1.6-2.8,2.1-7.8,1.6c-2.8-0.2-3.7,0-5.1,0.5c-0.9,0.7-1.8,1.4-4.6,1.8c-3.7,0.5-5.5,1.4-6.9,2.3
																c-1.4,0.9-3.2,1.4-6,1.4c-5.5,0.2-5.5,0.2-7.4,2.1c1.4,2.1,1.4,2.1-5.1,3.2c-0.9,0-1.8,0-2.3,0.2c-3.7,0.7-4.6,1.4-3.7,2.5
																c0.9,0.9,1.8,1.6,1.4,2.3c1.9,0.7,3.2,1.2,3.7,1.8c1.4,2.3,3.2,4.6,5,6.7c0.5,1.2-0.4,1.8-4.1,2.3c-5.5,0.2-6.5,1.4-6,3
																c1.4,2.5,4.2,5.3,6.4,7.8c2.8,2.3,1.4,4.4,0,6.7c-0.4,0.9-2.8,2.1-5.5,2.5c-2.3,0.7-4.6,0-6.9,0c-4.6-0.4-7.4,0.2-8.8,1.4
																c-4.2,3.4-10.1,6.4-19.8,8.5c-3.2,0.9-5.5,1.8-4.2,3c1.4,1.4-1.8,2.3-5.1,3c-2.3,0.7-5.5,0.7-8.3,0.9c-0.3,0-0.5,0.1-0.8,0.1v18.4
																c0.7,0.1,1.4,0.1,2.1,0.2c-0.8,0.1-1.6,0.3-2.1,0.4v4.2h1920V86.9C1919.9,86.9,1919.7,87,1919.6,87z M1898.5,80.7
																c0-0.1,0.2-0.2,0.4-0.2C1898.8,80.6,1898.6,80.7,1898.5,80.7c0,0.1,0,0.2,0,0.3c-0.9,0.2-3.2,0.9-5.1,1.2
																C1895.5,81.7,1897.2,81.3,1898.5,80.7z M43.2,121.4c0,0.2-0.9,0.7-1.4,0.9c-2.8,0.5-6,0.7-9.2,0.2c-3.7,0-5-0.5-4.1-1.4
																c1.4-0.4,3.7-0.4,4.6-0.9c1.4-0.9,4.6-0.9,6.9-0.7S43.6,120.2,43.2,121.4z M192,31.2c0.9,0,2.3-0.2,3.2,0c0.4,0,0.4,0.2,0.9,0.4
																C194.7,31.2,193.4,31.2,192,31.2z M390.5,47.6c0,0-0.1-0.1-0.1-0.1c-2.2-0.3-4.7-0.1-7.2,0.1c1.4-0.2,2.8-0.7,4.6-0.7
																c1.3,0,2.1,0.2,2.6,0.6c0.2,0,0.4,0.1,0.6,0.1C391,47.6,391,47.6,390.5,47.6z M412.7,87c0.9-0.2,0.9-0.4,2.3-0.4
																c0.5,0,0.5,0.2,0.5,0.2C414.5,86.8,413.6,86.8,412.7,87z M427.4,58.2l0.9-0.4C427.9,58,427.4,58.2,427.4,58.2z M428.3,50.1
																c0.4-0.2,0.4-0.7,1.4-0.7c0.5-0.2,1.4-0.2,2.3-0.4C430.2,49.4,429.2,49.6,428.3,50.1z M469.8,55.9c1.4-0.2,1.4-0.7,2.8-0.7
																c0.4,0,0.4,0.2,0.9,0.2C472.1,55.4,471.2,55.6,469.8,55.9z M478.1,58.6l-0.4-0.2c0-0.2,0-0.4,0-0.4c0.9,0.4,1.8,0.4,2.8,0.4
																C479.9,58.6,479,58.6,478.1,58.6z M551.3,61c-0.5-0.2,0-0.2,0-0.2V61z M614.3,58.5c-3.5,0.1-6.8,0.6-9.9,1.3
																c-0.5,0.3-1.3,0.5-2.4,0.6c0.8-0.2,1.6-0.5,2.4-0.6c0.1-0.1,0.3-0.2,0.4-0.3c0.5-1.2,3.7-1.2,6.9-1.2
																C612.5,58.5,613.4,58.5,614.3,58.5c2.7-0.1,5.5-0.1,8.5,0.1C619.9,58.6,617.1,58.6,614.3,58.5z M664.2,60.5
																c1.4-0.2,3.2-0.4,4.2-1.4C667.9,60,666.1,60.3,664.2,60.5z M672,62.3c-0.5,0,0.4-0.2,0.4-0.2c0,0.2,0,0.2,0.9,0.5
																C673,62.6,672,62.6,672,62.3z M679.9,63c-0.6-0.1-1.1-0.2-1.7-0.2c-0.3,0-0.7,0-1,0c0.3,0,0.7,0,1,0c1-0.1,2.1-0.5,3.1-0.5
																C680.8,62.6,680.3,62.8,679.9,63z M682.2,60c-0.3,0-0.8,0-1.2,0.1c-0.2,0-0.4,0.1-0.6,0.1c0.2-0.1,0.4-0.1,0.6-0.1
																c1.5-0.4,3.2-0.7,4.4-1.2C684.5,59.3,683.3,59.6,682.2,60z M719.9,67.1c-1.3,0-2.5,0-3.7,0C717.5,67.2,718.7,67.2,719.9,67.1
																c1.2,0,2.4-0.1,3.7-0.2h7.8C727.6,66.9,723.8,67.1,719.9,67.1z M770.6,51.7c-0.2,0-0.5,0-0.7-0.1c-0.8-0.1-1.4-0.3-1.6-0.8
																c0.7,0.3,1.1,0.7,1.6,0.8c0.7,0.1,1.4,0.1,2,0.1H770.6z M774.3,55.2c1.4,0,2.3,0,3.2,0.2c0.9,0.2,1.4,0.2,2.8,0.5
																C778.5,55.6,776.6,55.4,774.3,55.2z M834.7,58.2c-0.4-0.2-0.4-0.2-0.4-0.2c0.4,0,0.4,0.2,0.9,0.2H834.7z M868.3,52.4h-1.4
																c1.4,0,2.3-0.4,3.2-0.4C869.7,52,869.2,52.4,868.3,52.4z M887.6,60.7c0.5,0,0.9,0,1.4-0.2h0.5c0.9,0,0.9,0.5,1.4,0.7
																C890,60.7,888.6,61,887.6,60.7z M915.3,66.7h-0.4c0,0,0.4,0,0.9-0.2C915.3,66.7,915.3,66.7,915.3,66.7z M916.7,63.3
																c2.3,0,3.7-0.2,6-0.4c-0.9,0-1.8,0.4-2.8,0.4C918,63.5,918,63.3,916.7,63.3z M923.9,65.7c-0.1,0-0.2,0.1-0.3,0.1
																c-0.5,0-0.9-0.2-1.4,0c0.5-0.2,0.9,0,0.9-0.2C923.4,65.6,923.6,65.6,923.9,65.7c0.2-0.1,0.3-0.1,0.6-0.1
																C924.3,65.7,924.1,65.7,923.9,65.7z M953.1,60.5c0-0.1,0-0.1,0-0.2c-0.1,0-0.3-0.1-0.4-0.1c0.3,0,0.4,0,0.4,0.1
																c0.3,0.1,0.5,0.2,0.5,0.4C953.5,60.5,953.1,60.5,953.1,60.5z M974.7,56.8c0,0,0,0-0.5,0c0.5-0.2,0.5-0.2,0.5-0.5
																C974.7,56.6,974.7,56.6,974.7,56.8z M995.5,54c0-0.2,0-0.2,0-0.2C995.9,53.8,995.5,53.8,995.5,54z M1009.7,51.3c0,0,0,0,0-0.2
																c0.5,0,0.5,0.2,0.5,0.2S1010.2,51.3,1009.7,51.3z M1102.3,24.5c-1.8,0.4-3.2,0-4.6-0.5c4.1,0.5,6.9-0.2,8.8-1.4
																C1106,23.4,1104.7,24,1102.3,24.5z M1123.5,44.6c0.5,0.7,0.5,1.4,1.4,2.1C1124,46,1123.1,45.5,1123.5,44.6z M1138.7,40.9
																c0-0.5-0.9-0.9,0.9-1.4C1139.2,40,1138.7,40.4,1138.7,40.9z M1140.6,45.3c0,0,0-0.7,0.9-0.7s1.4,0.2,1.8,0.5
																C1142.4,45,1141.1,45,1140.6,45.3z M1140.6,41.8c1.4,0,1.8,0,2.8-0.2C1142.4,41.8,1142,42,1140.6,41.8z M1169.6,34.9
																c-0.5,0.2-0.9,0.2-1.4,0.5c0.4-0.2,1.4-0.5,1.8-0.7C1169.6,34.9,1170.1,34.9,1169.6,34.9z M1170.5,28.7c0.4,0,0-0.2,0.4-0.2
																c0.5,0,0.5,0.2,0.9,0C1171.5,28.7,1171,28.7,1170.5,28.7z M1174.8,33c0,0-0.1,0-0.1,0.1c0,0,0,0-0.4,0
																C1174.4,33,1174.6,33,1174.8,33c0.4-0.3,1.1,0,1.8-0.1C1176,32.9,1175.4,32.9,1174.8,33z M1201.4,28c0.5-0.2,0-0.4,0.9-0.7
																c0.9-0.2,2.3-0.2,3.2-0.2C1203.7,27.3,1202.3,27.5,1201.4,28z M1193.1,27c5.5-1.4,12-1.8,18.4-1.2
																C1205.1,25.4,1198.6,25.7,1193.1,27z M1215.4,28.2c-0.3,0-0.5,0-0.7,0h0.4C1215.3,28.2,1215.4,28.2,1215.4,28.2
																c0.3,0,0.7,0.1,1.2,0.2C1215.9,28.4,1215.7,28.3,1215.4,28.2z M1246.1,33.7c0.4,0,0.4,0,0.4,0c0,0.5,0.9,0.5,1.4,0.9
																C1247.5,34.2,1246.5,34.2,1246.1,33.7z M1253,59.3c0-0.2,0-0.7-0.5-0.9c0.5,0.2,0.5,0.2,0.9,0.2
																C1253.5,58.6,1253.5,59.1,1253,59.3z M1252.1,34.9c2.8,1.2,6,1.6,10.1,1.8C1258.1,36.7,1254.8,36,1252.1,34.9z M1273.3,40.4
																c1.4-0.2,2.8-0.4,4.6-0.2h1.4c3.7,0.2,6,0.9,6.9,1.6C1283.4,40.4,1278.8,40.2,1273.3,40.4z M1447.4,23.1c-0.5,0,0,0.2-0.9,0.2
																C1447,23.1,1447,23.1,1447.4,23.1z M1437.4,67.8c0.2-0.2-0.1-0.4,0.3-0.6h1.8C1438.8,67.2,1437.9,67.4,1437.4,67.8z M1447.9,56.8
																c-0.3,0-0.4-0.1-0.6-0.2c-0.3,0-0.5,0-0.7-0.1c0.4,0,0.6,0,0.7,0.1c1.2,0.1,2.7-0.1,3.4-0.1C1449.7,56.6,1448.8,56.8,1447.9,56.8z
																 M1455.3,41.3c0-0.2,0.4-0.2,0-0.2c0.4,0,0.4,0,0.9,0C1455.7,41.1,1455.7,41.1,1455.3,41.3z M1468.7,32.4c-0.2,0-0.3,0-0.5,0
																C1468.6,32.4,1468.6,32.4,1468.7,32.4C1468.6,32.4,1468.7,32.4,1468.7,32.4c1.6,0.1,2.9-0.5,4.6-0.3
																C1471.4,31.9,1469.6,33,1468.7,32.4z M1478.4,45.3c-0.1,0.1-0.1,0.2-0.1,0.2c-3.2,1.2-5,1.2-6.9,0c-0.5-0.2-0.5-0.2-0.5-0.2
																C1472.7,45.9,1475.3,46,1478.4,45.3c0.1,0,0.2-0.1,0.3-0.1C1478.6,45.3,1478.5,45.3,1478.4,45.3z M1472.8,34.9
																c4.2,0.2,7.4-0.2,10.1-1.4C1480.6,34.7,1476.9,35.4,1472.8,34.9z M1488.9,31.4c0-0.2,0.9-0.5,1.8-0.5c0.9,0.2,0.9,0.2,0.9,0.5
																C1490.7,31.2,1489.8,31.2,1488.9,31.4z M1505,42.3c2.3,0.9,5.5,1.4,9.7,1.4C1510.5,43.9,1507.3,43.2,1505,42.3z M1609.1,81
																c0.9-0.9,2.8-1.6,4.2-2.1C1611.9,79.6,1610,80.3,1609.1,81z M1627.6,42.2c-0.1,0.1-0.2,0.1-0.5,0.1c-1.8,0.9-3.7,0.9-5.1,0
																c0,0-0.4,0-0.9-0.2C1623.3,42.7,1625.4,42.7,1627.6,42.2c0.1-0.1,0.2-0.1,0.4-0.1C1627.9,42.1,1627.7,42.1,1627.6,42.2z
																 M1679.6,81.3c-0.5-0.1-0.3-0.4-0.3-0.7c-0.2-0.2-0.4-0.5-0.6-0.7c0.6,0.2,0.7,0.5,0.6,0.7c0.2,0.3,0.5,0.5,0.7,0.7
																C1679.6,81.3,1679.6,81.3,1679.6,81.3z M1721.1,70.6c1.4,0,2.8,0.2,3.2,0.4C1723.9,70.9,1722.5,70.9,1721.1,70.6z M1747.4,54
																c0.9,0.4,2.3,0.9,4.2,0.9C1749.6,55,1747.8,54.5,1747.4,54z M1750.6,51.7c0.5,0.4,0.9,0.7,1.9,1.2
																C1751.5,52.6,1751,52.2,1750.6,51.7z M1796.7,53.6c0,0.2,0.4,0,0.9,0.2C1797.1,53.8,1796.7,53.8,1796.7,53.6z M1839.5,62.6
																c0,0-0.5,0.2,0,0.2c-0.5,0,0,0-0.5,0C1839,62.6,1839.5,62.6,1839.5,62.6z M1831.7,67.2c0.4-0.4,0.4-0.7,0.9-1.2
																c-0.5,0.7,0.5,0.9,1.4,1.2H1831.7z M1835.3,86.8c-0.3,0-0.4-0.1-0.6-0.2c-0.1,0-0.2,0-0.3,0c0.1,0,0.2,0,0.3,0
																c1.4,0.2,3.1,0.4,4.8,0.4C1838.1,87,1836.3,87,1835.3,86.8z M1838.6,69.7h0.4c0.9-0.2,2.8,0,4.2,0c0.9,0,1.4,0.2,2.3,0.4
																C1843.2,69.7,1841.3,69.7,1838.6,69.7z M1857.5,84.9c-0.8,0.2-1.5,0.3-2.3,0.5C1856.1,85.2,1856.5,84.9,1857.5,84.9
																c1.5-0.3,2.9-0.6,4.1-0.9C1860.2,84.5,1859.3,84.9,1857.5,84.9z M989.5,31.2c0.4,0,0.9-0.2,1.4-0.5c0-0.2,0.5-0.2-0.9-0.4
																l-0.9,0.2C988.6,30.7,988.6,31,989.5,31.2z"></path>
														  </g>
														</g>
													  </svg>
													</span>';
				break;
				
			// SVG Pattern type 2
			case "svg_pattern_2":

				$svg_pattern_top = '<span class="brk-svg-pattern-container brk-svg-pattern-container-1 brk-svg-pattern-container_top"><svg xmlns="http://www.w3.org/2000/svg" xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1922 149">
						<defs>
							<path id="id-1-1" d="M0 4050.12s200.64 67.84 459 61.88c371.06-8.57 855.17-71.9 984-71.9 252.85 0 422.43 53.4 477 77.06V4033H0z" />
						</defs>
						<g>
							<g transform="translate(1 -4032)">
								<use fill="#fff" href="#id-1-1" />
							</g>
						</g>
					</svg></span>';

				$svg_pattern_bottom = '<span class="brk-svg-pattern-container brk-svg-pattern-container-2 brk-svg-pattern-container_bottom" data-brk-library="component__svg_pattern"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 197.02">
						<defs>
							<style>.a5 { fill: url(#some-id-1); } .a5, .b5 { fill-rule: evenodd; } .b5 { fill: #fff; }</style>
							<linearGradient id="some-id-1" y1="240" x2="1787" y2="240" gradientUnits="userSpaceOnUse">
								<stop offset="0%" stop-color="var(--brand-primary)" />
								<stop offset="80%" stop-color="var(--secondary)" />
							</linearGradient>
						</defs>
						<path class="a5" d="M1231,109.07C974.2,70.21,708.37,12,477,1.12,258.44-9.18,54.57,54.45,0,78.08V197H1920V31.1S1603.21,165.38,1231,109.07Z" />
						<path class="b5" d="M1920,131.06s-316.79,72.31-689,16C974.2,108.19,706.37,41,475,30.1,256.44,19.81,54.57,70.55,0,94.18V197H1920Z" />
					</svg></span>';

				break;

			// SVG Pattern type 7
			case "svg_pattern_7":

				$svg_pattern_top = '<span class="brk-svg-pattern-container brk-svg-pattern-container-7-top brk-svg-pattern-container_top">
						<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1920 144">
							<defs>
								<path id="id-7-1" d="M0 657.88s316.8-72.16 689-15.96c256.8 38.77 524.63 105.83 756 116.7 218.56 10.27 420.43-40.37 475-63.95V616H0z"/>
							</defs>
							<g>
								<g transform="translate(0 -616)">
									<use fill="#fff" xlink:href="#id-7-1" />
								</g>
							</g>
						</svg>
					</span>';

				/* Disabled temporary
				$svg_pattern_bottom = '<span class="brk-svg-pattern-container brk-svg-pattern-container-7-bottom brk-svg-pattern-container_bottom" data-brk-library="component__svg_pattern">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1920 144">
						<defs>
							<path id="id-7-2" d="M1920 1489.12s-316.8 72.16-689 15.96c-256.8-38.77-524.63-105.83-756-116.7-218.56-10.27-420.43 40.37-475 63.95V1531h1920z"/>
						</defs>
						<g>
							<g transform="translate(0 -1387)">
								<use fill="#fff" xlink:href="#id-7-2" />
							</g>
						</g>
					</svg>
				</span>';*/

				break;

			// SVG Pattern type 9
			case "svg_pattern_9":

				$svg_pattern_top = '<span class="brk-svg-pattern-container brk-svg-pattern-container-9-top brk-svg-pattern-container_top" data-brk-library="component__svg_pattern">
						<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 2149 668">
							<defs>
								<path id="id-9-1" d="M-113 3591s160.39-76.16 383 66 421.43 37.9 599-93 323.7-156.49 564-121c240.3 35.49 380.2-14.24 400-151 19.8-136.76 27.99-208.27 194-226 166.01-17.73-2122 0-2122 0z"/>
							</defs>
							<g>
								<g transform="translate(113 -3058)">
									<use fill="#fff" xlink:href="#id-9-1" />
								</g>
							</g>
						</svg>
					</span>';

				$svg_pattern_bottom = '<span class="brk-svg-pattern-container brk-svg-pattern-container-9-bottom brk-svg-pattern-container_bottom" data-brk-library="component__svg_pattern">
						<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 2210 97">
							<defs>
								<path id="id-9-2" d="M-101 4083s211.85 45.41 490 27c299.88-19.85 676.93-102.62 952-72 473.8 52.74 553.32 66.99 677 26 123.68-40.99 64 64 64 64H-113z"/>
							</defs>
							<g>
								<g transform="translate(113 -4031)">
									<use fill="#fff" xlink:href="#id-9-2" />
								</g>
							</g>
						</svg>
					</span>';

				break;

			// SVG Pattern type 10
			case "svg_pattern_10":

				$svg_pattern_top = '<span class="brk-svg-pattern-container  brk-svg-pattern-container-10-top brk-svg-pattern-container_top" data-brk-library="component__svg_pattern">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 2123 205">
						<defs>
							<path id="id-10-2" d="M1977 7276.22s35.04 26.84-286-46.9c-321.04-73.75-358.86-84.98-552-44.06-193.14 40.93-347.67 83.47-530 52.63-182.33-30.83-231-21.97-411 17.74-180 39.7-270-116.13-270-116.13l-13-63.5h2123z"/>
							</defs>
							<g>
								<g transform="translate(85 -7076)">
									<use fill="#fff" xlink:href="#id-10-2" />
								</g>
							</g>
						</svg>
					</span>';

				$svg_pattern_bottom = '<span class="brk-svg-pattern-container brk-svg-pattern-container-10-bottom brk-svg-pattern-container_bottom" data-brk-library="component__svg_pattern">
						<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 2278 381">
							<defs>
								<path id="id-10-1" d="M-71 8011s-44.44-43.87 271-2 565.56-160.95 1014-84c448.44 76.95 538.56 78.04 704-102 165.44-180.04 286-183 286-183l-156 381H-69z"/>
							</defs>
							<g>
								<g transform="translate(74 -7640)">
									<use fill="#fff" xlink:href="#id-10-1" />
								</g>
							</g>
						</svg>
					</span>';

				break;

			// SVG Pattern type 11
			case "svg_pattern_11":

				$svg_pattern_top = '<span class="brk-svg-pattern-container brk-svg-pattern-container-11-top brk-svg-pattern-container_top" data-brk-library="component__svg_pattern">
						<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1920 265" enable-background="new 0 0 1920 265" xml:space="preserve">
							<g>
								<g>
									<path fill="#FFFFFF" d="M0,245.355c73.796,20.648,167.146,31.35,259-0.356c198.5-68.516,300.465-106.329,544-77 c229.662,27.66,585.606,115.249,756-12.999C1686.134,59.311,1776.214,8.995,1912.11,0H0V245.355z M1912.11,0h7.89v-0.479 C1917.351-0.336,1914.725-0.173,1912.11,0z" />
								</g>
							</g>
						</svg>
					</span>';

				$svg_pattern_bottom = '<span class="brk-svg-pattern-container brk-svg-pattern-container-11-bottom brk-svg-pattern-container_bottom" data-brk-library="component__svg_pattern">
						<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1920 80" enable-background="new 0 0 1920 80" xml:space="preserve">
							<g>
								<g>
									<path fill="#FFFFFF" d="M1664,26C1193.465-60.58,959.422,159.636,497,45.999C198.597-27.33,60.458,1.476,0,31.136V80h1920V69.241 C1862.24,60.935,1780.166,47.375,1664,26z" />
								</g>
							</g>
						</svg>
					</span>';

				break;

			// SVG Pattern type 13
			case "svg_pattern_13":

				$svg_pattern_top = '';

				$svg_pattern_bottom = '<span class="brk-svg-pattern-container brk-svg-pattern-container-13 brk-svg-pattern-container_bottom">
						<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1920 330">
							<defs>
								<path id="svg-id-3" d="M0 2966s98.3-115.46 548.31-154.15c450.02-38.68 466.35-101.9 834.23-153.11 367.89-51.2 537.46 0 537.46 0V2966z"/>
							</defs>
							<g>
								<g transform="translate(0 -2636)">
									<use fill="#fff" xlink:href="#svg-id-3" />
								</g>
							</g>
						</svg>
					</span>';

				break;

			// SVG Pattern type 14
			case "svg_pattern_14":

				$svg_pattern_top = '<span class="brk-svg-pattern-container brk-svg-pattern-container-14-top brk-svg-pattern-container_top" data-brk-library="component__svg_pattern">
						<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1911 117">
							<defs>
								<path id="id-14-1" d="M485 4584c487.38-58.9 542.18-59.35 824-46 281.82 13.35 336.44-55 611-55H.23S-74.85 4651.65 485 4584z"/>
							</defs>
							<g>
								<g transform="translate(4 -4483)">
									<use fill="#fff" xlink:href="#id-14-1" />
								</g>
							</g>
						</svg>
					</span>';

				$svg_pattern_bottom = '<span class="brk-svg-pattern-container brk-svg-pattern-container-14-bottom brk-svg-pattern-container_bottom" data-brk-library="component__svg_pattern">
						<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1920 210">
							<defs>
								<path id="id-14-2" d="M0 4814.5s79.33 75.42 228.47 13.04c149.15-62.38 140.5 83.83 231.55 78.17 91.06-5.66 117.6-125.87 227.45-127.28 109.85-1.42 167.59 148.14 225.4 25.05 57.82-123.08 159.27-107.04 200.81-33.07 41.54 73.97 61.2 171.28 167.65 147.23 106.45-24.04 106.71-162.14 216.56-128.19 109.84 33.96 116.25 55.07 182.37-3 66.11-58.08 131.63-61.7 151.63 32.07 20 93.77 88.11 86.19 88.11 86.19V4923H0z"/>
							</defs>
							<g>
								<g transform="translate(0 -4713)">
									<use fill="#fff" xlink:href="#id-14-2" />
								</g>
							</g>
						</svg>
					</span>';

				break;

			// SVG Pattern type 15
			case "svg_pattern_15":

				$svg_pattern_top = '<span class="brk-svg-pattern-container brk-svg-pattern-container-15-top brk-svg-pattern-container_top" data-brk-library="component__svg_pattern">
						<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1920 237">
							<defs>
								<path id="id-15-1" d="M0 6912s132.83-133.73 460.72-81.1c327.9 52.63 536.48 71.78 808.73-25.2 272.26-96.97 541.5-46.48 650.55-130.7H0z"/>
							</defs>
							<g>
								<g transform="translate(0 -6675)">
									<use fill="#fff" xlink:href="#id-15-1" />
								</g>
							</g>
						</svg>
					</span>';

				$svg_pattern_bottom = '<span class="brk-svg-pattern-container brk-svg-pattern-container-15-bottom brk-svg-pattern-container_bottom" data-brk-library="component__svg_pattern">
						<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1920 137">
							<defs>
								<path id="id-15-2" d="M1920 8215H0v-80.78c25.76 8.63 67.3 19.24 133 29.1 144 21.64 208.92-49.01 388-50.29 179.08-1.27 262.24 117 496 61.32 215.22-51.26 328.47-96.35 483-96.35 154.53 0 339.96 98.05 420 98.05z"/>
							</defs>
							<g>
								<g transform="translate(0 -8078)">
									<use fill="#fff" xlink:href="#id-15-2" />
								</g>
							</g>
						</svg>
					</span>';

				break;

		}
	}

	//$css_classes[] = 'CSS';
	//$before_classes[] = 'BF';

	if ( $margin_top ) {
		$style[] = 'margin-top: ' . intval( $margin_top ) . 'px';
	}

	if ( $overlay_style && $overlay_style !== 'none' ) {

		if ( $overlay_style == 'overlay_curve_gradient' ) {
			$before_classes[] = 'overlay__curve overlay__gradient';
		} else {
			$before_classes[] = 'position-relative';
			//$before_classes[] = $overlay_style;
		}

		$before_classes[] = 'bg__style';

		$span_overlay_class = array();
		$span_overlay_style = '';

		switch ( $overlay_style ) {
			case "overlay__background":

				if ($custom_background == 'true'){
					$before_classes[]     = 'brk-background-color';
					$span_overlay_style   = 'background-color:' . $background_color;
					$span_overlay_class[] = ( $pattern_type == 'brk-bgi-13' ) ? 'brk-abs-overlay' : 'brk-background-color__before';
				}else{
					$span_overlay_class[] = 'brk-backgrounds__before';
					$span_overlay_class[] = $default_color;
					$span_overlay_class[] = $overlay_opacity;
				}

				break;

			case "overlay__gradient":

				if ( $custom_gradient == 'true' ) {
					$span_overlay_style = 'background: -webkit-gradient(linear, left top, right top, from(' . $color_1 . '), to(' . $color_2 . '));';
					$span_overlay_style .= 'background: -webkit-linear-gradient(left, ' . $color_1 . ', ' . $color_2 . ');';
					$span_overlay_style .= 'background: -o-linear-gradient(left, ' . $color_1 . ', ' . $color_2 . ');';
					$span_overlay_style .= 'background: linear-gradient(to right, ' . $color_1 . ', ' . $color_2 . ');';

					if ( ! empty( $angle ) ) {
						$span_overlay_style = 'background: linear-gradient(' . $angle . 'deg, ' . $color_1 . ' 0%, ' . $color_2 . ' 80%);';
					}

					$span_overlay_class[] = 'brk-layer';
					$span_overlay_class[] = $overlay_opacity;

				} else {

					$span_overlay_class[] = $default_gradient;
					$span_overlay_class[] = $overlay_opacity;
					$span_overlay_class[] = 'brk-backgrounds__before';

				}

				break;


			default:
				$span_overlay_class[] = 'brk-abs-bg-overlay';
				$span_overlay_class[] = $overlay_style;
				break;
		}
		//$span_overlay_class[] = 'brk-layer';
		$span_overlay_class[] = 'position-absolute';

		$span_overlay_class = implode( ' ', $span_overlay_class );

		$overlay_output .= '<div style="' . $span_overlay_style . '" class="' . $span_overlay_class . '"></div>';

	}

	if ( isset( $without_bg_on_mobile ) && $without_bg_on_mobile == 'true' ) {
		$before_classes[] = 'no-bg-sm';
	}

	if ( $pattern_type == "brk-bgi-13" ) {
		$overlay_output .= '<span class="brk-abs-overlay ' . $pattern_type . ' brk-bg-pattern"></span>';
	}
	
	/* */

	if ( isset( $bg_type ) && $bg_type == 'animated_background' ) {

		if ( $animated_bg_type != 'balls' ) {
			brs_add_libraries( 'component__backgrounds' );
		} else {
			brs_add_libraries( 'component__backgrounds_css' );
		}

		$animated_backgrounds_output = '';
		$before_classes[]            = 'brk-backgrounds';
		$css_classes[]               = 'brk-backgrounds__content';

		switch ( $animated_bg_type ) {
			case "type_1":
				$animated_backgrounds_output = '<div id="brk-particles-standart" class="brk-backgrounds__canvas"></div>';

				break;
			case "type_2":
				$animated_backgrounds_output = '<div id="fss" class="brk-backgrounds__canvas"></div>';
				break;
			case "type_3":
				$animated_backgrounds_output = '<canvas id="brk-metaballs" class="brk-backgrounds__canvas"></canvas>';
				break;
			case "type_4":
				$before_attr[]               = 'data-skrollr';
				$animated_backgrounds_output = '<div class="brk-backgrounds__parallax">
													<div class="brk-backgrounds__parallax--bg-1" data-0="background-position:center 0px;"
														 data-end="background-position:center -3000px;"></div>
													<div class="brk-backgrounds__parallax--bg-2" data-0="background-position:center 0px;"
														 data-end="background-position:center -2000px;"></div>
												</div>';
				break;
			case "type_5":
				$animated_backgrounds_output = '<div class="brk-backgrounds__impuls">
													<span></span>
													<span></span>
													<span></span>
													<span></span>
													<span></span>
												</div>';
				break;
			case "type_6":
				$animated_backgrounds_output = '<canvas id="brk-backgrounds__canvas-1" class="brk-backgrounds__canvas" resize></canvas>
												<canvas id="brk-backgrounds__canvas-2" class="brk-backgrounds__canvas" resize></canvas>';

				break;
			case "type_7":
				$animated_backgrounds_output = '<div class="brk-backgrounds__canvas brk-particles-fluid"></div>';

				break;
			case "type_8":
				$animated_backgrounds_output = '<div class="brk-backgrounds__before brk-base-bg-gradient-18 brk-backgrounds_gradient-flash"></div>
												 <div class="brk-backgrounds__after" style="background-image: url(' . BERSERK_SHORTCODES_URL . '/shortcodes/img/backgrounds-1.png)"></div>';
				break;

			case "balls":
				$animated_backgrounds_output = '<div class="brk-sc-item-page-section-2__balls">
													<span class="brk-radial-ball"></span>
													<span class="brk-radial-ball"></span>
													<span class="brk-radial-ball"></span>
												</div>';
				break;
			case "type_10":
				$animated_backgrounds_output = '<canvas class="brk-backgrounds__canvas brk-playing-hexagons"
												  data-hexagon-radius="50"
												  data-hexagon-max-speed="0.05"
												  data-hexagon-between="2"
												  data-hexagon-line-width="1"
												  data-hexagon-color="cyan"></canvas>';
				break;
			case "type_11":
				$animated_backgrounds_output = '<div id="hexagon-glow">
													<canvas class="brk-backgrounds__canvas"></canvas>
													<canvas class="brk-backgrounds__canvas"></canvas>
												  </div>';

				break;

			case "type_12_1":
				$animated_backgrounds_output = '
					<div class="brk-animated-circle brk-animated-circle-6" style="left:250px;top:165px;right:auto; bottom:auto">
						<div class="brk-animated-circle__figure">
							<div class="brk-abs-overlay brk-bg-pattern brk-bgi-14"></div>
							<div class="brk-abs-overlay brk-base-bg-gradient-90deg"></div>
						</div>
						<div class="brk-animated-circle__container">
							<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="79px" height="70px">
								<linearGradient id="backgrounds-id-1" x1="0%" y1="0%" x2="100%" y2="0%">
									<stop offset="0%" style="stop-color:var(--brk-base-2); stop-opacity:.92" />
									<stop offset="100%" style="stop-color:var(--brk-base-5); stop-opacity:.92" />
								</linearGradient>
								<path fill-rule="evenodd" fill-opacity="0" fill="transparent" stroke="url(#backgrounds-id-1)" stroke-width="4" d="M73.002,64.707 L5.693,45.499 L53.616,5.103 L73.002,64.707 Z"/>
							</svg>
						</div>
					</div>

					<div class="brk-animated-circle brk-animated-circle-9" style="left:auto;top:345px;right:200px; bottom:auto">
						<img class="lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" data-src="' . BERSERK_SHORTCODES_URL . '/shortcodes/img/animated-triangle.png" alt="alt">
						<div class="brk-animated-circle__container">
							<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="80px" height="62px">
								<linearGradient id="backgrounds-id-3" x1="0%" y1="0%" x2="100%" y2="0%">
									<stop offset="0%" style="stop-color:var(--brand-primary); stop-opacity:.92" />
									<stop offset="100%" style="stop-color:var(--secondary); stop-opacity:.92" />
								</linearGradient>
								<path fill-rule="evenodd" fill-opacity="0" stroke="url(#backgrounds-id-3)" stroke-width="4" fill="transparent" d="M74.998,57.000 L5.002,57.000 L40.000,5.003 L74.998,57.000 Z"/>
							</svg>
						</div>
					</div>

					<div class="brk-animated-circle brk-animated-circle-5" style="left:10px;top:720px;right:auto; bottom:auto">
						<img class="lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" data-src="' . BERSERK_SHORTCODES_URL . '/shortcodes/img/animated-circle-1.png" alt="alt">
						<div class="brk-animated-circle__container">
							<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="77px" height="77px">
								<linearGradient id="backgrounds-id-5" x1="0%" y1="0%" x2="100%" y2="0%">
									<stop offset="0%" style="stop-color:var(--brand-primary); stop-opacity:.92" />
									<stop offset="100%" style="stop-color:var(--secondary); stop-opacity:.92" />
								</linearGradient>
								<path fill-rule="evenodd" fill-opacity="0" stroke="url(#backgrounds-id-5)" stroke-width="4" fill="transparent" d="M39.000,6.000 C57.225,6.000 72.000,20.774 72.000,39.000 C72.000,57.225 57.225,71.999 39.000,71.999 C20.775,71.999 6.000,57.225 6.000,39.000 C6.000,20.774 20.775,6.000 39.000,6.000 Z"/>
							</svg>
						</div>
					</div>

					<div class="brk-animated-dot brk-animated-dot-1" style="left:auto;top:820px;right:50px; bottom:auto">
						<div class="brk-animated-dot__container">
						<div class="brk-animated-dot__figure"></div>
						</div>
					</div>

					<div class="brk-animated-dot brk-animated-dot-1" style="left:10px;top:auto;right:auto; bottom:200px">
						<div class="brk-animated-dot__container">
							<div class="brk-animated-dot__figure"></div>
						</div>
					</div>

					<div class="brk-animated-circle brk-animated-circle-3" style="left:auto;top:auto;right:30px; bottom:220px">
						<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="230" height="230" viewBox="0 0 230 230">
							<defs>
								<path id="backgrounds-id-12" d="M188.02 6501c63.52 0 115.01 51.49 115.01 115s-51.49 115-115.01 115S73 6679.51 73 6616s51.5-115 115.02-115z"/>
								<clipPath id="backgrounds-id-11">
									<use fill="#fff" xlink:href="#backgrounds-id-12" />
								</clipPath>
							</defs>
							<g>
								<g opacity=".02" transform="translate(-73 -6501)">
									<use fill="#fff" fill-opacity="0" stroke="#000" stroke-miterlimit="50" stroke-width="24" clip-path="url(&quot;#backgrounds-id-11&quot;)" xlink:href="#backgrounds-id-12" />
								</g>
							</g>
						</svg>
						<div class="brk-animated-circle__container">
							<span class="brk-animated-circle__dot-1">
								<span class="brk-animated-circle__dot-2"></span>
							</span>
						</div>
					</div>
				';

				break;

			case "type_12_2":
				$animated_backgrounds_output = '
					<div class="brk-animated-circle brk-animated-circle-9" style="left:162px;top:271px;right:auto; bottom:auto">
						<img class="lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" data-src="' . BERSERK_SHORTCODES_URL . '/shortcodes/img/animated-triangle.png" alt="alt">

						<div class="brk-animated-circle__container">
							<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="80px" height="62px">
								<linearGradient id="backgrounds-id-13" x1="0%" y1="0%" x2="100%" y2="0%">
									<stop offset="0%" style="stop-color:var(--brand-primary); stop-opacity:.92" />
									<stop offset="100%" style="stop-color:var(--secondary); stop-opacity:.92" />
								</linearGradient>
								<path fill-rule="evenodd" fill-opacity="0" stroke="url(#backgrounds-id-13)" stroke-width="4" fill="transparent" d="M74.998,57.000 L5.002,57.000 L40.000,5.003 L74.998,57.000 Z"/>
							</svg>
						</div>
					</div>

					<div class="brk-animated-circle brk-animated-circle-7" style="left:auto;top:38px;right:-128px; bottom:auto">
						<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="436" height="408" viewBox="0 0 436 408">
							<defs>
								<path id="backgrounds-id-15" d="M1990.07 5023.04c91.51 123.02 63.33 268.04-76.93 323.71-120.72 47.92-281.2-4.33-302.4-153.9-35.78-252.38 287.82-292.83 379.33-169.81z"
								/>
								<linearGradient id="backgrounds-id-16" x1="1825.98" x2="1824.99" y1="5363.99" y2="4955.99" gradientUnits="userSpaceOnUse">
									<stop offset="0" stop-color="var(--brand-primary)" stop-opacity=".9" />
									<stop offset="1" stop-color="var(--brk-base-5)" stop-opacity=".9" />
								</linearGradient>
							</defs>
							<g>
								<g transform="translate(-1607 -4956)">
									<use xlink:href="#backgrounds-id-15" />
									<use fill="url(#backgrounds-id-16)" xlink:href="#backgrounds-id-15" />
								</g>
							</g>
						</svg>
					</div>

					<div class="brk-animated-circle brk-animated-circle-8" style="left:-395px;top:390px;right:auto; bottom:auto">
						<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="569" height="452" viewBox="0 0 569 452">
							<defs>
								<path id="backgrounds-id-17" d="M-400 5576c5.93-190.96 231.5-282.42 358.39-269.39C85.1 5319.62 209.89 5395.82 153 5620c-56.9 224.18-558.93 146.96-553-44z"
								/>
								<linearGradient id="backgrounds-id-18" x1="-400.05" x2="166.95" y1="5530.93" y2="5531.39" gradientUnits="userSpaceOnUse">
									<stop offset="0" stop-color="var(--brand-primary)" stop-opacity=".9" />
									<stop offset="1" stop-color="var(--secondary)" stop-opacity=".9" />
								</linearGradient>
							</defs>
							<g>
								<g transform="translate(401 -5305)">
									<use xlink:href="#backgrounds-id-17" />
									<use fill="url(#backgrounds-id-18)" xlink:href="#backgrounds-id-17" />
								</g>
							</g>
						</svg>
					</div>

					<div class="brk-animated-dot brk-animated-dot-1" style="left:228px;top:50%;right:auto; bottom:auto">
						<div class="brk-animated-dot__container">
							<div class="brk-animated-dot__figure"></div>
						</div>
					</div>

					<div class="brk-animated-dot brk-animated-dot-1" style="left:auto;top:50%;right:228px; bottom:auto">
						<div class="brk-animated-dot__container">
							<div class="brk-animated-dot__figure"></div>
						</div>
					</div>

					<div class="brk-animated-circle brk-animated-circle-3" style="left:60px;top:auto;right:auto; bottom:422px">
						<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="230" height="230" viewBox="0 0 230 230">
							<defs>
								<path id="backgrounds-id-24" d="M188.02 6501c63.52 0 115.01 51.49 115.01 115s-51.49 115-115.01 115S73 6679.51 73 6616s51.5-115 115.02-115z"
								/>
								<clipPath id="backgrounds-id-23">
									<use fill="#fff" xlink:href="#backgrounds-id-24" />
								</clipPath>
							</defs>
							<g>
								<g opacity=".02" transform="translate(-73 -6501)">
									<use fill="#fff" fill-opacity="0" stroke="#000" stroke-miterlimit="50" stroke-width="24" clip-path="url(&quot;#backgrounds-id-23&quot;)"
										xlink:href="#backgrounds-id-24" />
								</g>
							</g>
						</svg>
						<div class="brk-animated-circle__container">

							<span class="brk-animated-circle__dot-1">
								<span class="brk-animated-circle__dot-2"></span>
							</span>
						</div>
					</div>

					<div class="brk-animated-circle brk-animated-circle-6" style="left:auto;top:auto;right:70px; bottom:400px">
						<div class="brk-animated-circle__figure">
							<div class="brk-abs-overlay brk-bg-pattern brk-bgi-14"></div>
							<div class="brk-abs-overlay brk-base-bg-gradient-90deg"></div>
						</div>
						<div class="brk-animated-circle__container">
							<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="79px" height="70px">
								<linearGradient id="backgrounds-id-25" x1="0%" y1="0%" x2="100%" y2="0%">
									<stop offset="0%" style="stop-color:var(--brk-base-2); stop-opacity:.92" />
									<stop offset="100%" style="stop-color:var(--brk-base-5); stop-opacity:.92" />
								</linearGradient>
								<path fill-rule="evenodd" fill-opacity="0" fill="transparent" stroke="url(#backgrounds-id-25)" stroke-width="4" d="M73.002,64.707 L5.693,45.499 L53.616,5.103 L73.002,64.707 Z"/>
							</svg>
						</div>
					</div>
				';

				break;

			case "type_12_3":
				$animated_backgrounds_output = '
					<div class="brk-animated-circle brk-animated-circle-1" style="left:-70px;top:200px; right:auto; bottom:auto">
						<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="417" height="416" viewBox="0 0 417 416">
							<defs>
								<path id="backgrounds-id-1" d="M134.56 5718.66c114.7 0 207.67 92.98 207.67 207.67 0 114.7-92.98 207.67-207.67 207.67-114.7 0-207.67-92.98-207.67-207.67 0-114.7 92.98-207.67 207.67-207.67z"/>
								<clipPath id="backgrounds-id-2">
									<use fill="#fff" xlink:href="#backgrounds-id-1" />
								</clipPath>
							</defs>
							<g>
								<g opacity=".3" transform="translate(74 -5718)">
									<use fill="#fff" fill-opacity="0" stroke="#000" stroke-dasharray="0 16" stroke-linecap="round" stroke-miterlimit="50"
										stroke-width="4" clip-path="url(&quot;#backgrounds-id-2&quot;)" xlink:href="#backgrounds-id-1" />
								</g>
							</g>
						</svg>

						<div class="brk-animated-circle__container">
							<span class="brk-animated-circle__dot-1"></span>
						</div>
					</div>
					<div class="brk-animated-circle brk-animated-circle-2" style="left:auto;top:30px;right:-10px; bottom:auto">
						<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="417" height="416" viewBox="0 0 417 416">
							<defs>
								<path id="backgrounds-id-13-2" d="M134.56 5718.66c114.7 0 207.67 92.98 207.67 207.67 0 114.7-92.98 207.67-207.67 207.67-114.7 0-207.67-92.98-207.67-207.67 0-114.7 92.98-207.67 207.67-207.67z"
								/>
								<clipPath id="backgrounds-id-13-1">
									<use fill="#fff" xlink:href="#backgrounds-id-13-2" />
								</clipPath>
							</defs>
							<g>
								<g opacity=".3" transform="translate(74 -5718)">
									<use fill="#fff" fill-opacity="0" stroke="#000" stroke-dasharray="0 16" stroke-linecap="round" stroke-miterlimit="50"
										stroke-width="4" clip-path="url(&quot;#backgrounds-id-13-1&quot;)" xlink:href="#backgrounds-id-13-2" />
								</g>
							</g>
						</svg>

						<div class="brk-animated-circle__container">
							<span class="brk-animated-circle__dot-1"></span>
						</div>
					</div>
					<div class="brk-animated-circle brk-animated-circle-3" style="left:70px;top:auto;right:auto; bottom:450px">
						<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="230" height="230" viewBox="0 0 230 230">
							<defs>
								<path id="backgrounds-id-14-2" d="M188.02 6501c63.52 0 115.01 51.49 115.01 115s-51.49 115-115.01 115S73 6679.51 73 6616s51.5-115 115.02-115z"
								/>
								<clipPath id="backgrounds-id-14-1">
									<use fill="#fff" xlink:href="#backgrounds-id-14-2" />
								</clipPath>
							</defs>
							<g>
								<g opacity=".02" transform="translate(-73 -6501)">
									<use fill="#fff" fill-opacity="0" stroke="#000" stroke-miterlimit="50" stroke-width="24" clip-path="url(&quot;#backgrounds-id-14-1&quot;)"
										xlink:href="#backgrounds-id-14-2" />
								</g>
							</g>
						</svg>

						<div class="brk-animated-circle__container">
							<span class="brk-animated-circle__dot-1">
								<span class="brk-animated-circle__dot-2"></span>
							</span>
						</div>
					</div>
					<div class="brk-animated-circle brk-animated-circle-4" style="left:auto;top:auto;right:0; bottom:50px" >
						<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="230" height="230" viewBox="0 0 230 230">
							<defs>
								<path id="backgrounds-id-15-1" d="M188.02 6501c63.52 0 115.01 51.49 115.01 115s-51.49 115-115.01 115S73 6679.51 73 6616s51.5-115 115.02-115z"
								/>
								<clipPath id="backgrounds-id-15-2">
									<use fill="#fff" xlink:href="#backgrounds-id-15-1" />
								</clipPath>
							</defs>
							<g>
								<g opacity=".02" transform="translate(-73 -6501)">
									<use fill="#fff" fill-opacity="0" stroke="#000" stroke-miterlimit="50" stroke-width="24" clip-path="url(&quot;#backgrounds-id-15-2&quot;)"
										xlink:href="#backgrounds-id-15-1" />
								</g>
							</g>
						</svg>
						<div class="brk-animated-circle__container">
							<span class="brk-animated-circle__dot-1">
								<span class="brk-animated-circle__dot-2"></span>
								<span class="brk-animated-circle__dot-3"></span>
							</span>
						</div>
					</div>';

				break;

		}
	}
	
	/* Images Background*/
	if ( isset( $bg_type ) && $bg_type == 'images' ) {

		$images_background = '';
		switch ( $images_bg_type ) {
			case "wave":
				$images_background .= '<img src="' . BERSERK_SHORTCODES_URL . '/shortcodes/img/wave-bg-1.png" alt="alt" style="position: absolute; left: 0; top: -10px;">'."\n";
				$images_background .= '<img src="' . BERSERK_SHORTCODES_URL . '/shortcodes/img/wave-bg-2.png" alt="alt" style="position: absolute; right: -50px; top: 120px">'."\n";
				$images_background .= '<img src="' . BERSERK_SHORTCODES_URL . '/shortcodes/img/wave-bg-3.png" alt="alt" style="position: absolute; left: 0; bottom: 0;">'."\n";
				break;
		}
		
		$animated_backgrounds_output = $images_background;
	
	}

	if ( isset( $bg_type ) && $bg_type == 'video' ) {

		$before_classes[] = 'parallax-bg';
		$before_classes[] = 'overflow-hid';
		$before_classes[] = 'position-relative';

		//vc_icon_element_fonts_enqueue( 'fontawesome' );

		$video_type = BRS_Shortcodes_VCParams::get_video_type( $bg_video );

		brs_add_libraries( 'component__parallax_video' );

		switch ( $video_type ) {
			case "youtube":

				$overlay_output = '<div class="video-background" data-brk-library="component__parallax-video">
											<div class="player-yt"
												 data-property="{
												   videoURL:\'' . esc_js( $bg_video ) . '\',
												   containment:\'self\',
												   autoPlay:true,
												   mute:true,
												   startAt:0,
												   opacity:1
												 }">
										    </div>
										</div>';

				break;
			case "vimeo":
				$overlay_output = '<div class="video-background vimeo-video">
									  <div class="player-vimeo"
										   data-property="{
											   videoURL:\'' . esc_js( $bg_video ) . '\',
											   containment:\'self\',
											   autoPlay:true,
											   mute:true,
											   startAt:0,
											   opacity:1,
											 }">
									  </div>
									</div>
									<script src="https://player.vimeo.com/api/player.js" type="text/javascript"></script>';
				break;
			case "mp4":
				$overlay_output = '<div class="video-background">
									  <div class="embed-responsive embed-responsive-16by9">
										<video  controls="" autoplay loop muted>
										  <source src="' . esc_url( $bg_video ) . '" type="video/mp4">
										  Your browser does not support the video tag.
										</video>
									  </div>
									</div>';
				break;
			case "ogv":
				$overlay_output = '<div class="video-background">
									  <div class="embed-responsive embed-responsive-16by9">
										<video  controls="" autoplay loop muted>
										  <source src="' . esc_url( $bg_video ) . '" type="video/ogg">
										  Your browser does not support the video tag.
										</video>
									  </div>
									</div>';
				break;
			case "webm":
				$overlay_output = '<div class="video-background">
									  <div class="embed-responsive embed-responsive-16by9">
										<video  controls="" autoplay loop muted>
										  <source src="' . esc_url( $bg_video ) . '" type="video/webm">
										  Your browser does not support the video tag.
										</video>
									  </div>
									</div>';
				break;

		}

	}

	$style = implode( ';', $style );

	if ( $style ) {
		$style = ' style="' . esc_attr( $style ) . '"';
	}

	$before_classes = apply_filters( 'presscore_vc_row_stripe_class', $before_classes, $atts );

	if ( $full_width_content == 'true' ) {
		$before_classes[] = 'container-fluid';
	}

	if ( $row_id && ! empty( $row_id ) ) {
		$before_attr[] = ' id="' . esc_attr( $row_id ) . '"';
	}

	$before_attr = implode( ' ', $before_attr );
	if ( $before_attr ) {
		$before_attr = ' ' . $before_attr;
	}

	if ( $full_width_content != 'true' ) {
		$before_output .= '<div class="' . esc_attr( implode( ' ', $before_classes ) ) . '"' . $style . $before_attr . '>' . $svg_pattern_top . $overlay_output . $animated_backgrounds_output . '<div class="container">';
		$after_output .= '</div>';
	} else {
		$before_output .= '<div class="' . esc_attr( implode( ' ', $before_classes ) ) . '"' . $style . $before_attr . '>' . $svg_pattern_top . $overlay_output . $animated_backgrounds_output;
	}

	$after_output .= $after_svg;

	$after_output .= $svg_pattern_bottom;

	$after_output .= '</div>';

} else {

	$wrapper_style[] = 'margin-top: ' . intval( $margin_top ) . 'px';
	$wrapper_style[] = 'margin-bottom: ' . intval( $margin_bottom ) . 'px';

	if ( $anchor ) {
		$wrapper_attributes[] = 'id="' . esc_attr( $anchor ) . '"';
		$wrapper_attributes[] = 'data-anchor="#' . esc_attr( $anchor ) . '"';
	}

	if ( $min_height ) {
		$wrapper_attributes[] = 'data-min-height="' . esc_attr( $min_height ) . '"';
	}

	$css_classes[] = 'dt-default';
}

if ( ! empty( $animation ) && 'none' !== $animation ) {
	$css_classes[] = sanitize_html_class( $animation );
	$css_classes[] = 'animate-element';
}

if ( $row_custom_class ) {
	$row_custom_class = explode( ' ' , $row_custom_class );
	foreach( $row_custom_class as $class_item ){
		$css_classes[] = $class_item;
	}
	
}

$before_content       = '';
$after_content        = '';
$before_content_class = array();
if ( ! empty( $inner_content_custom_css ) ) {
	$before_content_class = explode( ' ', $inner_content_custom_css );
}
if ( $inner_content_shadow == 'true' ) {
	$before_content_class[] = 'brk-base-bg-white-transparent';
	$before_content_class[] = 'shadow';
}

if ( ! empty( $before_content_class ) ) {
	$class          = implode( ' ', $before_content_class );
	$before_content = '<div class="' . $class . '">';
	$after_content  = '</div>';
}

if ( ! empty( $inner_content_bg_image ) ) {
	$bg_image = wp_get_attachment_image_src( $inner_content_bg_image, 'full' );
	$bg_image = $bg_image[0];
	$before_content .= '<div style="background: url(' . esc_url( $bg_image ) . ') no-repeat 56px 9px">';
	$after_content .= '</div>';
}

$css_class            = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( $css_classes ) ), $this->settings['base'], $atts ) );
$wrapper_attributes[] = 'class="' . esc_attr( trim( $css_class ) ) . '"';
$wrapper_attributes[] = 'style="' . esc_attr( implode( ';', $wrapper_style ) ) . '"';

$output .= $before_output;
$output .= $delimiter_before_svg;
$output .= $before_content;
$output .= '<div ' . implode( ' ', $wrapper_attributes ) . '>' . $content_after;
$output .= wpb_js_remove_wpautop( $content );
$output .= '</div>';
$output .= $after_content;
$output .= $delimiter_after_svg;
$output .= $after_output;

echo $output;