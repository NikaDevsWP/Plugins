<?php
/**
 * Shortcodes setup.
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// if visual composer class esixts

// $current_dir = dirname( __FILE__ );

require_once BERSERK_SHORTCODES_PATH . 'shortcodes/includes/class-register-button-wp-3.9.php';
require_once BERSERK_SHORTCODES_PATH . 'shortcodes/includes/class-shortcode.php';
require_once BERSERK_SHORTCODES_PATH . 'shortcodes/includes/class-radio-fields.php';

/**
 * Register theme template parts dir.
 */
presscore_template_manager()->add_path( 'shortcodes', 'shortcodes/includes' );

$tinymce_button = new DT_ADD_MCE_BUTTON( '', '' );

// List of shortcodes folders to include
// All folders located in /include
$presscore_shortcodes = array(
	'button',
	'list',
	'progress_bar',
	'countdown',
	'call_to_action',
	'services',
	'sequence',
	'steps',
	'shape_box',
	'info_box',
	'title',
	'title_section',
	'panel_content',
	'single_panel_content',
	'social_block',
	'image_frames',
	'progress_circle',
	'counter',
	'alert',
	'app_showcase',
	'subscription',
	'flip_box',
	'carousel',
	'content_slider',
	'team',
	'pricing_table',
	'testimonials',
	'contact_form',
	'map',
	'contact_form',
	'tabs',
	'tab_section',
	'tiles',
	'accordion',
	'accordion_section',
	'image_caption',
	'header',
	'portfolio',
	'tags',
	'logo',
	'timelines',
	'media',
	'gallery_sliders',
	'woo_tiles',
	'woo_masonry',
	'woo_grid_filter',
	'woo_honeycomb',
	'woo_product_row',
	'woo_banner',
	'image_map',
	'pure_html'
);

if ( ! function_exists( 'is_plugin_active' ) )
	require_once( ABSPATH . '/wp-admin/includes/plugin.php' );

if ( is_plugin_active( 'wpdatatables/wpdatatables.php' ) ) {
	$presscore_shortcodes[] = 'data_table';
}

$presscore_shortcodes = apply_filters( 'presscore_shortcodes', $presscore_shortcodes );

foreach ( $presscore_shortcodes as $shortcode_dirname ) {
	include_once BERSERK_SHORTCODES_PATH . '/shortcodes/includes/' . $shortcode_dirname . '/' . $shortcode_dirname . '.php';
}