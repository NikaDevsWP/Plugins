<?php
/**
 * Servises shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Panels', false ) ) {

	class BRS_Panels extends BRS_Shortcode {

		static protected $instance;

		protected $shortcode_name = 'brs_panel_content';
		protected $atts = array();

		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Panels();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( $this->shortcode_name, array( $this, 'shortcode' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				vc_map( array(
					"name"                    => __( "Panel  Content", "berserk" ),
					"base"                    => "brs_panel_content",
					"as_parent"               => array( 'only' => 'brs_single_panel_content' ),
					"content_element"         => true,
					"show_settings_on_create" => false,
					"is_container"            => true,
					"js_view"                 => 'VcColumnView',
					"category"                => array( 'Berserk', 'Content' ),
					'params'                  => array(
						array(
							'heading'    => __( 'Panels Type', 'berserk' ),
							'param_name' => 'panels_type',
							'type'       => 'brs_radio',
							'value'      => array(
								"Gradient"   => "gradient",
								"Table"      => "table",
								"Icon"       => "icon",
								"Image"      => "image",
								"Large"      => "large",
								"Info Block" => "info_block",

							),
							'images'     => array(
								"gradient"   => 'panel_content/p_gradient.jpg',
								"table"      => 'panel_content/p_table.jpg',
								"icon"       => 'panel_content/p_icon.jpg',
								"image"      => 'panel_content/p_image.jpg',
								"large"      => 'panel_content/p_large.jpg',
								"info_block" => 'panel_content/p_info_block.jpg',
							),
							'images_dim' => array(
								'w' => '310',
								'h' => '150'
							)
						),

						array(
							'type'        => 'attach_image',
							'heading'     => __( 'Background Image', 'js_composer' ),
							'param_name'  => 'bg_image',
							'value'       => '',
							'description' => __( 'Select image from media library.', 'js_composer' ),
						),

						array(
							'type'             => 'textfield',
							'heading'          => __( 'Heading', 'js_composer' ),
							'value'            => 'Panel heading',
							'param_name'       => 'p_heading',
							"edit_field_class" => "vc_col-sm-6 vc_column",
						),
						array(
							'type'             => 'textarea',
							'heading'          => __( 'Description', 'js_composer' ),
							'value'            => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Lorem ipsum dolor sit amet, consectetuer.',
							'param_name'       => 'p_description',
							"edit_field_class" => "vc_col-sm-6 vc_column",
						),

					),
				) );
			}
		}

		public function shortcode( $atts, $content = null ) {

      brs_add_libraries('component__panel');

			extract( shortcode_atts( array(
				'panels_type'   => 'gradient',
				'p_heading'     => 'Panel heading',
				'bg_image'      => '',
				'p_description' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Lorem ipsum dolor sit amet, consectetuer.',
			), $atts ) );


			switch ( $panels_type ) {
				case "gradient":
					$output = '<div class="panel__wrapper-gradient">
						          <div class="panel__head">
						            <h4 class="font__family-montserrat font__weight-semibold font__size-21">' . $p_heading . '</h4>
						            <hr>
						            <p class="font__family-open-sans font__size-14 text-gray">' . $p_description . '</p>
						          </div>
						          <ul class="panel__list">';

					$output .= do_shortcode( $content );
					$output .= '</ul>
        					</div>';
					break;

				case "table":
					$output = '<div class="panel__wrapper-table">
						          <div class="panel__head all-light">
						            <h4 class="font__family-montserrat font__weight-medium font__size-21">' . $p_heading . '</h4>
				                    <p class="font__family-open-sans font__size-14 text-gray">' . $p_description . '</p>
						          </div>
						          <ul class="panel__list">';

					$output .= do_shortcode( $content );
					$output .= '</ul>
        					</div>';
					break;

				case "icon":
					$output = '<div class="panel__wrapper-icon">
						          <div class="panel__head all-light">
						            <h4 class="font__family-montserrat font__weight-medium font__size-21">' . $p_heading . '</h4>
				                    <p class="font__family-open-sans font__size-14 text-gray">' . $p_description . '</p>
						          </div>
						          <ul class="panel__list">';

					$output .= do_shortcode( $content );
					$output .= '</ul>
        					</div>';

					break;

				case "image":
					$bg_image = wp_get_attachment_image_src( $bg_image, 'full' );
					$bg_image = $bg_image[0];
					$output   = '<div class="panel__wrapper-image overlay__gradient">
						          <div class="panel__head overlay__gradient bg__style all-light" style="background-image: url(' . esc_url( $bg_image ) . ');">
						            <h4 class="font__family-montserrat font__weight-light font__size-21 text-uppercase">' . $p_heading . '</h4>
				                    <p class="font__family-playfair font__size-16 text-gray line__height-22 font__style-italic">' . $p_description . '</p>
				                    <span class="overlay_after" style="background: linear-gradient(to right, #105AE0 , #7202bb);"></span>
						          </div>
						          <ul class="panel__list">';

					$output .= do_shortcode( $content );
					$output .= '</ul>
								<div class="item-footer bg__style" style="background-image: url(' . esc_url( $bg_image ) . ');"></div>
          						<span class="overlay_after"></span>
        					</div>';

					break;

				case "large":
					$output = '<div class="panel__wrapper-large">
						          <div class="panel__head all-light">
						            <h4 class="font__family-montserrat font__weight-light font__size-24 text-uppercase">' . $p_heading . '</h4>
						            <hr>
				                    <p class="font__family-open-sans font__size-14 text-gray">' . $p_description . '</p>
						          </div>
						          <ul class="panel__list">';

					$output .= do_shortcode( $content );
					$output .= '</ul>
        					</div>';

					break;

				case "info_block":

					$output = '<div class="panel__wrapper-info-block">
						          <div class="panel__head all-light">
						            <h4 class="font__family-montserrat font__weight-light font__size-24 text-uppercase">' . $p_heading . '</h4>
						          </div>
						          <ul class="panel__list">';

					$output .= do_shortcode( $content );
					$output .= '</ul>
        					</div>';

					break;

			}

			return $output;


		}


	}

	// create shortcode
	BRS_Panels::get_instance();

}
