<?php
/**
 * Header shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


if ( ! class_exists( 'BRS_Header_Shortcode', false ) ) {

	require_once BERSERK_SHORTCODES_PATH . 'shortcodes/includes/shortcodes-ext.php';

	class BRS_Header_Shortcode extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();

		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Header_Shortcode();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_header', array( $this, 'shortcode_header' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {

			if ( function_exists( "vc_map" ) ) {

				$params = array();

				$params[] = array(
					"heading"    => __( "Drop Down Styles", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$params[] = array(
					'param_name' => 'skin',
					'type'       => 'brs_radio',
					'value'      => array(
						"Skin 1" => "1",
						"Skin 2" => "2",
					),
					'images'     => array(
						"1" => 'header/skin-001.png',
						"2" => 'header/skin-002.png',
					),
					'images_dim' => array(
						'w' => '310',
						'h' => '150'
					)
				);

				$params[] = array(
					"heading"    => __( "Header Style", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$params[] = array(
					'param_name' => 'style',
					'type'       => 'brs_radio',
					'value'      => array(
						"Style 1" => "1",
						"Style 2" => "2",
					),
					'images'     => array(
						"1" => 'header/style-002.png',
						"2" => 'header/style-001.png',
					),
					'images_dim' => array(
						'w' => '310',
						'h' => '150'
					)
				);

				$params[] = array(
					"heading"    => __( "Header Settings", 'berserk' ),
					"param_name" => "brs_header_settings",
					"type"       => "brs_title",
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Position', 'js_composer' ),
					'param_name'       => 'position',
					'value'            => array(
						'Default'            => 'default',
						'Fixed Position'     => 'fixed',
						'Not Fixed Position' => 'not_fixed',
					),
					'edit_field_class' => 'vc_col-sm-3 vc_column',
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Font Color', 'js_composer' ),
					'param_name'       => 'font_color',
					'value'            => array(
						'White' => 'white',
						'Dark'  => 'dark',
					),
					'edit_field_class' => 'vc_col-sm-3 vc_column',
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Header type', 'js_composer' ),
					'param_name'       => 'header_type',
					'value'            => array(
						'Horizontal' => 'horizontal',
						'Vertical'   => 'vertical',
					),
					'edit_field_class' => 'vc_col-sm-3 vc_column',
				);

				$params[] = array(
					"param_name"       => "top_header_hide",
					"type"             => "checkbox",
					"value"            => array(
						"Top Header Auto Hide" => "1",
					),
					'edit_field_class' => 'vc_col-xs-3 vc_column',
				);

				$params[] = array(
					"heading"          => __( "Header Background Color", 'berserk' ),
					"param_name"       => "background_color",
					"type"             => "colorpicker",
					"value"            => "",
					"edit_field_class" => "vc_col-sm-6 vc_column",
				);

				$params[] = array(
					"heading"    => __( "Regions Settings", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$params[] = array(
					"param_name" => "top_header_enable",
					'heading'    => __( 'Top Header', 'js_composer' ),
					"type"       => "checkbox",
					"value"      => array(
						"Enable Top Header" => "y",
					),
				);

				$header_settings = berserk_shortcodes_header_settings( 'top_header_' );
				foreach ( $header_settings as $i => $j ) {
					$header_settings[ $i ]['dependency'] = array(
						'element' => 'top_header_enable',
						'value'   => 'y',
					);
				}
				$params = array_merge( $params, $header_settings );

				$params[] = array(
					"param_name" => "top_header_scroll",
					'heading'    => __( '', 'js_composer' ),
					"type"       => "checkbox",
					"value"      => array(
						"Top Header Scroll" => "y",
					),
				);

				$params[] = array(
					'type'       => 'param_group',
					'heading'    => __( 'Columns', 'js_composer' ),
					'param_name' => 'top_header_cols',
					'value'      => '',
					'dependency' => array(
						'element' => 'top_header_enable',
						'value'   => 'y',
					),
					'params'     => berserk_shortcodes_column_params(),
				);

				$params[] = array(
					"param_name" => "main_bar_enable",
					'heading'    => __( 'Main Bar', 'js_composer' ),
					"type"       => "checkbox",
					"value"      => array(
						"Enable Main Bar" => "y",
					),
				);

				$header_settings = berserk_shortcodes_header_settings( 'main_bar_' );
				foreach ( $header_settings as $i => $j ) {
					$header_settings[ $i ]['dependency'] = array(
						'element' => 'main_bar_enable',
						'value'   => 'y',
					);
				}
				$params = array_merge( $params, $header_settings );


				$params[] = array(
					'type'       => 'param_group',
					'heading'    => __( 'Columns', 'js_composer' ),
					'param_name' => 'main_bar_cols',
					'value'      => '',
					'dependency' => array(
						'element' => 'main_bar_enable',
						'value'   => 'y',
					),
					'params'     => berserk_shortcodes_column_params(),
				);

				$params[] = array(
					"param_name" => "side_menu_enable",
					'heading'    => __( 'Side Menu', 'js_composer' ),
					"type"       => "checkbox",
					"value"      => array(
						"Enable Side Menu" => "y",
					),
				);

				$params[] = array(
					"param_name" => "hide_labels",
					'heading'    => __( 'Hide all labels', 'js_composer' ),
					"type"       => "checkbox",
					"value"      => array(
						"Hide Labels" => "y",
					),
				);

				// Mobile settings
				$params[] = array(
					"heading"    => __( "Mobile Settings", 'berserk' ),
					"param_name" => "brs_title_logo",
					"type"       => "brs_title",
				);

				$params[] = array(
					'type'             => 'attach_image',
					'heading'          => esc_html__( 'Mobile Logo', 'js_composer' ),
					'param_name'       => 'mobile_side_logo',
					'value'            => '',
					'edit_field_class' => 'vc_col-sm-4 vc_column'
				);

				$params[] = array(
					'type'             => 'attach_image',
					'heading'          => __( 'Mobile Menu Background', 'js_composer' ),
					'param_name'       => 'mobile_bg',
					'value'            => '',
					'edit_field_class' => 'vc_col-sm-4 vc_column'
				);

				// Menu multiple adds with params

				$menu_options = array();
				$menus        = get_terms( 'nav_menu' );
				foreach ( $menus as $menu ) {
					$menu_options[ $menu->name ] = $menu->slug;
				}

				if ( ! empty( $menu_options ) ) {
					$params[] = array(
						"heading"    => __( "Menu", 'berserk' ),
						"param_name" => "brs_title_menu",
						"type"       => "brs_title",
					);

					$group_params = array(
						array(
							'type'             => 'dropdown',
							'heading'          => __( 'Menu', 'js_composer' ),
							'param_name'       => 'menu',
							'value'            => $menu_options,
							'edit_field_class' => 'vc_col-sm-4 vc_column',
						),
						array(
							'type'             => 'dropdown',
							'heading'          => __( 'Menu Style', 'js_composer' ),
							'param_name'       => 'brk_skin',
							'value'            => array(
								'None'               => 'none',
								'Big Font'           => '1',
								'Small Font'         => '2',
								'Bold Font'          => '4',
								'PopUp Menu default' => 'popup',
								'PopUp Menu simple'  => 'popup_simple',
							),
							'edit_field_class' => 'vc_col-xs-3 vc_column',
						),
					);

					$orders       = berserk_shortcodes_order_params();
					$group_params = array_merge( $group_params, $orders );

					$params[] = array(
						'type'       => 'param_group',
						'heading'    => __( 'Menus', 'js_composer' ),
						'param_name' => 'menus',
						'value'      => '',
						'params'     => $group_params,
					);

				}

				$params[] = array(
					"heading"    => __( "Text Blocks", 'berserk' ),
					"param_name" => "brs_title_menu",
					"type"       => "brs_title",
				);

				$group_params = array(
					array(
						'type'             => 'textfield',
						'heading'          => __( 'Title', 'js_composer' ),
						'param_name'       => 'title',
						'value'            => '',
						'edit_field_class' => 'vc_col-xs-3 vc_column',
					),
					array(
						'type'       => 'vc_link',
						'heading'    => __( 'Link URL', 'js_composer' ),
						'param_name' => 'url',
					),
					array(
						'type'             => 'iconpicker',
						'heading'          => esc_html__( 'Icon', 'berserk' ),
						'param_name'       => 'icon_fontawesome',
						'value'            => ' ', // default value to backend editor admin_label
						'settings'         => array(
							'emptyIcon'    => true,
							'iconsPerPage' => 4000,
						),
						'edit_field_class' => 'icon_option vc_col-xs-3 vc_column',
					),
					array(
						'type'             => 'dropdown',
						'heading'          => esc_html__( 'Style', 'js_composer' ),
						'param_name'       => 'elementskin',
						'value'            => array(
							'Big Font'          => '1',
							'Small Font'        => '2',
							'Font With Opacity' => '3',
							'Text White'        => 'text_white',
						),
						'edit_field_class' => 'vc_col-xs-3 vc_column',
					),
				);


				$orders       = berserk_shortcodes_order_params();
				$group_params = array_merge( $group_params, $orders );

				$params[] = array(
					'type'       => 'param_group',
					'heading'    => __( 'Text', 'js_composer' ),
					'param_name' => 'text_blocks',
					'value'      => '',
					'params'     => $group_params,
				);

				$params[] = array(
					"heading"    => __( "Logo", 'berserk' ),
					"param_name" => "brs_title_logo",
					"type"       => "brs_title",
				);

				$params[] = array(
					'type'             => 'attach_image',
					'heading'          => __( 'Logo', 'js_composer' ),
					'param_name'       => 'logo',
					'value'            => '',
					'edit_field_class' => 'vc_col-sm-4 vc_column'
				);


				$params[] = array(
					'type'             => 'attach_image',
					'heading'          => __( 'Sticky Logo', 'js_composer' ),
					'param_name'       => 'sticky_logo',
					'value'            => '',
					'edit_field_class' => 'vc_col-sm-4 vc_column'
				);

				$params[] = array(
					'type'             => 'attach_image',
					'heading'          => __( 'Mobile Logo', 'js_composer' ),
					'param_name'       => 'mobile_logo',
					'value'            => '',
					'edit_field_class' => 'vc_col-sm-4 vc_column'
				);


				// Image sizes
				$image_sizes = berserk_shortcodes_image_size_options();
				$params      = array_merge( $params, $image_sizes );

				$orders = berserk_shortcodes_order_params( 'logo_' );
				$params = array_merge( $params, $orders );

				// Search Settings
				$params[] = array(
					"heading"    => __( "Search", 'berserk' ),
					"param_name" => "brs_title_search",
					"type"       => "brs_title",
				);

				$orders = berserk_shortcodes_order_params( 'search_' );
				$params = array_merge( $params, $orders );

				$params[] = array(
					"heading"    => __( "Call button", 'berserk' ),
					"param_name" => "brs_title_call",
					"type"       => "brs_title",
				);

				$params[] = array(
					'type'       => 'textfield',
					'heading'    => __( 'Call Number', 'js_composer' ),
					'param_name' => 'call_number',
					'value'      => '',
				);


				$orders = berserk_shortcodes_order_params( 'call_' );
				$params = array_merge( $params, $orders );

				$params[] = array(
					"heading"    => __( "Language selector", 'berserk' ),
					"param_name" => "brs_title_language",
					"type"       => "brs_title",
				);

				$orders = berserk_shortcodes_order_params( 'language_' );
				$params = array_merge( $params, $orders );

				$params[] = array(
					"heading"    => __( "Cart", 'berserk' ),
					"param_name" => "brs_title_cart",
					"type"       => "brs_title",
				);

				$orders = berserk_shortcodes_order_params( 'cart_' );
				$params = array_merge( $params, $orders );

				$params[] = array(
					"heading"    => __( "Social Share", 'berserk' ),
					"param_name" => "brs_title_social",
					"type"       => "brs_title",
				);

				$orders = berserk_shortcodes_order_params( 'social_' );
				$params = array_merge( $params, $orders );


				$group_params = array(
					array(
						'type'             => 'textfield',
						'heading'          => __( 'Link', 'js_composer' ),
						'param_name'       => 'link',
						'value'            => '',
						'edit_field_class' => 'vc_col-xs-6 vc_column',
					),
					array(
						'type'             => 'iconpicker',
						'heading'          => __( 'Icon', 'berserk' ),
						'param_name'       => 'icon_fontawesome',
						'value'            => 'fa fa-facebook', // default value to backend editor admin_label
						'settings'         => array(
							'emptyIcon'    => false,
							'iconsPerPage' => 4000,
						),
						'edit_field_class' => 'icon_option vc_col-xs-6 vc_column',
					)
				);

				$params[] = array(
					'type'       => 'param_group',
					'heading'    => __( 'Social Links', 'js_composer' ),
					'param_name' => 'social_links',
					'value'      => '',
					'params'     => $group_params,
				);

				$params[] = array(
					"heading"    => __( "Side Menu Link", 'berserk' ),
					"param_name" => "brs_title_side",
					"type"       => "brs_title",
				);


				$orders = berserk_shortcodes_order_params( 'side_menu_' );
				$params = array_merge( $params, $orders );

				$params[] = array(
					"heading"    => __( "Compare Link", 'berserk' ),
					"param_name" => "brs_title_compare",
					"type"       => "brs_title",
				);

				$orders = berserk_shortcodes_order_params( 'compare_' );
				$params = array_merge( $params, $orders );

				$params[] = array(
					"heading"    => __( "Wish List", 'berserk' ),
					"param_name" => "brs_title_wishlist",
					"type"       => "brs_title",
				);

				$orders = berserk_shortcodes_order_params( 'wishlist_' );
				$params = array_merge( $params, $orders );

				$params[] = array(
					"heading"    => __( "Custom button", 'berserk' ),
					"param_name" => "brs_title_custom_button",
					"type"       => "brs_title",
				);

				$orders = berserk_shortcodes_order_params( 'custombutton_' );
				$params = array_merge( $params, $orders );

				$params[] = array(
					"heading"    => __( "To Top Button", 'berserk' ),
					"param_name" => "brs_title_to_top_button",
					"type"       => "brs_title",
				);

				$orders = berserk_shortcodes_order_params( 'to_top_button_' );
				$params = array_merge( $params, $orders );

				$params[] = array(
					"heading"    => __( "Shortcode or Sidebar", 'berserk' ),
					"param_name" => "brs_title_shortcode_sidebar",
					"type"       => "brs_title",
				);

				$orders   = berserk_shortcodes_order_params( 'shortcode_sidebar_' );
				$params   = array_merge( $params, $orders );
				$theme    = wp_get_theme();
				$sidebars = ( 'Berserk' == $theme->name ) ? berserk_helper()->get_berserk_sidebars() : '';

				$group_params = array(
					array(
						'type'             => 'dropdown',
						'heading'          => __( 'Type', 'js_composer' ),
						'param_name'       => 'content_type',
						'value'            => array(
							__( 'Shortcode', 'berserk' ) => 'shortcode',
							__( 'Sidebar', 'berserk' )   => 'sidebar',
						),
						'edit_field_class' => 'vc_col-xs-6 vc_column',
					),
					array(
						'type'             => 'textarea',
						'heading'          => __( 'Paste any shortcode', 'berserk' ),
						'param_name'       => 'content_shortcode',
						'value'            => '',
						'edit_field_class' => 'icon_option vc_col-xs-6 vc_column',
						'dependency'       => array(
							'element' => 'content_type',
							'value'   => 'shortcode',
						),
					),
					array(
						'type'             => 'dropdown',
						'heading'          => __( 'Choose any Sidebar', 'js_composer' ),
						'param_name'       => 'content_sidebar',
						'value'            => $sidebars,
						'edit_field_class' => 'vc_col-xs-6 vc_column',
						'dependency'       => array(
							'element' => 'content_type',
							'value'   => 'sidebar',
						),
					)
				);

				$params[] = array(
					'type'       => 'param_group',
					'heading'    => __( 'Custom content', 'js_composer' ),
					'param_name' => 'custom_content',
					'value'      => '',
					'params'     => $group_params,
				);


				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Header", 'berserk' ),
					"base"     => "brs_header",
					"icon"     => "brs_vc_ico_menu",
					"class"    => "brs_vc_sc_menu",
					"category" => __( 'Berserk', 'berserk' ),
					"params"   => $params
				) );
			}
		}

		public function shortcode_header( $atts, $content = null ) {

			$params   = array(
				'skin'                               => '1',
				'style'                              => '1',
				'brk_skin'                           => '',
				'font_color'                         => 'white',
				'top_header_hide'                    => '',
				'background_color'                   => '',
				'position'                           => '',
				'header_type'                        => '',
				'top_header_enable'                  => 'n',
				'top_header_scroll'                  => 'n',
				'main_bar_enable'                    => 'n',
				'hide_labels'                        => 'n',
				'side_menu_enable'                   => 'n',
				'top_header_cols'                    => '',
				'main_bar_cols'                      => '',
				'orders'                             => '',
				'top_header_fullwidth'               => 'n',
				'main_bar_fullwidth'                 => 'n',
				'top_header_gradient'                => '',
				'top_header_height'                  => '',
				'top_header_font_family'             => 'none',
				'top_header_justify_content_between' => '',
				'main_bar_height'                    => '',
				'main_bar_height_scroll'             => '',
				'main_bar_gradient'                  => '',
				'main_bar_opacity'                   => '',
				'top_header_border_bottom'           => '',
				'main_bar_border_bottom'             => '',
				'main_bar_justify_content_between'   => '',
				'menus'                              => '',
				'logo'                               => '',
				'image_size'                         => 'brk-logo',
				'image_custom_width'                 => '',
				'image_custom_height'                => '',
				'sticky_logo'                        => '',
				'mobile_logo'                        => '',
				'mobile_side_logo'                   => '',
				'mobile_bg'                          => '',
				'call_number'                        => '',
				'text_blocks'                        => '',
				'social_links'                       => '',
				'custom_content'                     => ''
			);
			$elements = array(
				'logo',
				'search',
				'call',
				'language',
				'cart',
				'social',
				'side_menu',
				'menus',
				'text_blocks',
				'compare',
				'wishlist',
				'custombutton',
				'shortcode_sidebar',
				'to_top_button'
			);
			foreach ( $elements as $element ) {
				$params[ $element . '_brk_region' ]      = '';
				$params[ $element . '_brk_column' ]      = '1';
				$params[ $element . '_brk_order' ]       = '1';
				$params[ $element . '_brk_skin' ]        = 'none';
				$params[ $element . '_brk_title' ]       = '';
				$params[ $element . '_brk_title_hover' ] = '';
				$params[ $element . '_brk_url' ]         = '';
				if ( $element == 'custombutton' ) {
					$params[ $element . '_brk_button_type' ] = '';
				}
				if ( $element == 'logo' ) {
					$params[ $element . '_brk_text_center' ] = '';
					$params[ $element . '_brk_ml' ]          = '';
					$params[ $element . '_brk_background' ]  = '';

				}
				if ( $element == 'language' ) {
					$params[ $element . '_brk_langs_type' ] = '';
				}
				if ( $element == 'side_menu' ) {
					$params[ $element . '_brk_smi_type' ] = '';
				}
			}

			$atts = shortcode_atts( $params, $atts );

			vc_icon_element_fonts_enqueue( 'fontawesome' );

			$atts['image_size'] = berserk_shortcodes_image_size_render( $atts );

			brs_add_libraries( 'component__header' );
			//brs_add_libraries( 'component__header_skin_' . $atts['skin'] );
			brs_add_libraries( 'component__button' );

			$content = array(
				'top_header' => vc_param_group_parse_atts( $atts['top_header_cols'] ),
				'main_bar'   => vc_param_group_parse_atts( $atts['main_bar_cols'] ),
				//'custom_content' => vc_param_group_parse_atts( $atts['custom_content'] ),
				'side_menu'  => array( 0 => array() ),
			);


			$atts['text_blocks']                   = vc_param_group_parse_atts( $atts['text_blocks'] );
			$atts['text_blocks'][0]['hide_labels'] = $atts['hide_labels'];

			$atts['menus']          = vc_param_group_parse_atts( $atts['menus'] );
			$atts['custom_content'] = vc_param_group_parse_atts( $atts['custom_content'] );


			foreach ( $elements as $element ) {
				// Menus is a multiple field, so it should be checked in the render function
				if ( $atts[ $element . '_brk_region' ] ) {
					$fun_name = 'render_' . $element;
					$rendered = $this->$fun_name( $atts );
					$place    = &$content[ $atts[ $element . '_brk_region' ] ]['output'][ $atts[ $element . '_brk_column' ] ][ $atts[ $element . '_brk_order' ] ];
					$place    = ! empty( $place ) ? $place . $rendered : $rendered;
				}
				if ( in_array( $element, array( 'menus', 'text_blocks' ) ) && isset( $atts[ $element ] ) ) {
					foreach ( $atts[ $element ] as $att ) {
						if ( isset( $att['brk_region'] ) ) {
							$fun_name = 'render_' . $element;
							$rendered = $this->$fun_name( $att );
							$place    = &$content[ $att['brk_region'] ]['output'][ $att['brk_column'] ][ $att['brk_order'] ];
							$place    = ! empty( $place ) ? $place . $rendered : $rendered;
						}
					}
				}
			}

			$logo             = wp_get_attachment_image_src( $atts['logo'], 'full' );
			$sticky_logo      = $atts['sticky_logo'] ? wp_get_attachment_image_src( $atts['sticky_logo'], $atts['image_size'] ) : $logo;
			$mobile_logo      = $atts['mobile_logo'] ? wp_get_attachment_image_src( $atts['mobile_logo'] ) : $logo;
			$mobile_side_logo = $atts['mobile_side_logo'] ? wp_get_attachment_image_src( $atts['mobile_side_logo'] ) : $mobile_logo;
			$mobile_bg        = $atts['mobile_bg'] ? wp_get_attachment_image_src( $atts['mobile_bg'] ) : array( 0 => '' );

			$output = '<div class="brk-header-mobile">
					        <div class="brk-header-mobile__open brk-header-mobile__open_white">
					          <span></span>
					        </div>
					        <div class="brk-header-mobile__logo">
					          <a href="' . home_url() . '">
                                <img class="brk-header-mobile__logo-1 lazyload" src="' . esc_attr( BRK_DATA_IMAGE ) . '" data-src="' . $mobile_logo[0] . '" alt="alt">
						        <img class="brk-header-mobile__logo-2 lazyload" src="' . esc_attr( BRK_DATA_IMAGE ) . '" data-src="' . $sticky_logo[0] . '" alt="alt">
					          </a>
					        </div>
				      </div>';

			$attributes = array(
				'brk-header_skin-' . $atts['skin'],
				'brk-header_style-' . $atts['style'],
				( $atts['position'] == 'fixed' ) ? 'position-fixed' : '',
				'brk-header_color-' . $atts['font_color'],
				$atts['header_type'] == 'vertical' ? 'brk-header_vertical' : '',
				$atts['menus'][0]['brk_skin'] == 'popup' ? 'brk-header_popup' : ''
			);

			$attr_style = ( isset( $atts['background_color'] ) && ! empty( $atts['background_color'] ) ) ? "style='background: " . $atts['background_color'] . ";'" : "";

			$data_sticky_hide = $atts['position'] == 'not_fixed' ? '1' : '';

			$output .= '
      <header class="brk-header d-flex flex-column ' . implode( ' ', $attributes ) . '" ' . $attr_style . ' data-logo-src="' . $mobile_side_logo[0] . '" data-bg-mobile="' . $mobile_bg[0] . '" data-sticky-hide="' . $data_sticky_hide . '">';
			if ( $atts['top_header_enable'] == 'y' ) {
				$height     = $atts['top_header_height'] ? 'style="height: ' . $atts['top_header_height'] . 'px"' : '';
				$atts_class = $atts['top_header_hide'] ? ' brk-header__top-bar_hide' : '';
				$atts_class .= ' ' . $atts['top_header_gradient'];

				switch ( $atts['top_header_border_bottom'] ) {
					case "ultralight":
						$atts_class .= ' brk-header_border-bottom';
						break;
					case "light":
						$atts_class .= ' brk-header_border-bottom-50';
						break;
					case "dark":
						$atts_class .= ' brk-header_border-bottom-dark';
						break;
				}

				$atts_class .= ( isset( $atts['top_header_scroll'] ) && $atts['top_header_scroll'] == 'y' ) ? ' brk-header__top-bar_scroll' : '';

				$atts_class .= $atts['top_header_font_family'] != 'none' ? ' font__family-' . $atts['top_header_font_family'] : '';

				$output .= '
          <div class="brk-header__top-bar order-lg-1 order-2' . $atts_class . '" data-top="3" ' . $height . '>' .
				           $this->render_region( $content, 'top_header', $atts ) .
				           '</div>';
			}
			if ( $atts['main_bar_enable'] == 'y' ) {
				$height        = $atts['main_bar_height'] ? 'style="height: ' . $atts['main_bar_height'] . 'px"' : '';
				$height_scroll = isset( $atts['main_bar_height_scroll'] ) ? ' data-height-scroll="' . $atts['main_bar_height_scroll'] . '"' : '';

				$atts_class = '';
				switch ( $atts['main_bar_border_bottom'] ) {
					case "ultralight":
						$atts_class .= ' brk-header_border-bottom';
						break;
					case "light":
						$atts_class .= ' brk-header_border-bottom-50';
						break;
					case "dark":
						$atts_class .= ' brk-header_border-bottom-dark';
						break;
				}

				$atts_class .= ( $atts['main_bar_gradient'] == 'bg-white' ) ? ' bg-white' : ' ';
				$output .= '
          <div class="brk-header__main-bar order-lg-2 order-1 ' . $atts_class . '" ' . $height . $height_scroll . '>' .
				           $this->render_region( $content, 'main_bar', $atts ) .
				           '</div>';
			}

			if ( $atts['side_menu_enable'] == 'y' ) {

				$output .= '<div class="brk-info-menu">
								<div class="brk-info-menu__bar">
									<div class="brk-info-menu__header font__family-montserrat font__weight-bold font__size-21">' . esc_html__( 'More info', 'berserk' ) . '
										<button class="brk-info-menu__close"><i class="fa fa-times" aria-hidden="true"></i></button>
									</div>
								' .
				           $this->render_region( $content, 'side_menu', $atts ) .
				           '</div>
						</div>';
			}

			$output .= '
      </header>';

			return $output;
		}

		/*
		 * Render functions
		 */
		function render_region( $content, $region, $atts ) {

			if ( ! isset( $content[ $region ]['output'] ) ) {
				return;
			}

			$container_class = ( $region == 'main_bar' ) ? $atts['main_bar_gradient'] : '';
			$container_class .= ( $region == 'main_bar' ) ? ' ' . $atts['main_bar_opacity'] : '';

			$row_class   = array();
			$row_class[] = 'row';
			$row_class[] = 'align-items-center';

			if ( isset( $atts[ $region . '_fullwidth' ] ) && $atts[ $region . '_fullwidth' ] == 'full_width_no_paddings' ) {
				$row_class[] = 'no-gutters';
			}

			if ( isset( $atts[ $region . '_justify_content_between' ] ) && $atts[ $region . '_justify_content_between' ] == 'y' ) {
				$row_class[] = 'justify-content-between';
			}

			$row_class = implode( ' ', $row_class );

			$output = '';
			if ( $region != 'side_menu' ) {
				$output .= '
        <div class = "container' . ( $atts[ $region . '_fullwidth' ] == 'full_width' ? '-fluid' : ( $atts[ $region . '_fullwidth' ] == 'full_width_no_paddings' ? '-fluid brk-wp-no-gutters' : '' ) ) . ' ' . $container_class . '">
          <div class = "' . $row_class . '">';
			}

			ksort( $content[ $region ]['output'] );

			foreach ( $content[ $region ]['output'] as $i => $content_array ) {

				if ( $region != 'side_menu' ) {
					$col_attrs = ( $content[ $region ][ $i - 1 ]['column_size'] !== ' ' ) ? 'col-lg-' . $content[ $region ][ $i - 1 ]['column_size'] : 'col-lg';
					$col_attrs .= isset( $content[ $region ][ $i - 1 ]['vertical_align'] ) && $content[ $region ][ $i - 1 ]['vertical_align'] !== 'none' ? ' align-self-lg-' . $content[ $region ][ $i - 1 ]['vertical_align'] : '';
					$col_attrs .= isset( $content[ $region ][ $i - 1 ]['column_align'] ) && $content[ $region ][ $i - 1 ]['column_align'] !== 'none' ? ' brk-align-' . $content[ $region ][ $i - 1 ]['column_align'] . ' text-lg-' . $content[ $region ][ $i - 1 ]['column_align'] : '';
					$col_attrs .= isset( $content[ $region ][ $i - 1 ]['hide_mobile'] ) && $content[ $region ][ $i - 1 ]['hide_mobile'] == 'y' ? ' d-none d-lg-block' : '';
					$col_attrs .= isset( $content[ $region ][ $i - 1 ]['background'] ) && $content[ $region ][ $i - 1 ]['background'] != 'none' ? ' ' . $content[ $region ][ $i - 1 ]['background'] . ' d-flex align-items-center h-100 pl-30 pr-30' : '';
					$col_attrs .= isset( $content[ $region ][ $i - 1 ]['padding_right'] ) && $content[ $region ][ $i - 1 ]['padding_right'] != 'none' ? ' ' . $content[ $region ][ $i - 1 ]['padding_right'] : '';
					$col_attrs .= isset( $content[ $region ][ $i - 1 ]['margin_right'] ) && $content[ $region ][ $i - 1 ]['margin_right'] != 'none' ? ' ' . $content[ $region ][ $i - 1 ]['margin_right'] : '';
					$col_attrs .= isset( $content[ $region ][ $i - 1 ]['border_right'] ) && $content[ $region ][ $i - 1 ]['border_right'] == 'y' ? ' brk-header_border-right-20' : '';
					$col_attrs .= isset( $content[ $region ][ $i - 1 ]['dispalay'] ) && $content[ $region ][ $i - 1 ]['dispalay'] == 'flex' ? ' d-lg-flex' : '';

					$output .= '<div class = "' . $col_attrs . '">';
				}

				ksort( $content_array );
				$output .= implode( "\n", $content_array );

				if ( $region != 'side_menu' ) {
					$output .= '</div>';
				}

			}

			if ( $region != 'side_menu' ) {
				$output .= '
          </div>
        </div>';
			}

			return $output;
		}

		function render_text_blocks( $atts ) {

			//vc_icon_element_fonts_enqueue( $atts['icon_fontawesome']);
			$output = '';

			if ( isset( $atts['title'] ) ) {
				$url         = ( isset( $atts['url'] ) ) ? $atts['url'] : '';
				$url         = vc_build_link( $url );
				$link_url    = $url['url'];
				$a_title     = ( $url['title'] == '' ) ? '' : $url['title'];
				$a_target    = ( $url['target'] == '' ) ? '' : 'target="' . $url['target'] . '"';
				$label_class = ( isset( $atts['hide_labels'] ) && $atts['hide_labels'] == 'y' ) ? 'd-lg-none' : '';

				$elementskin = 1;
				if ( isset( $atts['elementskin'] ) ) {
					$elementskin = $atts['elementskin'];
					if ( $elementskin == 'text_white' ) {
						$elementskin = '2 text-white';
					};
				}
				$icon   = isset( $atts['icon_fontawesome'] ) ? '<i class="' . $atts['icon_fontawesome'] . '" aria-hidden="true"></i>' : '';
				$text   = $icon . '<span class = "brk-header__element--label ' . $label_class . '">' . $atts['title'] . '</span>';
				$text   = isset( $link_url ) && ! empty( $link_url ) ? '<a href = "' . esc_url( $link_url ) . '" class = "brk-header__element--wrap">' . $text . '</a>' : '<div class = "brk-header__element--wrap">' . $text . '</div>';
				$output = '
      <div class="brk-header__element brk-header__element_skin-' . esc_attr( $elementskin ) . ' brk-header__item">
        ' . $text . '
      </div>';
			}

			return $output;
		}

		function render_menus( $atts ) {
			//dpm($atts);

			$container_class   = array();
			$container_class[] = 'brk-nav';
			$container_class[] = 'brk-header__item';

			$menu_class = 'brk-nav__menu';

			$before_output  = '';
			$after_output   = '';
			$container_type = 'nav';

			if ( isset( $atts['brk_skin'] ) && $atts['brk_skin'] !== 'none' ) {

				switch ( $atts['brk_skin'] ) {
					case "1":
						$container_class[] = 'brk-nav_skin-' . $atts['brk_skin'];
						break;
					case "2":
						$container_class[] = 'brk-nav_skin-' . $atts['brk_skin'];
						break;
					case "4":
						$container_class[] = 'brk-nav_modifier-bold';
						break;
					case "popup":
					case "popup_simple":
						$container_type = false;
						$menu_class     = '';
						$before_output  = '<div class="brk-header-popup-menu">
						  <div class="brk-header-popup-menu__open-close font__family-montserrat font__weight-light font__size-14 letter-spacing-40">
						    <div class="brk-open"><i class="fa fa-bars"></i> Menu</div>
						    <div class="brk-close"><i class="fa fa-times"></i> Close</div>
						  </div>
						  <div class="brk-header-popup-menu__menu text-lg-center font__family-roboto font__weight-thin">';
						$after_output   = '</div>
						</div>';
						break;
					default:
						$container_class[] = 'brk-nav_skin-' . $atts['brk_skin'];
						break;
				}

			}
			$container_class = implode( ' ', $container_class );

			$menu = isset( $atts['menu'] ) ? $atts['menu'] : 'primary';

			if ( has_nav_menu( 'primary' ) ) {
				$output = wp_nav_menu( array(
					'theme_location'  => 'primary',
					'menu'            => $menu,
					'container'       => $container_type,
					'container_class' => $container_class,
					'menu_class'      => $menu_class,
					'echo'            => false,
					'walker'          => new Berserk_Walker_Nav_Menu
				) );

			} else {
				$output = wp_page_menu( array(
					'menu_class' => 'brk-nav  brk-header__item',
					'container'  => 'nav',
					'echo'       => false,
				) );
			}
			$output = $before_output . $output . $after_output;

			return $output;
		}

		function render_logo( $atts ) {
			$logo        = wp_get_attachment_image_src( $atts['logo'], $atts['image_size'] );
			$sticky_logo = wp_get_attachment_image_src( $atts['sticky_logo'], $atts['image_size'] );
			if ( ! $logo ) {
				return;
			}
			$div_class = array();
			if ( isset( $atts['logo_brk_text_center'] ) ) {
				if ( $atts['logo_brk_text_center'] == 'y' ) {
					$div_class[] = 'text-center';
				}
			}
			if ( isset( $atts['logo_brk_ml'] ) ) {
				if ( $atts['logo_brk_ml'] ) {
					$div_class[] = 'ml-' . $atts['logo_brk_ml'];
				}
			}
			if ( isset( $atts['logo_brk_background'] ) ) {
				if ( $atts['logo_brk_background'] ) {
					$div_class[] = $atts['logo_brk_background'];
				}
			}
			$div_class = implode( ' ', $div_class );

			$output = '<div class="' . esc_attr( $div_class ) . '">
				          <a href="' . home_url() . '" class="brk-header__logo brk-header__item">
				             <img class="brk-header__logo-1" src="' . $logo[0] . '" alt="">';
			if ( ! empty( $sticky_logo ) ) {
				$output .= '<img class="brk-header__logo-2" src="' . $sticky_logo[0] . '" alt="">';
			}
			$output .= '</a>
				        </div>';

			return $output;
		}

		function render_search( $atts ) {

			$search_item_class = '';
			$search_form_close = '';
			$search_open_class = '';
			switch ( $atts['search_brk_skin'] ) {
				case "default":
					break;
				case "interactive":
					$search_item_class = 'brk-search_interactive brk-location-screen-right';
					$search_form_close = '<span class="brk-search__close font__family-montserrat font__weight-medium">' . __( 'Close ', 'berserk' ) . '<i class="fa fa-times"></i></span>';
					break;
				case "white":
					$search_open_class = 'text-white';
					break;
			}

			$output = '<div class="brk-search brk-header__item ' . $search_item_class . '">
				          <div class="brk-search__open ' . $search_open_class . '">
				            <i class="fa fa-search" aria-hidden="true"></i>
				            <div class="brk-search__title">' . __( 'Search website', 'berserk' ) . '</div>
				          </div>

				          <div class="brk-search__block">
				            <div class="brk-search__header">
				              <span class="font__family-montserrat font__weight-bold font__size-18">' . __( 'Search', 'berserk' ) . '</span>
				            </div>

				            <form class="brk-search__form searchform" role="search" method="get" action="' . esc_url( home_url( "/" ) ) . '">
				              <input name="s" id="s" maxlength="50" type="search" value="' . get_search_query() . '" placeholder="' . __( 'Enter search text', 'berserk' ) . '">
				              <button type="submit"><i class="fa fa-search"></i></button>
				            </form>
				            ' . $search_form_close . '
				          </div>
				        </div>';

			return $output;
		}

		function render_call( $atts ) {

			//dpm($atts);

			switch ( $atts['call_brk_skin'] ) {
				case 'alternate':
					$output = '<div class="brk-call-us brk-header__item">
						          <a href="tel:' . $atts['call_number'] . '" class="brk-call-us__number"><i class="fa fa-phone"></i> ' . $atts['call_number'] . '</a>
						          <a href="tel:' . $atts['call_number'] . '" class="brk-call-us__link"><i class="fa fa-phone"></i></a>
						        </div>';

					break;
				case 2:
					$output = '<div class="brk-header__element brk-header__element_skin-2 brk-header__item">
						<a href="tel:' . brk_esc_phone( $atts['call_number'] ) . '" class="brk-header__element--wrap">
							<i class="fa fa-phone"></i> <span class="brk-header__element--label font__weight-semibold">' . $atts['call_number'] . '</span></a>
						</div>';
					break;
				default:

					$after_call = ( $atts['call_brk_skin'] == 3 ) ? '<br>' . __( ' Free call', 'berserk' ) : '';

					$label_class = ( isset( $atts['hide_labels'] ) && $atts['hide_labels'] == 'y' ) ? 'd-lg-none' : '';

					$output = '<div class="brk-header__element brk-header__element_skin-' . $atts['call_brk_skin'] . ' brk-header__item">
								  <a href="tel:' . brk_esc_phone( $atts['call_number'] ) . '" class="brk-header__element--wrap">
								    <i class="fa fa-phone"></i>
								    <span class="brk-header__element--label ' . $label_class . '">' . $atts['call_number'] . $after_call . '</span>
								  </a>
								</div>';

					break;
			}

			return $output;
		}

		function render_language( $atts ) {

			$lang_class   = '';
			$lang_opacity = '';

			switch ( $atts['language_brk_langs_type'] ) {
				case "interactive":
					$lang_class = 'brk-lang_interactive brk-lang-rendered';
					//$lang_opacity = 'opacity-80';
					break;
				case "square":
					$lang_class = 'brk-lang_square brk-bg-primary brk-location-screen-left';
					break;
				case "text_white":
					$lang_class   = 'brk-lang_interactive';
					$lang_opacity = 'text-white';
					break;
			}

			$output = '';

			if ( defined( 'ICL_LANGUAGE_CODE' ) ) {

				$languages = icl_get_languages( 'skip_missing=0' );

				$output = '<div class="brk-lang brk-header__item ' . $lang_class . '">';
				foreach ( $languages as $l ) {
					if ( $l['active'] ) {
						$output .= '<span class="brk-lang__selected ' . $lang_opacity . '">' . strtoupper( $l['language_code'] ) . '<i class="fa fa-caret-down" aria-hidden="true"></i></span>
				        <span class="brk-lang__open"><i class="fa fa-language"></i> ' . __( 'Language', 'berserk' ) . ' <span class="brk-lang__active-lang text-white brk-bg-primary">' . strtoupper( $l['language_code'] ) . '</span></span>';
					}
				}

				$output .= '<ul class="brk-lang__option">';

				foreach ( $languages as $l ) {
					if ( ! $l['active'] ) {
						$output .= '<li><a href="' . $l['url'] . '">' . strtoupper( $l['language_code'] ) . '</a></li>';
					}
				}

				$output .= '</ul>
				      </div>';
			} else {

				$current_url = $_SERVER['SERVER_NAME'];
				$pos         = strrpos( $current_url, "nikadevs.com" );
				$pos_local   = strrpos( $current_url, "local" );
				if ( $pos !== false || $pos_local !== false ) {
					$output = '<div class="brk-lang brk-header__item brk-location-screen-right ' . $lang_class . '">
							  <span class="brk-lang__selected ' . $lang_opacity . '">' . __( 'US', 'berserk' ) . '<i class="fa fa-caret-down" aria-hidden="true"></i></span>
							  <span class="brk-lang__open"><i class="fa fa-language"></i>' . __( 'Language ', 'berserk' ) . '<span class="brk-lang__active-lang text-white brk-bg-primary">' . __( 'US', 'berserk' ) . '</span></span>
							  <ul class="brk-lang__option">
							    <li><a href="#">' . __( 'UA', 'berserk' ) . '</a></li>
							    <li><a href="#">' . __( 'US', 'berserk' ) . '</a></li>
							    <li><a href="#">' . __( 'PL', 'berserk' ) . '</a></li>
							    <li><a href="#">' . __( 'ES', 'berserk' ) . '</a></li>
							  </ul>
							</div>';
				}
			}

			return $output;
		}

		function render_cart( $atts ) {

			global $woocommerce;
			$items = $woocommerce->cart->get_cart();
			//dpm( $atts );

			$output = '';

			$class_cart_open = $class_cart_count = array();

			switch ( $atts['cart_brk_skin'] ) {
				case "1":
					$class_cart_open[]  = 'brk-mini-cart__open';
					$class_cart_count[] = 'brk-mini-cart__count';
					$class_cart_open[]  = 'brk-mini-cart__open_skin-' . $atts['cart_brk_skin'];
					$class_cart_count[] = 'brk-mini-cart__count_skin-' . $atts['cart_brk_skin'];
					break;
				case "interactive":
					$class_cart_open[] = 'brk-mini-cart__info-open';
					break;
				case "gray_white_bg":
					$class_cart_open[] = 'brk-mini-cart__open';
					$class_cart_open[] = 'brk-mini-cart__open_skin-1';

					$class_cart_count[] = 'brk-mini-cart__count';
					$class_cart_count[] = 'brk-mini-cart__count_white';
					$class_cart_count[] = 'brk-mini-cart__count_skin-1';

					break;
				case "gray_dark_bg":
					$class_cart_open[] = 'brk-mini-cart__open';
					$class_cart_open[] = 'brk-mini-cart__open_skin-1';

					$class_cart_count[] = 'brk-mini-cart__count';
					$class_cart_count[] = 'brk-mini-cart__count_skin-1';

					break;
				case "text_white":
					$class_cart_open[]  = 'brk-mini-cart__open';
					$class_cart_open[]  = 'text-white';
					$class_cart_count[] = 'brk-mini-cart__count';
					$class_cart_count[] = 'brk-mini-cart__count_skin-1';
					$class_cart_count[] = 'brk-mini-cart__count_white';

					break;
				default:
					$class_cart_open[]  = 'brk-mini-cart__open';
					$class_cart_count[] = 'brk-mini-cart__count';
					break;
			}

			$class_cart_open  = implode( ' ', $class_cart_open );
			$class_cart_count = implode( ' ', $class_cart_count );

			if ( brk_is_woo_activated() ) {

				$output = '<div class="brk-mini-cart brk-header__item" data-count_class="' . $class_cart_count . '">
					        <div class="' . $class_cart_open . '">';

				if ( $atts['cart_brk_skin'] == 'interactive' ) {

					$output .= '<div class="brk-mini-cart__info-open-thumb">';
					$currency = get_woocommerce_currency_symbol();
					$i        = 1;
					foreach ( WC()->cart->cart_contents as $item ) {
						$id       = $item['product_id'];
						$bg_image = wp_get_attachment_image_src( get_post_thumbnail_id( $id ), 'header-mini-cart-image' );
						$output .= '<div class="thumb-' . $i . '" style="background-image: url(' . $bg_image[0] . ')"></div>';
						$i ++;
					}

					$output .= '<span class="brk-mini-cart__info-open-count">' . esc_html( WC()->cart->cart_contents_count ) . '</span>
						      </div>
						      <div class="brk-mini-cart__info-open-total-price font__family-montserrat font__weight-semibold">' . $currency . esc_html( WC()->cart->get_cart_contents_total() ) . '</div>';
				} else {

					$output .= '<i class="fa fa-shopping-basket" aria-hidden="true"></i>
						          <span class="brk-mini-cart__label font__family-montserrat font__weight-medium text-uppercase letter-spacing-60 font__size-10 opacity-80">' . __( 'My cart', 'berserk' ) . '</span>
						          <span class="brk-mini-cart__title">' . esc_html__( 'Shopping Cart', 'berserk' ) . '</span>
						          <span class="' . esc_attr( $class_cart_count ) . '">' . esc_html( WC()->cart->cart_contents_count ) . '</span>';
				}

				$output .= '</div>

					        <div class="brk-mini-cart__menu">
					          <div class="brk-mini-cart__header">
					            <span class="font__family-montserrat font__weight-bold font__size-18">' . esc_html__( 'Your Cart', 'berserk' ) . '</span>
					          </div>

					          <div class="brk-mini-cart__products">';

				do_action( 'woocommerce_before_mini_cart_contents' );

				foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
					$_product   = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
					$product_id = apply_filters( 'woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key );

					$remove_from_cart_link = apply_filters( 'woocommerce_cart_item_remove_link', sprintf(
						'<a href="%s" class="remove brk-mini-cart__product--remove" aria-label="%s" data-product_id="%s" data-product_sku="%s" data-cart_item_key="%s"><i class="fa fa-times-circle" aria-hidden="true"></i></a>',
						esc_url( wc_get_cart_remove_url( $cart_item_key ) ),
						esc_html__( 'Remove this item', 'deepsoul' ),
						esc_attr( $_product->get_id() ),
						esc_attr( $_product->get_sku() ),
						esc_attr( $cart_item_key )
					), $cart_item_key );

					$thumbnail = get_the_post_thumbnail_url( $product_id, array( 80, 80 ) );

					$price     = '<span class="brk-mini-cart__product--price font__family-montserrat">' . wc_price( $_product->get_price() ) . '</span>';
					$old_price = $_product->get_sale_price() !== '' ? '<span class="brk-mini-cart__product--old-price font__family-montserrat">' . wc_price( $_product->get_regular_price() ) . '</span>' : '';

					ob_start();

					include( locate_template( 'woocommerce/cart/mini-cart_product.php' ) );

					$output .= ob_get_clean();


				}
				do_action( 'woocommerce_mini_cart_contents' );

				$output .= '</div>
					          <div class="brk-mini-cart__links">
					            <div class="brk-mini-cart__links--wrap">
					              <a class="brk-mini-cart__links--cart" href="' . esc_url( wc_get_cart_url() ) . '"><i class="fa fa-shopping-basket"></i>' . __( ' Cart', 'berserk' ) . '</a>
					              <a class="brk-mini-cart__links--checkout" href="' . esc_url( wc_get_checkout_url() ) . '">' . esc_html__( 'Proceed to checkout ', 'berserk' ) . '<i class="fa fa-arrow-right"></i></a>
					            </div>
					          </div>
					        </div>
					      </div>';
			}


			return $output;
		}

		function render_social( $atts ) {

			if ( ! $atts['social_links'] ) {
				return;
			}
			$links                = '';
			$atts['social_links'] = vc_param_group_parse_atts( $atts['social_links'] );

			$social_links_class = '';

			if ( isset( $atts['social_brk_skin'] ) ) {
				switch ( $atts['social_brk_skin'] ) {
					case "vertical":
						$social_links_class = 'brk-social-links_no-open brk-social-links_link-14  brk-location-screen-left';
						break;
				}
			}

			foreach ( $atts['social_links'] as $link ) {
				$icon       = explode( ' ', $link['icon_fontawesome'] );
				$icon_class = $icon['1'];
				if ( $icon_class == 'fa-youtube-play' ) {
					$icon_class = 'fa-youtube';
				}
				$links .= '<a href="' . ( isset( $link['link'] ) ? esc_url( $link['link'] ) : '#' ) . '"><i class="fa ' . esc_attr( $icon_class ) . '"></i></a>';
			}

			$output = '<div class="brk-social-links brk-header__item ' . $social_links_class . '">
				          <div class="brk-social-links__open">
				            <i class="fa fa-share-alt"></i>
				            <div class="brk-social-links__title">' . esc_html__( 'Share our website', 'berserk' ) . '</div>
				          </div>

				          <div class="brk-social-links__block">
				            <div class="brk-social-links__header">
				              <span class="font__family-montserrat font__weight-bold font__size-18">' . esc_html__( 'Share our website', 'berserk' ) . '</span>
				            </div>
				            <div class="brk-social-links__content">
				              ' . $links . '
				            </div>
				          </div>
				        </div>';

			return $output;
		}

		function render_side_menu( $atts ) {

			$side_menu_icon_class = '';
			$side_brk_lines       = '';
			if ( isset( $atts['side_menu_brk_smi_type'] ) ) {
				switch ( $atts['side_menu_brk_smi_type'] ) {
					case "small":
						$side_menu_icon_class = 'brk-info-menu-open_skin-1';
						break;
					case "big":
						$side_menu_icon_class = 'brk-info-menu-open_skin-2';
						break;
					case "custom":
						$side_menu_icon_class = 'brk-info-menu-open_skin-3';
						break;
					case "custom_2":
						$side_menu_icon_class = 'brk-info-menu-open_skin-4';
						break;
					case "white":
						$side_menu_icon_class = 'brk-info-menu-open_skin-2';
						$side_brk_lines       = 'brk-info-menu-open_white';
						break;
				}
			}

			$output = '<div class="brk-info-menu-open brk-header__item ' . $side_menu_icon_class . '">
						  <span class="brk-lines ' . $side_brk_lines . '">
						    <span class="brk-center-line"></span>
						  </span>
						  <div class="brk-info-menu-open__title">' . __( 'Side Menu', 'berserk' ) . '</div>
						</div>';

			return $output;
		}

		function render_compare( $atts ) {

			$args    = array(
				'post_type'  => 'product',
				'meta_query' => array(
					array(
						'key'   => 'compare',
						'value' => 'true'
					)
				)
			);
			$posts   = get_posts( $args );
			$compare = ( ! empty( $posts ) ) ? count( $posts ) : 0;

			$label_class   = ( isset( $atts['hide_labels'] ) && $atts['hide_labels'] == 'y' ) ? 'd-lg-none' : '';
			$skin_type     = $atts['compare_brk_skin'];
			$element_class = '';

			switch ( $atts['compare_brk_skin'] ) {
				case 1:
					$compare_class = 'brk-header__compare_white';
					break;
				case 2:
					$compare_class = 'brk-header__compare_dark';
					break;
				case "gray_white_bg":
					$compare_class = 'brk-header__compare brk-header__compare_white brk-header__compare_skin-1';
					$skin_type     = '2';
					$label_class   = 'font__weight-medium';
					break;
				case "gray_dark_bg":
					$compare_class = 'brk-header__compare brk-header__compare_dark brk-header__compare_skin-1';
					$skin_type     = '2';
					$label_class   = 'font__weight-medium';
					break;
				case "text_white":
					$skin_type     = '2';
					$element_class = ' text-white';
					$compare_class = 'brk-header__compare_white brk-header__compare_skin-1';
					break;
			}


			$output = '<div class="brk-header__element brk-header__element_skin-' . $skin_type . $element_class . ' brk-header__item">
						  <a href="#" class="brk-header__element--wrap">
						  <i class="fa fa-exchange"></i>
						    <span class="brk-header__element--label ' . $label_class . '">' . __( 'Compare List' ) . '</span>
						    <span class="brk-header__compare ' . $compare_class . '">' . $compare . '</span>
						  </a>
						</div>';

			return $output;
		}

		function render_wishlist( $atts ) {

			$args = array(
				'post_type'  => 'product',
				'meta_query' => array(
					array(
						'key'   => 'wishlist',
						'value' => 'true'
					)
				)
			);

			$posts    = get_posts( $args );
			$wishlist = ( ! empty( $posts ) ) ? count( $posts ) : 0;

			$skin_type = $atts['wishlist_brk_skin'];

			$label_class   = ( isset( $atts['hide_labels'] ) && $atts['hide_labels'] == 'y' ) ? 'd-lg-none' : '';
			$compare_class = '';
			$element_class = '';

			switch ( $atts['wishlist_brk_skin'] ) {
				case 1:
					$compare_class = 'brk-header__compare_white';
					break;
				case 2:
					$compare_class = 'brk-header__compare_dark';
					break;
				case "gray_white_bg":
					$compare_class = 'brk-header__compare brk-header__compare_white brk-header__compare_skin-1';
					$skin_type     = '2';
					$label_class   = 'font__weight-medium';
					break;
				case "gray_dark_bg":
					$compare_class = 'brk-header__compare brk-header__compare_dark brk-header__compare_skin-1';
					$skin_type     = '2';
					$label_class   = 'font__weight-medium';
					break;
				case "text_white":
					$skin_type     = '2';
					$element_class = ' text-white';
					$compare_class = 'brk-header__compare_white brk-header__compare_skin-1';
					break;
			}

			$output = '<div class="brk-header__element brk-header__element_skin-' . $skin_type . $element_class . ' brk-header__item">
						  <a href="#" class="brk-header__element--wrap">
						    <i class="fa fa-heart"></i>
						    <span class="brk-header__element--label ' . $label_class . '">' . __( 'My wishlist' ) . '</span>
						    <span class="brk-header__compare ' . $compare_class . '">' . $wishlist . '</span>
						  </a>
						</div>';

			return $output;
		}

		function render_custombutton( $atts ) {

			brs_add_libraries( 'component__button' );

			//dpm($atts);

			$title       = isset( $atts['custombutton_brk_title'] ) ? $atts['custombutton_brk_title'] : '';
			$title       = explode( '^', $title );
			$title_1     = $title[0];
			$title_2     = $title[1];
			$title_3     = $title[2];
			$title_hover = '';
			if ( isset( $atts['custombutton_brk_title_hover'] ) ) {
				if ( ! empty( $atts['custombutton_brk_title_hover'] ) ) {
					$title_hover = $atts['custombutton_brk_title_hover'];
				}
			}

			$url      = ( isset( $atts['custombutton_brk_url'] ) ) ? $atts['custombutton_brk_url'] : '';
			$url      = vc_build_link( $url );
			$link_url = $url['url'];

			$button_type  = isset( $atts['custombutton_brk_button_type'] ) ? $atts['custombutton_brk_button_type'] : '';
			$button_class = '';
			$output       = '';

			switch ( $button_type ) {
				case "btn-inside-out":
				case "white":

					if ( $button_type == 'btn-inside-out' ) {
						$button_class = 'btn btn-inside-out btn- ml-20 mr-10 brk-header__item brk-header__btn btn-sm-1 border-radius-25 font__family-open-sans font__weight-bold m-0 pl-30 pr-30';
					} elseif ( $button_type == 'white' ) {
						$button_class = 'btn btn-inside-out btn- brk-header__item brk-header__btn brk-header__btn_white btn-sm-1 brk-base-box-shadow border-radius-25 font__family-open-sans font__weight-bold pl-30 pr-30';
					}

					$output = '<a href="' . esc_url( $link_url ) . '" class="' . $button_class . '">
								<span class="before">' . esc_html( $title_1 ) . '<span class="font__family-times-new-roman text-lowercase font__style-italic">' . esc_html( $title_2 ) . '</span>' . esc_html( $title_3 ) . '</span>';
					if ( $title_hover ) {
						$output .= '<span class="text">' . esc_html( $title_hover ) . '</span>';
					} else {
						$output .= '<span class="text">' . esc_html( $title_1 ) . '<span class="font__family-times-new-roman text-lowercase font__style-italic">' . esc_html( $title_2 ) . '</span>' . esc_html( $title_3 ) . '</span>';
					}
					$output .= '<span class="after">' . esc_html( $title_1 ) . '<span class="font__family-times-new-roman text-lowercase font__style-italic">' . esc_html( $title_2 ) . '</span>' . esc_html( $title_3 ) . '</span>
							</a>';
					break;
				case "btn-prime":
					$button_class = 'btn btn-prime btn-md brk-header__item brk-header__btn border-radius-25 font__family-open-sans font__weight-bold';
					$output       = '<a href="' . esc_url( $link_url ) . '" class="' . $button_class . '" style="opacity: 1;">
								<span class="before"></span>
								<span class="after"></span>
								<span class="border-btn"></span>' . esc_html( $title_1 ) . '
								<span class="font__family-times-new-roman text-lowercase font__style-italic">' . esc_html( $title_2 ) . '</span>' . esc_html( $title_3 ) . '</a>';
					break;

				case "gradient":
					$output = '<a href="' . esc_url( $link_url ) . '" class="btn btn-gradient brk-header__item brk-header__btn btn-sm-1 border-radius-25 font__family-open-sans font__weight-bold brk-white-font-color">
									<span>' . esc_html( $title_1 ) . ' <span class="font__family-times-new-roman text-lowercase font__style-italic">' . esc_html( $title_2 ) . '</span> ' . esc_html( $title_3 ) . '</span>
								</a>';
					break;
			}

			return $output;
		}

		function render_to_top_button( $atts ) {

			$output = '<div class="brk-totop brk-header_border-top-20">
						  <i class="fa fa-arrow-up"></i>
						</div>';

			return $output;
		}

		function render_shortcode_sidebar( $atts ) {

			switch ( $atts['custom_content']['0']['content_type'] ) {
				case 'sidebar':
					$sidebar_id = isset( $atts['custom_content']['0']['content_sidebar'] ) ? $atts['custom_content']['0']['content_sidebar'] : '';

					if ( ! empty( $sidebar_id ) ) {
						ob_start();
						dynamic_sidebar( $sidebar_id );
						$output = ob_get_clean();
					}
					break;
				case 'shortcode':
					$shortcode = isset( $atts['custom_content']['0']['content_shortcode'] ) ? $atts['custom_content']['0']['content_shortcode'] : '';
					if ( ! empty( $shortcode ) ) {
						$output = do_shortcode( $shortcode );
					}
					break;
			}

			return $output;
		}

	}

	// create shortcode
	BRS_Header_Shortcode::get_instance();

}
