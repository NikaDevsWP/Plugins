<?php
/**
 * Team shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Team', false ) ) {

	require_once BERSERK_SHORTCODES_PATH . 'shortcodes/includes/shortcodes-ext.php';

	class BRS_Team extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Team();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_team', array( $this, 'shortcode_team' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				$params = array();

				$params[] = array(
					'heading'    => __( 'Team', 'berserk' ),
					'param_name' => 'team_type',
					'type'       => 'brs_radio',
					'value'      => array(
						"Persone Circle" => "persone_circle",
						"Material Card"  => "material_card",
						"Persone Table"  => "persone_table",
					),
					'images'     => array(
						"persone_circle" => 'team/002.png',
						"material_card"  => 'team/003.png',
						"persone_table"  => 'team/005.png',
					),
					'images_dim' => array(
						'w' => '310',
						'h' => '150'
					)
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Image size', 'berserk' ),
					'value'            => BRS_Shortcodes_VCParams::get_image_sizes_names(),
					'param_name'       => 'image_size',
					'std'              => 'image-frames',
					'edit_field_class' => 'vc_col-sm-6 vc_column'
				);

				$params[] = array(
					"heading"    => __( "Dynamic Content", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				// Add dynamic filter and order functionality @see ../shortcodes-ext.php
				$params = array_merge( $params, berserk_shortcodes_dynamic_filter() );

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Put items in columns with size:', 'berserk' ),
					'value'            => array(
						'2 - 50%' => 6,
						'3 - 33%' => 4,
						'4 - 25%' => 3,
						'6 - 16%' => 2,
					),
					'param_name'       => 'columns',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					'admin_label'      => true,
				);

				$params[] = array(
					"heading"    => __( "Content Values", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Get title from', 'js_composer' ),
					'param_name'       => 'title_val',
					'value'            => array(
						'Post Title'  => 'post_title',
						'Post Date'   => 'post_date',
						'Post Author' => 'post_author'
					),
					'edit_field_class' => 'vc_col-sm-4 vc_column',
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Get Position from', 'js_composer' ),
					'param_name'       => 'position_val',
					'value'            => array(
						'Post Title'  => 'post_title',
						'Post Date'   => 'post_date',
						'Post Author' => 'post_author'
					),
					'edit_field_class' => 'vc_col-sm-4 vc_column',
				);
				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Get description from', 'js_composer' ),
					'param_name'       => 'description_val',
					//'admin_label'      => true,
					'value'            => array(
						'Post Title'   => 'post_title',
						'Post Date'    => 'post_date',
						'Post Author'  => 'post_author',
						'Post Content' => 'post_content',
						'Post Excerpt' => 'post_excerpt',
					),
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					'std'              => 'post_content',
				);

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Team", 'berserk' ),
					"base"     => "brs_team",
					"icon"     => "brs_vc_ico_team",
					"class"    => "brs_vc_sc_team",
					"category" => __( 'Berserk', 'berserk' ),
					"params"   => $params
				) );
			}
		}

		public function shortcode_team( $atts, $content = null ) {

			brs_add_libraries( 'component__team' );

			extract( shortcode_atts( array(
				'team_type'       => 'persone_circle',
				'image_size'      => 'image-frames',
				'filters'         => '',
				'columns'         => 4,
				'orderby'         => 'date',
				'order_direction' => 'ASC',
				'title_val'       => 'post_title',
				'position_val'    => 'post_position',
				'description_val' => 'post_content'
			), $atts ) );

			// store atts
			$atts_backup = self::$atts;

			$args   = berserk_shortcodes_dynamic_filter_process( $filters, $orderby, $order_direction );
			$output = '';
			$posts  = get_posts( $args );
			switch ( $team_type ) {
				case "persone_circle":

					foreach ( $posts as $post ) {

						$custom_values = get_post_custom( $post->ID );
						$bg_image      = get_the_post_thumbnail_url( $post->ID, $image_size );
						$title         = BRS_Shortcodes_VCParams::get_content_title( $title_val, $post );
						$post_type     = get_post_type( $post->ID );
						if ( $post_type == BRS_Staff::postType() ) {
							$positions = BRS_Shortcodes_VCParams::get_term_names( $post->ID, 'position' );
							$position  = implode( ',', $positions );
						}

						$post    = '
							<article class="brk-team-persone-circle brk-base-box-shadow text-center">
								<div class="brk-team-persone-circle__name-position">
									<a href="' . get_permalink( $post->ID ) . '"><h4 class="font__family-montserrat font__weight-bold font__size-18">' . esc_html( $title ) . '</h4></a>
									<span class="font__family-montserrat font__weight-normal font__size-16 line__height-24">' . esc_html( $position ) . '</span>
								</div>
								<div class="brk-team-persone-circle__bg" style="background-image: url(' . esc_url( $bg_image ) . ')">
									<span class="brk-team-persone-circle__bg-overlay">
										<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 270 37">
											<path d="M270,37H0V0A267.6,267.6,0,0,0,135.53,36.5,267.52,267.52,0,0,0,270,0Z" fill="rgb(255, 255, 255)"/>
										</svg>
									</span>
									<ul class="brk-team-persone-circle__contacts">';
						$meta    = BRS_Staff::postMeta();
						$counter = 0;
						foreach ( $custom_values as $key => $value ) {
							if ( ! empty( $value[0] ) && isset( $meta[ $key ] ) && $meta[ $key ]['group'] == 'socials' ) {
								$fa = 'fa';
								if ($meta[ $key ]['icon'] == 'email'){
									$meta[ $key ]['icon'] = 'envelope';
								}
								$post .= '
										<li>
											<i class="' . $fa . ' fa-' . $meta[ $key ]['icon'] . '" aria-hidden="true"></i>
											<a href="' . @$meta[ $key ]['prefix'] . $value[0] . '">' . $value[0] . '</a>
										</li>';
								$counter ++;
								unset( $custom_values[ $key ] );
							}
							if ( $counter > 3 ) {
								break;
							}
						}

						$post .= '
								</ul>
							</div>
							<div class="brk-team-persone-circle__social-links">
								<ul>';

						foreach ( $custom_values as $key => $value ) {
							if ( ! empty( $value[0] ) && isset( $meta[ $key ] ) && $meta[ $key ]['group'] == 'socials' ) {

								$post .= '
									<li><a href="' . @$meta[ $key ]['prefix'] . $value[0] . '"><i class="fa fa-' . $meta[ $key ]['icon'] . '" aria-hidden="true"></i></a></li>';
								$counter ++;
								unset( $custom_values[ $key ] );
							}
							if ( $counter > 7 ) {
								break;
							}
						}

						$post .= '
								</ul>
							</div>
						</article>';
						$output .= count( $posts ) > 1 ? '<div class = "col-sm-6 col-lg-' . $columns . '">' . $post . '</div>' : $post;
					}


					break;
				case 'material_card':

					$post_counter = 0;
					$color_scheme = array( 'red', 'purple', 'base', 'light-blue' );
					foreach ( $posts as $post ) {

						$custom_values = get_post_custom( $post->ID );
						$bg_image      = get_the_post_thumbnail_url( $post->ID, $image_size );
						$title         = BRS_Shortcodes_VCParams::get_content_title( $title_val, $post );
						$description   = BRS_Shortcodes_VCParams::get_content_description( $description_val, $post );
						$post_type     = get_post_type( $post->ID );
						if ( $post_type == BRS_Staff::postType() ) {
							$positions = BRS_Shortcodes_VCParams::get_term_names( $post->ID, 'position' );
							$position  = implode( ',', $positions );
						}

						$meta       = BRS_Staff::postMeta();
						$counter    = 0;
						$attributes = '';
						foreach ( $custom_values as $key => $value ) {
							if ( ! empty( $value[0] ) && isset( $meta[ $key ] ) && $meta[ $key ]['group'] == 'socials' ) {
								$attributes .= '<li><a href="' . @$meta[ $key ]['prefix'] . $value[0] . '"><i class="fa fa-' . $meta[ $key ]['icon'] . '" aria-hidden="true"></i></a></li>';
								$counter ++;
							}
							if ( $counter > 4 ) {
								break;
							}
						}


						$post = '
							<article class="brk-team-mc brk-mc-' . $color_scheme[ $post_counter ++ % 4 ] . '" style="background-image: url(' . esc_url( $bg_image ) . ')">
								<h4>
									<a href="' . get_permalink( $post->ID ) . '" class="font__family-montserrat font__weight-light font__size-24 line__height-26">' . esc_html( $title ) . '</a>
									<span class="font__family-montserrat font__weight-ultralight font__size-16 line__height-21">' . esc_html( $position ) . '</span>
								</h4>
								<div class="brk-team-mc__content">
									<div class="mc-description font__family-open-sans font__size-16 line__height-26">' . esc_html( $description ) . '</div>
									<ul class="mc-social">
										<li><span>' . __( 'Social', 'berserk' ) . ':</span></li>'
										. $attributes .
										'</ul>
							</div>
							<div class="mc-btn-bg-action"><span></span></div>
							<button class="mc-btn-action"><i class="far fa-bars"></i></button>
						</article>';
						$output .= count( $posts ) > 1 ? '<div class="col-sm-6 col-lg-' . $columns . '">' . $post . '</div>' : $post;
					}
					break;

				case 'persone_table':

					$counter_post = 0;
					foreach ( $posts as $post ) {

						$custom_values = get_post_custom( $post->ID );
						$bg_image      = get_the_post_thumbnail_url( $post->ID, $image_size );
						$title         = BRS_Shortcodes_VCParams::get_content_title( $title_val, $post );
						$description   = BRS_Shortcodes_VCParams::get_content_description( $description_val, $post );
						$post_type     = get_post_type( $post->ID );
						if ( $post_type == BRS_Staff::postType() ) {
							$positions = BRS_Shortcodes_VCParams::get_term_names( $post->ID, 'position' );
							$position  = implode( ',', $positions );
						}

						$meta       = BRS_Staff::postMeta();
						$counter    = 0;
						$attributes = '';
						foreach ( $custom_values as $key => $value ) {
							if ( ! empty( $value[0] ) && isset( $meta[ $key ] ) && $meta[ $key ]['group'] == 'socials' ) {
								$fa = 'fa';
								if ($meta[ $key ]['icon'] == 'email'){
									$meta[ $key ]['icon'] = 'envelope';

								}
								$attributes .= '
									<li>
										<i class="' . $fa . ' fa-' . $meta[ $key ]['icon'] . '" aria-hidden="true"></i>
										<a href="' . @$meta[ $key ]['prefix'] . $value[0] . '">' . $value[0] . '</a>
									</li>';
								if ( $counter ++ > 4 ) {
									break;
								}
							}
						}

						$bg_class = $counter_post ++ % 2 ? 'white' : 'dark';

						$post = '
						<div class="brk-team-persone-table__item" style="background-image: url(' . esc_url( $bg_image ) . ')">
							<span class="brk-base-gradient-persone-table brk-team-persone-table__overlay"></span>
							<div class="brk-team-persone-table__title brk-team-persone-table__title_' . $bg_class . '">
								<div class="brk-team-persone-table__name-position">
									<a href="' . get_permalink( $post->ID ) . '"><h4 class="font__family-montserrat font__weight-bold font__size-24 line__height-40">' . esc_html( $title ) . '</h4></a>
									<span class="font__family-montserrat font__weight-light font__size-15 line__height-21">' . esc_html( $position ) . '</span>
								</div>
							</div>
							<ul class="brk-team-persone-table__contacts">' .
										$attributes . '
							</ul>
							<div class="brk-elev brk-elev-1"></div>
							<div class="brk-elev brk-elev-2"></div>
							<div class="brk-elev brk-elev-3"></div>
							<div class="brk-elev brk-elev-4"></div>
						</div>';
						$output .= count( $posts ) > 1 ? '<div class="col-sm-6 col-lg-' . $columns . '">' . $post . '</div>' : $post;
					}
					break;
			}

			// restore atts
			self::$atts = $atts_backup;

			if ( count( $posts ) > 1 ) {
				if ( $team_type == 'persone_table' ) {
					$output = '<div class="brk-team-persone-table">
						<div class="row no-gutters">' . $output . '</div>
						<div class="ptable-top"></div>
						<div class="ptable-bottom"></div>
						<div class="ptable-right"></div>
						<div class="ptable-left"></div>
					</div>';
				} else {
					$output = '<div class="row">' . $output . '</div>';
				}
			}

			return $output;
		}


	}

	// create shortcode
	BRS_Team::get_instance();

}
