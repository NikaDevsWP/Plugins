<?php
/**
 * Button shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Shortcode_Button', false ) ) {

	class BRS_Shortcode_Button extends BRS_Shortcode {

		protected $atts = array();
		protected $content = null;
		protected $config = null;
		protected $color_atts = array();
		protected $button_id = '';
		protected $shortcode_id = 0;
		protected $custom_colors = array();
		public static $font;

		public function __construct() {
			$this->config = presscore_config();
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Button", 'berserk' ),
					"base"     => "brs_button",
					"icon"     => "brs_vc_ico_button",
					"class"    => "brs_vc_sc_button",
					"category" => __( 'Berserk', 'berserk' ),
					"params"   => array(
						array(
							"type"             => "textfield",
							"class"            => "",
							"heading"          => __( "Caption", 'berserk' ),
							"param_name"       => "caption",
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							"value"            => ""
						),
						array(
							'heading'          => __( 'Use another caption on hover', 'berserk' ),
							'param_name'       => 'caption_on_hover',
							'type'             => 'brs_switch',
							'value'            => 'n',
							'options'          => array(
								'Yes' => 'y',
								'No'  => 'n',
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column'
						),
						array(
							"type"             => "textfield",
							"class"            => "",
							"heading"          => __( "Caption on hover", 'berserk' ),
							//"admin_label"      => true,
							"param_name"       => "hover_caption",
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							"value"            => "",
							'dependency'       => array(
								'element' => 'caption_on_hover',
								'value'   => 'y',
							),
						),
						array(
							"type"             => "textfield",
							"heading"          => __( "Custom css class name", 'berserk' ),
							"param_name"       => "el_class",
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							"value"            => "",
							//"description" => __( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'berserk' )
						),

						array(
							'type'       => 'vc_link',
							'heading'    => __( 'Link URL', 'js_composer' ),
							'param_name' => 'url',
						),
						/*
						array(
							"type"             => "textfield",
							"class"            => "",
							"heading"          => __( "Link URL", 'berserk' ),
							"param_name"       => "link",
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							"value"            => ""
						),
						array(
							"type"             => "dropdown",
							"class"            => "",
							"heading"          => __( "Open link in", 'berserk' ),
							"param_name"       => "target_blank",
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							"value"            => array(
								"Same window" => "false",
								"New window"  => "true"
							)
						),*/
						array(
							"type"             => "dropdown",
							"class"            => "",
							"heading"          => __( "Button alignment", 'berserk' ),
							"param_name"       => "button_alignment",
							"value"            => array(
								"None"   => "none",
								"Left"   => "left",
								"Right"  => "right",
								"Centre" => "center",

							),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

						array(
							'heading'          => __( 'Button without left and right margin', 'berserk' ),
							'param_name'       => 'mh_0',
							'type'             => 'brs_switch',
							'value'            => 'n',
							'options'          => array(
								'Yes' => 'y',
								'No'  => 'n',
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column'
						),

						array(
							"group"      => __( "Style", 'berserk' ),
							"heading"    => __( "Button types", 'berserk' ),
							"param_name" => "brs_title",
							"type"       => "brs_title",
						),

						array(
							"group"      => __( "Style", 'berserk' ),
							'heading'    => __( 'Button type', 'berserk' ),
							'param_name' => 'brs_type',
							'type'       => 'brs_radio',
							'value'      => array(
								"Default (border radius 5)"  => "default_br_5",
								"Default (border radius 10)" => "default_br_10",
								"Round"                      => "round",
								"Oval"                       => 'oval',
								"Square"                     => 'square',
								"Dropdown"                   => "dropdown"
							),
							'images'     => array(
								"default_br_5"  => 'button/radio_default.png',
								"default_br_10" => 'button/radio_default.png',
								"round"         => 'button/radio_round.png',
								"oval"          => 'button/radio_oval.png',
								"square"        => 'button/radio_square.png',
								"dropdown"      => 'button/radio_dropdown.png'
							),
							'images_dim' => array(
								'w' => '100',
								'h' => '60'
							)
						),

						array(
							"group"      => __( "Style", 'berserk' ),
							'type'       => 'param_group',
							'heading'    => __( '', 'js_composer' ),
							'param_name' => 'dropdown_values',
							'value'      => urlencode( json_encode( array(
								array(
									'label' => __( 'First', 'js_composer' ),
									'url'   => '#',
								),
								array(
									'label' => __( 'Second', 'js_composer' ),
									'url'   => '#',
								),
								array(
									'label' => __( 'Third', 'js_composer' ),
									'url'   => '#',
								),
							) ) ),
							'params'     => array(
								array(
									'type'        => 'textfield',
									'heading'     => __( 'Caption', 'js_composer' ),
									'param_name'  => 'label',
									'admin_label' => true,
								),

								array(
									"type"        => "textfield",
									"class"       => "",
									"heading"     => __( "Link URL", 'berserk' ),
									"param_name"  => "url",
									"value"       => "",
									'admin_label' => true,
								),
							),
						),

						array(
							"group"            => __( "Style", 'berserk' ),
							'heading'          => __( 'Opened/Closed', 'berserk' ),
							'param_name'       => 'dropdown_opened',
							'type'             => 'brs_switch',
							'value'            => 'c',
							'options'          => array(
								'Opened' => 'o',
								'Closed' => 'c',
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

						array(
							"group"            => __( "Style", 'berserk' ),
							"type"             => "dropdown",
							"class"            => "",
							"heading"          => __( "Color Scheme", 'berserk' ),
							"param_name"       => "drop_color_scheme",
							"value"            => array(
								"Dark"  => "dark",
								"Light" => "light"
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

						array(
							"group"            => __( "Style", 'berserk' ),
							"type"             => "dropdown",
							"class"            => "",
							"heading"          => __( "Button Size", 'berserk' ),
							"param_name"       => "size",
							"value"            => array(
								"S"             => "btn_s",
								"M"             => "btn_m",
								"M Wide"        => "btn_m_1",
								"M Width 200px" => "btn_m_2",
								"L"             => "btn_l",
								"L Width 200px" => "btn_l_2",
								"XL"            => "btn_xl",
								"Full Width"    => "btn_fw",
								"Simple"        => "btn_simple"
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

						array(
							"group"            => __( "Style", 'berserk' ),
							"param_name"       => "round_circled",
							"type"             => "checkbox",
							"value"            => array(
								"Show circles" => "y",
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

						array(
							"group"      => __( "Style", 'berserk' ),
							"heading"    => __( "Delimiters", 'berserk' ),
							"param_name" => "brs_title",
							"type"       => "brs_title",
						),

						array(
							"group"      => __( "Style", 'berserk' ),
							'heading'    => __( 'Enable Delimiters', 'berserk' ),
							'param_name' => 'enable_delimiter',
							'type'       => 'brs_switch',
							'value'      => 'n',
							'options'    => array(
								'Yes' => 'y',
								'No'  => 'n',
							),
						),

						array(
							"group"      => __( "Style", 'berserk' ),
							'heading'    => __( 'Delimiter', 'berserk' ),
							'param_name' => 'delimiter',
							'type'       => 'brs_radio',
							'value'      => array(
								"Solid"          => "solid",
								"Solid Gradient" => "solid_gradient",
								"Double"         => "double",
								"Solid slope"    => "solid_slope",
								"Solid Shade"    => "solid_shade",
								"Doted"          => "doted",
								"Double colors"  => "double_colors"
							),
							'images'     => array(
								"solid"          => 'button/solid.png',
								"solid_gradient" => 'button/solid.png',
								"double"         => 'button/double.png',
								"solid_slope"    => 'button/solid_slope.png',
								"solid_shade"    => 'button/solid_shade.png',
								"doted"          => 'button/doted.png',
								"double_colors"  => 'button/double_colors.png'
							),
							'images_dim' => array(
								'w' => '100',
								'h' => '60'
							),
							'dependency' => array(
								'element' => 'enable_delimiter',
								'value'   => 'y',
							),
						),

						array(
							"group"      => __( "Style", 'berserk' ),
							'type'       => 'colorpicker',
							'heading'    => __( 'Delimiter Color', 'js_composer' ),
							'param_name' => 'delimiter_color',
							'value'      => '#2775FF',
							'dependency' => array(
								'element' => 'enable_delimiter',
								'value'   => 'y',
							),
						),

						array(
							"group"            => __( "Style", 'berserk' ),
							'type'             => 'colorpicker',
							'heading'          => __( 'Delimiter First Color', 'js_composer' ),
							'param_name'       => 'delimiter_color_first',
							'value'            => '#0dbeff',
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'dependency'       => array(
								'element' => 'enable_delimiter',
								'value'   => 'y',
							),
						),

						array(
							"group"            => __( "Style", 'berserk' ),
							'type'             => 'colorpicker',
							'heading'          => __( 'Delimiter Second Color', 'js_composer' ),
							'param_name'       => 'delimiter_color_second',
							'value'            => '#2775FF',
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'dependency'       => array(
								'element' => 'enable_delimiter',
								'value'   => 'y',
							),
						),

						array(
							"group"      => __( "Style", 'berserk' ),
							"heading"    => __( "Button style", 'berserk' ),
							"param_name" => "brs_title",
							"type"       => "brs_title",
						),

						array(
							"group"      => __( "Style", 'berserk' ),
							'heading'    => __( 'Style', 'berserk' ),
							'param_name' => 'style',
							'type'       => 'brs_radio',
							'value'      => array(
								"Solid"               => "solid",
								"Border"              => "border",
								"Gradient"            => "gradient",
								"Double"              => "double",
								"Solid Dark"          => "solid_dark",
								"Border Gradient"     => "border_gradient",
								"Gradient Wave"       => "gradient_wave",
								"Border Progress"     => "border_progress",
								"Double Background"   => "double_background",
								"Light Border Shadow" => "light_border_shadow",
								"Simple Gradient"     => "simple_gradient"

							),
							'images'     => array(
								"solid"               => 'button/s_solid.png',
								"border"              => 'button/border.png',
								"gradient"            => 'button/gradient.png',
								"double"              => 'button/s_double.png',
								"solid_dark"          => 'button/solid_dark.png',
								"border_gradient"     => 'button/border_gradient.png',
								"gradient_wave"       => 'button/gradient_wave.png',
								"border_progress"     => 'button/border_progress.png',
								"double_background"   => 'button/double_background.png',
								"light_border_shadow" => 'button/light_border_shadow.png',
								"simple_gradient"     => 'button/simple_gradient.png',

							),
							'images_dim' => array(
								'w' => '100',
								'h' => '60'
							)
						),

						array(
							'group'            => __( 'Style', 'berserk' ),
							"param_name"       => "button_violet",
							"type"             => "checkbox",
							"value"            => array(
								"Violet button" => "y",
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__style light_border_shadow',
						),

						array(
							'group'            => __( 'Style', 'berserk' ),
							"param_name"       => "button_white_transparent",
							"type"             => "checkbox",
							"value"            => array(
								"White Transparent button" => "y",
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__style border',
						),

						array(
							"group"      => __( "Style", 'berserk' ),
							'type'       => 'colorpicker',
							'heading'    => __( 'Background Color', 'js_composer' ),
							'param_name' => 'custom_background',
							'std'        => '#2775FF',
						),

						array(
							'group'            => __( 'Style', 'berserk' ),
							'heading'          => __( 'Enable custom background', 'berserk' ),
							'param_name'       => 'enable_custom_background',
							'type'             => 'brs_switch',
							'value'            => 'n',
							'options'          => array(
								'Yes' => 'y',
								'No'  => 'n',
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__style simple_gradient',
						),

						array(
							'group'            => __( 'Style', 'berserk' ),
							"heading"          => __( "Default Gradient Type", 'berserk' ),
							"param_name"       => "default_gradient",
							"type"             => "brs_color_scheme",
							'colors'           => array(
								"White background"         => "btn-backgrounds_white",
								"Default"                  => "brk-bg-grad",
								"Default button"           => "brk-base-gradient-btn-backgrounds",
								"Base Gradient 30deg"      => "brk-base-bg-gradient--30deg",
								"Blue"                     => "brk-base-bg-gradient-left-blue",
								"Yellow"                   => "brk-base-bg-yellow",
								"Pink to purple"           => "brk-base-bg-gradient-pink-purple",
								"Base blue gradient"       => "brk-base-bg-gradient-15",
								"Base pink gradient"       => "brk-base-bg-gradient-19",
								"Base 16 gradient"         => "brk-base-bg-gradient-16",
								"Base light dark gradient" => "brk-base-bg-light-dark",
								"Base green gradient"      => "brk-base-bg-green",
								"Base 17 gradient"         => "brk-base-bg-gradient-17"
							),
							"dependency"       => array(
								"element" => "enable_custom_background",
								"value"   => array( 'y' ),
							),
							"edit_field_class" => "vc_col-sm-6 vc_column brk-dependency__style simple_gradient",
						),

						array(
							'group'            => __( 'Style', 'berserk' ),
							'heading'          => __( 'Enable custom text color', 'berserk' ),
							'param_name'       => 'enable_custom_text_color',
							'type'             => 'brs_switch',
							'value'            => 'n',
							'options'          => array(
								'Yes' => 'y',
								'No'  => 'n',
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

						array(
							"group"      => __( "Style", 'berserk' ),
							'type'       => 'colorpicker',
							'heading'    => __( 'Text Color', 'js_composer' ),
							'param_name' => 'text_color',
							'std'        => '#2775FF',
							'dependency' => array(
								'element' => 'enable_custom_text_color',
								'value'   => 'y',
							),
						),

						array(
							"group"            => __( "Style", 'berserk' ),
							"heading"          => __( "First background gradient color", 'berserk' ),
							"param_name"       => "bg_color_g_1",
							"type"             => "colorpicker",
							"value"            => "#15BDFF",
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

						array(
							"group"            => __( "Style", 'berserk' ),
							"heading"          => __( "Second background gradient color", 'berserk' ),
							"param_name"       => "bg_color_g_2",
							"type"             => "colorpicker",
							"value"            => "#00F6FF",
							'edit_field_class' => 'vc_col-sm-6 vc_column',

						),
						array(
							"group"            => __( "Style", 'berserk' ),
							"heading"          => __( "First background gradient color", 'berserk' ),
							"param_name"       => "bg_color_g_3",
							"type"             => "colorpicker",
							"value"            => "#2775ff",
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

						array(
							"group"            => __( "Style", 'berserk' ),
							"heading"          => __( "Second background gradient color", 'berserk' ),
							"param_name"       => "bg_color_g_4",
							"type"             => "colorpicker",
							"value"            => "#7202bb",
							'edit_field_class' => 'vc_col-sm-6 vc_column',

						),

						array(
							"group"      => __( "Style", 'berserk' ),
							"heading"    => __( "Fonts", 'berserk' ),
							"param_name" => "brs_title",
							"type"       => "brs_title",
						),

						array(
							'group'            => __( 'Style', 'berserk' ),
							'heading'          => __( 'Use Custom Font', 'berserk' ),
							'param_name'       => 'enable_font',
							'type'             => 'brs_switch',
							'value'            => 'n',
							'options'          => array(
								'Yes' => 'y',
								'No'  => 'n',
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

						array(
							"group"            => __( "Style", 'berserk' ),
							'type'             => 'google_fonts',
							'param_name'       => 'google_fonts',
							'value'            => 'font_family:Open%20Sans%3A300%2C300italic%2Cregular%2Citalic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic|font_style:700%20bold%20regular%3A700%3Anormal',
							'settings'         => array(
								'fields' => array(
									'font_family_description' => __( '', 'js_composer' ),
									'font_style_description'  => __( '', 'js_composer' ),
								),
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'dependency'       => array(
								'element' => 'enable_font',
								'value'   => 'y',
							),
						),

						array(
							"group"            => __( "Style", 'berserk' ),
							'heading'          => __( 'Font Size', 'js_composer' ),
							"param_name"       => "font_size",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_font_size(),
							'edit_field_class' => 'vc_col-sm-6 vc_column',

						),

						array(
							"group"            => __( "Style", 'berserk' ),
							'type'             => 'dropdown',
							'heading'          => __( 'Letter Spacing', 'berserk' ),
							"value"            => BRS_Shortcodes_VCParams::get_letter_spacing(),
							'param_name'       => 'brs_letter_spacing',
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

						array(
							"group"      => __( "Advanced Title Options", 'berserk' ),
							'heading'    => __( 'Use different fonts in title', 'berserk' ),
							'param_name' => 'split_title',
							'type'       => 'brs_switch',
							'value'      => 'n',
							'options'    => array(
								'Yes' => 'y',
								'No'  => 'n',
							),
						),

						array(
							"group"      => __( "Advanced Title Options", 'berserk' ),
							'type'       => 'param_group',
							'heading'    => __( '', 'js_composer' ),
							'param_name' => 'values',
							'value'      => urlencode( json_encode( array(
								array(
									'label'             => __( 'Buy now', 'js_composer' ),
									'label_google_font' => 'font_family:Montserrat%3Aregular%2C700|font_style:700%20bold%20regular%3A700%3Anormal',
									'lowercase'         => 'n'
								),
								array(
									'label'             => __( 'for', 'js_composer' ),
									'label_google_font' => 'font_family:Montserrat%3Aregular%2C700|font_style:400%20regular%3A400%3Anormal',
									'lowercase'         => 'y'
								),
								array(
									'label'             => __( '39$', 'js_composer' ),
									'label_google_font' => 'font_family:Montserrat%3Aregular%2C700|font_style:700%20bold%20regular%3A700%3Anormal',
									'lowercase'         => 'n'
								),

							) ) ),
							'params'     => array(
								array(
									'type'        => 'textfield',
									'heading'     => __( 'Caption', 'js_composer' ),
									'param_name'  => 'label',
									'admin_label' => true,
								),

								array(
									'type'             => 'google_fonts',
									'param_name'       => 'label_google_font',
									'value'            => 'font_family:Abril%20Fatface%3Aregular|font_style:400%20regular%3A400%3Anormal',
									'settings'         => array(
										'fields' => array(
											'font_family_description' => __( '', 'js_composer' ),
											'font_style_description'  => __( ' ', 'js_composer' ),
										),
									),
									'edit_field_class' => 'vc_col-sm-6 vc_column',
								),
								array(
									"param_name"       => "lowercase",
									"type"             => "checkbox",
									"value"            => array(
										"Use lowercase" => "y",
									),
									'heading'          => __( 'Lowercase', 'js_composer' ),
									'edit_field_class' => 'vc_col-sm-6 vc_column',
								),

							),
							'dependency' => array(
								'element' => 'split_title',
								'value'   => 'y',
							),
						),

						array(
							"group"      => __( "Icon", 'berserk' ),
							"heading"    => __( "Button Icon", 'berserk' ),
							"param_name" => "brs_title",
							"type"       => "brs_title",
						),

						array(
							'group'            => __( 'Icon', 'berserk' ),
							'heading'          => __( 'Enable Button Icon', 'berserk' ),
							'param_name'       => 'enable_icon',
							'type'             => 'brs_switch',
							'value'            => 'n',
							'options'          => array(
								'Yes' => 'y',
								'No'  => 'n',
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

						array(
							'group'            => __( 'Icon', 'berserk' ),
							"param_name"       => "icon_right",
							"type"             => "checkbox",
							"value"            => array(
								"Icon Right" => "y",
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

						array(
							'group'            => __( 'Icon', 'berserk' ),
							'type'             => 'dropdown',
							'heading'          => __( 'Icon library', 'berserk' ),
							'value'            => array(
								__( 'Font Awesome', 'berserk' ) => 'fontawesome',
								__( 'Open Iconic', 'berserk' )  => 'openiconic',
								__( 'Typicons', 'berserk' )     => 'typicons',
								__( 'Entypo', 'berserk' )       => 'entypo',
								__( 'Linecons', 'berserk' )     => 'linecons',
								__( 'Mono Social', 'berserk' )  => 'monosocial',
								__( 'Livicon', 'berserk' )      => 'livicon',
							),
							'admin_label'      => true,
							'param_name'       => 'btn_icon_type',
							'dependency'       => array(
								'element' => 'enable_icon',
								'value'   => 'y',
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),
						array(
							'group'      => __( 'Icon', 'berserk' ),
							'type'       => 'iconpicker',
							'heading'    => __( 'Icon', 'berserk' ),
							'param_name' => 'icon_fontawesome',
							'value'      => 'fa fa-adjust', // default value to backend editor admin_label
							'settings'   => array(
								'emptyIcon'    => false,
								// default true, display an "EMPTY" icon?
								'iconsPerPage' => 4000,
								// default 100, how many icons per/page to display, we use (big number) to display all icons in single page
							),
							'dependency' => array(
								'element' => 'btn_icon_type',
								'value'   => 'fontawesome',
							),
						),
						array(
							'group'      => __( 'Icon', 'berserk' ),
							'type'       => 'iconpicker',
							'heading'    => __( 'Icon', 'berserk' ),
							'param_name' => 'icon_openiconic',
							'value'      => 'vc-oi vc-oi-dial', // default value to backend editor admin_label
							'settings'   => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'openiconic',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency' => array(
								'element' => 'btn_icon_type',
								'value'   => 'openiconic',
							),
						),
						array(
							'group'      => __( 'Icon', 'berserk' ),
							'type'       => 'iconpicker',
							'heading'    => __( 'Icon', 'berserk' ),
							'param_name' => 'icon_typicons',
							'value'      => 'typcn typcn-adjust-brightness',
							// default value to backend editor admin_label
							'settings'   => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'typicons',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency' => array(
								'element' => 'btn_icon_type',
								'value'   => 'typicons',
							),
						),
						array(
							'group'      => __( 'Icon', 'berserk' ),
							'type'       => 'iconpicker',
							'heading'    => __( 'Icon', 'berserk' ),
							'param_name' => 'icon_entypo',
							'value'      => 'entypo-icon entypo-icon-note',
							// default value to backend editor admin_label
							'settings'   => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'entypo',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency' => array(
								'element' => 'btn_icon_type',
								'value'   => 'entypo',
							),
						),
						array(
							'group'      => __( 'Icon', 'berserk' ),
							'type'       => 'iconpicker',
							'heading'    => __( 'Icon', 'berserk' ),
							'param_name' => 'icon_linecons',
							'value'      => 'vc_li vc_li-heart', // default value to backend editor admin_label
							'settings'   => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'linecons',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency' => array(
								'element' => 'btn_icon_type',
								'value'   => 'linecons',
							),
						),
						array(
							'group'      => __( 'Icon', 'berserk' ),
							'type'       => 'iconpicker',
							'heading'    => __( 'Icon', 'berserk' ),
							'param_name' => 'icon_monosocial',
							'value'      => 'vc-mono vc-mono-fivehundredpx',
							// default value to backend editor admin_label
							'settings'   => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'monosocial',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency' => array(
								'element' => 'btn_icon_type',
								'value'   => 'monosocial',
							),
						),

						array(
							'group'       => __( 'Icon', 'berserk' ),
							"type"        => "textarea_html",
							"holder"      => "div",
							"class"       => "",
							"param_name"  => "content",
							"value"       => __( "", 'berserk' ),
							"description" => "",
							'dependency'  => array(
								'element' => 'btn_icon_type',
								'value'   => 'livicon',
							),
						),

						array(
							"group"      => __( "Icon", 'berserk' ),
							"heading"    => __( "Button Background Icon", 'berserk' ),
							"param_name" => "brs_title",
							"type"       => "brs_title",
						),

						array(
							'group'            => __( 'Icon', 'berserk' ),
							'heading'          => __( 'Enable Button Background Icon', 'berserk' ),
							'param_name'       => 'enable_bg_icon',
							'type'             => 'brs_switch',
							'value'            => 'n',
							'options'          => array(
								'Yes' => 'y',
								'No'  => 'n',
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column',

						),
						array(
							'group'            => __( 'Icon', 'berserk' ),
							'type'             => 'dropdown',
							'heading'          => __( 'Icon library', 'berserk' ),
							'value'            => array(
								__( 'Font Awesome', 'berserk' ) => 'fontawesome',
								__( 'Open Iconic', 'berserk' )  => 'openiconic',
								__( 'Typicons', 'berserk' )     => 'typicons',
								__( 'Entypo', 'berserk' )       => 'entypo',
								__( 'Linecons', 'berserk' )     => 'linecons',
								__( 'Mono Social', 'berserk' )  => 'monosocial',
							),
							'admin_label'      => true,
							'param_name'       => 'bg_icon_type',
							'description'      => __( 'Select icon library.', 'berserk' ),
							'dependency'       => array(
								'element' => 'enable_bg_icon',
								'value'   => 'y',
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),
						array(
							'group'       => __( 'Icon', 'berserk' ),
							'type'        => 'iconpicker',
							'heading'     => __( 'Background Icon', 'berserk' ),
							'param_name'  => 'bg_icon_fontawesome',
							'value'       => 'fa fa-adjust', // default value to backend editor admin_label
							'settings'    => array(
								'emptyIcon'    => false,
								// default true, display an "EMPTY" icon?
								'iconsPerPage' => 4000,
								// default 100, how many icons per/page to display, we use (big number) to display all icons in single page
							),
							'dependency'  => array(
								'element' => 'bg_icon_type',
								'value'   => 'fontawesome',
							),
							'description' => __( 'Select icon from library.', 'berserk' ),
						),
						array(
							'group'       => __( 'Icon', 'berserk' ),
							'type'        => 'iconpicker',
							'heading'     => __( 'Background Icon', 'berserk' ),
							'param_name'  => 'bg_icon_openiconic',
							'value'       => 'vc-oi vc-oi-dial', // default value to backend editor admin_label
							'settings'    => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'openiconic',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency'  => array(
								'element' => 'bg_icon_type',
								'value'   => 'openiconic',
							),
							'description' => __( 'Select icon from library.', 'berserk' ),
						),
						array(
							'group'       => __( 'Icon', 'berserk' ),
							'type'        => 'iconpicker',
							'heading'     => __( 'Background Icon', 'berserk' ),
							'param_name'  => 'bg_icon_typicons',
							'value'       => 'typcn typcn-adjust-brightness',
							// default value to backend editor admin_label
							'settings'    => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'typicons',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency'  => array(
								'element' => 'bg_icon_type',
								'value'   => 'typicons',
							),
							'description' => __( 'Select icon from library.', 'berserk' ),
						),
						array(
							'group'      => __( 'Icon', 'berserk' ),
							'type'       => 'iconpicker',
							'heading'    => __( 'Background Icon', 'berserk' ),
							'param_name' => 'bg_icon_entypo',
							'value'      => 'entypo-icon entypo-icon-note',
							// default value to backend editor admin_label
							'settings'   => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'entypo',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency' => array(
								'element' => 'bg_icon_type',
								'value'   => 'entypo',
							),
						),
						array(
							'group'       => __( 'Icon', 'berserk' ),
							'type'        => 'iconpicker',
							'heading'     => __( 'Background Icon', 'berserk' ),
							'param_name'  => 'bg_icon_linecons',
							'value'       => 'vc_li vc_li-heart', // default value to backend editor admin_label
							'settings'    => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'linecons',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency'  => array(
								'element' => 'bg_icon_type',
								'value'   => 'linecons',
							),
							'description' => __( 'Select icon from library.', 'berserk' ),
						),
						array(
							'group'       => __( 'Icon', 'berserk' ),
							'type'        => 'iconpicker',
							'heading'     => __( 'Background Icon', 'berserk' ),
							'param_name'  => 'bg_icon_monosocial',
							'value'       => 'vc-mono vc-mono-fivehundredpx',
							// default value to backend editor admin_label
							'settings'    => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'monosocial',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency'  => array(
								'element' => 'bg_icon_type',
								'value'   => 'monosocial',
							),
							'description' => __( 'Select icon from library.', 'berserk' ),
						),

						array(
							'group'      => __( 'Adaptive Paddings', 'berserk' ),
							"heading"    => __( "Adaptive Paddings", 'bersek' ),
							"param_name" => "brs_adaptive_paddings_img",
							"type"       => "brs_images",
							"images"     => array(
								'desktop'          => 'desktop.png',
								'tablet'           => 'tablet.png',
								'tablet_landscape' => 'tablet_landscape.png',
								'mobile'           => 'mobile.png',
								'mobile_landscape' => 'mobile_landscape.png',
							),
							'images_dim' => array(
								'w' => '109',
								'h' => '60'
							)
						),

						array(
							"group"      => __( "Adaptive Paddings", 'berserk' ),
							"heading"    => __( "Margin Top", 'berserk' ),
							"param_name" => "brs_title",
							"type"       => "brs_title",
						),

						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "desktop_margin_top",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "tablet_margin_top",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "tablet_landscape_margin_top",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "mobile_margin_top",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "mobile_landscape_margin_top",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),

						array(
							"group"      => __( "Adaptive Paddings", 'berserk' ),
							"heading"    => __( "Margin Bottom", 'berserk' ),
							"param_name" => "brs_title",
							"type"       => "brs_title",
						),

						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "desktop_margin_bottom",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "tablet_margin_bottom",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "tablet_landscape_margin_bottom",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "mobile_margin_bottom",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "mobile_landscape_margin_bottom",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),

						array(
							"group"      => __( "Adaptive Paddings", 'berserk' ),
							"heading"    => __( "Margin Right", 'berserk' ),
							"param_name" => "brs_title",
							"type"       => "brs_title",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "desktop_margin_right",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "tablet_margin_right",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "tablet_landscape_margin_right",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "mobile_margin_right",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "mobile_landscape_margin_right",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),

						array(
							"group"      => __( "Adaptive Paddings", 'berserk' ),
							"heading"    => __( "Margin Left", 'berserk' ),
							"param_name" => "brs_title",
							"type"       => "brs_title",
						),

						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "desktop_margin_left",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "tablet_margin_left",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "tablet_landscape_margin_left",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "mobile_margin_left",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "mobile_landscape_margin_left",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),

						array(
							"group"      => __( "Adaptive Paddings", 'berserk' ),
							"heading"    => __( "Padding Top", 'berserk' ),
							"param_name" => "brs_title",
							"type"       => "brs_title",
						),

						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "desktop_padding_top",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "tablet_padding_top",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "tablet_landscape_padding_top",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "mobile_padding_top",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "mobile_landscape_padding_top",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),

						array(
							"group"      => __( "Adaptive Paddings", 'berserk' ),
							"heading"    => __( "Padding Bottom", 'berserk' ),
							"param_name" => "brs_title",
							"type"       => "brs_title",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "desktop_padding_bottom",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "tablet_padding_bottom",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "tablet_landscape_padding_bottom",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "mobile_padding_bottom",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "mobile_landscape_padding_bottom",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),

						array(
							"group"      => __( "Adaptive Paddings", 'berserk' ),
							"heading"    => __( "Padding Right", 'berserk' ),
							"param_name" => "brs_title",
							"type"       => "brs_title",
						),

						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "desktop_padding_right",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "tablet_padding_right",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "tablet_landscape_padding_right",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "mobile_padding_right",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "mobile_landscape_padding_right",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),

						array(
							"group"      => __( "Adaptive Paddings", 'berserk' ),
							"heading"    => __( "Padding Left", 'berserk' ),
							"param_name" => "brs_title",
							"type"       => "brs_title",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "desktop_padding_left",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "tablet_padding_left",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "tablet_landscape_padding_left",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "mobile_padding_left",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),
						array(
							"group"            => __( "Adaptive Paddings", 'berserk' ),
							"param_name"       => "mobile_landscape_padding_left",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_paddings_value(),
							"edit_field_class" => "vc_col-sm-2 vc_column paddings_column",
						),


					),
				) );
			}
		}

		public function shortcode( $atts, $content = null ) {

			$libraries = array( 'component__button' );
			brs_add_libraries( $libraries );

			// setup button id
			$this->shortcode_id ++;
			$this->button_id = esc_attr( 'brs-btn-' . $this->shortcode_id );

			// sanitize attributes
			$this->atts = $this->sanitize_attributes( $atts );

			// store content
			$this->content = trim( preg_replace( '/<\/?p\>/', '', $content ) );

			// return html
			return $this->get_html();
		}

		protected function sanitize_attributes( &$atts ) {

			$dropdown_values = array(
				array(
					'label' => __( 'First', 'js_composer' ),
					'url'   => '#',
				),
				array(
					'label' => __( 'Second', 'js_composer' ),
					'url'   => '#',
				),
				array(
					'label' => __( 'Third', 'js_composer' ),
					'url'   => '#',
				),
			);

			$attributes = shortcode_atts( array(
				'caption_on_hover'       => 'n',
				'hover_caption'          => '',
				'caption'                => '',
				'mh_0'                   => 'n',
				'type'                   => 'default',
				'size'                   => 'btn_s',
				'style'                  => 'solid',
				'delimiter'              => 'solid',
				'delimiter_color'        => '#2775FF',
				'delimiter_color_first'  => '#0dbeff',
				'delimiter_color_second' => '#2775FF',
				'brs_type'               => 'default_br_5',
				'dropdown_items'         => '',
				'dropdown_opened'        => 'c',
				'drop_color_scheme'      => 'dark',
				'enable_delimiter'       => 'n',
				'font'                   => '',
				'google_fonts'           => 'font_family:Open%20Sans%3A300%2C300italic%2Cregular%2Citalic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic|font_style:700%20bold%20regular%3A700%3Anormalf',
				'url'                    => '',
				'link'                   => '',
				'target_blank'           => '',
				'font_size'              => '',
				'brs_letter_spacing'     => '',

				'dropdown_values' => urlencode( json_encode( $dropdown_values ) ),

				'values'        => '',
				'split_title'   => 'n',
				'splited_title' => '',
				'google_font_1' => '',
				'google_font_2' => '',
				'google_font_3' => '',

				'enable_icon'      => 'n',
				'icon_monosocial'  => '',
				'icon_linecons'    => '',
				'icon_entypo'      => '',
				'icon_typicons'    => '',
				'icon_openiconic'  => '',
				'icon_fontawesome' => '',
				'icon_livicon'     => '',

				'enable_bg_icon'      => 'n',
				'icon_right'          => '',
				'bg_icon_monosocial'  => '',
				'bg_icon_linecons'    => '',
				'bg_icon_entypo'      => '',
				'bg_icon_typicons'    => '',
				'bg_icon_openiconic'  => '',
				'bg_icon_fontawesome' => '',

				'button_alignment'         => 'none',

				//'bg_color'          => '#888888',
				'custom_background'        => '#2775FF',
				'enable_custom_text_color' => 'n',
				'text_color'               => '#2775FF',
				'bg_color_g_1'             => '#15BDFF',
				'bg_color_g_2'             => '#00F6FF',
				'bg_color_g_3'             => '#2775ff',
				'bg_color_g_4'             => '#7202bb',

				'round_circled'    => '',
				'default_gradient' => 'btn-backgrounds_white',

				'el_class'      => '',
				'btn_icon_type' => '',
				'enable_font'   => '',

				'button_violet'            => '',
				'button_white_transparent' => ''
			), $atts );

			$attributes['type'] = sanitize_key( $attributes['type'] );
			$attributes['size'] = sanitize_key( $attributes['size'] );

			//$attributes['icon_align']       = sanitize_key( $attributes['icon_align'] );
			$attributes['button_alignment'] = sanitize_key( $attributes['button_alignment'] );

			$this->color_atts = array(
				'bg_color_style'         => 'bg_color',
				'bg_hover_color_style'   => 'bg_hover_color',
				'text_color_style'       => 'text_color',
				'text_hover_color_style' => 'text_hover_color',
			);


			$url      = ( $attributes['url'] == '||' ) ? '' : $attributes['url'];
			$url      = vc_build_link( $url );
			$link_url = $url['url'];
			$a_title  = ( $url['title'] == '' ) ? '' : $url['title'];
			$a_target = ( $url['target'] == '' ) ? '' : 'target="' . $url['target'] . '"';

			$attributes['link']         = $link_url ? $link_url : '#';
			$attributes['target_blank'] = $a_target;
			//$attributes['smooth_scroll'] = apply_filters( 'brs_sanitize_flag', $attributes['smooth_scroll'] );
			$attributes['el_class'] = esc_attr( $attributes['el_class'] );

			return $attributes;
		}

		protected function get_html() {

			// get button html
			$button_html = brs_get_button_html( array(
				'before_title'      => $this->get_before_title( $this->atts ),
				'after_title'       => $this->get_after_title( $this->atts ),
				'href'              => $this->atts['link'],
				'title'             => $this->atts['caption'],
				'caption_on_hover'  => $this->atts['caption_on_hover'],
				'hover_caption'     => $this->atts['hover_caption'],
				'target'            => $this->atts['target_blank'],
				'class'             => $this->get_btn_class(),
				'brs_type'          => $this->atts['brs_type'],
				'dropdown_items'    => $this->atts['dropdown_items'],
				'dropdown_opened'   => $this->atts['dropdown_opened'],
				'drop_color_scheme' => $this->atts['drop_color_scheme'],
				'atts'              => ' id="' . $this->get_button_id() . '"',
				'enable_icon'       => $this->atts['enable_icon'],
				'btn_icon'          => $this->get_icon_class(),
				'icon_type'         => $this->get_icon_type(),
				'enable_bg_icon'    => $this->atts['enable_bg_icon'],
				'btn_bg_icon'       => $this->get_bg_icon_class(),
				'bg_icon_type'      => $this->get_bg_icon_type(),
				'style'             => $this->get_style( $this->atts ),
				'brs_style'         => $this->atts['style'],
				'content_icon'      => $this->content,
				//'style_1'           => $this->get_font_style( $this->atts['google_font_1'] ),
				//'style_2'           => $this->get_font_style( $this->atts['google_font_2'] ),
				//'style_3'           => $this->get_font_style( $this->atts['google_font_3'] ),
				'split_title'       => $this->atts['split_title'],
				'values'            => $this->atts['values'],
				'splited_title'     => $this->atts['splited_title'],
				'dropdown_values'   => $this->atts['dropdown_values'],

			) );

			// alignment
			if ( 'center' == $this->atts['button_alignment'] ) {
				$button_html = '<div class="text-center">' . $button_html . '</div>';
			}

			// delimiter
			if ( $this->atts['enable_delimiter'] == 'y' ) {
				$button_html = '<div class="delimiter-box ' . $this->get_delimiter_class() . '"><span class="before" style="' . $this->get_delimiter_style() . '"></span>' . $button_html . '</div>';
			}

			// get inline styleseet tag
			//$output = $this->get_inline_style_tag();
			$output = $button_html;

			return $output;
		}

		protected function get_before_title( $atts ) {
			$style         = $atts['style'];
			$bg_gradient_1 = $atts['bg_color_g_1'];
			$bg_gradient_2 = $atts['bg_color_g_2'];
			$bg_gradient_3 = $atts['bg_color_g_3'];
			$bg_gradient_4 = $atts['bg_color_g_4'];
			$bg_color      = $atts['custom_background'];
			$text_color    = $atts['text_color'];
			$icon_right    = $atts['icon_right'];
			$before_title  = '';

			$btn_icon    = $this->get_icon_class();
			$btn_bg_icon = $this->get_bg_icon_class();

			switch ( $style ) {

				case "solid":
				case "gradient":
				case "solid_dark":
				case "gradient_wave":
				case "light_border_shadow":
					//case "simple_gradient":


					if ( $atts['enable_icon'] == 'y' && ! empty( $btn_icon ) ) {

						if ( $atts['icon_right'] == 'y' ) {
							$btn_icon .= ' icon-left';
						}

						if ( $style == 'solid' ) {
							$btn_icon = str_replace( ' icon-left', '', $btn_icon );
							if ( $icon_right == 'y' ) {
								$btn_icon = str_replace( 'icon-inside ', '', $btn_icon );
							}
						}

						$before_i  = '';
						$after_i   = '';
						$b_a_style = 'background-color:' . $bg_color . ';';
						if ( $atts['brs_type'] == 'round' ) {
							$before_i = '<span style="' . $b_a_style . '" class="before"></span>';
							$after_i  = '<span style="' . $b_a_style . '" class="after"></span>';
						}
						$before_title = $before_i . '<i class="' . $btn_icon . '" aria-hidden="true"></i>' . $after_i;
					}
					if ( $atts['enable_bg_icon'] == 'y' && ! empty( $btn_bg_icon ) ) {
						$before_title = '<i class="' . $btn_bg_icon . '" aria-hidden="true"></i>';
					}

					if ( $atts['enable_icon'] == 'y' && $atts['btn_icon_type'] == 'livicon' ) {
						$before_title .= do_shortcode( $this->content );
					}

					//if ( $atts['caption_on_hover'] == 'y' && ! empty( $atts['hover_caption'] ) ) {

					$before_style = '';
					if ( $style == 'solid' ) {
						$before_style = 'background: ' . $bg_color . ';';

						if ( $atts['enable_custom_text_color'] == 'y' ) {
							$before_style .= ' color: ' . $text_color . ';';
						}

					}

					if ( $style == 'solid' || $style == 'light_border_shadow' ) {
						$before_title .= '<span style="' . $before_style . '" class="before">' . $atts['caption'] . '</span>';
					}

					//}

					break;

				case "border":
					$before_style = 'background: ' . $bg_color . ';';

					$before_title = '<span style="' . $before_style . '" class="before"></span>';
					if ( $atts['enable_icon'] == 'y' && ! empty( $btn_icon ) ) {
						if ( $atts['icon_right'] == 'y' ) {
							$btn_icon .= ' icon-left';
						}
						$before_title .= '<i class="' . $btn_icon . '" aria-hidden="true"></i>';
					}
					if ( $atts['enable_bg_icon'] == 'y' && ! empty( $btn_bg_icon ) ) {
						$before_title .= '<i class="' . $btn_bg_icon . '" aria-hidden="true"></i>';
					}
					if ( $atts['enable_icon'] == 'y' && $atts['btn_icon_type'] == 'livicon' ) {
						$before_title .= do_shortcode( $this->content );
					}

					break;

				case "double":
					$before_style     = 'border-color: transparent transparent transparent ' . $bg_color . ';';
					$border_btn_style = 'border: 2px solid ' . $bg_color . ';';
					$span_style       = 'border: 1px solid ' . $bg_color . ';';
					$before_title     = '<div style="' . $before_style . '" class="before"></div><span style="' . $border_btn_style . '" class="border-btn"></span><span style="' . $span_style . '"></span>';
					if ( $atts['enable_icon'] == 'y' && ! empty( $btn_icon ) ) {
						if ( $atts['icon_right'] == 'y' ) {
							$btn_icon .= ' icon-left';
						}
						$before_title .= '<i class="' . $btn_icon . '" aria-hidden="true"></i>';
					}
					if ( $atts['enable_bg_icon'] == 'y' && ! empty( $btn_bg_icon ) ) {
						$before_title .= '<i class="' . $btn_bg_icon . '" aria-hidden="true"></i>';
					}
					if ( $atts['enable_icon'] == 'y' && $atts['btn_icon_type'] == 'livicon' ) {
						$before_title .= do_shortcode( $this->content );
					}
					break;

				case "border_gradient":
					$before_style = 'background: -webkit-gradient( linear, left top, right top, from(' . $bg_color . '), color-stop(' . $bg_gradient_3 . '), to(' . $bg_gradient_4 . ')); ';
					$before_style .= 'background: -webkit-linear-gradient( left, ' . $bg_color . ', ' . $bg_gradient_3 . ', ' . $bg_gradient_4 . '); ';
					$before_style .= 'background: -o-linear-gradient( left, ' . $bg_color . ', ' . $bg_gradient_3 . ', ' . $bg_gradient_4 . '); ';
					$before_style .= 'background: linear-gradient( to right, ' . $bg_color . ', ' . $bg_gradient_3 . ', ' . $bg_gradient_4 . '); ';

					$before_title_i = '';
					if ( $atts['enable_bg_icon'] == 'y' && ! empty( $btn_bg_icon ) ) {
						$before_title_i = '<i class="' . $btn_bg_icon . '" aria-hidden="true"></i>';
					}
					$before_title = '<div style="' . $before_style . '" class="before"></div><span class="bg"></span>' . $before_title_i . '<span>';
					if ( $atts['enable_icon'] == 'y' && ! empty( $btn_icon ) ) {
						if ( $atts['icon_right'] == 'y' ) {
							$btn_icon .= ' icon-left';
						}
						$before_title .= '<i class="' . $btn_icon . '" aria-hidden="true"></i>';
					}
					if ( $atts['enable_icon'] == 'y' && $atts['btn_icon_type'] == 'livicon' ) {
						$before_title .= do_shortcode( $this->content );
					}

					break;
				case "border_progress":
					$left_br_style        = 'background-color: ' . $bg_color . ';';
					$top_line_style       = 'background-color: ' . $bg_color . ';';
					$b_style              = 'background: ' . $bg_color . ';';
					$btn_text_color       = 'color:' . $bg_color . ';';
					$style_top_line_after = '-webkit-box-shadow: 1px 1px 3px ' . $bg_color . ', -1px -1px 3px ' . $bg_color . ', -1px 1px 3px ' . $bg_color . ', 1px -1px 3px ' . $bg_color . ';';
					$style_top_line_after .= 'box-shadow: 1px 1px 3px ' . $bg_color . ', -1px -1px 3px ' . $bg_color . ', -1px 1px 3px ' . $bg_color . ', 1px -1px 3px ' . $bg_color . ';';

					$before_title = '<span style="' . $left_br_style . '" class="left-border"></span><span style="' . $top_line_style . '" class="top-line"><span style="' . $style_top_line_after . '" class="after"></span></span>
					<span style="' . $btn_text_color . '" class="btn-text"><span style="' . $b_style . '" class="before"></span>';
					if ( $atts['enable_icon'] == 'y' && ! empty( $btn_icon ) ) {
						if ( $atts['icon_right'] == 'y' ) {
							$btn_icon .= ' icon-left';
						}
						$before_title .= '<i class="' . $btn_icon . '" aria-hidden="true"></i>';
					}
					if ( $atts['enable_bg_icon'] == 'y' && ! empty( $btn_bg_icon ) ) {
						$before_title .= '<i class="' . $btn_bg_icon . '" aria-hidden="true"></i>';
					}
					if ( $atts['enable_icon'] == 'y' && $atts['btn_icon_type'] == 'livicon' ) {
						$before_title .= do_shortcode( $this->content );
					}
					break;
				case "double_background":
					$before_style = 'background: -webkit-gradient(linear, left top, right top, from(rgba(' . brs_hex2rgb( $bg_gradient_1 ) . ', 0.82)), to(rgba(' . brs_hex2rgb( $bg_gradient_2 ) . ', 0.82)));';
					$before_style .= 'background: -webkit-linear-gradient(left, rgba(' . brs_hex2rgb( $bg_gradient_1 ) . ', 0.82), rgba(' . brs_hex2rgb( $bg_gradient_2 ) . ', 0.82));';
					$before_style .= 'background: -o-linear-gradient(left, rgba(' . brs_hex2rgb( $bg_gradient_1 ) . ', 0.82), rgba(' . brs_hex2rgb( $bg_gradient_2 ) . ', 0.82));';
					$before_style .= 'background: linear-gradient(to right, rgba(' . brs_hex2rgb( $bg_gradient_1 ) . ', 0.82), rgba(' . brs_hex2rgb( $bg_gradient_2 ) . ', 0.82));';
					$before_title = '<span style="' . $before_style . '" class="before"></span><span>';
					if ( $atts['enable_icon'] == 'y' && ! empty( $btn_icon ) ) {
						if ( $atts['icon_right'] == 'y' ) {
							$btn_icon .= ' icon-left';
						}
						$before_title .= '<i class="' . $btn_icon . '" aria-hidden="true"></i>';
					}
					if ( $atts['enable_bg_icon'] == 'y' && ! empty( $btn_bg_icon ) ) {
						$before_title .= '<i class="' . $btn_bg_icon . '" aria-hidden="true"></i>';
					}
					if ( $atts['enable_icon'] == 'y' && $atts['btn_icon_type'] == 'livicon' ) {
						$before_title .= do_shortcode( $this->content );
					}
					break;

				default:
					$before_title = '<span class="before"></span>';
					break;
			}

			return $before_title;
		}

		protected function get_after_title( $atts ) {
			$style         = $atts['style'];
			$bg_gradient_3 = $atts['bg_color_g_3'];
			$bg_gradient_2 = $atts['bg_color_g_2'];
			$bg_gradient_4 = $atts['bg_color_g_4'];
			$bg_color      = $atts['custom_background'];
			$text_color    = $atts['text_color'];
			$after_title   = '';
			$btn_icon      = $this->get_icon_class();
			switch ( $style ) {
				case "simple_gradient":

					if ( $atts['enable_icon'] == 'y' && ! empty( $btn_icon ) ) {

						$after_title = '<span class="before"><i class="' . $btn_icon . '" aria-hidden="true"></i></span>';

					}

					break;
				case "solid":
				case "light_border_shadow":
					//if ( $atts['caption_on_hover'] == 'y' && ! empty( $atts['hover_caption'] ) ) {
					$after_style = '';
					if ( $style == 'solid' ) {
						$after_style = 'background: ' . $bg_color . ';';
						if ( $atts['enable_custom_text_color'] == 'y' ) {
							$after_style .= ' color: ' . $text_color . ';';
						}
					}
					$after_title = '<span style="' . $after_style . '" class="after">' . $atts['caption'] . '</span>';
					//}
					break;
				case "border":
					$border_btn_style = ( $atts['button_white_transparent'] != 'y' ) ? 'border: 2px solid ' . $bg_color . ';' : '';
					$after_style      = 'background: ' . $bg_color . ';';
					$after_title      = '<span style="' . $after_style . '" class="after"></span><span style="' . $border_btn_style . '" class="border-btn"></span>';
					break;
				case "gradient":
					$after_style = 'background: -webkit-gradient(linear, right top, left top, from(' . $bg_gradient_4 . '), to(' . $bg_gradient_2 . '))';
					$after_style .= 'background: -webkit-linear-gradient(right, ' . $bg_gradient_4 . ', ' . $bg_gradient_2 . ');';
					$after_style .= 'background: -o-linear-gradient(right, ' . $bg_gradient_4 . ', ' . $bg_gradient_2 . ');';
					$after_style .= 'background: linear-gradient(to left, ' . $bg_gradient_4 . ', ' . $bg_gradient_2 . ');';
					$after_title = '<span style="' . $after_style . '" class="after"></span>';
					break;
				case "double":
					$after_style = ' border-color: transparent ' . $bg_color . ' transparent transparent;';
					$after_title = '<div style="' . $after_style . '" class="after"></div>';
					break;
				case "border_gradient":
				case "border_progress":
					$after_title = '</span>';
					break;
				case "double_background":
					$after_style = 'background: -webkit-gradient(linear, left top, right top, from(' . $bg_gradient_3 . '), to(' . $bg_gradient_4 . '));';
					$after_style .= 'background: -webkit-linear-gradient(left, ' . $bg_gradient_3 . ', ' . $bg_gradient_4 . ');';
					$after_style .= 'background: -o-linear-gradient(left, ' . $bg_gradient_3 . ', ' . $bg_gradient_4 . ');';
					$after_style .= 'background: linear-gradient(to right, ' . $bg_gradient_3 . ', ' . $bg_gradient_4 . ');';
					$after_title = '</span><span style="' . $after_style . '" class="after"></span>';
					break;
				case "solid_dark":
					$after_style = 'background-color: ' . $bg_color . ';';
					$after_title = '<span style="' . $after_style . '" class="after"></span>';
					break;

				default:
					$after_title = '<span class="after"></span>';
					break;
			}

			return $after_title;
		}

		public function get_style( $atts ) {
			$google_fonts = $atts['google_fonts'];

			//echo 'google_fonts='.$google_fonts;

			$bg_color      = $atts['custom_background'];
			$bg_gradient_1 = $atts['bg_color_g_1'];
			$bg_gradient_2 = $atts['bg_color_g_2'];
			$bg_gradient_3 = $atts['bg_color_g_3'];
			$bg_gradient_4 = $atts['bg_color_g_4'];
			$style         = $atts['style'];

			$style_sting = '';

			if ( $atts['enable_font'] == 'y' ) {
				$fonts_style = $this->get_font_style( $google_fonts );

				if ( ! empty( $fonts_style ) ) {
					$style_sting .= $fonts_style . ";";
				}
			}

			if ( $atts['font_size'] ) {
				$style_sting .= 'font-size: ' . $atts['font_size'] . 'px; ';
			}
			if ( $atts['text_color'] && $atts['enable_custom_text_color'] == 'y' ) {
				$style_sting .= 'color: ' . $atts['text_color'] . '; ';
			}

			if ( $atts['brs_type'] != 'dropdown' ) {
				switch ( $style ) {

					case "border":
						//$style_sting .= 'color:' . $bg_color . ';';
						break;

					case "double":
						if ( ! empty( $bg_color ) ) {
							$style_sting .= '-webkit-box-shadow: 0px 5px 21px rgba(' . brs_hex2rgb( $bg_color ) . ', 0.3);';
							$style_sting .= ' box-shadow: 0px 5px 21px rgba(' . brs_hex2rgb( $bg_color ) . ', 0.3);';
							$style_sting .= ' color:' . $bg_color . ';';
						}
						break;

					case "gradient":
						if ( ! empty( $bg_gradient_3 ) && ! empty( $bg_gradient_1 ) ) {
							$style_sting .= '; background: -webkit-gradient(linear, right top, left top, from(' . $bg_gradient_3 . '), to(' . $bg_gradient_1 . '));';
							$style_sting .= '; background: -webkit-linear-gradient(right, ' . $bg_gradient_3 . ', ' . $bg_gradient_1 . ');';
							$style_sting .= '; background: -o-linear-gradient(right, ' . $bg_gradient_3 . ', ' . $bg_gradient_1 . ');';
							$style_sting .= '; background: linear-gradient(to left, ' . $bg_gradient_3 . ', ' . $bg_gradient_1 . ');';
						}
						break;
					case "border_progress":
						if ( ! empty( $bg_color ) ) {
							$style_sting .= 'background-color: rgba(' . brs_hex2rgb( $bg_color ) . ', 0.3);';
							$style_sting .= '-webkit-box-shadow: 0px 5px 21px rgba(' . brs_hex2rgb( $bg_color ) . ', 0.3);';
							$style_sting .= 'box-shadow: 0px 5px 21px rgba(' . brs_hex2rgb( $bg_color ) . ', 0.3);';
						}
						break;
					case "gradient_wave":

						if ( ! empty( $bg_gradient_3 ) && ! empty( $bg_gradient_4 ) ) {
							$style_sting .= 'background: -webkit-linear-gradient(45deg, ' . $bg_gradient_3 . ' 0%, ' . $bg_gradient_4 . ' 100%);';
							$style_sting .= 'background: -o-linear-gradient(45deg, ' . $bg_gradient_3 . ' 0%, ' . $bg_gradient_4 . ' 100%);';
							$style_sting .= 'background: linear - gradient( 45deg, ' . $bg_gradient_3 . ' 0%, ' . $bg_gradient_4 . ' 100%);';
						}

						break;

				}
			}

			if ( $atts['brs_type'] == 'round' ) {
				$style_sting = 'background:' . $bg_color . ';';
			}

			return $style_sting;
		}

		public static function get_font_style( $google_fonts ) {
			$style = '';
			if ( ! empty( $google_fonts ) ) {
				$fontsData         = $google_fonts;
				$googleFontsStyles = self::googleFontsStyles( $fontsData );
				$font_family       = explode( ':', $googleFontsStyles[0] );
				$font_family_e     = explode( ' ', $font_family[1] );
				$font_family_count = count( $font_family_e );

				if ( $font_family_count > 1 ) {
					$googleFontsStyles[0] = 'font-family:"' . implode( " ", $font_family_e ) . '"';
				}

				$style = esc_attr( implode( ';', $googleFontsStyles ) );
			}

			return $style;
		}

		protected function getFontsData( $atts, $paramName ) {
			$googleFontsParam = new Vc_Google_Fonts();
			$field            = WPBMap::getParam( $this->shortcode, $paramName );
			$fieldSettings    = isset( $field['settings'], $field['settings']['fields'] ) ? $field['settings']['fields'] : array();
			$fontsData        = strlen( $atts[ $paramName ] ) > 0 ? $googleFontsParam->_vc_google_fonts_parse_attributes( $fieldSettings, $atts[ $paramName ] ) : '';

			return $fontsData;
		}

		protected static function googleFontsStyles( $fontsData ) {
			// Inline styles
			$fontFamily = BRS_Font::_vc_google_fonts_parse_attributes( '', $fontsData );
			$fontStyles = explode( ':', $fontFamily['values']['font_style'] );
			$fontFamily = explode( ':', $fontFamily['values']['font_family'] );
			$styles[]   = 'font-family:' . $fontFamily[0];
			$styles[]   = 'font-weight:' . $fontStyles[1];
			$styles[]   = 'font-style:' . $fontStyles[2];

			return $styles;
		}

		protected function enqueueGoogleFonts( $fontsData ) {
			// Get extra subsets for settings (latin/cyrillic/etc)
			$settings = get_option( 'wpb_js_google_fonts_subsets' );
			if ( is_array( $settings ) && ! empty( $settings ) ) {
				$subsets = '&subset=' . implode( ',', $settings );
			} else {
				$subsets = '';
			}
			// We also need to enqueue font from googleapis
			if ( isset( $fontsData['values']['font_family'] ) ) {
				wp_enqueue_style( 'vc_google_fonts_' . vc_build_safe_css_class( $fontsData['values']['font_family'] ), '//fonts.googleapis.com/css?family=' . $fontsData['values']['font_family'] . $subsets );
			}
		}

		protected function get_icon( $icon_type ) {
			if ( 'html' == $icon_type ) {
				return $this->atts['icon'];
			}

			$icon_class = $this->atts["icon_{$icon_type}"];
			if ( $icon_class ) {
				return '<i class="' . esc_attr( $icon_class ) . '"></i>';
			}

			return '';
		}

		protected function get_btn_class() {

			// static classes
			$classes  = array();
			$size     = array();
			$gradient = array();

			if ( $this->atts['style'] !== 'simple_gradient' ) {
				$classes[] = 'btn';
			}

			if ( $this->atts['style'] == 'light_border_shadow' && $this->atts['button_violet'] == 'y' ) {
				$classes[] = 'btn-violet';
			}

			if ( $this->atts['style'] == 'border' && $this->atts['button_white_transparent'] == 'y' ) {
				$classes[] = 'btn-prime-white-transparent';
				$classes[] = 'btn-no-shadow';
				$classes[] = 'brk-white-font-color';
			}

			if ( $this->atts['icon_right'] == 'y' ) {
				$classes[] = 'btn-icon-right';
			}

			if ( $this->atts['style'] == 'simple_gradient' ) {
				$gradient = array(
					"btn-backgrounds_white"             => "btn-backgrounds_white",
					"brk-bg-grad"                       => "brk-bg-grad btn-backgrounds_dark",
					"brk-base-gradient-btn-backgrounds" => "brk-base-gradient-btn-backgrounds btn-backgrounds_dark",
					"brk-base-bg-gradient--30deg"       => "brk-base-bg-gradient--30deg btn-backgrounds_dark",
					"brk-base-bg-gradient-left-blue"    => "brk-base-bg-gradient-left-blue btn-backgrounds_dark",
					"brk-base-bg-yellow"                => "brk-base-bg-yellow btn-backgrounds_dark",
					"brk-base-bg-gradient-pink-purple"  => "brk-base-bg-gradient-pink-purple btn-backgrounds_dark",
					"brk-base-bg-gradient-15"           => "brk-base-bg-gradient-15 btn-backgrounds_dark",
					"brk-base-bg-gradient-19"           => "brk-base-bg-gradient-19 btn-backgrounds_dark",
					"brk-base-bg-gradient-16"           => "brk-base-bg-gradient-16 btn-backgrounds_dark",
					"brk-base-bg-light-dark"            => "brk-base-bg-light-dark btn-backgrounds_dark",
					"brk-base-bg-green"                 => "brk-base-bg-green btn-backgrounds_dark",
					"brk-base-bg-gradient-17"           => "brk-base-bg-gradient-17 btn-backgrounds_dark"
				);
			}

			if ( $this->atts['style'] !== 'simple_gradient' ) {
				$size = array(
					"btn_s"      => "btn-sm",
					"btn_m"      => "btn-md",
					"btn_m_1"    => "btn-md-1",
					"btn_m_2"    => "btn-md btn-min-width-200",
					"btn_l"      => "btn-lg",
					"btn_l_2"    => "btn-lg btn-min-width-200",
					"btn_xl"     => "btn-xl",
					"btn_fw"     => "btn-lg btn__full_width",
					"btn_simple" => "btn-simple"
				);
			}

			if ( $this->atts['brs_type'] == 'round' ) {
				$size = array(
					"btn_s"      => "icon__btn-sm",
					"btn_m"      => "icon__btn-md",
					"btn_l"      => "icon__btn-lg",
					"btn_xl"     => "icon__btn-xl",
					"btn_fw"     => "btn-lg btn__full_width",
					"btn_simple" => "btn-simple"
				);
			}

			$att_value_class_table = array(
				'default_gradient' => $gradient,
				'size'             => $size,
				'button_alignment' => array(
					"none"   => "",
					"left"   => "alignleft",
					"right"  => "alignright",
					"center" => "aligncenter",
				),
				'brs_type'         => array(
					'default_br_5'  => 'border-radius-5',
					'default_br_10' => 'border-radius-10',
					'round'         => 'icon__btn btn-circle',
					'oval'          => 'border-radius-25',
					'square'        => 'border-radius-0',
					'dropdown'      => 'margin-box__btn-dropdown font__weight-bold font__family-montserrat font__size-21'
				),

				'style' => array(
					'solid'               => '',
					'border'              => 'btn-prime',
					'gradient'            => 'btn-gradient',
					'double'              => 'btn-slice',
					'solid_dark'          => 'btn-pos',
					'border_gradient'     => 'btn-lightning',
					'gradient_wave'       => 'btn-gradient-wave',
					'border_progress'     => 'btn-ice',
					'double_background'   => 'btn-two-bg',
					'light_border_shadow' => 'btn-inside-out-invert btn-inside-out',
					'simple_gradient'     => 'btn-backgrounds font__family-montserrat font__weight-bold text-uppercase font__size-13 text-center'
				)

			);

			foreach ( $att_value_class_table as $att => $values ) {

				// if att from table exists - get it's value
				$value = array_key_exists( $att, $this->atts ) ? $this->atts[ $att ] : false;

				// if att value mentioned in table - add class from table
				if ( $value && array_key_exists( $value, $values ) ) {
					$classes[] = $values[ $value ];
				}
			}

			if ( $this->atts['round_circled'] == 'y' ) {
				$classes[] = 'icon__btn-circled';
			}

			if ( $this->atts['style'] == 'solid' && $this->atts['brs_type'] != 'round' ) {
				$classes[] = 'btn-inside-out';
			}

			if ( $this->atts['brs_letter_spacing'] ) {
				$classes[] = 'letter-spacing-' . $this->atts['brs_letter_spacing'];
			}

			//$classes[] = 'bsk-btn';

			// caption on hover
			/*
			if ( $this->atts['caption_on_hover'] == 'y' ) {
				$classes[] = 'btn-inside-out';
			}*/

			//echo 'brs_type=' . $this->atts['brs_type'];

			//icon
			if ( ( $this->atts['enable_icon'] == 'y' &&
			       ! empty( $this->get_icon_class() ) &&
			       $this->atts['style'] == 'solid' ||
			       $this->atts['style'] == 'light_border_shadow' ) && ( $this->atts['brs_type'] !== 'round' )
			) {
				$classes[] = 'btn-icon';
			}

			//bg icon
			if ( $this->atts['enable_bg_icon'] == 'y' && ! empty( $this->get_bg_icon_class() ) ) {
				$classes[] = 'btn-icon-abs';
			}

			if ( $this->atts['mh_0'] == 'y' && ! empty( $this->atts['mh_0'] ) ) {
				$classes[] = 'ml-0';
				$classes[] = 'mr-0';
			}

			// icon alignment
			/*
			if ( $this->atts['icon'] && 'right' == $this->atts['icon_align'] ) {
				$classes[] = 'ico-right-side';
			}*/

			// custom class
			if ( $this->atts['el_class'] ) {
				$classes[] = $this->atts['el_class'];
			}

			return presscore_esc_implode( ' ', $classes );
		}

		protected function get_delimiter_style() {
			$enable_delimiter = $this->atts['enable_delimiter'];
			$style            = "";
			if ( $enable_delimiter ) {
				$delimiter              = $this->atts['delimiter'];
				$delimiter_color        = $this->atts['delimiter_color'];
				$delimiter_color_first  = $this->atts['delimiter_color_first'];
				$delimiter_color_second = $this->atts['delimiter_color_second'];

				switch ( $delimiter ) {
					case "solid":
						$style = 'background-color:' . $delimiter_color;
						break;
					case "solid_gradient":
						$style = 'background: -webkit-gradient(linear, left top, right top, from(' . $delimiter_color_first . '), to(' . $delimiter_color_second . '));';
						$style .= 'background: -webkit-linear-gradient(left, ' . $delimiter_color_first . ', ' . $delimiter_color_second . ');';
						$style .= 'background: - o - linear - gradient( left, ' . $delimiter_color_first . ', ' . $delimiter_color_second . ');';
						$style .= 'background: linear - gradient( to right, ' . $delimiter_color_first . ', ' . $delimiter_color_second . ');';
						break;
					case "double":
						$style = 'border-top: 2px solid ' . $delimiter_color . ';';
						$style .= 'border-bottom: 2px solid ' . $delimiter_color . ';';
						break;
					case "solid_slope":
						$style = 'background-color: ' . $delimiter_color . ';';
						break;
					case "solid_shade":
						$style = 'background-color: ' . $delimiter_color . ';';
						break;
					case "doted":
						$style = 'border-top: 4px dotted ' . $delimiter_color . ';';
						break;
					case "double_colors":
						$style = 'border-top: 1px solid ' . $delimiter_color_first . ';';
						$style .= 'border-bottom: 1px solid ' . $delimiter_color_second . ';';
						break;
				}

			}

			return $style;

		}

		protected function get_delimiter_class() {

			// static classes
			$classes = array( 'btn-shortcode' );

			// base classes table
			// contains array( 'attribute' => array( 'value' => 'class' ) )
			$att_value_class_table = array(

				'delimiter' => array(
					"solid"          => 'delimiter__delimiter-solid',
					"solid_gradient" => 'delimiter__delimiter-solid-gradient',
					"double"         => 'delimiter__delimiter-double-border',
					"solid_slope"    => 'delimiter__delimiter-solid-slope',
					"solid_shade"    => 'delimiter__delimiter-solid delimiter__delimiter-solid-shade',
					"doted"          => 'delimiter__delimiter-doted',
					"double_colors"  => 'delimiter__delimiter-double-colors'
				)

			);

			foreach ( $att_value_class_table as $att => $values ) {

				// if att from table exists - get it's value
				$value = array_key_exists( $att, $this->atts ) ? $this->atts[ $att ] : false;

				// if att value mentioned in table - add class from table
				if ( $value && array_key_exists( $value, $values ) ) {
					$classes[] = $values[ $value ];
				}
			}


			return presscore_esc_implode( ' ', $classes );
		}

		protected function get_icon_type() {
			$icon_type = '';

			if ( ! empty( $this->atts['icon_fontawesome'] ) ) {
				$icon_type = 'fontawesome';
			}
			if ( ! empty( $this->atts['icon_openiconic'] ) ) {
				$icon_type = 'openiconic';
			}
			if ( ! empty( $this->atts['icon_typicons'] ) ) {
				$icon_type = 'typicons';
			}
			if ( ! empty( $this->atts['icon_entypo'] ) ) {
				$icon_type = 'entypo';
			}
			if ( ! empty( $this->atts['icon_linecons'] ) ) {
				$icon_type = 'linecons';
			}
			if ( ! empty( $this->atts['icon_monosocial'] ) ) {
				$icon_type = 'monosocial';
			}

			return $icon_type;
		}

		protected function get_bg_icon_type() {
			$icon_type = '';

			if ( ! empty( $this->atts['bg_icon_fontawesome'] ) ) {
				$icon_type = 'fontawesome';
			}
			if ( ! empty( $this->atts['bg_icon_openiconic'] ) ) {
				$icon_type = 'openiconic';
			}
			if ( ! empty( $this->atts['bg_icon_typicons'] ) ) {
				$icon_type = 'typicons';
			}
			if ( ! empty( $this->atts['bg_icon_entypo'] ) ) {
				$icon_type = 'entypo';
			}
			if ( ! empty( $this->atts['bg_icon_linecons'] ) ) {
				$icon_type = 'linecons';
			}
			if ( ! empty( $this->atts['bg_icon_monosocial'] ) ) {
				$icon_type = 'monosocial';
			}

			return $icon_type;
		}

		protected function get_icon_class() {
			$icon_class = 'icon-inside ';
			if ( $this->atts['style'] == 'light_border_shadow' ) {
				$icon_class .= 'icon-inline ';
			}
			if ( ! empty( $this->atts['icon_fontawesome'] ) ) {
				$icon_class .= $this->atts['icon_fontawesome'];
			}
			if ( ! empty( $this->atts['icon_openiconic'] ) ) {
				$icon_class .= $this->atts['icon_openiconic'];
			}
			if ( ! empty( $this->atts['icon_typicons'] ) ) {
				$icon_class .= $this->atts['icon_typicons'];
			}
			if ( ! empty( $this->atts['icon_entypo'] ) ) {
				$icon_class .= $this->atts['icon_entypo'];
			}
			if ( ! empty( $this->atts['icon_linecons'] ) ) {
				$icon_class .= $this->atts['icon_linecons'];
			}
			if ( ! empty( $this->atts['icon_monosocial'] ) ) {
				$icon_class .= $this->atts['icon_monosocial'];
			}

			return $icon_class;
		}

		protected function get_bg_icon_class() {
			$icon_class = '';
			if ( ! empty( $this->atts['bg_icon_fontawesome'] ) ) {
				$icon_class = $this->atts['bg_icon_fontawesome'];
			}
			if ( ! empty( $this->atts['bg_icon_openiconic'] ) ) {
				$icon_class = $this->atts['bg_icon_openiconic'];
			}
			if ( ! empty( $this->atts['bg_icon_typicons'] ) ) {
				$icon_class = $this->atts['bg_icon_typicons'];
			}
			if ( ! empty( $this->atts['bg_icon_entypo'] ) ) {
				$icon_class = $this->atts['bg_icon_entypo'];
			}
			if ( ! empty( $this->atts['bg_icon_linecons'] ) ) {
				$icon_class = $this->atts['bg_icon_linecons'];
			}
			if ( ! empty( $this->atts['bg_icon_monosocial'] ) ) {
				$icon_class = $this->atts['bg_icon_monosocial'];
			}

			return $icon_class;
		}

		protected function get_button_id() {
			return $this->button_id;
		}

		protected function prepare_css_rules_block( $selector, $rules ) {
			if ( $rules ) {
				return $selector . ' {' . $rules . '}';
			}

			return '';
		}

		protected function prepare_css_rule( $template ) {
			$args = func_get_args();
			array_shift( $args );
			if ( implode( '', $args ) ) {
				return vsprintf( $template, $args );
			}

			return '';
		}

		protected function darken_color( $color = '', $amount = 18 ) {
			if ( $color ) {
				if ( false !== strpos( $color, 'rgb' ) ) {
					$color_obj = new Color( Color::rgbToHex( $color ) );
				} else {
					$color_obj = new Color( $color );
				}

				return '#' . $color_obj->darken( $amount );
			}

			return '';
		}

		protected function compatibility_filter( &$atts ) {
			if ( ! isset( $atts['icon_type'] ) ) {
				$atts['icon_type'] = 'html';
			}

			return $atts;
		}
	}

	add_shortcode( 'brs_button', array( new BRS_Shortcode_Button(), 'shortcode' ) );

	function brs_get_button_html( $options = array() ) {
		$default_options = array(
			'before_title' => '',
			'after_title'  => '',
			'title'        => '',
			'target'       => '',
			'href'         => '',
			'class'        => 'brs-btn',
			'atts'         => ''
		);

		$options = wp_parse_args( $options, $default_options );
		vc_icon_element_fonts_enqueue( $options['icon_type'] );
		vc_icon_element_fonts_enqueue( $options['bg_icon_type'] );

		$title = $options['title'];


		if ( $options['split_title'] == 'y' && ! empty( $options['values'] ) ) {

			$values = vc_param_group_parse_atts( $options['values'] );
			$title  = '';

			foreach ( $values as $value ) {
				$style      = BRS_Shortcode_Button::get_font_style( $value['label_google_font'] );
				$span_class = '';
				if ( ( isset( $value['lowercase'] ) ) && $value['lowercase'] == 'y' ) {
					$span_class = 'text-lowercase';
				}
				$title .= '<span class="' . $span_class . '" style="' . $style . '">' . $value['label'] . ' </span>';
			}
		}

		//if ( $options['caption_on_hover'] == 'y' && ! empty( $options['hover_caption'] ) ) {


		if ( $options['brs_style'] == 'solid' || $options['brs_style'] == 'light_border_shadow' ) {

			if ( $options['caption_on_hover'] == 'y' && ! empty( $options['hover_caption'] ) ) {
				$title = $options['hover_caption'];
			}

			$title = '<span class="text">' . $title . '</span>';
		}

		//}

		$html = sprintf(
			'<a href="%1$s" style="%2$s" class="%3$s" %4$s >%5$s</a>',
			$options['href'],
			$options['style'],
			esc_attr( $options['class'] ),
			( $options['target'] ? ' target="_blank"' : '' ) . $options['atts'],
			$options['before_title'] . $title . $options['after_title']
		);

		if ( $options['brs_type'] == 'dropdown' ) {

			$ul_class = 'btn__dropdown_wrap border-radius-25';

			if ( $options['dropdown_opened'] == 'o' ) {
				$ul_class .= ' open';
			}

			if ( $options['drop_color_scheme'] == 'light' ) {
				$ul_class .= ' btn__white font__weight-light';
			} else {
				$ul_class .= ' btn__primary font__weight-bold  invert';
			}

			$str_ul = '<ul class="' . $ul_class . '">';
			$str_li = '';


			if ( ! empty( $options['dropdown_values'] ) ) {
				$values = vc_param_group_parse_atts( $options['dropdown_values'] );

				foreach ( $values as $value ) {
					$str_li .= '<li class="btn__dropdown_item">
		                <a href="' . $value['url'] . '" class="btn btn__dropdown_btn">' . $value['label'] . '</a>
		              </li>';
				}
			}

			$html = $str_ul . $str_li . '</ul>';
		}

		return apply_filters( 'brs_get_button_html', $html, $options );
	}
}
