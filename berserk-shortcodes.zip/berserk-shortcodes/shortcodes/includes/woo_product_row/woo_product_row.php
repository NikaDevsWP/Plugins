<?php
/**
 * BRS Woocommerce Product Row shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Woo_Product_Row', false ) ) {

	require_once BERSERK_SHORTCODES_PATH . 'shortcodes/includes/shortcodes-ext.php';

	class BRS_Woo_Product_Row extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Woo_Product_Row();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_woo_product_row', array( $this, 'shortcode_product_row' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				$params = array();

				$params[] = array(
					"heading"    => __( "Main Settings", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$params[] = array(
					'heading'    => esc_html__( 'Woocommerce Product Row Type', 'berserk' ),
					'param_name' => 'woo_product_row_type',
					'type'       => 'brs_radio',
					'value'      => array(
						"Type 1" => "type_1",
						"Type 2" => "type_2",
						"Type 3" => "type_3",
						"Type 4" => "type_4",
					),
					'images'     => array(
						"type_1" => 'woo_product_row/001.png',
						"type_2" => 'woo_product_row/002.png',
						"type_3" => 'woo_product_row/003.png',
						"type_4" => 'woo_product_row/004.png',
					),
					'images_dim' => array(
						'w' => '310',
						'h' => '150'
					)
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Image size', 'berserk' ),
					'value'            => BRS_Shortcodes_VCParams::get_image_sizes_names(),
					'param_name'       => 'image_size',
					'std'              => 'image-frames',
					'edit_field_class' => 'vc_col-sm-6 vc_column'
				);

				$params[] = array(
					"heading"          => __( "Excerpt Symbols Count", 'berserk' ),
					'type'             => 'textfield',
					'param_name'       => 'excerpt_symbols_count',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
				);

				$params[] = array(
					"heading"          => __( "Before Title", 'berserk' ),
					'type'             => 'textfield',
					'param_name'       => 'before_title',
					'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__woo_product_row_type type_1',
				);

				$params[] = array(
					"heading"    => __( "Choose Items", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$params[] = array(
					"heading"          => __( "Add Product", 'berserk' ),
					"param_name"       => "product",
					"type"             => "brs_add_product",
					'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__woo_product_row_type type_1',
				);

				$params[] = array(
					"heading"          => __( "Add Products", 'berserk' ),
					"param_name"       => "products",
					"type"             => "brs_add_product_multiple",
					'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__woo_product_row_type type_2 type_3 type_4',
				);
				
				// Additional CSS Class
				$params[] = array(
					'type'             => 'textfield',
					'heading'          => esc_html__( 'Additional CSS Class', 'berserk' ),
					'group'            => esc_html__( 'Advanced', 'berserk' ),
					'param_name'       => 'css_class',
					'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__services_type info',
				);

				//$options  = array( 'edit_field_class' => 'brk-dependency__woo_product_row_type trend split angle' );
				$patterns = berserk_shortcodes_patterns();
				$params   = array_merge( $params, $patterns );

				$backgrounds                                 = berserk_shortcodes_backgrounds();
				$backgrounds['bg_color']['edit_field_class'] = "vc_col-sm-12 vc_column  brk-dependency__woo_product_row_type type_1 type_2 type_4";
				$backgrounds['opacity']['edit_field_class']  = "vc_col-sm-6 vc_column  brk-dependency__woo_product_row_type type_1 type_2 type_4";

				$params = array_merge( $params, $backgrounds );

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Woo: Product Row", 'berserk' ),
					"base"     => "brs_woo_product_row",
					"icon"     => "brs_vc_ico_product_row",
					"class"    => "brs_vc_sc_product_row",
					"category" => __( 'Woocommerce Berserk', 'berserk' ),
					"params"   => $params
				) );
			}
		}

		public function shortcode_product_row( $atts, $content = null ) {

			brs_add_libraries( array( 'component__shop_product_row' ) );

			$pairs = array(
				'woo_product_row_type'  => 'type_1',
				'image_size'            => '',
				'product'               => '',
				'products'              => '',
				'gradient'              => 'brk-base-bg-gradient-5',
				'opacity'               => '',
				'excerpt_symbols_count' => '',
				'before_title'          => '',
				'bg_image'              => '',
				'pattern_type'          => '',
				'background_size'       => 'bg-cover',
				'background_repeat'     => '',
				'background_position'   => '',
				'use_custom_background' => 'no',
				'css_class'             => '',
			);

			$atts = shortcode_atts( $pairs, $atts );


			$currency = get_woocommerce_currency_symbol();

			//Pattern or custom Image
			$pattern_style = '';
			$pattern_class = '';
			if ( $atts['use_custom_background'] == 'yes' ) {
				$image         = wp_get_attachment_image_src( $atts['bg_image'], 'full' );
				$image         = $image[0];
				$pattern_style = 'background-image: url(' . esc_url( $image ) . ');';
			} else {
				$pattern_class = $atts['pattern_type'];
			}

			if(isset( $atts['background_size']) && ( $atts['background_size'] !='none')){
				$pattern_class = $atts['background_size'];
			}
			if(isset( $atts['background_repeat']) && ( $atts['background_repeat'] !='none')){
				$pattern_class = $atts['background_repeat'];
			}
			if(isset( $atts['background_position']) && ( $atts['background_position'] !='none')){
				$pattern_class = $atts['background_position'];
			}

			//Gradient
			$overlay_class   = array();
			$overlay_class[] = 'brk-sc-row-four__bg-layer';
			$overlay_class[] = $atts['gradient'];
			$overlay_class[] = $atts['opacity'];
			$overlay_class   = implode( ' ', $overlay_class );


			switch ( $atts['woo_product_row_type'] ) {

				case "type_1":

					$post = wc_get_product( $atts['product'] );
					if ( ! $post ) {
						return;
					}

					$categories = $post->get_category_ids();
					$terms      = array();
					foreach ( $categories as $cat_id ) {
						$term    = get_term( $cat_id );
						$terms[] = $term->name;
					}
					$terms = implode( ', ', $terms );

					$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $atts['product'] ), $atts['image_size'] );

					$symbols_count = ( $atts['excerpt_symbols_count'] !== '' ) ? $atts['excerpt_symbols_count'] : 50;
					$desc          = $post->get_description();
					if ( ! empty( $desc ) ) {
						$desc = ( strlen( $desc ) > $symbols_count ) ? mb_substr( $desc, 0, $symbols_count ) . " etc." : $desc;
					}

					$buy_now = apply_filters( 'woocommerce_loop_add_to_cart_link',
						sprintf( '<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="btn btn-inside-out btn-inside-out-invert btn-lg btn-icon border-radius-25 font__family-open-sans font__weight-bold add-cart ajax_add_to_cart %s product_type_%s">
								<i class="fa fa-shopping-basket icon-inside icon-inline"></i>
								<span class="before">' . esc_html__( 'Add to cart', 'berserk' ) . '</span><span class="text">' . esc_html__( 'Add to cart', 'berserk' ) . '</span><span class="after">' . esc_html__( 'Add to cart', 'berserk' ) . '</span></a>',
							esc_url( $post->add_to_cart_url() ),
							esc_attr( $post->get_id() ),
							esc_attr( $post->get_sku() ),
							$post->is_purchasable() ? 'add_to_cart_button' : '',
							esc_attr( $post->get_type() )
						),
						$post );

					$class = array(
						'brk-sc-row-one',
					);
					if( $pattern_class ) {
						$pattern_class = explode( ' ', $pattern_class );
						$class = array_merge( $class, $pattern_class );
					}
					if( $atts['css_class'] ) {
						$css_class = explode( ' ', $atts['css_class'] );
						$class = array_merge( $class, $css_class );
					}
					$class = implode( ' ', $class );

					$output = '<div class="' . esc_attr( $class ) . '" style="' . $pattern_style . '">
									<div class="brk-sc-row-one__left wow fadeInLeft">
										<div class="brk-sc-row-one__left--container ' . $overlay_class . ' brk-white-font-color">
											<div class="brk-sc-row-one__left--content">
												<h3 class="font__family-montserrat text-uppercase">
													<span class="font__weight-ultralight">' . $terms . '</span><br>
													<span class="font__weight-bold">' . esc_html( $atts['before_title'] ) . '</span>
												</h3>
												<h4 class="font__family-montserrat font__weight-bold text-uppercase">' . esc_html( $post->get_name() ) . '</h4>
											</div>
										</div>
									</div>

									<div class="brk-sc-row-one__image d-flex justify-content-center align-items-center wow zoomIn">
										<img src="' . esc_url( $image_url[0] ) . '" alt="">
									</div>

									<div class="brk-sc-row-one__right wow fadeInRight">
										<div class="brk-sc-row-one__right--container brk-base-bg-gradient-3 d-flex align-items-center justify-content-center">
											<div class="brk-sc-row-one__right--content text-center">
												<p>' . esc_html( $desc ) . '</p>
												' . $buy_now . '
												</div>
										</div>
									</div>
								</div>';

					break;

				case "type_2":

					brs_add_libraries( array( 'slider__swiper', 'component__content_slider' ) );

					$class = array(
						'filmstrip-slider',
						'slider--scroll',
						'brk-sc-row-two',
					);
					if( $pattern_class ) {
						$pattern_class = explode( ' ', $pattern_class );
						$class = array_merge( $class, $pattern_class );
					}
					if( $atts['css_class'] ) {
						$css_class = explode( ' ', $atts['css_class'] );
						$class = array_merge( $class, $css_class );
					}
					$class = implode( ' ', $class );

					$output = '<div class="' . esc_attr( $class ) . '" data-perwiew="1" style="' . $pattern_style . '">
									<div class="' . $overlay_class . '"></div>
									<div class="filmstrip-slider-container swiper-container">
										<div class="swiper-wrapper">';

					$products = explode( ',', $atts['products'] );
					if ( ! empty( $products ) ) {
						foreach ( $products as $product ) {
							$post       = wc_get_product( $product );
							if ( $post ) {
								$rate       = $post->get_average_rating() * 20;
								$categories = $post->get_category_ids();
								$terms      = array();
								foreach ( $categories as $cat_id ) {
									$term    = get_term( $cat_id );
									$terms[] = $term->name;
								}
								$terms = implode( ', ', $terms );

								$image_url = wp_get_attachment_image_url( get_post_thumbnail_id( $product ), $atts['image_size'] );

								$old_price = $post->get_sale_price() !== '' ? '<div class="old-price brk-dark-font-color">' . $currency . $post->get_regular_price() . '</div>' : '';

								$buy_now = apply_filters( 'woocommerce_loop_add_to_cart_link',
									sprintf( '<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="btn btn-gradient btn-lg border-radius-25 font__family-open-sans font__weight-bold add-cart ajax_add_to_cart %s product_type_%s">
														<span class="after"></span>' . esc_html__( 'Read more', 'berserk' ) . '</a>',
										esc_url( $post->add_to_cart_url() ),
										esc_attr( $post->get_id() ),
										esc_attr( $post->get_sku() ),
										$post->is_purchasable() ? 'add_to_cart_button' : '',
										esc_attr( $post->get_type() )
									),
									$post );

								$symbols_count = ( $atts['excerpt_symbols_count'] !== '' ) ? $atts['excerpt_symbols_count'] : 50;
								$desc          = $post->get_description();
								if ( ! empty( $desc ) ) {
									$desc = ( strlen( $desc ) > $symbols_count ) ? mb_substr( $desc, 0, $symbols_count ) . " etc." : $desc;
								}

								$label_terms = get_the_terms( $post->get_id(), 'brs_product_type' );
								$labels      = array();
								if ( is_array( $label_terms ) && ! empty( $label_terms ) ) {
									foreach ( $label_terms as $term ) {
										$labels[] = $term->name;
									}
								}
								$labels[] = get_the_date('Y', $post->get_id());

								$title = $post->get_name();
								$title = explode(' ', $title);
								$title_light = '';
								$title_bold = $post->get_name();
								if(!empty($title)){
									$title_light = $title[0];
									array_shift($title);
									$title_bold = implode(' ', $title);
								}

								$output .= '<div class="brk-sc-row-two__slide swiper-slide">
													<div class="brk-sc-row-two__container">
														<div class="brk-sc-row-two__layer-content">
															<div class="layer-content-before" style="background-image: url(' . BERSERK_SHORTCODES_URL . '/shortcodes/img/brk-sc-row-layer-top.png)"></div>
														</div>

														<div class="brk-sc-row-two__thumb">
															<img class="lazyload" src="' . esc_attr( BRK_DATA_IMAGE ) . '" data-src="' . esc_url( $image_url ) . '" alt="">
														</div>

														<div class="brk-sc-row-two__desc">
															<div class="brk-sc-row-two__desc-before" style="background-image: url(' . BERSERK_SHORTCODES_URL . '/shortcodes/img/brk-sc-row-layer-bottom.png)"></div>
															<div class="brk-sc-row-two__decor-layer">
																<div class="brk-sc-row-two__decor-layer--col-l">
																	<img class="lazyload" src="' . esc_attr( BRK_DATA_IMAGE ) . '" data-src="' . esc_url( $image_url ) . '" alt="">
																</div>
																<div class="brk-sc-row-two__decor-layer--col-r">
																	<div class="brk-sc-row-two__title">
																		<h4 class="font__family-montserrat text-uppercase brk-sc-row-two__title-text">
																			<span class="font__weight-light">' . esc_html( $title_light ) . '</span>
																			<span class="font__weight-bold">' . esc_html( $title_bold ) . '</span>
																		</h4>';

								foreach ( $labels as $label ) {
									$output .= '<div class="year brk-bg-grad brk-white-font-color">' . $label . '</div>';
								}
								$output .= '</div>
																	<div class="brk-sc-row-two__price font__family-montserrat">
																		<div class="price brk-base-font-color"> ' . $currency . $post->get_price() . '</div>
																	   ' . $old_price . '
																	</div>

																	<div class="brk-rating">
																		<div class="brk-rating__layer">
																			<i class="fa fa-star brk-dark-font-color"></i>
																			<i class="fa fa-star brk-dark-font-color"></i>
																			<i class="fa fa-star brk-dark-font-color"></i>
																			<i class="fa fa-star brk-dark-font-color"></i>
																			<i class="fa fa-star brk-dark-font-color"></i>
																		</div>
																		<div class="brk-rating__imposition" style="width: ' . $rate . '%">
																			<div class="visible">
																				<i class="fa fa-star brk-base-font-color"></i>
																				<i class="fa fa-star brk-base-font-color"></i>
																				<i class="fa fa-star brk-base-font-color"></i>
																				<i class="fa fa-star brk-base-font-color"></i>
																				<i class="fa fa-star brk-base-font-color"></i>
																			</div>
																		</div>
																	</div>

																	<div class="brk-sc-row-two__content brk-dark-font-color font__family-oxygen">
																	' . $desc . '
																	</div>
																</div>
															</div>
															<a href="' . get_permalink( $post->get_id() ) . '" class="btn btn-gradient btn-lg border-radius-25 font__family-open-sans font__weight-bold btn-min-width-200">
															<span class="after"></span>' . esc_html__( 'Read more', 'berserk' ) . '</a>
															</div>
													</div>
												</div>';
							}
						}
					}

					$output .= '</div>
									</div>
									<div class="brk-scrollbar">
										<div class="brk-scrollbar-track"></div>
									</div>
								</div>';


					break;

				case "type_3":

					brs_add_libraries( array( 'slider__swiper', 'component__content_slider' ) );

					$class = array(
						'brk-sc-row-three',
					);
					if( $pattern_class ) {
						$pattern_class = explode( ' ', $pattern_class );
						$class = array_merge( $class, $pattern_class );
					}
					if( $atts['css_class'] ) {
						$css_class = explode( ' ', $atts['css_class'] );
						$class = array_merge( $class, $css_class );
					}
					$class = implode( ' ', $class );

					$output = '<div class="' . esc_attr( $class ) . '" style="' . $pattern_style . '">
								<div class="brk-sc-row-three__before brk-base-bg-gradient-right"></div>
								<div class="brk-sc-row-three__after brk-post-brick-gradient-1"></div>

								<div class="brk-sc-row-three__container container">
									<div class="swiper-container">
										<div class="swiper-wrapper">';

					$products = explode( ',', $atts['products'] );
					if ( ! empty( $products ) ) {
						foreach ( $products as $product ) {
							$post       = wc_get_product( $product );
							$rate       = $post->get_average_rating() * 20;
							$categories = $post->get_category_ids();
							$terms      = array();
							foreach ( $categories as $cat_id ) {
								$term    = get_term( $cat_id );
								$terms[] = $term->name;
							}
							$terms = implode( ', ', $terms );

							$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $product ), $atts['image_size'] );
							$old_price = $post->get_sale_price() !== '' ? '<div class="old-price brk-dark-font-color">' . $currency . $post->get_regular_price() . '</div>' : '';

							$buy_now = apply_filters( 'woocommerce_loop_add_to_cart_link',
								sprintf( '<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="btn btn-inside-out btn-inside-out-invert btn-lg btn-icon border-radius-25 font__family-open-sans font__weight-bold add-cart ajax_add_to_cart %s product_type_%s">
											<i class="fa fa-shopping-basket icon-inside icon-inline" aria-hidden="true"></i>
											<span class="before">' . esc_html__( 'Add to cart', 'berserk' ) . '</span><span class="text">' . esc_html__( 'Add to cart', 'berserk' ) . '</span><span class="after">' . esc_html__( 'Add to cart', 'berserk' ) . '</span></a>',
									esc_url( $post->add_to_cart_url() ),
									esc_attr( $post->get_id() ),
									esc_attr( $post->get_sku() ),
									$post->is_purchasable() ? 'add_to_cart_button' : '',
									esc_attr( $post->get_type() )
								),
								$post );

							$symbols_count = ( $atts['excerpt_symbols_count'] !== '' ) ? $atts['excerpt_symbols_count'] : 50;
							$desc          = $post->get_description();
							if ( ! empty( $desc ) ) {
								$desc = ( strlen( $desc ) > $symbols_count ) ? mb_substr( $desc, 0, $symbols_count ) . " etc." : $desc;
							}

							$label_terms = get_the_terms( $post->get_id(), 'brs_product_type' );
							$labels      = array();
							if ( is_array( $label_terms ) && ! empty( $label_terms ) ) {
								foreach ( $label_terms as $term ) {
									$labels[] = $term->name;
								}
							}

							$title = $post->get_name();
							$title = explode(' ', $title);
							$title_light = '';
							$title_bold = $post->get_name();
							if(!empty($title)){
								$title_light = $title[0];
								array_shift($title);
								$title_bold = implode(' ', $title);
							}

							$output .= '<div class="swiper-slide brk-sc-row-three__slide brk-white-font-color">
											<div class="row align-items-lg-center align-content-start align-content-lg-stretch">
												<div class="col-xl-4 col-lg-3 align-self-stretch order-xl-1">
													<div class="brk-sc-row-three__thumb"><img src="' . esc_url( $image_url[0] ) . '" alt=""></div>
												</div>
												<div class="col-xl-7 col-lg-8 pt-150 pb-150">
													<div class="brk-sc-row-three__desc">
														<h4 class="font__family-montserrat text-uppercase">
															<span class="font__weight-light">' . esc_html($title_light ) . '</span>
															<span class="font__weight-bold">' . esc_html( $title_bold ) . '</span>
														</h4>

														<div class="brk-sc-row-three__desc--text">
														' . $desc . '
														</div>
														<div class="brk-sc-row-three__price">' . $buy_now . '
															<span class="brk-sc-row-three__price--price font__family-montserrat font__weight-ultralight">' . $post->get_regular_price() . $currency . '</span>
														</div>
													</div>
												</div>
											</div>
										</div>';
						}
					}

					$output .= '</div>
									</div>

									<div class="brk-sc-row-three__pagination"></div>
								</div>
							</div>';

					break;

				case "type_4":

					brs_add_libraries( array( 'slider__swiper' ) );

					$class = array(
						'brk-sc-row-four',
					);
					if( $atts['css_class'] ) {
						$css_class = explode( ' ', $atts['css_class'] );
						$class = array_merge( $class, $css_class );
					}
					$class = implode( ' ', $class );

					$output = '<div class="' . esc_attr( $class ) . '">

									<div class="brk-sc-row-four__bg ' . $pattern_class . '" style="' . $pattern_style . '">
										<div class="' . $overlay_class . '"></div>
									</div>

									<div class="swiper-container">
										<div class="swiper-wrapper">';

					$products = explode( ',', $atts['products'] );
					if ( ! empty( $products ) ) {
						foreach ( $products as $product ) {
							$post       = wc_get_product( $product );
							$rate       = $post->get_average_rating() * 20;
							$categories = $post->get_category_ids();
							$terms      = array();
							foreach ( $categories as $cat_id ) {
								$term    = get_term( $cat_id );
								$terms[] = $term->name;
							}
							$terms = implode( ', ', $terms );

							$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $product ), $atts['image_size'] );
							$old_price = $post->get_sale_price() !== '' ? '<div class="old-price brk-dark-font-color">' . $currency . $post->get_regular_price() . '</div>' : '';

							$buy_now = apply_filters( 'woocommerce_loop_add_to_cart_link',
								sprintf( '<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="btn btn-gradient btn-lg border-radius-25 font__family-open-sans font__weight-bold add-cart ajax_add_to_cart %s product_type_%s">
													<span class="after"></span>' . esc_html__( 'Read more', 'berserk' ) . '</a>',
									esc_url( $post->add_to_cart_url() ),
									esc_attr( $post->get_id() ),
									esc_attr( $post->get_sku() ),
									$post->is_purchasable() ? 'add_to_cart_button' : '',
									esc_attr( $post->get_type() )
								),
								$post );

							$symbols_count = ( $atts['excerpt_symbols_count'] !== '' ) ? $atts['excerpt_symbols_count'] : 50;
							$desc          = $post->get_description();
							if ( ! empty( $desc ) ) {
								$desc = ( strlen( $desc ) > $symbols_count ) ? mb_substr( $desc, 0, $symbols_count ) . " etc." : $desc;
							}

							$label_terms = get_the_terms( $post->get_id(), 'brs_product_type' );
							$labels      = array();
							if ( is_array( $label_terms ) && ! empty( $label_terms ) ) {
								foreach ( $label_terms as $term ) {
									$labels[] = $term->name;
								}
							}

							$title = $post->get_name();
							$title = explode(' ', $title);
							$title_light = '';
							$title_bold = $post->get_name();
							if(!empty($title)){
								$title_light = $title[0];
								array_shift($title);
								$title_bold = implode(' ', $title);
							}

							$video_url    = get_post_meta( $post->get_id(), 'product-video-review-link', true );
							$video_iframe = ( ! empty( $video_url ) ) ? '<iframe width="560" height="315" src="' . $video_url . '?rel=0&amp;showinfo=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>' : '';

							$output .= '<div class="brk-sc-row-four__slide swiper-slide">
											<div class="brk-sc-row-four__video">
											' . $video_iframe . '
											</div>
											<div class="brk-sc-row-four__desc brk-white-font-color">
												<h4 class="font__family-montserrat brk-white-font-color">
													<span class="font__weight-light">' . esc_html( $title_light) . ' </span>
													<span class="font__weight-bold">' . esc_html( $title_bold ) . '</span>
												</h4>

												<div class="brk-sc-row-four__desc--cat">
													' . esc_html__( 'Category: ', 'bererk' ) . '<span class="font__weight-bold text-uppercase">' . $terms . '</span>
												</div>

												<div class="brk-sc-row-four__desc--text">
												' . esc_html( $desc ) . '
												</div>
											</div>
										</div>';
						}
					}

					$output .= '</div>
									</div>

									<div class="brk-sc-row-four-pagination"></div>

								</div>';

					break;

			}

			return $output;
		}
	}

	// create shortcode
	BRS_Woo_Product_Row::get_instance();

}
