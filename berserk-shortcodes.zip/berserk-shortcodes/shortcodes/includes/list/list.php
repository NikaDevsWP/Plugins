<?php
/**
 * List shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Shortcode_List', false ) ) {

	class BRS_Shortcode_List extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Shortcode_List();
			}

			return self::$instance;
		}

		protected function __construct() {
			//add_shortcode( 'brs_vc_list_item', array( $this, 'shortcode_item' ) );
			add_shortcode( 'brs_list', array( $this, 'shortcode_list' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "List", 'berserk' ),
					"base"     => "brs_list",
					"icon"     => "brs_vc_ico_list",
					"class"    => "brs_vc_sc_list",
					"category" => __( 'Berserk', 'berserk' ),
					"params"   => array(

						array(
							'type'       => 'param_group',
							'heading'    => __( 'Values', 'js_composer' ),
							'param_name' => 'values',
							//'description' => __( 'Enter values for List', 'js_composer' ),
							'value'      => urlencode( json_encode( array(
								array(
									'list_item' => __( 'Some list item name', 'js_composer' ),
									'link_url'  => '',
									'font_size' => '16',
									'color_1'   => '#2775FF',
									'color_2'   => '#C423EE',
								),
								array(
									'list_item' => __( 'Some list item name', 'js_composer' ),
									'link_url'  => '',
									'font_size' => '16',
									'color_1'   => '#2775FF',
									'color_2'   => '#C423EE',
								),
								array(
									'list_item' => __( 'Some list item name', 'js_composer' ),
									'link_url'  => '',
									'font_size' => '16',
									'color_1'   => '#2775FF',
									'color_2'   => '#C423EE',
								),
							) ) ),
							'params'     => array(
								array(
									'type'             => 'textfield',
									'heading'          => __( 'List Item', 'js_composer' ),
									'param_name'       => 'list_item',
									//'description' => __( 'Enter text used as title of bar.', 'js_composer' ),
									'admin_label'      => true,
									'edit_field_class' => 'vc_col-sm-6 vc_column',
								),
								array(
									'type'             => 'textfield',
									'heading'          => __( 'Link URL', 'js_composer' ),
									'param_name'       => 'link_url',
									//'description' => __( 'Enter value of bar.', 'js_composer' ),
									'admin_label'      => true,
									'edit_field_class' => 'vc_col-sm-6 vc_column',
								),
								array(
									'heading'          => __( 'Font Size', 'js_composer' ),
									"param_name"       => "font_size",
									"type"             => "dropdown",
									"value"            => BRS_Shortcodes_VCParams::get_font_size(),
									'admin_label'      => true,
									'edit_field_class' => 'vc_col-sm-6 vc_column',

								),

								array(
									'type'             => 'colorpicker',
									//'heading'          => __( 'Color', 'js_composer' ),
									'param_name'       => 'color_1',
									'value'            => '#2775FF',
									'edit_field_class' => 'vc_col-sm-6 vc_column',
									//'admin_label' => true,
								),

								array(
									'type'             => 'colorpicker',
									//'heading'          => __( 'Color', 'js_composer' ),
									'param_name'       => 'color_2',
									'value'            => '#C423EE',
									'edit_field_class' => 'vc_col-sm-6 vc_column',
									//'admin_label' => true,
								),
							),
						),

						array(
							'heading'    => __( 'List Type', 'berserk' ),
							'param_name' => 'list_type',
							'type'       => 'brs_radio',
							'value'      => array(
								"Type 1" => "type_1",
								"Type 2" => "type_2",
								"Type 3" => "type_3",
								"Type 4" => "type_4",
								"Type 5" => "type_5",
								"Type 6" => "type_6"

							),
							'images'     => array(
								"type_1" => 'list/type_1.png',
								"type_2" => 'list/type_2.png',
								"type_3" => 'list/type_3.png',
								"type_4" => 'list/type_4.png',
								"type_5" => 'list/type_5.png',
								"type_6" => 'list/type_6.png'

							),
							'images_dim' => array(
								'w' => '185',
								'h' => '160'
							)
						),

						array(
							"heading"    => __( "Fonts", 'berserk' ),
							"param_name" => "brs_title",
							"type"       => "brs_title",
						),

						array(
							'type'             => 'dropdown',
							'heading'          => __( 'Font', 'berserk' ),
							'value'            => array(
								__( 'Open Sans', 'berserk' )             => 'open-sans',
								__( 'Montserrat', 'berserk' )            => 'montserrat',
								__( 'Montserrat Alternates', 'berserk' ) => 'montserrat-alt',
								__( 'Playfair Display', 'berserk' )      => 'playfair',
								__( 'Poppins', 'berserk' )               => 'poppins',
								__( 'Pacifico', 'berserk' )              => 'pacifico',
								__( 'Roboto', 'berserk' )                => 'roboto',
								__( 'Roboto Slab', 'berserk' )           => 'roboto-slab',
								__( 'Oxygen', 'berserk' )                => 'oxygen',
								__( 'Times New Roman', 'berserk' )       => 'times-new-roman',
							),
							'param_name'       => 'brs_font',
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							"std"              => "montserrat",
						),

						array(
							'type'             => 'dropdown',
							'heading'          => __( 'Font weight', 'berserk' ),
							'value'            => array(
								__( 'Normal', 'berserk' ) => 'normal',
								__( 'Light', 'berserk' )  => 'light',
								__( 'Bold', 'berserk' )   => 'bold'
							),
							'param_name'       => 'brs_font_weight',
							'edit_field_class' => 'vc_col-sm-6 vc_column',

						),

						array(
							'heading'          => __( 'Use Custom Font', 'berserk' ),
							'param_name'       => 'enable_font',
							'type'             => 'brs_switch',
							'value'            => 'n',
							'options'          => array(
								'Yes' => 'y',
								'No'  => 'n',
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

						array(
							'type'             => 'google_fonts',
							'param_name'       => 'google_fonts',
							'value'            => 'font_family:Montserrat%3Aregular%2C700|font_style:400%20regular%3A400%3Anormal',
							'settings'         => array(
								'fields' => array(
									'font_family_description' => __( '', 'js_composer' ),
									'font_style_description'  => __( '', 'js_composer' ),
								),
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'dependency'       => array(
								'element' => 'enable_font',
								'value'   => 'y',
							),
						),

						// Additional CSS Class
						array(
							'type'             => 'textfield',
							'heading'          => esc_html__( 'Additional CSS Class', 'berserk' ),
							'group'            => esc_html__( 'Advanced', 'berserk' ),
							'param_name'       => 'css_class',
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__services_type info',
						),

					)
				) );

			}
		}


		public function shortcode_list( $atts, $content = null ) {

      brs_add_libraries('component__list');

			extract( shortcode_atts( array(
				'values'          => '',
				'list_type'       => 'type_1',
				'google_fonts'    => 'font_family:Montserrat%3Aregular%2C700|font_style:400%20regular%3A400%3Anormal',
				'link_url'        => '',
				'enable_font'     => 'n',
				'brs_font'        => 'montserrat',
				'brs_font_weight' => 'normal',
				'css_class'       => '',
			), $atts ) );


			$classes          = array();
			$class_li         = '';
			$before_title     = '';
			$after_title      = '';
			$admin_images_uri = BERSERK_SHORTCODES_URL . '/shortcodes/images/';


			if ( $enable_font == 'n' ) {
				$classes[] = 'font__family-' . $brs_font;
				if ( $brs_font_weight != 'normal' ) {
					$classes[] = 'font__weight-' . $brs_font_weight;
				}

			}

			switch ( $list_type ) {
				case 'type_1':
					$classes[] = 'list-inline-1';
					$class_li  = 'list-counter';

					break;
				case 'type_2':
					$classes[] = 'list-inline-2';

					break;
				case 'type_3':
					$classes[] = 'list-inline-3';
					break;
				case 'type_4':
					vc_icon_element_fonts_enqueue('fontawesome');
					$classes[] = 'list-inline-4';

					break;
				case 'type_5':
					$classes[] = 'list-inline-5';
					$class_li  = 'list-counter';
					break;
				case 'type_6':
					$classes[] = 'list-inline-6';
					break;
				default:
					$classes[] = '';
			}

			if( $css_class ) {
				$css_class = explode( ' ', $css_class );
				$classes = array_merge( $classes, $css_class );
			}

			$classes = implode( ' ', $classes );

			// store atts
			$atts_backup = self::$atts;

			// change atts
			self::$atts = array(
				'list_type' => $list_type,
				//'dividers' => $dividers
			);

			$values = vc_param_group_parse_atts( $values );

			$content_li    = '';
			$style_li_font = '';

			if ( $enable_font == 'y' ) {
				$style_li_font = $this->get_font_style( $google_fonts );
			}


			foreach ( $values as $value ) {
				$style_li = $style_li_font . ' font-size:' . $value['font_size'] . 'px;';

				$before_link = '';
				$after_link  = '';

				switch ( $list_type ) {
					case 'type_1':
						$before_style = 'background: ' . $value['color_1'] . ';';
						$before_link  = '<span style="' . $before_style . '" class="before"></span>';
						break;
					case 'type_2':

						$before_style = 'background: ' . $value['color_1'] . ';';
						$before_title = '<span class="text"><span class="cirlce"><span style="' . $before_style . '" class="before"></span><span class="after"></span></span>';
						$after_title  = '</span>';
						break;
					case 'type_3':

						$style       = 'background: ' . $value['color_1'] . ';';
						$before_link = '<span style="' . $style . '" class="before"></span>';
						$after_link  = '<span style="' . $style . '" class="after"></span>';
						break;
					case 'type_4':

						$after_title = '<i class="icon fa fa-angle-right"></i>';

						$style_b = 'background: ' . $value['color_1'] . ';';

						$style_a = 'background: -webkit-gradient(linear, left top, right top, from(' . $value['color_1'] . '), to(' . $value['color_2'] . '));';
						$style_a .= 'background: -webkit-linear-gradient(left, ' . $value['color_1'] . ', ' . $value['color_2'] . ');';
						$style_a .= 'background: -o-linear-gradient(left, ' . $value['color_1'] . ', ' . $value['color_2'] . ');';
						$style_a .= 'background: linear-gradient(to right, ' . $value['color_1'] . ', ' . $value['color_2'] . ');';

						$before_link = '<span style="' . $style_b . '" class="before"></span>';
						$after_link  = '<span style="' . $style_a . '" class="after"></span>';

						break;
					case 'type_5':

						$style_a = 'background: -webkit-gradient(linear, left top, right top, from(' . $value['color_1'] . '), to(' . $value['color_2'] . '));';
						$style_a .= 'background: -webkit-linear-gradient(left, ' . $value['color_1'] . ', ' . $value['color_2'] . ');';
						$style_a .= 'background: -o-linear-gradient(left, ' . $value['color_1'] . ', ' . $value['color_2'] . ');';
						$style_a .= 'background: linear-gradient(to right, ' . $value['color_1'] . ', ' . $value['color_2'] . ');';

						$before_link = '<span  class="before"></span>';
						$after_link  = '<span style="' . $style_a . '" class="after"></span>';

						$after_title = '<img src="' . $admin_images_uri . 'shape-1.png" alt="" class="list-shape">';
						break;
					case 'type_6':

						$style      = 'background: ' . $value['color_1'] . ';';
						$after_link = '<namespan style="' . $style . '" class="after"></namespan>';

						break;

				}

				if ( ! empty( $value['link_url'] ) ) {
					$content_li .= ' <li style="' . $style_li . '" class="' . $class_li . '">' . $before_link . '<a href="' . esc_url( $value['link_url'] ) . '">' . $before_title . $value['list_item'] . $after_title . '</a>' . $after_link . '</li>';
				} else {
					$content_li .= ' <li style="' . $style_li . '" class="' . $class_li . '">' . $before_link . $before_title . $value['list_item'] . $after_title . $after_link . '</li>';
				}

			}

			$output = sprintf( '<ul class="%1$s">%2$s</ul>',
				esc_attr( $classes ),
				$content_li );

			// restore atts
			self::$atts = $atts_backup;

			return $output;
		}

		public function get_font_style( $google_fonts ) {
			$style = '';
			if ( ! empty( $google_fonts ) ) {
				$fontsData         = $google_fonts;
				$googleFontsStyles = $this->googleFontsStyles( $fontsData );
				$font_family       = explode( ':', $googleFontsStyles[0] );
				$font_family_e     = explode( ' ', $font_family[1] );
				$font_family_count = count( $font_family_e );

				if ( $font_family_count > 1 ) {
					$googleFontsStyles[0] = 'font-family:"' . implode( " ", $font_family_e ) . '"';
				}

				$style = esc_attr( implode( ';', $googleFontsStyles ) );
			}
			if ( ! empty( $style ) ) {
				$style = $style . ';';
			}

			return $style;
		}

		protected function googleFontsStyles( $fontsData ) {
			// Inline styles
			$fontFamily = BRS_Font::_vc_google_fonts_parse_attributes( '', $fontsData );
			$fontStyles = explode( ':', $fontFamily['values']['font_style'] );
			$fontFamily = explode( ':', $fontFamily['values']['font_family'] );
			$styles[]   = 'font-family:' . $fontFamily[0];
			$styles[]   = 'font-weight:' . $fontStyles[1];
			$styles[]   = 'font-style:' . $fontStyles[2];

			return $styles;
		}

	}

	// create shortcode
	BRS_Shortcode_List::get_instance();

}
