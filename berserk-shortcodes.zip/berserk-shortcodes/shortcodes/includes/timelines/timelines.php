<?php
/**
 * BRS_Timelines shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


if ( ! class_exists( 'BRS_Timelines', false ) ) {

	require_once BERSERK_SHORTCODES_PATH . 'shortcodes/includes/shortcodes-ext.php';

	class BRS_Timelines extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Timelines();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_timelines', array( $this, 'shortcode_timelines' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				$params = array();

				$params[] = array(
					"heading"    => __( "Main Settings", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);
				$params[] = array(
					'heading'    => __( 'Timelines Type', 'berserk' ),
					'param_name' => 'timelines_type',
					'type'       => 'brs_radio',
					'value'      => array(
						"Type 1" => "type_1",
						"Type 2" => "type_2",
						"Type 3" => "type_3",
						"Type 4" => "type_4",
						"Type 5" => "type_5",
						"Type 6" => "type_6",
					),
					'images'     => array(
						"type_1" => 'timelines/001.png',
						"type_2" => 'timelines/002.png',
						"type_3" => 'timelines/003.png',
						"type_4" => 'timelines/004.png',
						"type_5" => 'timelines/005.png',
						"type_6" => 'timelines/006.png',
					),
					'images_dim' => array(
						'w' => '320',
						'h' => '100'
					)
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Post Image size', 'berserk' ),
					'value'            => BRS_Shortcodes_VCParams::get_image_sizes_names(),
					'param_name'       => 'image_size',
					'std'              => '',
					'edit_field_class' => 'vc_col-sm-6 vc_column'
				);

				$params[] = array(
					'type'             => 'checkbox',
					'heading'          => esc_html__( 'Show Top Delimiter', 'berserk' ),
					'param_name'       => 'top_delimiter',
					'value'            => '',
					'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__timelines_type type_2',
				);


				$params[] = array(
					"heading"    => __( "Dynamic Content", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$params = array_merge( $params, berserk_shortcodes_dynamic_filter() );

				$params[] = array(
					'type'             => 'textfield',
					'heading'          => __( 'AJAX: Items Per Load', 'js_composer' ),
					'param_name'       => 'items_per_load',
					"value"            => '4',
					'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__timelines_type type_4 type_5',
				);

				$params[] = array(
					"heading"    => __( "Content Values", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Get title from', 'js_composer' ),
					'param_name'       => 'title_val',
					'value'            => array(
						'Post Title'  => 'post_title',
						'Post Date'   => 'post_date',
						'Post Author' => 'post_author'
					),
					'edit_field_class' => 'vc_col-sm-6 vc_column',
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Get description from', 'js_composer' ),
					'param_name'       => 'description_val',
					'value'            => array(
						'Post Title'   => 'post_title',
						'Post Date'    => 'post_date',
						'Post Author'  => 'post_author',
						'Post Content' => 'post_content',
						'Post Excerpt' => 'post_excerpt',
					),
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					'std'              => 'post_content'
				);

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Timelines", 'berserk' ),
					"base"     => "brs_timelines",
					"icon"     => "brs_vc_ico_timelines",
					"class"    => "brs_vc_sc_timelines",
					"category" => __( 'Berserk', 'berserk' ),
					"params"   => $params
				) );

			}
		}

		public static function shortcode_timelines( $atts, $content = null ) {

			brs_add_libraries( 'component__timelines' );

			$atts = shortcode_atts( array(
				'timelines_type'  => 'type_1',
				'dynamic_content' => 'no',
				'image_size'      => 'timeline-strict',
				'custom_items'    => '',
				'orderby'         => 'date',
				'order_direction' => 'ASC',
				'filters'         => '',
				'title_val'       => 'post_title',
				'description_val' => 'post_content',
				'items_per_load'  => 4,
				'top_delimiter'   => '',
			), $atts );


			if ( $atts['dynamic_content'] == 'y' ) {
				$args  = array();
				$args  = array_merge( $args, berserk_shortcodes_dynamic_filter_process( $atts['filters'], $atts['orderby'], $atts['order_direction'] ) );
				$posts = get_posts( $args );
			} else {
				$posts        = array();
				$custom_items = explode( ',', $atts['custom_items'] );
				foreach ( $custom_items as $item ) {
					$posts[] = get_post( $item );
				}
			}

			$svg_delimiter = '';

			switch ( $atts['timelines_type'] ) {
				case 'type_1':

					brs_add_libraries( 'slider__swiper' );

					$output = '
		  <div class="filmstrip-slider timeline timeline--strict">
			<div class="filmstrip-slider-container swiper-container">
			  <div class="swiper-wrapper">';

					foreach ( $posts as $post ) {
						$bg_image    = get_the_post_thumbnail_url( $post->ID, $atts['image_size'] );
						$description = BRS_Shortcodes_VCParams::get_content_description( $atts['description_val'], $post );
						$timestamp   = strtotime( $post->post_date );

						$output .= '
			<div class="post-filmstrip swiper-slide">
			  <div class="timeline__item">
				<a href="' . get_permalink( $post->ID ) . '" class="timeline__link bg-cover" style="background-image: url(' . esc_url( $bg_image ) . ')">
				  <span class="overlay brk-base-bg-1"></span>
				  <i class="icon fal fa-link"></i>
				</a>
				<div class="timeline__content text-left brk-dark-font-color">
				  <div class="timeline__date">
					<div class="timeline__date-year font__family-montserrat-alt font__weight-semibold font__size-19 brk-base-font-color letter-spacing-100 line__height-19">
					  ' . date( 'Y', $timestamp ) . '
					</div>
					<div class="timeline__date-month font__family-oxygen font__weight-medium font__size-14 brk-black-font-color text-uppercase">
					  ' . date( 'M d', $timestamp ) . '
					</div>
				  </div>

				  <p class="mt-15 font__family-oxygen font__weight-medium font__size-16 letter-spacing--1 line__height-26">' . esc_html( $description ) . '</p>
				  <a href="' . get_permalink( $post->ID ) . '" class="btn btn--square font__family-oxygen font__size-16 brk-base-border-color brk-black-font-color mt-30">' . __( "Read more", 'berserk' ) . '<i class="angle brk-base-bg-1"></i></a>
				</div>
			  </div>
			</div>';
					}

					$output .= '
			  </div>
			  <div class="swiper-pagination"></div>
			</div>
		  </div>';
					break;

				case "type_6":

					brs_add_libraries( 'slider__swiper' );

					$output = '<div class="filmstrip-slider timeline timeline--strict timeline--strict_full-width position-relative brk-z-index-20"
								 data-perwiew="1" data-spacebetween="0">
								<div class="filmstrip-slider-container swiper-container pt-70">
									<div class="swiper-wrapper">';

					foreach ( $posts as $post ) {

						$timestamp   = strtotime( $post->post_date );
						$description = BRS_Shortcodes_VCParams::get_content_description( $atts['description_val'], $post );

						$output .= '<div class="post-filmstrip swiper-slide">
											<div class="font__family-montserrat-alt font__weight-bold font__size-21 line__height-22 brk-base-font-color">
												' . date( 'Y', $timestamp ) . '
											</div>
											<div class="font__family-oxygen font__weight-light font__size-14 line__height-18 text-uppercase">
											   ' . date( 'M d', $timestamp ) . '
											</div>
											<p class="font__family-oxygen font__weight-light font__size-16 line__height-26 brk-dark-font-color mt-20">
											' .$description . '
											</p>
										</div>';
					}
					$output .= '</div>
									<div class="swiper-pagination"></div>
								</div>
							</div>';

					break;

				case 'type_2':

					brs_add_libraries( 'slider__swiper' );

					$has_delimiter_class = '';
					if ( $atts['top_delimiter'] ) {
						$has_delimiter_class = ' timeline--mosaic__has-delimiter';
						$svg_delimiter = '<div class="timeline--mosaic__svg-container">
						<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1922 178" class="z-index-2">
							<defs>
								<path id="timelines-id-1" d="M0 1681.08s316.8 134.28 689 77.96c256.8-38.85 522.63-97.05 754-107.95 218.56-10.29 422.43 53.34 477 76.97V1644H0z"/>
							</defs>
							<g>
								<g transform="translate(1 -1639)">
									<use fill="#fff" xlink:href="#timelines-id-1" />
								/g>
								</g>
						</svg>
						<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1922 207" class="z-index-2" style="margin-top: 25px">
							<defs>
								<path id="yof1a" d="M0 1751.03s316.8 102.31 689 46c256.8-38.86 524.63-106.06 756-116.95 218.56-10.3 420.43 50.45 475 74.08V1810s-194.6-118.95-470-112c-285.7 7.2-657.01 120.7-913 143-368.4 32.1-537-25-537-25z"/>
								<linearGradient id="yof1b" x1="888" x2="1032" y1="1850.79" y2="1678.92" gradientUnits="userSpaceOnUse">
									<stop offset="0" stop-color="var(--brand-primary)" stop-opacity=".94" />
									<stop offset="1" stop-color="var(--brk-base-2)" stop-opacity=".94" />
								</linearGradient>
							</defs>
							<g>
								<g transform="translate(1 -1668)">
									<use fill="transparent" xlink:href="#yof1a" />
									<use fill="url(#yof1b)" xlink:href="#yof1a" />
								</g>
							</g>
						</svg>
					</div>';
					}

					$output = '
			<div class="filmstrip-slider slider--scroll timeline timeline--mosaic' . $has_delimiter_class . '">
			' . $svg_delimiter . '
			<div class="filmstrip-slider-container swiper-container">
			  <div class="swiper-wrapper">';

					foreach ( $posts as $post ) {
						$bg_image    = get_the_post_thumbnail_url( $post->ID, $atts['image_size'] );
						$title       = BRS_Shortcodes_VCParams::get_content_title( $atts['title_val'], $post );
						$description = BRS_Shortcodes_VCParams::get_content_description( $atts['description_val'], $post );
						$timestamp   = strtotime( $post->post_date );
						$output .= '
			<div class="post-filmstrip swiper-slide">
			  <div class="timeline__item">
				<a href="' . get_permalink( $post->ID ) . '" class="timeline__link bg-cover">
				  <img src="' . esc_url( $bg_image ) . '" alt="">
				</a>
				<div class="timeline__content text-left">
				  <div class="timeline__date">
					<div class="timeline__date-year font__family-open-sans font__weight-semibold font__size-18 line__height-24">
					  ' . date( 'Y', $timestamp ) . '
					</div>
				  </div>
				  <h2 class="timeline__title font__family-montserrat font__weight-semibold font__size-21 line__height-30 letter-spacing--1">
					' . esc_html( $title ) . '
				  </h2>

				  <p class="font__family-open-sans font__weight-light font__size-16 letter-spacing-20 line__height-26">
					' . esc_html( $description ) . '</p>
				</div>
			  </div>
			</div>';
					}

					$output .= '
			  </div>
			</div>
			<div class="brk-scrollbar">
				<div class="brk-scrollbar-track"></div>
			</div>
		  </div>';

					break;

				case 'type_3':

					brs_add_libraries( 'slider__swiper' );

					$output = '
		  <div class="filmstrip-slider timeline timeline--masonry">
			<div class="filmstrip-slider-container swiper-container">
			  <div class="swiper-wrapper">';

					foreach ( $posts as $post ) {
						$bg_image    = get_the_post_thumbnail_url( $post->ID, $atts['image_size'] );
						$title       = BRS_Shortcodes_VCParams::get_content_title( $atts['title_val'], $post );
						$description = BRS_Shortcodes_VCParams::get_content_description( $atts['description_val'], $post );
						$timestamp   = strtotime( $post->post_date );

						$output .= '
			<div class="post-filmstrip swiper-slide" data-caption="' . date( 'M, Y', $timestamp ) . '">
			  <div class="timeline__item">
				<div class="timeline__content text-left brk-dark-font-color">
				  <div class="timeline__date">
					<div class="timeline__date-year font__family-montserrat font__size-19 font-weight-bold brk-black-font-color line__height-40">
					  ' . date( 'M, Y', $timestamp ) . '
					</div>
				  </div>
	  
				  <p class="mt-20 brk-dark-font-color font__family-roboto font__weight-light font__size-15 letter-spacing--1 line__height-26">' . esc_html( $description ) . '</p>
				</div>
				<a href="' . get_permalink( $post->ID ) . '" class="timeline__link bg-cover"><img class="mt-30" src="' . esc_url( $bg_image ) . '"></a>
			  </div>
			</div>';
					}

					$output .= '
			  </div>
			<div class="swiper-pagination"></div>
			</div>
		  </div>';

					break;
				case 'type_4':

					brs_add_libraries( 'component__timelines_js' );

					$output = '
		  <div class="timeline timeline--masonry-grid timeline--vertical-circles brk-js-parent">
			<div class="timeline__wrapper brk-js-append">';

					foreach ( $posts as $post ) {
						$image_url    = get_the_post_thumbnail_url( $post->ID, $atts['image_size'] );
						$title       = BRS_Shortcodes_VCParams::get_content_title( $atts['title_val'], $post );
						$description = BRS_Shortcodes_VCParams::get_content_description( $atts['description_val'], $post );
						$timestamp   = strtotime( $post->post_date );
						$output .= '
						  <div class="timeline__item">
							<div class="timeline__box">';
								$year_color = 'brk-black-font-color';
								if ( has_post_thumbnail( $post->ID ) ) {
									$output .='<img class="lazyload" src="' . esc_attr( BRK_DATA_IMAGE ) . '" data-src="' . esc_url( $image_url ) . '" alt="">';
									$year_color = 'brk-base-font-color';
								}
								$output .= '<div class="timeline__content text-center brk-dark-font-color">
								<div class="timeline__date">
								  <div class="timeline__date-year font__family-montserrat font__weight-semibold font__size-18  line__height-16 ' . esc_attr( $year_color ) . '">
									' . date( 'Y', $timestamp ) . '
								  </div>
								  <div class="timeline__date-month font__family-montserrat font__weight-medium font__size-15 line__height-16">
									' . date( 'M d', $timestamp ) . '
								  </div>
								</div>
								' . wpautop( do_shortcode( $description ) ) . '
							  </div>
							</div>
						  </div>';

					}

					$output .= '
			  </div>
			  <div class="timeline__progress-bar">
				<a class="btn btn-simple btn-circle border-radius-50 brk-shortcode-pagination-ajax" data-shortcode = "timelines" data-numberposts = "' . $atts['items_per_load'] . '">
				  <i class="fa fa-refresh"></i>
				</a>
				' . berserk_shortcodes_dynamic_filter_data( $atts ) . '
			  </div>
			</div>
		  </div>';

					break;

				case 'type_5':

					$icons = array(
						'archive',
						'user',
						'clipboard',
						'child',
						'globe',
						'calendar',
						'camera',
						'car',
						'chart-pie'
					);

					$output = '
			<div class="timeline timeline--vertical-squares brk-js-parent">
			  <div class="timeline__wrapper brk-js-append">';

					foreach ( $posts as $post ) {
						$bg_image    = get_the_post_thumbnail_url( $post->ID, $atts['image_size'] );
						$title       = BRS_Shortcodes_VCParams::get_content_title( $atts['title_val'], $post );
						$description = BRS_Shortcodes_VCParams::get_content_description( $atts['description_val'], $post );
						$timestamp   = strtotime( $post->post_date );

						$rand = array_rand( $icons, 1 );
						$output .= '
			  <div class="timeline__item">
				<span class="timeline__active-line"></span>
				<div class="timeline__box">
				  <span class="before brk-base-bg-gradient-bottom-blue"></span>
				  <div class="timeline__content text-left brk-dark-font-color">
					<div class="timeline__date">
					  <div class="font__family-montserrat text-left font__weight-bold font__size-20 brk-black-font-color line__height-h2">
						' . date( 'Y, M d', $timestamp ) . '
					  </div>
					</div>
		  
					<p class="mt-25 text-left font__family-oxygen font__weight-medium font__size-16 letter-spacing--1 line__height-26">
					  ' . esc_html( $description ) . '
					</p>
				  </div>
				  <span class="after"><i class="fal fa-' . $icons[ $rand ] . '"></i></span>
				</div>
			  </div>';
					}


					$output .= '
			  </div>
			<div class="timeline__progress-bar">
			  <a class="btn btn--bg__icon font__family-open-sans font-weight-bold font__size-16 line__height-16 brk-shortcode-pagination-ajax" data-shortcode = "timelines" data-numberposts = "' . $atts['items_per_load'] . '">
				<i class="fa fa-refresh"></i>
				' . esc_html__( 'LOAD MORE', 'berserk' ) . '
			  </a>
			  ' . berserk_shortcodes_dynamic_filter_data( $atts ) . '
			</div>
			</div>
		  </div>';

					break;
			}

			return $output;
		}


	}

	// create shortcode
	BRS_Timelines::get_instance();

}