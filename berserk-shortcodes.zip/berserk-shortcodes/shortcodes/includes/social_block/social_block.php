<?php
/**
 * Servises shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Social_Block', false ) ) {

	class BRS_Social_Block extends BRS_Shortcode {

		static protected $instance;

		protected $shortcode_name = 'brs_social_block';
		protected $atts = array();

		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Social_Block();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( $this->shortcode_name, array( $this, 'shortcode' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Social Block", 'berserk' ),
					"base"     => "brs_social_block",
					"icon"     => "brs_vc_ico_social_block",
					"class"    => "brs_vc_sc_social_block",
					"category" => __( 'Berserk', 'berserk' ),
					"params"   => array(

						array(
							'heading'    => __( 'Social Block Type', 'berserk' ),
							'param_name' => 'social_block_type',
							'type'       => 'brs_radio',
							'value'      => array(
								"Circle"    => "circle",
								"Round"     => "round",
								"Square"    => "square",
								"Honeycomb" => "honeycomb",
								"Double"    => "double",
								"Gradient"  => "gradient",

							),
							'images'     => array(
								"circle"    => 'sb_circle.png',
								"round"     => 'sb_round.png',
								"square"    => 'sb_square.png',
								"honeycomb" => 'sb_honeycomb.png',
								"double"    => 'sb_double.png',
								"gradient"  => 'sb_gradient.png',
							),
							'images_dim' => array(
								'w' => '185',
								'h' => '160'
							)
						),
						array(
							"type"             => "textfield",
							"heading"          => __( "Label", 'berserk' ),
							"param_name"       => "label",
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							"value"            => "Facebook"
						),
						array(
							'type'             => 'dropdown',
							'heading'          => esc_html__( 'Label Color', 'berserk' ),
							'value'            => BRS_Shortcodes_VCParams::get_text_colors(),
							'std'              => '',
							'param_name'       => 'label_color',
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),
						array(
							"type"             => "textfield",
							"heading"          => __( "Social Item Link URL", 'berserk' ),
							"param_name"       => "link_url",
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							"value"            => "#"
						),
						array(
							"type"             => "textfield",
							"heading"          => __( "Follow Text", 'berserk' ),
							"param_name"       => "follow_text",
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							"value"            => "Follow Now"
						),
						array(
							'type'             => 'dropdown',
							'heading'          => esc_html__( 'Hue type', 'berserk' ),
							'param_name'       => 'hue_type',
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'value'            => array(
								esc_html__( 'Default', 'berserk' ) => '',
								esc_html__( 'Dark', 'berserk' )    => 'dark',
							),
						),
						array(
							"heading"          => __( "Icon", 'berserk' ),
							"param_name"       => "brs_title",
							"type"             => "brs_title",
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
						),
						array(
							'type'             => 'dropdown',
							'heading'          => __( 'Icon library', 'berserk' ),
							'value'            => array(
								__( 'Font Awesome', 'berserk' ) => 'fontawesome',
								__( 'Open Iconic', 'berserk' )  => 'openiconic',
								__( 'Typicons', 'berserk' )     => 'typicons',
								__( 'Entypo', 'berserk' )       => 'entypo',
								__( 'Linecons', 'berserk' )     => 'linecons',
								__( 'Mono Social', 'berserk' )  => 'monosocial',
								__( 'Livicon', 'berserk' )      => 'livicon',
							),
							'param_name'       => 'btn_icon_type',
							'edit_field_class' => 'vc_col-sm-6 vc_column icon_option',
						),
						array(
							'type'             => 'iconpicker',
							'heading'          => __( 'Icon', 'berserk' ),
							'param_name'       => 'icon_fontawesome',
							'value'            => 'fa fa-facebook', // default value to backend editor admin_label
							'settings'         => array(
								'emptyIcon'    => false,
								'iconsPerPage' => 4000,
							),
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'fontawesome',
							),
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
						),
						array(
							'type'             => 'iconpicker',
							'heading'          => __( 'Icon', 'berserk' ),
							'param_name'       => 'icon_openiconic',
							'value'            => 'vc-oi vc-oi-dial', // default value to backend editor admin_label
							'settings'         => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'openiconic',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'openiconic',
							),
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
						),
						array(
							'type'             => 'iconpicker',
							'heading'          => __( 'Icon', 'berserk' ),
							'param_name'       => 'icon_typicons',
							'value'            => 'typcn typcn-adjust-brightness',
							// default value to backend editor admin_label
							'settings'         => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'typicons',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'typicons',
							),
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
						),
						array(
							'type'             => 'iconpicker',
							'heading'          => __( 'Icon', 'berserk' ),
							'param_name'       => 'icon_entypo',
							'value'            => 'entypo-icon entypo-icon-note',
							// default value to backend editor admin_label
							'settings'         => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'entypo',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'entypo',
							),
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
						),
						array(
							'type'             => 'iconpicker',
							'heading'          => __( 'Icon', 'berserk' ),
							'param_name'       => 'icon_linecons',
							'value'            => 'vc_li vc_li-heart', // default value to backend editor admin_label
							'settings'         => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'linecons',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'linecons',
							),
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
						),
						array(
							'type'             => 'iconpicker',
							'heading'          => __( 'Icon', 'berserk' ),
							'param_name'       => 'icon_monosocial',
							'value'            => 'vc-mono vc-mono-fivehundredpx',
							// default value to backend editor admin_label
							'settings'         => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'monosocial',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'monosocial',
							),
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
						),
						array(
							"type"             => "textarea_html",
							"holder"           => "div",
							"class"            => "",
							"param_name"       => "content",
							"value"            => __( "", 'berserk' ),
							"description"      => "",
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'livicon',
							),
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
						),
					)
				) );
			}
		}

		public function shortcode( $atts, $content = null ) {

			brs_add_libraries( 'component__social_block' );

			extract( shortcode_atts( array(
				'social_block_type' => 'circle',
				'label'             => 'Facebook',
				'link_url'          => '#',
				'follow_text'       => 'Follow Now',
				'hue_type'          => '',
				'btn_icon_type'     => 'fontawesome',
				'icon_fontawesome'  => 'fa fa-facebook',
				'icon_monosocial'   => '',
				'icon_linecons'     => '',
				'icon_entypo'       => '',
				'icon_typicons'     => '',
				'icon_openiconic'   => '',
				'label_color'       => 'default',

			), $atts ) );

			$output = '';

			vc_icon_element_fonts_enqueue( $btn_icon_type );

			$icon_class                     = array();
			$icon_class['type']             = $btn_icon_type;
			$icon_class['icon_livicon']     = '';
			$icon_class['icon_fontawesome'] = $icon_fontawesome;
			$icon_class['icon_openiconic']  = $icon_openiconic;
			$icon_class['icon_typicons']    = $icon_typicons;
			$icon_class['icon_entypo']      = $icon_entypo;
			$icon_class['icon_linecons']    = $icon_linecons;
			$icon_class['icon_monosocial']  = $icon_monosocial;
			$icon_class                     = $this->get_icon_class( $icon_class );

			switch ( $social_block_type ) {

				case "circle":

					$icon_html = ' <i class="brk-icon ' . $icon_class . '"><span class="before"></span><span class="after"></span></i>';
					if ( isset( $content ) && $btn_icon_type == 'livicon' ) {
						$svg_icon  = do_shortcode( $content );
						$icon_html = $svg_icon;
					}

					if ( $label_color == 'default' ) {
						$label_color = 'text-light-blue';
					}

					$output = '<div class="social__icon-circle">
				                <a href="' . esc_url( $link_url ) . '">' . $icon_html . '</a>
				                <h4 class="font__family-montserrat font__weight-light font__size-28 ' . esc_attr( $label_color ) . '">' . $label . '</h4>
				                <p class="font__family-montserrat font__weight-medium font__size-16">' . $follow_text . '</p>
				              </div>';

					break;

				case "round":

					$icon_html = ' <i class="brk-icon ' . $icon_class . '"></i>';
					if ( isset( $content ) && $btn_icon_type == 'livicon' ) {
						$svg_icon  = do_shortcode( $content );
						$icon_html = $svg_icon;
					}

					if ( $label_color == 'default' ) {
						$label_color = 'text-light-blue';
					}

					$output = '<div class="social__icon-round">
				                <a href="' . esc_url( $link_url ) . '" class="icon-wrap">' . $icon_html . '</a>
				                <h4 class="font__family-montserrat font__weight-light font__size-28 ' . esc_attr( $label_color ) . '">' . $label . '</h4>
				                <p class="font__family-montserrat font__weight-medium font__size-16">' . $follow_text . '</p>
				              </div>';

					break;

				case "square":

					$icon_html = ' <i class="brk-icon slide-bg-wrap ' . $icon_class . '"><span class="slide-bg"></span></i>';
					if ( isset( $content ) && $btn_icon_type == 'livicon' ) {
						$svg_icon  = do_shortcode( $content );
						$icon_html = $svg_icon;
					}

					if ( $label_color == 'default' ) {
						$label_color = 'text-blue-2';
					}

					$social_class       = 'social__icon-square';
					$social_hue_type    = $hue_type;
					$social_label_class = 'font__family-montserrat font__size-16 text';
					if ( $social_hue_type != '' ) {
						$social_class .= ' social__icon-square_' . $social_hue_type;
					} else {
						$social_label_class .= ' ' . $label_color;
					}


					$output = '<div class="' . esc_attr( $social_class ) . '">
									<a href="' . esc_url( $link_url ) . '">' . $icon_html . '</a>
									<h4 class="' . esc_attr( $social_label_class ) . '">' . $label . '</h4>
								</div>';

					break;

				case "honeycomb":

					$icon_html = ' <i class="brk-icon ' . $icon_class . '"></i>';
					if ( isset( $content ) && $btn_icon_type == 'livicon' ) {
						$svg_icon  = do_shortcode( $content );
						$icon_html = $svg_icon;
					}

					$output = '<div class="social__icon-honeycomb">
									<a href="' . esc_url( $link_url ) . '" class="hexagon">
										<span class="hexagon__side hexagon__side-1"></span> <span class="hexagon__side hexagon__side-2"></span>
										' . $icon_html . ' <span class="after"></span>
									</a>
									<div class="icon-title">
										<h4 class="font__family-montserrat font__weight-ultralight font__size-24 ' . esc_attr( $label_color ) . '">' . $label . '</h4>
										<p class="font__family-montserrat font__weight-light font__size-16">' . $follow_text . '</p>
									</div>
								</div>';

					break;

				case "double":

					$icon_html = ' <i class="brk-icon ' . $icon_class . '"></i>';
					if ( isset( $content ) && $btn_icon_type == 'livicon' ) {
						$svg_icon  = do_shortcode( $content );
						$icon_html = $svg_icon;
					}

					if ( $label_color == 'default' ) {
						$label_color = 'text-light-soft';
					}

					$output = '<div class="social__icon-round">
				                <a href="' . esc_url( $link_url ) . '" class="icon-wrap">' . $icon_html . '</a>
				                <h4 class="font__family-montserrat font__weight-light font__size-28 ' . esc_attr( $label_color ) . '">' . $label . '</h4>
				                <p class="font__family-montserrat font__weight-medium font__size-16">' . $follow_text . '</p>
				              </div>';

					break;

				case "gradient":

					$icon_html = ' <i class="brk-icon ' . $icon_class . '"></i>';
					if ( isset( $content ) && $btn_icon_type == 'livicon' ) {
						$svg_icon  = do_shortcode( $content );
						$icon_html = $svg_icon;
					}

					$output = '<div class="social__icon-gradient">
									<span class="before"></span><span class="after"></span>
									<a href="' . esc_url( $link_url ) . '" class="hexagon">
										<div class="hexagon__side hexagon__side-1"></div>
										<div class="hexagon__side hexagon__side-2"></div>
										' . $icon_html . ' <span class="after"></span>
									</a>
									<h4 class="font__family-montserrat font__weight-medium font__size-16 icon-title text-center ' . esc_attr( $label_color ) . '">' . $label . '</h4>
								</div>';
					break;
			}

			return $output;
		}

		protected function get_icon_class( $atts ) {

			$icon_class = $atts[ 'icon_' . $atts['type'] ];

			if ( empty( $icon_class ) ) {
				$icon_class = 'fa fa-facebook';
			}

			return $icon_class;
		}

	}

	// create shortcode
	BRS_Social_Block::get_instance();

}
