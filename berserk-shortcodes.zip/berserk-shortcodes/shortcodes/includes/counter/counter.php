<?php
/**
 * Counter shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Counter', false ) ) {

	class BRS_Counter extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Counter();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_counter', array( $this, 'shortcode_counter' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Counter", 'berserk' ),
					"base"     => "brs_counter",
					"icon"     => "brs_vc_ico_counter",
					"class"    => "brs_vc_sc_counter",
					"category" => __( 'Berserk', 'berserk' ),
					"params"   => array(
						array(
							'heading'    => __( 'Counter Type', 'berserk' ),
							'param_name' => 'counter_type',
							'type'       => 'brs_radio',
							'value'      => array(
								"Filled"     => "filled",
								"Invertible" => "invertible",
								"Clean"      => "clean",
								"Roller"     => "roller",
								"Icon"       => "icon",
								"Airport"    => "airport",
								"Gradient"   => "gradient"
							),
							'images'     => array(
								"filled"     => 'counter/filled.png',
								"invertible" => 'counter/invertible.png',
								"clean"      => 'counter/clean.png',
								"roller"     => 'counter/roller.png',
								"icon"       => 'counter/icon.png',
								"airport"    => 'counter/airport.png',
								"gradient"   => 'counter/gradient.png'
							),
							'images_dim' => array(
								'w' => '320',
								'h' => '100'
							)
						),
						array(
							'type'             => 'textfield',
							'heading'          => __( 'Label', 'js_composer' ),
							'param_name'       => 'label',
							"value"            => "Some item title",
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),
						array(
							'type'             => 'textfield',
							'heading'          => __( 'Value', 'js_composer' ),
							'param_name'       => 'value',
							"value"            => "98",
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),
						array(
							'type'             => 'textfield',
							'heading'          => __( 'Max count', 'js_composer' ),
							'param_name'       => 'max_count',
							"value"            => "1800",
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),
						array(
							"heading"          => __( "Color", 'berserk' ),
							"param_name"       => "brs_title_color",
							"type"             => "brs_title",
							'edit_field_class' => 'vc_col-xs-12 vc_column',
						),

						array(
							"heading"          => __( "Color Scheme", 'berserk' ),
							"param_name"       => "color_scheme",
							"type"             => "brs_color_scheme",
							'colors'           => array(
								"Blue"   => 'blue',
								"Purple" => 'purple',
								"Pink"   => 'pink',
								"Aqua"   => 'aqua',
								"Gray"   => 'gray',
								"Brown"  => 'brown',
								"White"  => 'white',
								"Black"  => 'black',
							),
							'edit_field_class' => 'vc_col-xs-12 vc_column',
						),

						array(
							'heading'          => __( 'Use custom color', 'berserk' ),
							'param_name'       => 'use_custom_color',
							'type'             => 'brs_switch',
							'value'            => 'n',
							'options'          => array(
								'Yes' => 'y',
								'No'  => 'n',
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column'
						),

						array(
							'type'             => 'colorpicker',
							'heading'          => __( 'Custom Color', 'js_composer' ),
							'param_name'       => 'custom_color',
							'value'            => '#2775ff',
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'dependency'       => array(
								'element' => 'use_custom_color',
								'value'   => 'y',
							),
						),
						array(
							"heading"          => __( "Icon", 'berserk' ),
							"param_name"       => "brs_title",
							"type"             => "brs_title",
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
						),
						array(
							'type'             => 'dropdown',
							'heading'          => __( 'Icon library', 'berserk' ),
							'value'            => array(
								__( 'Font Awesome', 'berserk' ) => 'fontawesome',
								__( 'Open Iconic', 'berserk' )  => 'openiconic',
								__( 'Typicons', 'berserk' )     => 'typicons',
								__( 'Entypo', 'berserk' )       => 'entypo',
								__( 'Linecons', 'berserk' )     => 'linecons',
								__( 'Mono Social', 'berserk' )  => 'monosocial',
								__( 'Livicon', 'berserk' )      => 'livicon',
							),
							'param_name'       => 'btn_icon_type',
							'edit_field_class' => 'vc_col-sm-6 vc_column icon_option',
						),
						array(
							'type'             => 'iconpicker',
							'heading'          => __( 'Icon', 'berserk' ),
							'param_name'       => 'icon_fontawesome',
							'value'            => 'fa fa-adjust', // default value to backend editor admin_label
							'settings'         => array(
								'emptyIcon'    => false,
								'iconsPerPage' => 4000,
							),
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'fontawesome',
							),
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
						),
						array(
							'type'             => 'iconpicker',
							'heading'          => __( 'Icon', 'berserk' ),
							'param_name'       => 'icon_openiconic',
							'value'            => 'vc-oi vc-oi-dial', // default value to backend editor admin_label
							'settings'         => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'openiconic',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'openiconic',
							),
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
						),
						array(
							'type'             => 'iconpicker',
							'heading'          => __( 'Icon', 'berserk' ),
							'param_name'       => 'icon_typicons',
							'value'            => 'typcn typcn-adjust-brightness',
							// default value to backend editor admin_label
							'settings'         => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'typicons',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'typicons',
							),
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
						),
						array(
							'type'             => 'iconpicker',
							'heading'          => __( 'Icon', 'berserk' ),
							'param_name'       => 'icon_entypo',
							'value'            => 'entypo-icon entypo-icon-note',
							// default value to backend editor admin_label
							'settings'         => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'entypo',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'entypo',
							),
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
						),
						array(
							'type'             => 'iconpicker',
							'heading'          => __( 'Icon', 'berserk' ),
							'param_name'       => 'icon_linecons',
							'value'            => 'vc_li vc_li-heart', // default value to backend editor admin_label
							'settings'         => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'linecons',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'linecons',
							),
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
						),
						array(
							'type'             => 'iconpicker',
							'heading'          => __( 'Icon', 'berserk' ),
							'param_name'       => 'icon_monosocial',
							'value'            => 'vc-mono vc-mono-fivehundredpx',
							// default value to backend editor admin_label
							'settings'         => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'monosocial',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'monosocial',
							),
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
						),
						/*
						array(
							"heading"    => __( "Add livicon", 'berserk' ),
							"param_name" => "brs_btn_icon",
							"type"       => "brs_btn_icon",
							'dependency' => array(
								'element' => 'btn_icon_type',
								'value'   => 'livicon',
							),
						)*/
						array(
							"type"             => "textarea_html",
							"holder"           => "div",
							"class"            => "",
							"param_name"       => "content",
							"value"            => __( "", 'berserk' ),
							"description"      => "",
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'livicon',
							),
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
						),

					)
				) );
			}
		}

		public function shortcode_counter( $atts, $content = null ) {

      $libraries = array('component__counter');

			extract( shortcode_atts( array(
				'counter_type'     => 'filled',
				'label'            => 'Some item title',
				'value'            => '98',
				'max_count'        => '1800',
				'color_scheme'     => '',
				'use_custom_color' => 'n',
				'custom_color'     => '#2775ff',
				'btn_icon_type'    => 'fontawesome',
				'icon_monosocial'  => '',
				'icon_linecons'    => '',
				'icon_entypo'      => '',
				'icon_typicons'    => '',
				'icon_openiconic'  => '',
				'icon_fontawesome' => 'fa fa-trophy',

			), $atts ) );

			// store atts
			$atts_backup = self::$atts;

			vc_icon_element_fonts_enqueue( $btn_icon_type );

			$icon_class                     = array();
			$icon_class['type']             = $btn_icon_type;
			$icon_class['icon_livicon']     = '';
			$icon_class['icon_fontawesome'] = $icon_fontawesome;
			$icon_class['icon_openiconic']  = $icon_openiconic;
			$icon_class['icon_typicons']    = $icon_typicons;
			$icon_class['icon_entypo']      = $icon_entypo;
			$icon_class['icon_linecons']    = $icon_linecons;
			$icon_class['icon_monosocial']  = $icon_monosocial;
			$icon_class                     = $this->get_icon_class( $icon_class );
			$icon_html                      = ' <i class="icon ' . $icon_class . '"></i>';

			if ( $use_custom_color == 'y' ) {
				$icon_html = ' <i class="icon ' . $icon_class . '" style="color: ' . $custom_color . '"></i>';
			}

			if ( isset( $content ) && $btn_icon_type == 'livicon' ) {

				$svg_icon  = do_shortcode( $content );
				$icon_html = $svg_icon;
			}

			switch ( $counter_type ) {
				case "filled":
					$font_w_counter = 'font__weight-light';
					$font_w_h       = 'font__weight-light';

					switch ( $color_scheme ) {
						case "gray":
						case "brown":
						case "black":
							$font_w_counter = 'font__weight-semibold';
							$font_w_h       = 'font__weight-bold';
							break;

					}


					if ( $use_custom_color == 'y' ) {
						$output = '<div class="counter__wrapper-filled">
					                <div class="counter-wrap">
					                  <svg><circle style="stroke: ' . $custom_color . '"></circle></svg>
					                  <div class="counter-tri"><span class="before" style="background: ' . $custom_color . ';"></span></div>
					                  <div data-count-speed="3000" data-count-from="0" data-count-to="' . esc_attr( $value ) . '" data-count-max="' . $max_count . '" class="counter ' . $font_w_counter . '" style="color: ' . $custom_color . ';"></div>
					                </div>
					                <h4 class="font__family-montserrat ' . $font_w_h . ' font__size-19 line__height-22 mt-30">' . $label . '</h4>
					              </div>';
					} else {
						$output = '<div class="counter__wrapper-filled ' . $color_scheme . '">
						            <div class="counter-wrap">
						              <svg><circle></circle></svg>
						              <div class="counter-tri"><span class="before"></span></div>
						              <div data-count-speed="3000" data-count-from="0" data-count-to="' . esc_attr( $value ) . '" data-count-max="' . $max_count . '" class="counter ' . $font_w_counter . '"></div>
						            </div>
						            <h4 class="font__family-montserrat ' . $font_w_h . ' font__size-19 line__height-22 mt-30">' . $label . '</h4>
						          </div>';
					}


					break;

				case "invertible":
					if ( $use_custom_color == 'y' ) {
						$output = '<div class="counter__wrapper-invertible">
					                <div class="counter-wrap" style="background: linear-gradient(50deg,' . $custom_color . ',#000)">
					                  <span class="before" style="border-color: #000;"></span>
					                  <div data-count-speed="3000" data-count-from="0" data-count-to="' . esc_attr( $value ) . '" class="counter"></div>
					                </div>
					                <h4 class="font__family-montserrat font__weight-bold font__size-24 line__height-26 mt-30">' . $label . '</h4>
					              </div>';
					} else {
						$output = '<div class="counter__wrapper-invertible ' . $color_scheme . '">
						            <div class="counter-wrap">
						              <span class="before"></span>
						              <div data-count-speed="3000" data-count-from="0" data-count-to="' . $value . '" class="counter"></div>
						            </div>
						            <h4 class="font__family-montserrat font__weight-bold font__size-24 line__height-26 mt-30">' . $label . '</h4>
						          </div>';
					}

					break;

				case "clean":
					if ( $use_custom_color == 'y' ) {
						$unique_id = uniqid();

						$output = '<div class="counter__wrapper-clean">
					                <div class="counter-wrap">
					                  <svg>
					                    <linearGradient id="linearColors_' . $unique_id . '" x1="0" y1="0" x2="1" y2="1">
					                      <stop offset="0%" stop-color="' . $custom_color . '"></stop>
					                      <stop offset="40%" stop-color="' . $custom_color . '"></stop>
					                      <stop offset="60%" stop-color="#000"></stop>
					                      <stop offset="100%" stop-color="#000"></stop>
					                    </linearGradient>
					                    <circle r="115" cx="115" cy="115" class="external-circle" stroke-width="3" fill="none" stroke="url(#linearColors_' . $unique_id . ')"></circle>
					                  </svg>
					                  <div data-count-speed="3000" data-count-from="0" data-count-to="' . esc_attr( $value ) . '" class="counter" style="color: ' . $custom_color . '"></div>
					                </div>
					                <h4 class="font__family-montserrat font__weight-bold font__size-24 line__height-26 mt-40">' . $label . '</h4>
					              </div>';
					} else {
						$svg_circle = $this->get_svg( $color_scheme );
						$output     = '<div class="counter__wrapper-clean  ' . $color_scheme . '">
							            <div class="counter-wrap">
							              ' . $svg_circle . '
							              <div data-count-speed="3000" data-count-from="0" data-count-to="' . esc_attr( $value ) . '" class="counter"></div>
							            </div>
							            <h4 class="font__family-montserrat font__weight-bold font__size-24 line__height-26 mt-40">' . $label . '</h4>
							          </div>';
					}

					break;

				case "roller":
          $libraries[] = 'odometer';
					if ( $use_custom_color == 'y' ) {
						$output = '<div class="counter__wrapper-roller blue">
					                <div data-count-speed="30000" data-count-from="0" data-count-to="' . esc_attr( $value ) . '" class="counter odometer" style="color: ' . $custom_color . '"></div>
					                <h4 class="font__family-montserrat font__weight-semibold font__size-24 line__height-26 mt-70">' . $label . '</h4>
					              </div>';
					} else {
						$output = '<div class="counter__wrapper-roller ' . $color_scheme . '">
						            <div data-count-speed="30000" data-count-from="0" data-count-to="' . esc_attr( $value ) . '" class="counter odometer"></div>
						            <h4 class="font__family-montserrat font__weight-semibold font__size-24 line__height-26 mt-70">' . $label . '</h4>
						          </div>';
					}

					break;
				case "icon":
					if ( $use_custom_color == 'y' ) {
						$output = '<div class="counter__wrapper-icon">
					                ' . $icon_html . '
					                <div class="cont">
					                  <div data-count-speed="3000" data-count-from="0" data-count-to="' . esc_attr( $value ) . '" class="counter" style="color: ' . $custom_color . '"></div>
					                  <p class="font__family-montserrat font__weight-semibold font__size-16 mt-10">' . $label . '</p>
					                </div>
					              </div>';
					} else {
						$output = '<div class="counter__wrapper-icon ' . $color_scheme . '">
					            ' . $icon_html . '
					            <div class="cont">
					              <div data-count-speed="3000" data-count-from="0" data-count-to="' . esc_attr( $value ) . '" class="counter"></div>
					              <p class="font__family-montserrat font__weight-semibold font__size-16 mt-10">' . $label . '</p>
					            </div>
					          </div>';
					}

					break;
				case "airport":

					if ( $use_custom_color == 'y' ) {
						$output = '<div class="counter__wrapper-airport">
					                <div data-count-speed="3000" data-count-from="100" data-count-to="' . esc_attr( $value ) . '" class="counter" style="background: linear-gradient(80deg,' . $custom_color . ',#000)"></div>
					                <p class="font__family-montserrat font__size-36 line__height-40 text-uppercase">' . $label . '</p>
					              </div>';
					} else {
						$output = '<div class="counter__wrapper-airport ' . $color_scheme . '">
						            <div data-count-speed="3000" data-count-from="100" data-count-to="' . esc_attr( $value ) . '" class="counter"></div>
						            <p class="font__family-montserrat font__size-36 line__height-40 text-uppercase">' . $label . '</p>
						          </div>';
					}

					break;
				case "gradient":
					if ( $use_custom_color == 'y' ) {
						$output = '<div class="counter__wrapper-gradient">
					                <div class="counter-wrap" style="background: linear-gradient(180deg,' . $custom_color . ',#000)">
					                  <div data-count-speed="3000" data-count-from="0" data-count-to="' . esc_attr( $value ) . '" class="counter"></div>
					                </div>
					                <h4 class="font__family-montserrat font__weight-bold font__size-24 line__height-26 mt-30">' . $label . '</h4>
					              </div>';
					} else {
						$output = '<div class="counter__wrapper-gradient ' . $color_scheme . '">
						            <div class="counter-wrap">
						              <div data-count-speed="3000" data-count-from="0" data-count-to="' . esc_attr( $value ) . '" class="counter"></div>
						            </div>
						            <h4 class="font__family-montserrat font__weight-bold font__size-24 line__height-26 mt-30">' . $label . '</h4>
						          </div>';
					}

					break;
			}


			brs_add_libraries($libraries);

			return $output;
		}

		protected function get_svg( $color ) {
			$svg = '';
			switch ( $color ) {

				case "blue":
					$svg = '<svg>
			                    <linearGradient id="linearColors1" x1="0" y1="0" x2="1" y2="1">
		                        	<stop offset="0%" stop-color="#0F5AE0"></stop>
			                     	<stop offset="40%" stop-color="#0F5AE0"></stop>
			                      	<stop offset="60%" stop-color="#7400BA"></stop>
			                     	<stop offset="100%" stop-color="#7400BA"></stop>
			                    </linearGradient>
			                    <circle r="115" cx="115" cy="115" class="external-circle" stroke-width="3" fill="none" stroke="url(#linearColors1)"></circle>
			                  </svg>';
					break;
				case "purple":
					$svg = '<svg>
			                    <linearGradient id="linearColors2" x1="0" y1="0" x2="1" y2="1">
			                      <stop offset="0%" stop-color="#6e50c2"></stop>
			                      <stop offset="40%" stop-color="#6e50c2"></stop>
			                      <stop offset="60%" stop-color="#661ada"></stop>
			                      <stop offset="100%" stop-color="#661ada"></stop>
			                    </linearGradient>
			                    <circle r="115" cx="115" cy="115" class="external-circle" stroke-width="3" fill="none" stroke="url(#linearColors2)"></circle>
			                  </svg>';
					break;
				case "pink":
					$svg = '<svg>
			                    <linearGradient id="linearColors3" x1="0" y1="0" x2="1" y2="1">
			                      <stop offset="0%" stop-color="#C423EE"></stop>
			                      <stop offset="40%" stop-color="#C423EE"></stop>
			                      <stop offset="60%" stop-color="#EE23EC"></stop>
			                      <stop offset="100%" stop-color="#EE23EC"></stop>
			                    </linearGradient>
			                    <circle r="115" cx="115" cy="115" class="external-circle" stroke-width="3" fill="none" stroke="url(#linearColors3)"></circle>
			                  </svg>';
					break;
				case "aqua":
					$svg = '<svg>
			                    <linearGradient id="linearColors4" x1="0" y1="0" x2="1" y2="1">
			                      <stop offset="0%" stop-color="#15BDFF"></stop>
			                      <stop offset="40%" stop-color="#15BDFF"></stop>
			                      <stop offset="60%" stop-color="#15DBFF"></stop>
			                      <stop offset="100%" stop-color="#15DBFF"></stop>
			                    </linearGradient>
			                    <circle r="115" cx="115" cy="115" class="external-circle" stroke-width="3" fill="none" stroke="url(#linearColors4)"></circle>
			                  </svg>';
					break;
				case "gray":
					$svg = '<svg>
			                    <linearGradient id="linearColors5" x1="0" y1="0" x2="1" y2="1">
			                    	<stop offset="0%" stop-color="#B2B2B2"></stop>
			                    	<stop offset="40%" stop-color="#B2B2B2"></stop>
			                    	<stop offset="60%" stop-color="#f1f1f1"></stop>
			                    	<stop offset="100%" stop-color="#f1f1f1"></stop>
			                    </linearGradient>
			                    <circle r="115" cx="115" cy="115" class="external-circle" stroke-width="3" fill="none" stroke="url(#linearColors5)"></circle>
			                  </svg>';
					break;
				case "brown":
					$svg = '<svg>
			                    <linearGradient id="linearColors6" x1="0" y1="0" x2="1" y2="1">
			                      	<stop offset="0%" stop-color="#AB752B"></stop>
				                    <stop offset="40%" stop-color="#AB752B"></stop>
				                    <stop offset="60%" stop-color="#D5AA6F"></stop>
				                    <stop offset="100%" stop-color="#D5AA6F"></stop>
			                    </linearGradient>
			                    <circle r="115" cx="115" cy="115" class="external-circle" stroke-width="3" fill="none" stroke="url(#linearColors6)"></circle>
			                  </svg>';
					break;
				case "black":
					$svg = '<svg>
			                    <linearGradient id="linearColors7" x1="0" y1="0" x2="1" y2="1">
			                      	<stop offset="0%" stop-color="#000000"></stop>
				                    <stop offset="20%" stop-color="#000000"></stop>
				                    <stop offset="50%" stop-color="#383838"></stop>
				                    <stop offset="100%" stop-color="#383838"></stop>
			                    </linearGradient>
			                    <circle r="115" cx="115" cy="115" class="external-circle" stroke-width="3" fill="none" stroke="url(#linearColors7)"></circle>
			                  </svg>';
					break;


			}

			return $svg;
		}

		protected function get_icon_class( $atts ) {
			$icon_class = '';

			$icon_class = $atts[ 'icon_' . $atts['type'] ];

			if ( empty( $icon_class ) ) {
				$icon_class = 'fa fa-trophy';
			}

			return $icon_class;
		}


	}

	// create shortcode
	BRS_Counter::get_instance();

}
