<?php
/**
 * Shortcodes class.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function berserk_shortcodes_dynamic_filter() {
	$params = array(
		array(
			'heading'          => __( 'Dynamic Content', 'berserk' ),
			'param_name'       => 'dynamic_content',
			'type'             => 'brs_switch',
			'value'            => 'no',
			'options'          => array(
				'Yes' => 'y',
				'No'  => 'no',
			),
			'edit_field_class' => 'vc_col-sm-6 vc_column'
		),

		array(
			"heading"    => __( "Add Item from custom post type", 'berserk' ),
			"param_name" => "custom_items",
			"type"       => "brs_add_custom_post_type",
		),

		array(
			'type'       => 'param_group',
			'heading'    => __( 'Filters', 'js_composer' ),
			'param_name' => 'filters',
			'value'      => urlencode( json_encode( array(
				array(
					'filter_type' => 'post_type',
				),
				array(
					'filter_type' => 'post_status',
					'post_status' => 'publish'
				),

			) ) ),
			'params'     => array(

				array(
					'type'             => 'dropdown',
					'heading'          => __( 'Filter type', 'berserk' ),
					'value'            => array(
						__( 'Post type', 'berserk' )           => 'post_type',
						__( 'Taxonomies', 'berserk' )          => 'taxonomies',
						__( 'Post Status', 'berserk' )         => 'post_status',
						__( 'Post with Thumbnail', 'berserk' ) => 'post_with_thumbnail',
						__( 'Numberposts', 'berserk' )         => 'numberposts',
					),
					'param_name'       => 'filter_type',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					'admin_label'      => true,
				),

				array(
					'type'             => 'dropdown',
					'heading'          => __( 'Post type', 'js_composer' ),
					'param_name'       => 'post_type',
					'value'            => BRS_Shortcodes_VCParams::get_all_post_types(),
					"dependency"       => array(
						"element" => "filter_type",
						"value"   => array( 'post_type' ),
					),
					'edit_field_class' => 'vc_col-sm-6 vc_column',
				),
				array(
					'type'             => 'dropdown',
					'heading'          => __( 'Taxonomies', 'js_composer' ),
					'param_name'       => 'taxonomies',
					'value'            => BRS_Shortcodes_VCParams::get_taxonomies( 'post' ),
					"dependency"       => array(
						"element" => "filter_type",
						"value"   => array( 'taxonomies' ),
					),
					'edit_field_class' => 'vc_col-sm-6 vc_column',
				),
				array(
					'type'             => 'dropdown',
					'heading'          => __( 'Taxonomy values', 'js_composer' ),
					'param_name'       => 'taxonomy_values',
					'value'            => BRS_Shortcodes_VCParams::get_terms( 'category' ),
					"dependency"       => array(
						"element" => "filter_type",
						"value"   => array( 'taxonomies' ),
					),
					'edit_field_class' => 'vc_col-sm-6 vc_column',
				),
				array(
					'type'             => 'dropdown',
					'heading'          => __( 'Post Status', 'js_composer' ),
					'param_name'       => 'post_status',
					'value'            => BRS_Shortcodes_VCParams::get_post_statuses(),
					"dependency"       => array(
						"element" => "filter_type",
						"value"   => array( 'post_status' ),
					),
					'std'              => 'publish',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
				),

				array(
					"param_name"       => "post_with_thumbnail",
					"type"             => "checkbox",
					"value"            => array(
						"Post With Thumbnail" => "y",
					),
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					"dependency"       => array(
						"element" => "filter_type",
						"value"   => array( 'post_with_thumbnail' ),
					),
				),
				array(
					'type'             => 'textfield',
					'heading'          => __( 'Numberposts', 'js_composer' ),
					'param_name'       => 'numberposts',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					"dependency"       => array(
						"element" => "filter_type",
						"value"   => array( 'numberposts' ),
					),
				),

			),
			"dependency" => array(
				"element" => "dynamic_content",
				"value"   => array( 'y' ),
			),
		),

		array(
			'type'             => 'dropdown',
			'heading'          => __( 'Orderby', 'js_composer' ),
			'param_name'       => 'orderby',
			'value'            => BRS_Shortcodes_VCParams::get_orderby_values(),
			"dependency"       => array(
				"element" => "dynamic_content",
				"value"   => array( 'y' ),
			),
			'std'              => 'date',
			'edit_field_class' => 'vc_col-sm-6 vc_column',
		),
		array(
			'type'             => 'dropdown',
			'heading'          => __( 'Direction', 'js_composer' ),
			'param_name'       => 'order_direction',
			'value'            => array(
				'ASC'  => 'ASC',
				'DESC' => 'DESC'
			),
			"dependency"       => array(
				"element" => "dynamic_content",
				"value"   => array( 'y' ),
			),
			'edit_field_class' => 'vc_col-sm-6 vc_column',
		)
	);

	return $params;
}


function berserk_shortcodes_dynamic_filter_process( $filters, $orderby, $order_direction ) {

	$args                = array();
	$args['numberposts'] = - 1;
	$filters             = is_array( $filters ) ? $filters : vc_param_group_parse_atts( $filters );

	foreach ( $filters as $filter ) {
		$filter_type = $filter['filter_type'];
		switch ( $filter_type ) {
			case "post_type":
				$args['post_type'] = $filter['post_type'];
				break;
			case "taxonomies":
				$args['tax_query'][]           =
					array(
						'taxonomy' => $filter['taxonomies'],
						'field'    => 'slug',
						'terms'    => $filter['taxonomy_values']
					);
				$args['tax_query']['relation'] = 'OR';
				break;
			case "post_status":
				$args['post_status'] = $filter['post_status'];
				break;

			case "post_with_thumbnail":
				if ( isset( $filter['post_with_thumbnail'] ) && $filter['post_with_thumbnail'] == 'y' ) {
					$args['meta_query'] = array(
						array(
							'key'     => '_thumbnail_id',
							'compare' => 'EXISTS'
						)
					);
				}
				break;
			case "numberposts":
				if ( isset( $filter['numberposts'] ) ) {
					$args['numberposts'] = $filter['numberposts'];
				}
				break;
			case "offset":
				if ( isset( $filter['offset'] ) ) {
					$args['offset'] = $filter['offset'];
				}
				break;

			case "price":

				if ( isset( $filter['min_price'] ) && isset( $filter['max_price'] ) ) {
					$args['meta_query'] = array(
						array(
							'key'     => '_price',
							'value'   => array( $filter['min_price'], $filter['max_price'] ),
							'compare' => 'BETWEEN',
							'type'    => 'NUMERIC'
						),
					);
				}

				break;

			case "color":
				if ( isset( $filter['color'] ) ) {
					$args['tax_query'] = array(
						array(
							'taxonomy' => 'pa_color',
							'field'    => 'slug',
							'terms'    => $filter['color']
						)
					);
				}
				break;

			case "brand":
				if ( isset( $filter['brand'] ) ) {
					$args['tax_query'] = array(
						array(
							'taxonomy' => 'pa_brand',
							'field'    => 'slug',
							'terms'    => $filter['brand']
						)
					);
				}
				break;
		}
	}

	if ( isset( $orderby ) ) {
		$args['orderby'] = $orderby;
	}
	if ( isset( $order_direction ) ) {
		$args['order'] = $order_direction;
	}

	return $args;
}

/**
 * Print some required information for JavaScript function
 */
function berserk_shortcodes_dynamic_filter_data( $atts ) {

	$atts['filters'] = is_array( $atts['filters'] ) ? $atts['filters'] : vc_param_group_parse_atts( $atts['filters'] );

	// Check if there are more posts
	$args = berserk_shortcodes_dynamic_filter_process( $atts['filters'], $atts['orderby'], $atts['order_direction'] );
	// Set the offset as the numberposts, so will be quired the next items
	$args['offset'] = isset( $_POST['numberposts'] ) ? $_POST['numberposts'] + $_POST['offset'] : $args['numberposts'];

	if ( isset( $atts['posts_count'] ) ) {
		$args['offset'] = $atts['posts_count'];
		unset( $args['numberposts'] );
	}


	$posts = get_posts( $args );
	// Flag which means if there is more posts
	$more_posts = count( $posts );

	// Print all attributes so we will render the same data
	$output = '<div class = "brk-atts hide" data-more-posts = "' . $more_posts . '">' . json_encode( $atts ) . '</div>';

	return $output;
}

/**
 * Get form with all available icons
 */
function berserk_shortcodes_icons( $options = array() ) {
	$options                     = ! is_array( $options ) ? array() : $options;
	$options['edit_field_class'] = isset( $options['edit_field_class'] ) ? $options['edit_field_class'] : '';
	$options['dependency']       = isset( $options['dependency'] ) ? $options['dependency'] : '';
	$params                      = array();
	$params[]                    = array(
		'type'             => 'dropdown',
		'heading'          => __( 'Icon library', 'berserk' ),
		'value'            => array(
			__( 'Livicon', 'berserk' )      => 'livicon',
			__( 'Font Awesome', 'berserk' ) => 'fontawesome',
			__( 'Open Iconic', 'berserk' )  => 'openiconic',
			__( 'Typicons', 'berserk' )     => 'typicons',
			__( 'Entypo', 'berserk' )       => 'entypo',
			__( 'Linecons', 'berserk' )     => 'linecons',
			__( 'Mono Social', 'berserk' )  => 'monosocial',
		),
		'param_name'       => 'btn_icon_type',
		'edit_field_class' => 'vc_col-sm-6 vc_column icon_option ' . $options['edit_field_class'],
		'dependency'       => $options['dependency']
	);
	$params[]                    = array(
		'type'             => 'iconpicker',
		'heading'          => __( 'Icon', 'berserk' ),
		'param_name'       => 'icon_fontawesome',
		'value'            => 'fa fa-facebook', // default value to backend editor admin_label
		'settings'         => array(
			'emptyIcon'    => false,
			'iconsPerPage' => 4000,
		),
		'dependency'       => array(
			'element' => 'btn_icon_type',
			'value'   => 'fontawesome',
		),
		'edit_field_class' => 'icon_option vc_col-xs-12 vc_column ' . $options['edit_field_class'],
	);
	$params[]                    = array(
		'type'             => 'iconpicker',
		'heading'          => __( 'Icon', 'berserk' ),
		'param_name'       => 'icon_openiconic',
		'value'            => 'vc-oi vc-oi-dial', // default value to backend editor admin_label
		'settings'         => array(
			'emptyIcon'    => false, // default true, display an "EMPTY" icon?
			'type'         => 'openiconic',
			'iconsPerPage' => 4000, // default 100, how many icons per/page to display
		),
		'dependency'       => array(
			'element' => 'btn_icon_type',
			'value'   => 'openiconic',
		),
		'edit_field_class' => 'icon_option vc_col-xs-12 vc_column ' . $options['edit_field_class'],
	);
	$params[]                    = array(
		'type'             => 'iconpicker',
		'heading'          => __( 'Icon', 'berserk' ),
		'param_name'       => 'icon_typicons',
		'value'            => 'typcn typcn-adjust-brightness',
		// default value to backend editor admin_label
		'settings'         => array(
			'emptyIcon'    => false, // default true, display an "EMPTY" icon?
			'type'         => 'typicons',
			'iconsPerPage' => 4000, // default 100, how many icons per/page to display
		),
		'dependency'       => array(
			'element' => 'btn_icon_type',
			'value'   => 'typicons',
		),
		'edit_field_class' => 'icon_option vc_col-xs-12 vc_column ' . $options['edit_field_class'],
	);
	$params[]                    = array(
		'type'             => 'iconpicker',
		'heading'          => __( 'Icon', 'berserk' ),
		'param_name'       => 'icon_entypo',
		'value'            => 'entypo-icon entypo-icon-note',
		// default value to backend editor admin_label
		'settings'         => array(
			'emptyIcon'    => false, // default true, display an "EMPTY" icon?
			'type'         => 'entypo',
			'iconsPerPage' => 4000, // default 100, how many icons per/page to display
		),
		'dependency'       => array(
			'element' => 'btn_icon_type',
			'value'   => 'entypo',
		),
		'edit_field_class' => 'icon_option vc_col-xs-12 vc_column ' . $options['edit_field_class'],
	);
	$params[]                    = array(
		'type'             => 'iconpicker',
		'heading'          => __( 'Icon', 'berserk' ),
		'param_name'       => 'icon_linecons',
		'value'            => 'vc_li vc_li-heart', // default value to backend editor admin_label
		'settings'         => array(
			'emptyIcon'    => false, // default true, display an "EMPTY" icon?
			'type'         => 'linecons',
			'iconsPerPage' => 4000, // default 100, how many icons per/page to display
		),
		'dependency'       => array(
			'element' => 'btn_icon_type',
			'value'   => 'linecons',
		),
		'edit_field_class' => 'icon_option vc_col-xs-12 vc_column ' . $options['edit_field_class'],
	);
	$params[]                    = array(
		'type'             => 'iconpicker',
		'heading'          => __( 'Icon', 'berserk' ),
		'param_name'       => 'icon_monosocial',
		'value'            => 'vc-mono vc-mono-fivehundredpx',
		// default value to backend editor admin_label
		'settings'         => array(
			'emptyIcon'    => false, // default true, display an "EMPTY" icon?
			'type'         => 'monosocial',
			'iconsPerPage' => 4000, // default 100, how many icons per/page to display
		),
		'dependency'       => array(
			'element' => 'btn_icon_type',
			'value'   => 'monosocial',
		),
		'edit_field_class' => 'icon_option vc_col-xs-12 vc_column ' . $options['edit_field_class'],
	);
	$params[]                    = array(
		"heading"          => __( "Add livicon", 'berserk' ),
		"param_name"       => "brs_btn_icon",
		"type"             => "brs_btn_icon",
		'dependency'       => array(
			'element' => 'btn_icon_type',
			'value'   => 'livicon',
		),
		'edit_field_class' => 'vc_col-sm-6 vc_column icon_option ' . $options['edit_field_class'],
	);

	return $params;
}

function berserk_shortcodes_icons_process( $atts ) {

	$atts = shortcode_atts( array(
		'btn_icon_type'    => 'livicon',
		'icon_fontawesome' => '',
		'icon_openiconic'  => '',
		'icon_typicons'    => '',
		'icon_entypo'      => '',
		'icon_linecons'    => '',
		'icon_monosocial'  => '',
		'brs_btn_icon'     => '',
		'option_type'      => ''
	), $atts );

	extract( $atts );

	if ( $btn_icon_type == 'livicon' ) {
		$icon = vc_param_group_parse_atts( $brs_btn_icon );
		//$icon['val'] = $brs_btn_icon;
		$find      = "\\";
		$svg_icon  = do_shortcode( str_replace( $find, '', $icon['val'] ) );
		$icon_html = $svg_icon;

		if ( $option_type == 'parsed_shortcode' ) {
			$icon_html = do_shortcode( $brs_btn_icon );
		}

	} else {
		$icon_class = $atts[ 'icon_' . $btn_icon_type ] ? $atts[ 'icon_' . $btn_icon_type ] : '';
		$icon_html  = ' <i class="' . $icon_class . '"></i>';

		vc_icon_element_fonts_enqueue( $btn_icon_type );
	}

	return $icon_html;
}

function berserk_shortcodes_column_params() {
	$params = array(
		array(
			'type'             => 'dropdown',
			'heading'          => __( 'Size', 'js_composer' ),
			'param_name'       => 'column_size',
			'admin_label'      => true,
			'value'            => array(
				'col-lg' => ' ',
				'auto'   => 'auto',
				'1'      => '1',
				'2'      => '2',
				'3'      => '3',
				'4'      => '4',
				'5'      => '5',
				'6'      => '6',
				'7'      => '7',
				'8'      => '8',
				'9'      => '9',
				'10'     => '10',
				'11'     => '11',
				'12'     => '12',
			),
			'edit_field_class' => 'vc_col-xs-3 vc_column',
		),
		array(
			'type'             => 'dropdown',
			'heading'          => __( 'Horizontal Align', 'js_composer' ),
			'param_name'       => 'column_align',
			'value'            => array(
				'None'   => 'none',
				'Left'   => 'left',
				'Center' => 'center',
				'Right'  => 'right',
			),
			'edit_field_class' => 'vc_col-xs-3 vc_column',
		),
		array(
			'type'             => 'dropdown',
			'heading'          => __( 'Vertical Align', 'js_composer' ),
			'param_name'       => 'vertical_align',
			'value'            => array(
				'None'    => 'none',
				'Stretch' => 'stretch',
				'Center'  => 'center',
			),
			'edit_field_class' => 'vc_col-xs-3 vc_column',
		),
		array(
			'type'             => 'dropdown',
			'heading'          => __( 'Background', 'js_composer' ),
			'param_name'       => 'background',
			'value'            => array(
				'None'    => 'none',
				'White'   => 'bg-white',
				'Dark'    => 'bg-dark',
				'Primary' => 'brk-bg-primary',
			),
			'edit_field_class' => 'vc_col-xs-3 vc_column',
		),
		array(
			'type'             => 'dropdown',
			'heading'          => __( 'Padding right', 'js_composer' ),
			'param_name'       => 'padding_right',
			'value'            => array(
				'None'  => 'none',
				'0 px'  => 'pr-0',
				'10 px' => 'pr-10',
				'20 px' => 'pr-20',
				'30 px' => 'pr-30',
				'40 px' => 'pr-40',
				'50 px' => 'pr-50',
				'60 px' => 'pr-60',
				'70 px' => 'pr-70',
			),
			'edit_field_class' => 'vc_col-xs-3 vc_column',
		),
		array(
			'type'             => 'dropdown',
			'heading'          => __( 'Margin right', 'js_composer' ),
			'param_name'       => 'margin_right',
			'value'            => array(
				'None'  => 'none',
				'10 px' => 'mr-10',
				'20 px' => 'mr-20',
				'30 px' => 'mr-30',
				'40 px' => 'mr-40',
			),
			'edit_field_class' => 'vc_col-xs-3 vc_column',
		),
		array(
			'type'             => 'dropdown',
			'heading'          => __( 'Display', 'js_composer' ),
			'param_name'       => 'dispalay',
			'value'            => array(
				'Default' => 'default',
				'Flex'    => 'flex',
			),
			'edit_field_class' => 'vc_col-xs-3 vc_column',
		),
		array(
			'param_name'       => 'border_right',
			'type'             => 'checkbox',
			'value'            => array(
				'Border right' => 'y',
			),
			'edit_field_class' => 'vc_col-xs-3 vc_column',
		),
		array(
			'param_name'       => 'hide_mobile',
			'type'             => 'checkbox',
			'value'            => array(
				'Hide on Mobile' => 'y',
			),
			'edit_field_class' => 'vc_col-xs-3 vc_column',
		)
	);

	return $params;
}

function berserk_shortcodes_order_params( $prefix = '' ) {

	$params = array();

	$params[] = array(
		'type'             => 'dropdown',
		'heading'          => __( 'Region', 'berserk' ),
		'admin_label'      => true,
		'value'            => array(
			__( 'None', 'berserk' )       => '',
			__( 'Top Header', 'berserk' ) => 'top_header',
			__( 'Main Bar', 'berserk' )   => 'main_bar',
			__( 'Side Menu', 'berserk' )  => 'side_menu',
		),
		'param_name'       => $prefix . 'brk_region',
		'edit_field_class' => 'vc_col-xs-4 vc_column',
	);

	$params[] = array(
		'type'             => 'dropdown',
		'heading'          => __( 'Column', 'js_composer' ),
		'param_name'       => $prefix . 'brk_column',
		'admin_label'      => true,
		'value'            => array(
			'1'  => '1',
			'2'  => '2',
			'3'  => '3',
			'4'  => '4',
			'5'  => '5',
			'6'  => '6',
			'7'  => '7',
			'8'  => '8',
			'9'  => '9',
			'10' => '10',
			'11' => '11',
			'12' => '12',
		),
		'edit_field_class' => 'vc_col-xs-4 vc_column',
		'dependency'       => array(
			'element' => $prefix . 'brk_region',
			'value'   => array( 'top_header', 'main_bar', 'side_menu' ),
		),
	);

	$params[] = array(
		'type'             => 'dropdown',
		'heading'          => __( 'Order', 'js_composer' ),
		'param_name'       => $prefix . 'brk_order',
		'value'            => array(
			'1'  => '1',
			'2'  => '2',
			'3'  => '3',
			'4'  => '4',
			'5'  => '5',
			'6'  => '6',
			'7'  => '7',
			'8'  => '8',
			'9'  => '9',
			'10' => '10',
			'11' => '11',
			'12' => '12',
		),
		'edit_field_class' => 'vc_col-xs-4 vc_column',
		'dependency'       => array(
			'element' => $prefix . 'brk_region',
			'value'   => array( 'top_header', 'main_bar', 'side_menu' ),
		),
	);

	if ( $prefix == 'social_' ) {
		$params[] = array(
			'type'             => 'dropdown',
			'heading'          => __( 'Type', 'js_composer' ),
			'param_name'       => $prefix . 'brk_skin',
			'value'            => array(
				'None'     => 'none',
				'Vertical' => 'vertical',
			),
			'edit_field_class' => 'vc_col-xs-4 vc_column',
			'dependency'       => array(
				'element' => $prefix . 'brk_region',
				'value'   => array( 'top_header', 'main_bar', 'side_menu' ),
			),
		);
	}

	if ( $prefix == 'compare_' || $prefix == 'wishlist_' || $prefix == 'call_' ) {
		$params[] = array(
			'type'             => 'dropdown',
			'heading'          => __( 'Skin', 'js_composer' ),
			'param_name'       => $prefix . 'brk_skin',
			'value'            => array(
				'None'                     => 'none',
				'Default'                  => '1',
				'Small Font'               => '2',
				'Font With Opacity'        => '3',
				'Bold Font'                => '4',
				'Gray on White background' => 'gray_white_bg',
				'Gray on Dark background'  => 'gray_dark_bg',
				'Text White'               => 'text_white',
				'Alternate'                => 'alternate'
			),
			'edit_field_class' => 'vc_col-xs-4 vc_column',
			'dependency'       => array(
				'element' => $prefix . 'brk_region',
				'value'   => array( 'top_header', 'main_bar', 'side_menu' ),
			),
		);
	}

	if ( $prefix == 'cart_' ) {
		$params[] = array(
			'type'             => 'dropdown',
			'heading'          => __( 'Skin', 'js_composer' ),
			'param_name'       => $prefix . 'brk_skin',
			'value'            => array(
				'None'                     => 'none',
				'Small Font'               => '1',
				'Interactive'              => 'interactive',
				'Gray on White background' => 'gray_white_bg',
				'Gray on Dark background'  => 'gray_dark_bg',
				'Text White'               => 'text_white'
			),
			'edit_field_class' => 'vc_col-xs-4 vc_column',
			'dependency'       => array(
				'element' => $prefix . 'brk_region',
				'value'   => array( 'top_header', 'main_bar', 'side_menu' ),
			),
		);
	}

	if ( $prefix == 'custombutton_' ) {

		$params[] = array(
			'type'             => 'textfield',
			'heading'          => __( 'Title', 'js_composer' ),
			'param_name'       => $prefix . 'brk_title',
			'value'            => '',
			'edit_field_class' => 'vc_col-xs-3 vc_column',
			'description'      => __( 'Split title with "^" symbol', 'js_composer' )
		);

		$params[] = array(
			'type'             => 'textfield',
			'heading'          => esc_html__( 'Title On Hover', 'berserk' ),
			'param_name'       => $prefix . 'brk_title_hover',
			'value'            => '',
			'edit_field_class' => 'vc_col-xs-3 vc_column',
		);

		$params[] = array(
			'type'       => 'vc_link',
			'heading'    => __( 'Link URL', 'js_composer' ),
			'param_name' => $prefix . 'brk_url',
		);

		$params[] = array(
			'type'             => 'dropdown',
			'heading'          => __( 'Button type', 'js_composer' ),
			'param_name'       => $prefix . 'brk_button_type',
			'value'            => array(
				'Inside-Out' => 'btn-inside-out',
				'Prime'      => 'btn-prime',
				'White'      => 'white',
				'Gradient'   => 'gradient',
			),
			'edit_field_class' => 'vc_col-xs-4 vc_column',
		);
	}

	if ( $prefix == 'logo_' ) {

		$params[] = array(
			"param_name"       => $prefix . "brk_text_center",
			'heading'          => __( 'Align center', 'js_composer' ),
			"type"             => "checkbox",
			"value"            => array(
				"Align center" => "y",
			),
			'edit_field_class' => 'vc_col-sm-4 vc_column',
		);

		$params[] = array(
			"param_name"       => $prefix . "brk_ml",
			'heading'          => esc_html__( 'Margin left 10px', 'berserk' ),
			"type"             => "checkbox",
			"value"            => array(
				"Margin left 10px" => "10",
			),
			'edit_field_class' => 'vc_col-sm-4 vc_column',
		);

		$params[] = array(
			'type'             => 'dropdown',
			'heading'          => __( 'Background', 'js_composer' ),
			'param_name'       => $prefix . 'brk_background',
			'value'            => array(
				'None'    => 'none',
				'White'   => 'bg-white',
				'Dark'    => 'bg-dark',
				'Primary' => 'brk-bg-primary',
			),
			'edit_field_class' => 'vc_col-xs-4 vc_column',
		);

	}

	if ( $prefix == 'language_' ) {
		$params[] = array(
			'type'             => 'dropdown',
			'heading'          => __( 'Language Selector Type', 'js_composer' ),
			'param_name'       => $prefix . 'brk_langs_type',
			'value'            => array(
				'Default'                => 'default',
				'Interactive'            => 'interactive',
				'Square'                 => 'square',
				'Text White Interactive' => 'text_white'
			),
			'edit_field_class' => 'vc_col-xs-4 vc_column',
		);
	}

	if ( $prefix == 'side_menu_' ) {
		$params[] = array(
			'type'             => 'dropdown',
			'heading'          => __( 'Side Menu Icon Type', 'js_composer' ),
			'param_name'       => $prefix . 'brk_smi_type',
			'value'            => array(
				'Small'          => 'small',
				'Big'            => 'big',
				'Custom Lines'   => 'custom',
				'Custom Lines 2' => 'custom_2',
				'White'          => 'white',
			),
			'edit_field_class' => 'vc_col-xs-4 vc_column',
		);
	}

	if ( $prefix == 'search_' ) {
		$params[] = array(
			'type'             => 'dropdown',
			'heading'          => __( 'Search Type', 'js_composer' ),
			'param_name'       => $prefix . 'brk_skin',
			'value'            => array(
				'Default'     => 'default',
				'Interactive' => 'interactive',
				'White'       => 'white',
			),
			'edit_field_class' => 'vc_col-xs-4 vc_column',
		);
	}

	return $params;
}

function berserk_shortcodes_header_settings( $prefix_name = '' ) {
	$params    = array();
	$params_bg = berserk_shortcodes_backgrounds( $prefix_name );

	$params = array_merge( $params, $params_bg );

	/*
	foreach ( $params as $i => $param ) {
		$params[ $i ]['param_name'] = $prefix_name . $params[ $i ]['param_name'];
	}*/

	$params[ $prefix_name . 'height' ] = array(
		'type'             => 'textfield',
		'heading'          => __( 'Override height: px', 'js_composer' ),
		'param_name'       => $prefix_name . 'height',
		'value'            => '',
		'edit_field_class' => 'vc_col-sm-3 vc_column',
	);

	$params[ $prefix_name . 'height_scroll' ] = array(
		'type'             => 'textfield',
		'heading'          => __( 'Override sticky height: px', 'js_composer' ),
		'param_name'       => $prefix_name . 'height_scroll',
		'value'            => '',
		'edit_field_class' => 'vc_col-sm-3 vc_column',
	);

	$params[ $prefix_name . 'full_width' ] = array(
		'param_name'       => $prefix_name . 'fullwidth',
		'type'             => 'dropdown',
		'heading'          => __( 'Full Width', 'berserk' ),
		'value'            => array(
			__( 'None', 'berserk' )                        => 'none',
			__( 'Full Width', 'berserk' )                  => 'full_width',
			__( 'Full Width without paddings', 'berserk' ) => 'full_width_no_paddings',
		),
		'edit_field_class' => 'vc_col-xs-3 vc_column',
	);

	$params[ $prefix_name . 'border_bottom' ] = array(
		'param_name'       => $prefix_name . 'border_bottom',
		'type'             => 'dropdown',
		'heading'          => __( 'Border Bottom', 'berserk' ),
		'value'            => array(
			__( 'None', 'berserk' )       => 'none',
			__( 'Ultralight', 'berserk' ) => 'ultralight',
			__( 'Light', 'berserk' )      => 'light',
			__( 'Dark', 'berserk' )       => 'dark',
		),
		'edit_field_class' => 'vc_col-xs-3 vc_column',
	);

	$params[ $prefix_name . 'justify_content_between' ] = array(
		'param_name'       => $prefix_name . 'justify_content_between',
		'type'             => 'checkbox',
		'value'            => array(
			'Justify Content Between' => 'y',
		),
		'edit_field_class' => 'vc_col-xs-3 vc_column',
	);

	if ( $prefix_name == 'top_header_' ) {
		$params[ $prefix_name . 'font_family' ] = array(
			'type'             => 'dropdown',
			'heading'          => __( 'Font', 'berserk' ),
			'value'            => array(
				__( 'None', 'berserk' )                  => 'none',
				__( 'Open Sans', 'berserk' )             => 'open-sans',
				__( 'Montserrat', 'berserk' )            => 'montserrat',
				__( 'Montserrat Alternates', 'berserk' ) => 'montserrat-alt',
				__( 'Playfair Display', 'berserk' )      => 'playfair',
				__( 'Poppins', 'berserk' )               => 'poppins',
				__( 'Pacifico', 'berserk' )              => 'pacifico',
				__( 'Roboto', 'berserk' )                => 'roboto',
				__( 'Roboto Slab', 'berserk' )           => 'roboto-slab',
				__( 'Oxygen', 'berserk' )                => 'oxygen',
				__( 'Times New Roman', 'berserk' )       => 'times-new-roman',
			),
			'param_name'       => $prefix_name . 'font_family',
			'edit_field_class' => 'vc_col-sm-6 vc_column',
		);
	}


	return $params;
}

/* Get patterns options */
function berserk_shortcodes_patterns( $options = array() ) {
	$options['edit_field_class'] = isset( $options['edit_field_class'] ) ? $options['edit_field_class'] : '';
	$options['dependency']       = isset( $options['dependency'] ) ? $options['dependency'] : '';
	$params                      = array();

	$params[] = array(
		"heading"    => __( "Backgrounds", 'berserk' ),
		"param_name" => "brs_title",
		"type"       => "brs_title",
	);

	$params[] = array(
		'heading'          => __( 'Use Custom Background', 'berserk' ),
		'param_name'       => 'use_custom_background',
		'type'             => 'brs_switch',
		'value'            => 'no',
		'options'          => array(
			'Yes' => 'yes',
			'No'  => 'no',
		),
		'edit_field_class' => 'vc_col-sm-6 vc_column ' . $options['edit_field_class'],
		'dependency'       => $options['dependency']
	);

	$params[] = array(
		"heading"          => __( "Background Size", 'berserk' ),
		"param_name"       => "background_size",
		"type"             => "dropdown",
		'value'            => array(
			'None'    => 'none',
			'Cover'   => 'bg-cover',
			'Contain' => 'bg-contain',
		),
		'edit_field_class' => 'vc_col-sm-6 vc_column ' . $options['edit_field_class'],
		'dependency'       => $options['dependency']
	);

	$params[] = array(
		"heading"          => __( "Background Repeat", 'berserk' ),
		"param_name"       => "background_repeat",
		"type"             => "dropdown",
		'value'            => array(
			'None'     => 'none',
			'Repeat'   => 'bg-repeat',
			'Norepeat' => 'bg-norepeat',
		),
		'edit_field_class' => 'vc_col-sm-6 vc_column ' . $options['edit_field_class'],
		'dependency'       => $options['dependency']
	);

	$params[] = array(
		"heading"          => __( "Background Position", 'berserk' ),
		"param_name"       => "background_position",
		"type"             => "dropdown",
		'value'            => array(
			'None'          => 'none',
			'Top-Left'      => 'bg-position_top-left',
			'Top-Center'    => 'bg-position_top-center',
			'Top-Right'     => 'bg-position_top-right',
			'Bottom-Left'   => 'bg-position_bottom-left',
			'Bottom-Center' => 'bg-position_bottom-center',
			'Bottom-Right'  => 'bg-position_bottom-right',
			'Left-Center'   => 'bg-position_left-center',
			'Right-Center'  => 'bg-position_right-center',
			'Center'        => 'bg-position_center',
		),
		'edit_field_class' => 'vc_col-sm-6 vc_column ' . $options['edit_field_class'],
		'dependency'       => $options['dependency']
	);

	$params[] = array(
		"heading"          => __( "Patterns", 'berserk' ),
		"param_name"       => "pattern_type",
		"type"             => "brs_color_scheme",
		'colors'           => array(
			"None"      => 'none',
			"Type 1"    => 'brk-bgi-1',
			"Type 2"    => 'brk-bgi-2',
			"Type 3"    => 'brk-bgi-3',
			"Type 4"    => 'brk-bgi-4',
			"Type 5"    => 'brk-bgi-5',
			"Type 6"    => 'brk-bgi-6',
			"Type 7"    => 'brk-bgi-7',
			"Type 8"    => 'brk-bgi-8',
			"Type 9"    => 'brk-bgi-9',
			"Type 10"   => 'brk-bgi-10',
			"Type 11"   => 'brk-bgi-11',
			"Type 12"   => 'brk-bgi-12',
			"Type 13"   => 'brk-bgi-13',
			"Type Wave" => 'brk-bgi-wave',
		),
		'value'            => 'brk-bgi-1',
		'edit_field_class' => 'vc_col-xs-12 vc_column pattern_type ' . $options['edit_field_class'],
		'dependency'       => $options['dependency']
	);

	$params[] = array(
		'type'             => 'attach_image',
		'heading'          => __( 'Background Image', 'js_composer' ),
		'param_name'       => 'bg_image',
		'edit_field_class' => 'vc_col-xs-12 vc_column image_uploader ' . $options['edit_field_class'],
		'value'            => '',
		'dependency'       => $options['dependency']
	);

	return $params;
}

function berserk_shortcodes_backgrounds( $prefix_name = '' ) {

	$params                              = array();
	$params[ $prefix_name . 'bg_color' ] = array(
		"heading"    => __( "Background Color", 'berserk' ),
		"param_name" => $prefix_name . "gradient",
		"type"       => "brs_color_scheme",
		'colors'     => array(
			"None"                      => "",
			"White background"          => "btn-backgrounds_white",
			"BG White"                  => "bg-white",
			"Light background"          => "brk-bg-light-white",
			"Default"                   => "brk-bg-grad",
			"Base bg 1"                 => "brk-base-bg-1",
			"Default with opacity"      => "brk-base-bg-gradient-50deg-opacity-28",
			"Base Gradient 40deg"       => "brk-bg-gradient-40deg-92",
			"Default button"            => "brk-base-gradient-btn-backgrounds",
			"Base Gradient 30deg"       => "brk-base-bg-gradient--30deg",
			"Base Gradient 10deg"       => "brk-base-bg-gradient-10deg",
			"Base Gradient 90deg"       => "brk-base-bg-gradient-90deg",
			"Blue"                      => "brk-base-bg-gradient-left-blue",
			"Yellow"                    => "brk-base-bg-yellow",
			"Pink to purple"            => "brk-base-bg-gradient-pink-purple",
			"Base blue gradient"        => "brk-base-bg-gradient-15",
			"Base pink gradient"        => "brk-base-bg-gradient-19",
			"Base 16 gradient"          => "brk-base-bg-gradient-16",
			"Base light dark gradient"  => "brk-base-bg-light-dark",
			"Base green gradient"       => "brk-base-bg-green",
			"Base 17 gradient"          => "brk-base-bg-gradient-17",
			"Base 3 gradient"           => "brk-base-bg-gradient-3",
			"Background Secondary"      => "brk-bg-secondary",
			"Background Gradient Brown" => "brk-base-bg-gradient-brown",
		),
	);

	$params[ $prefix_name . 'opacity' ] = array(
		"heading"    => __( "Opacity", 'berserk' ),
		"param_name" => $prefix_name . "opacity",
		"type"       => "dropdown",
		"value"      => array(
			"1"   => "opacity-100",
			"0.9" => "opacity-90",
			"0.8" => "opacity-80",
			"0.7" => "opacity-70",
			"0.6" => "opacity-60",
			"0.5" => "opacity-50",
			"0.4" => "opacity-40",
			"0.3" => "opacity-30",
			"0.2" => "opacity-20",
			"0.1" => "opacity-10",

		),

		"edit_field_class" => "vc_col-sm-3 vc_column",
	);

	return $params;
}

function berserk_shortcodes_product_categories( $options = array() ) {
	$options['edit_field_class'] = isset( $options['edit_field_class'] ) ? $options['edit_field_class'] : '';
	$params                      = array();

	$terms_arr = array();

	$terms = get_terms( array(
		'taxonomy'   => array( 'product_cat' ),
		'hide_empty' => false,
	) );

	if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {

		foreach ( $terms as $term ) {
			$terms_arr[ $term->name ] = $term->slug;
		}

		foreach ( $terms_arr as $name => $slug ) {
			$params[] = array(
				"param_name"       => 'category_' . $slug,
				"type"             => "checkbox",
				"value"            => array(
					$name => "y",
				),
				'edit_field_class' => 'vc_col-sm-2 vc_column ' . $options['edit_field_class'],
			);
		}

	}

	return $params;
}


function berserk_shortcodes_image_size_options() {

	$params = array();

	$options = array( 'Custom Size' => 'custom_image_size' );
	$options = array_merge( $options, BRS_Shortcodes_VCParams::get_image_sizes_names() );

	$params[] = array(
		'type'             => 'dropdown',
		'heading'          => __( 'Image size', 'berserk' ),
		'value'            => $options,
		'param_name'       => 'image_size',
		'std'              => '',
		'edit_field_class' => 'vc_col-sm-4 vc_column',
		'dependency'       => array(
			'element' => 'custom_image_size',
			'value'   => array( '' ),
		),
	);

	$params[] = array(
		'type'             => 'textfield',
		'heading'          => __( 'Width', 'js_composer' ),
		'param_name'       => 'image_custom_width',
		'value'            => '',
		'std'              => '400',
		'edit_field_class' => 'vc_col-sm-4',
		'dependency'       => array(
			'element' => 'image_size',
			'value'   => array( 'custom_image_size' ),
		),
	);

	$params[] = array(
		'type'             => 'textfield',
		'heading'          => __( 'Height', 'js_composer' ),
		'param_name'       => 'image_custom_height',
		'value'            => '',
		'std'              => '300',
		'edit_field_class' => 'vc_col-sm-4',
		'dependency'       => array(
			'element' => 'image_size',
			'value'   => array( 'custom_image_size' ),
		),
	);

	return $params;
}

function berserk_shortcodes_image_size_render( $atts ) {
	$atts['image_size'] = $atts['image_size'] == 'custom_image_size' ? array(
		$atts['image_custom_width'],
		$atts['image_custom_height']
	) : $atts['image_size'];

	return $atts['image_size'];
}