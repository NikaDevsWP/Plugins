<?php
/**
 * Progress bars shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Shortcode progress bars class.
 *
 */
class BRS_Shortcode_ProgressBars extends BRS_Shortcode {

	static protected $instance;
	static protected $atts = array();

	protected $plugin_name = 'dt_mce_plugin_shortcode_progress_bars';

	public static function get_instance() {
		if ( ! self::$instance ) {
			self::$instance = new BRS_Shortcode_ProgressBars();
		}

		return self::$instance;
	}

	protected function __construct() {

		add_shortcode( 'brs_progress_bar', array( $this, 'shortcode_bar' ) );
		add_action( 'init', array( $this, 'admin_init' ) );
	}

	public function admin_init() {
		if ( function_exists( "vc_map" ) ) {
			vc_map( array(
				"weight"   => - 1,
				"name"     => __( "Progress Bar", 'berserk' ),
				"base"     => "brs_progress_bar",
				"icon"     => "brs_progress_bar",
				"class"    => "brs_progress_bar",
				"category" => __( 'Berserk', 'berserk' ),
				"params"   => array(
					array(
						'type'       => 'param_group',
						'heading'    => __( 'Values', 'js_composer' ),
						'param_name' => 'values',
						'value'      => urlencode( json_encode( array(
							array(
								'label'     => __( 'Hard Work', 'js_composer' ),
								'value'     => '90',
								'max_value' => '100',
							),
							array(
								'label'     => __( 'Projects Delivery', 'js_composer' ),
								'value'     => '80',
								'max_value' => '100',
							),
							array(
								'label'     => __( 'Customers Love', 'js_composer' ),
								'value'     => '70',
								'max_value' => '100',
							),
						) ) ),
						'params'     => array(
							array(
								'type'        => 'textfield',
								'heading'     => __( 'Label', 'js_composer' ),
								'param_name'  => 'label',
								//'description' => __( 'Enter text used as title of bar.', 'js_composer' ),
								'admin_label' => true,
							),
							array(
								'type'        => 'textfield',
								'heading'     => __( 'Value', 'js_composer' ),
								'param_name'  => 'value',
								//'description' => __( 'Enter value of bar.', 'js_composer' ),
								'admin_label' => true,
							),
							array(
								'type'        => 'textfield',
								'heading'     => __( 'Max Value', 'js_composer' ),
								'param_name'  => 'max_value',
								//'description' => __( 'Enter value of bar.', 'js_composer' ),
								'admin_label' => true,
							),
						),
					),
					array(
						'heading'    => __( 'Progress Bar Type', 'berserk' ),
						'param_name' => 'progress_bar_type',
						'type'       => 'brs_radio',
						'value'      => array(
							"Gradient"    => "gradient",
							"Wide"        => "wide",
							"Doted"       => "doted",
							"Stripe"      => "stripe",
							"Count"       => "count",
							"Squared"     => "squared",
							"Transparent" => "transparent",
							"Inline"      => "inline",
							"Classic"     => "classic",
							"Minimal"     => "minimal",
							"Light"       => "light",
							"Thin"        => "thin",
							"Curve"       => "curve",
							"Triangle"    => "triangle",
							"Round"       => "round"
						),
						'images'     => array(
							"gradient"    => 'progress_bar/bar_gradient.png',
							"wide"        => 'progress_bar/bar_wide.png',
							"doted"       => 'progress_bar/bar_doted.png',
							"stripe"      => 'progress_bar/bar_stripe.png',
							"count"       => 'progress_bar/bar_count.png',
							"squared"     => 'progress_bar/bar_squared.png',
							"transparent" => 'progress_bar/bar_transparent.png',
							"inline"      => 'progress_bar/bar_inline.png',
							"classic"     => 'progress_bar/bar_classic.png',
							"minimal"     => 'progress_bar/bar_minimal.png',
							"light"       => 'progress_bar/bar_light.png',
							"thin"        => 'progress_bar/bar_thin.png',
							"curve"       => 'progress_bar/bar_curve.png',
							"triangle"    => 'progress_bar/bar_triangle.png',
							"round"       => 'progress_bar/bar_round.png',

						),
						'images_dim' => array(
							'w' => '210',
							'h' => '100'
						)
					),
					array(
						'type'             => 'colorpicker',
						'heading'          => __( 'Color', 'js_composer' ),
						'param_name'       => 'pb_color_1',
						'value'            => '#2775ff',
						'std'              => '#2775ff',
						'edit_field_class' => 'vc_col-sm-6 vc_column',
					),
					array(
						'type'             => 'colorpicker',
						'heading'          => __( 'Color Gradient End', 'js_composer' ),
						'param_name'       => 'pb_color_2',
						'value'            => '#7202bb',
						'std'              => '#7202bb',
						'edit_field_class' => 'vc_col-sm-6 vc_column',
					),

				)
			) );

		}
	}

	public function shortcode_bar( $atts, $content = null ) {

    brs_add_libraries('component__progress_bar');

		extract( shortcode_atts( array(
			'values'            => '',
			'progress_bar_type' => 'gradient',
			'pb_color_1'        => '#2775ff',
			'pb_color_2'        => '#7202bb',
		), $atts ) );

		$pb_class = 'progress__wrapper ';

		//echo "progress_bar_type=".$progress_bar_type;

		$values = vc_param_group_parse_atts( $values );
		$output = '';

		switch ( $progress_bar_type ) {

			case "gradient":

				$pb_class .= 'progress__gradient';
				$pb_style   = '';
				$pb_style_b = '';
				if( $pb_color_1 != '#2775ff' || $pb_color_2 != '#7202bb' ) {
					$pb_style_b = 'background: ' . $pb_color_1 . ';';
					$pb_style = $pb_style_b;
					$pb_style .= 'background: -webkit-gradient(linear, left top, right top, from(' . $pb_color_1 . '), to(' . $pb_color_2 . '));';
					$pb_style .= 'background: - webkit - linear - gradient( left, ' . $pb_color_1 . ', ' . $pb_color_2 . ');';
					$pb_style .= 'background: - o - linear - gradient( left, ' . $pb_color_1 . ', ' . $pb_color_2 . ');';
					$pb_style .= 'background: linear - gradient( to right, ' . $pb_color_1 . ', ' . $pb_color_2 . ');';
				}
				if( empty( $pb_color_1 ) && empty( $pb_color_2) ) {
					$pb_style   = '';
					$pb_style_b = '';
				}

				foreach ( $values as $key => $value ) {
					$output .= '<div class="' . $pb_class . '">
				          <div class="progress">
				            <div style="' . $pb_style . '" data-valuenow="' . $value['value'] . '" data-valuemin="0" data-valuemax="' . $value['max_value'] . '" class="progress__bar"><span style="' . $pb_style_b . '" class="before"></span></div>
				            <span class="font__family-montserrat font__size-16 font__weight-bold progress__bar-counter hide">' . $value['value'] . '</span>
				          </div>
				          <h5 class="font__family-montserrat font__size-16 font__weight-bold progress__title">' . $value['label'] . '</h5>
				        </div>';
				}
				break;
			case "wide":
				$pb_class .= 'progress__wide';

				$pb_style   = 'background: ' . $pb_color_1 . ';';
				$pb_c_style = 'color: ' . $pb_color_1 . ';';

				foreach ( $values as $key => $value ) {
					$output .= '<div class="' . $pb_class . '">
				          <div class="progress">
				            <div style="' . $pb_style . '" data-valuenow="' . $value['value'] . '" data-valuemin="0" data-valuemax="' . $value['max_value'] . '" class="progress__bar">
				            <span style="' . $pb_c_style . '" class="font__family-montserrat font__size-16 font__weight-semibold progress__bar-counter hide">' . $value['value'] . '</span></div>
				          </div>
				          <h5 class="font__family-montserrat font__size-16 font__weight-medium progress__title">' . $value['label'] . '</h5>
				        </div>';
				}
				break;

			case "doted":
				$pb_class .= 'progress__doted';
				$pb_c_style = 'color: ' . $pb_color_1 . ';';

				$pb_style_a = 'background: ' . $pb_color_1 . ';';

				$pb_style_ac = 'background-image: -webkit-radial-gradient(ellipse, ' . $pb_color_1 . ' 1px, ' . $pb_color_1 . ' 1px, transparent 2px);';
				$pb_style_ac .= 'background-image: -o-radial-gradient(ellipse, ' . $pb_color_1 . ' 1px, ' . $pb_color_1 . ' 1px, transparent 2px);';
				$pb_style_ac .= 'background-image: radial-gradient(ellipse, ' . $pb_color_1 . ' 1px, ' . $pb_color_1 . ' 1px, transparent 2px);';

				foreach ( $values as $key => $value ) {

					$output .= '<div class="' . $pb_class . '">
						          <div class="progress__descr">
						            <h5 class="font__family-montserrat font__size-16 font__weight-bold progress__title">' . $value['label'] . '</h5>
						            <span style="' . $pb_c_style . '" class="font__family-montserrat font__size-16 font__weight-bold progress__bar-counter hide">' . $value['value'] . '</span>
						          </div>
						          <div class="progress">
						            <div data-valuenow="' . $value['value'] . '" data-valuemin="0" data-valuemax="' . $value['max_value'] . '" class="progress__bar">
						              <span class="circle"><span style="' . $pb_style_a . '" class="after"></span></span>
						              <span style="' . $pb_style_ac . '" class="after"></span>
						            </div>
						            <span class="after"></span>
						          </div>
						        </div>';
				}

				break;
			case "stripe":
				$pb_class .= 'progress__stripe';
				$pb_style = 'background-color: ' . $pb_color_1 . ';';

				foreach ( $values as $key => $value ) {

					$output .= '<div class="' . $pb_class . ' no-anim">
						          <div class="progress__descr">
						            <h5 class="font__family-montserrat font__size-16 font__weight-bold progress__title">' . $value['label'] . '</h5>
						          </div>
						          <div class="progress">
						           <span class="font__family-montserrat font__size-16 font__weight-bold progress__bar-counter hide">' . $value['value'] . '</span>
						            <div style="' . $pb_style . '" data-valuenow="' . $value['value'] . '" data-valuemin="0" data-valuemax="' . $value['max_value'] . '" class="progress__bar">
						            </div>
						          </div>
						        </div>';
				}

				break;
			case "count":
				$pb_class .= 'progress__count';

				foreach ( $values as $key => $value ) {

					$output .= '<div class="' . esc_attr__( $pb_class ) . '">';
					$output .= '<div class="progress__descr">';
					$output .= '<h5 class="font__family-montserrat font__size-16 font__weight-bold progress__title">' . esc_html__( $value['label'] ) . '</h5>';
					$output .= '<div class="count">';
					$output .= '<span class="font__family-montserrat font__weight-regular count-value">' . esc_html__( $value['value'] ) . '</span>';
					$output .= '<span class="font__family-montserrat font__weight-regular count-amount">' . esc_html__( $value['max_value'] ) . '</span>';
					$output .= '</div>';
					$output .= '</div>';
					$output .= '<div class="progress">';
					$output .= '<div class="progress__bar">';
					$output .= '<span class="circle"></span>';
					$output .= '</div>';
					$output .= '</div>';
					$output .= '</div>';

				}

				break;

			case "squared":
				$pb_class .= 'progress__squared';
				$pb_style   = 'background: ' . $pb_color_1 . ';';
				$pb_c_style = 'color: ' . $pb_color_1 . ';';
				$pb_c_style .= 'border: 2px solid ' . $pb_color_1 . ';';

				$pb_c_style_b = 'border-color: ' . $pb_color_1 . ' transparent transparent transparent;';

				foreach ( $values as $key => $value ) {

					$output .= '<div class="' . $pb_class . '">
						          <h5 class="font__family-montserrat font__size-16 font__weight-bold progress__title">' . $value['label'] . '</h5>
						          <div class="progress">
						            <div style="' . $pb_style . '" data-valuenow="' . $value['value'] . '" data-valuemin="0" data-valuemax="' . $value['max_value'] . '" class="progress__bar">
						              <div style="' . $pb_c_style . '" class="progress__bar-counter_wrap"><span style="' . $pb_c_style_b . '" class="before"></span><span class="font__family-montserrat font__size-16 font__weight-semibold progress__bar-counter hide">' . $value['value'] . '</span></div>
				                        <span class="circle"><span style="' . $pb_style . '" class="before"></span><span style="' . $pb_style . '" class="after"></span></span>
						            </div>
						          </div>
						        </div>';
				}
				break;

			case "transparent":
				$pb_class .= 'progress__transparent';
				$pb_style = 'background: ' . $pb_color_1 . ';';
				$pb_style .= 'background: -webkit-gradient(linear, left top, right top, from(transparent), to(' . $pb_color_1 . '));';
				$pb_style .= 'background: -webkit-linear-gradient(left, transparent, ' . $pb_color_1 . ');';
				$pb_style .= 'background: -o-linear-gradient(left, transparent, ' . $pb_color_1 . ');';
				$pb_style .= 'background: linear-gradient(to right, transparent, ' . $pb_color_1 . ');';

				$pb_c_style   = 'background: ' . $pb_color_1 . ';';
				$pb_c_style_b = 'border-color: ' . $pb_color_1 . ' transparent transparent transparent;';

				foreach ( $values as $key => $value ) {

					$output .= '<div class="' . $pb_class . '">
						          <h5 class="font__family-montserrat font__size-16 font__weight-bold progress__title">' . $value['label'] . '</h5>
						          <div class="progress">
						            <div style="' . $pb_style . '" data-valuenow="' . $value['value'] . '" data-valuemin="0" data-valuemax="' . $value['max_value'] . '" class="progress__bar">
						              <div style="' . $pb_c_style . '" class="progress__bar-counter_wrap"><span style="' . $pb_c_style_b . '" class="before"></span><span class="font__family-open-sans font__size-16 font__weight-bold progress__bar-counter hide">' . $value['value'] . '</span></div>
			                            <span style="' . $pb_c_style . '" class="circle"></span>
						            </div>
						          </div>
						        </div>';
				}

				break;
			case "inline":
				$pb_class .= 'progress__inline';

				$pb_style = 'background: ' . $pb_color_1 . ';';

				foreach ( $values as $key => $value ) {

					$output .= '<div class="' . $pb_class . '">
						          <h5 class="font__family-montserrat font__size-16 font__weight-bold progress__title">' . $value['label'] . '</h5>
						          <div class="progress">
						            <div style="' . $pb_style . '" data-valuenow="' . $value['value'] . '" data-valuemin="0" data-valuemax="' . $value['max_value'] . '" class="progress__bar">
						              <div class="progress__bar-counter_wrap"><span style="' . $pb_style . '" class="before"></span><span class="font__family-open-sans font__size-16 font__weight-bold progress__bar-counter hide">' . $value['value'] . '</span></div>
						            </div>
						          </div>
						        </div>';
				}

				break;
			case "classic":
				$pb_class .= 'progress__classic';

				$pb_style   = 'background: ' . $pb_color_1 . ';';
				$pb_c_style = 'color: ' . $pb_color_1 . ';';

				$pb_style_a = 'border: 2px solid ' . $pb_color_1 . ';';

				foreach ( $values as $key => $value ) {

					$output .= '<div class="' . $pb_class . '">
						          <span style="' . $pb_c_style . '" class="font__family-open-sans font__size-16 font__weight-bold progress__bar-counter hide">' . $value['value'] . '</span>
						          <div class="progress">
						            <div style="' . $pb_style . '" data-valuenow="' . $value['value'] . '" data-valuemin="0" data-valuemax="' . $value['max_value'] . '" class="progress__bar">
						              <span class="circle"><span style="' . $pb_style_a . '" class="after"></span></span>
						            </div>
						          </div>
						          <h5 class="font__family-montserrat font__size-16 font__weight-bold text-uppercase progress__title">' . $value['label'] . '</h5>
						        </div>';
				}

				break;
			case "minimal":
				$pb_class .= 'progress__minimal mb-35 mb-md-0';

				$pb_style = 'background: ' . $pb_color_1 . ';';

				foreach ( $values as $key => $value ) {

					$output .= '<div class="' . $pb_class . '">
						          <div><span style="' . $pb_style . '" class="font__family-open-sans font__size-13 font__weight-bold progress__bar-counter hide">' . $value['value'] . '</span></div>
						          <div class="progress">
						            <div style="' . $pb_style . '" data-valuenow="' . $value['value'] . '" data-valuemin="0" data-valuemax="' . $value['max_value'] . '" class="progress__bar">
						              <span style="' . $pb_style . '" class="circle"></span>
						            </div>
						          </div>
						          <h5 class="font__family-montserrat font__size-16 font__weight-bold progress__title">' . $value['label'] . '</h5>
						        </div>';
				}

				break;

			case "light":
				$pb_class .= 'progress__light';
				$pb_style = 'background: ' . $pb_color_1 . ';';

				foreach ( $values as $key => $value ) {

					$output .= '<div class="' . $pb_class . '">
						          <h5 class="font__family-oxygen font__size-21 font__weight-light text-uppercase progress__title">' . $value['label'] . '</h5>
						          <div class="progress">
						            <div style="' . $pb_style . '" data-valuenow="' . $value['value'] . '" data-valuemin="0" data-valuemax="' . $value['max_value'] . '" class="progress__bar">
						                <div class="progress__bar-counter_wrap"><span style="' . $pb_style . '" class="before"></span><span class="font__family-oxygen font__size-16 font__weight-light progress__bar-counter hide">' . $value['value'] . '</span></div>
						            </div>
						          </div>
						        </div>';

				}

				break;
			case "thin":
				$pb_class .= 'progress__thin';
				$pb_style      = 'background: ' . $pb_color_1 . ';';
				$pb_c_style    = 'color: ' . $pb_color_1 . ';';
				$pb_style_circ = 'border: 2px solid ' . $pb_color_1 . ';';

				foreach ( $values as $key => $value ) {

					$output .= '<div class="' . $pb_class . '">
						          <div class="progress">
						            <div style="' . $pb_style . '" data-valuenow="' . $value['value'] . '" data-valuemin="0" data-valuemax="' . $value['max_value'] . '" class="progress__bar">
						              <span style="' . $pb_c_style . '" class="font__family-open-sans font__size-16 font__weight-semibold progress__bar-counter hide">' . $value['value'] . '</span>
						              <span style="' . $pb_style_circ . '" class="circle"></span>
						            </div>
						          </div>
						          <h5 class="font__family-montserrat font__size-18 font__weight-medium letter-space-40 progress__title">' . $value['label'] . '</h5>
						        </div>';
				}

				break;

			case "curve":
				$pb_class .= 'progress__curve';

				$pb_style = 'stroke: ' . $pb_color_1 . ';';


				foreach ( $values as $key => $value ) {

					$output .= '<div class="' . $pb_class . '" data-value="' . $value['value'] . '">
						          <h4 class="font__family-montserrat font__size-21 font__weight-light progress__title">' . $value['label'] . '</h4>
						          <svg>
						            <path class="path-after" d="M 0 130 L 600.6 130 Q 770 130 770 0" stroke-width="1" stroke="#000000" fill="transparent"/>
						            <path style="' . $pb_style . '" class="path" d="M 0 130 L 600.6 130 Q 770 130 770 0" stroke-width="1" stroke="#000000" fill="transparent"/>
						          </svg>
						        </div>';
				}

				break;
			case "triangle":
				$pb_class .= 'progress__triangle';

				$pb_c_style = 'color: ' . $pb_color_1 . ';';

				$pb_style = 'background: ' . $pb_color_1 . ';';
				$pb_style .= 'background: -webkit-gradient(linear, left top, right top, from(' . $pb_color_1 . '), to(' . $pb_color_2 . '));';
				$pb_style .= 'background: -webkit-linear-gradient(left, ' . $pb_color_1 . ', ' . $pb_color_2 . ');';
				$pb_style .= 'background: -o-linear-gradient(left, ' . $pb_color_1 . ', ' . $pb_color_2 . ');';
				$pb_style .= 'background: linear-gradient(to right, ' . $pb_color_1 . ', ' . $pb_color_2 . ');';

				foreach ( $values as $key => $value ) {

					$output .= '<div class="' . $pb_class . '">
						          <div class="progress">
						            <div style="' . $pb_style . '" data-valuenow="' . $value['value'] . '" data-valuemin="0" data-valuemax="' . $value['max_value'] . '" class="progress__bar">
						              <span style="' . $pb_c_style . '" class="font__family-montserrat font__size-21 font__weight-normal progress__bar-counter hide">' . $value['value'] . '</span>
						            </div>
						          </div>
						          <h5 class="font__family-montserrat font__size-21 letter-space-40 progress__title">' . $value['label'] . '</h5>
						        </div>';
				}
				break;
			case "round":
				$pb_class .= 'progress__rounded';

				$pb_style_b = 'background: -webkit-gradient(linear, left top, left bottom, from(' . $pb_color_1 . '), to(' . $pb_color_2 . '));';
				$pb_style_b .= 'background: -webkit-linear-gradient(top, ' . $pb_color_1 . ', ' . $pb_color_2 . ');';
				$pb_style_b .= 'background: -o-linear-gradient(top, ' . $pb_color_1 . ', ' . $pb_color_2 . ');';
				$pb_style_b .= 'background: linear-gradient(to bottom, ' . $pb_color_1 . ', ' . $pb_color_2 . ');';

				$pb_style_a = 'background-color: ' . $pb_color_1 . ';';

				foreach ( $values as $key => $value ) {

					$output .= '<div class="' . $pb_class . '">
						          <h5 class="font__family-montserrat font__size-16 font__weight-bold text-uppercase progress__title">' . $value['label'] . '</h5>
						          <div class="progress">
						            <span style="' . $pb_style_b . '" class="before"></span>
						            <div data-valuenow="' . $value['value'] . '" data-valuemin="0" data-valuemax="' . $value['max_value'] . '" class="progress__bar">
						              <span class="font__family-montserrat font__size-16 font__weight-bold progress__bar-counter hide">' . $value['value'] . '</span>
						              <span class="circle"><span class="after"></span></span>
						            </div>
						            <span class="progress-bg"></span>
						            <span style="' . $pb_style_a . '" class="after"></span>
						          </div>
						        </div>';
				}

				break;
			default:
				foreach ( $values as $key => $value ) {

					$output .= '<div class="' . $pb_class . '">
						          <div class="progress__descr">
						            <h5 class="font__family-montserrat font__size-16 font__weight-bold progress__title">' . $value['label'] . '</h5>
						            <span class="font__family-montserrat font__size-16 font__weight-bold progress__bar-counter hide">' . $value['label'] . '</span>
						          </div>
						          <div class="progress">
						            <div data-valuenow="' . $value['label'] . '" data-valuemin="0" data-valuemax="' . $value['max_value'] . '" class="progress__bar">
						              <span class="circle"></span>
						            </div>
						          </div>
						        </div>';
				}
				break;

		}

		return $output;
	}

}

// create shortcode
BRS_Shortcode_ProgressBars::get_instance();
