<?php
/**
 * Servises shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Title_Section', false ) ) {

	class BRS_Title_Section extends BRS_Shortcode {

		static protected $instance;

		protected $shortcode_name = 'brs_title_section';
		protected $atts = array();

		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Title_Section();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( $this->shortcode_name, array( $this, 'shortcode' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Title Section", 'berserk' ),
					"base"     => "brs_title_section",
					"icon"     => "brs_vc_ico_title_section",
					"class"    => "brs_vc_sc_title_section",
					"category" => __( 'Berserk', 'berserk' ),
					"params"   => array(

						array(
							'heading'    => __( 'Title Section Type', 'berserk' ),
							'param_name' => 'titles_section_type',
							'type'       => 'brs_radio',
							'value'      => array(
								"Extra Heading 01" => "extra_heading_1",
								"Extra Heading 02" => "extra_heading_2",
								"Extra Heading 03" => "extra_heading_3",

							),
							'images'     => array(
								"extra_heading_1" => 'titles_section/extra_heading_1.png',
								"extra_heading_2" => 'titles_section/extra_heading_2.png',
								"extra_heading_3" => 'titles_section/extra_heading_3.png',
							),
							'images_dim' => array(
								'w' => '185',
								'h' => '160'
							)
						),

						array(
							'type'       => 'param_group',
							'heading'    => __( 'Title Items', 'js_composer' ),
							'param_name' => 'title_values',
							'value'      => urlencode( json_encode( array(
								array(
									'label'     => __( 'LOOK AT THE WORLD', 'js_composer' ),
									'brs_font'  => 'montserrat',
									'font_size' => '72'

								),
								array(
									'label'     => __( 'IN A NEW WAY', 'js_composer' ),
									'brs_font'  => 'montserrat',
									'font_size' => '72'

								),

							) ) ),
							'params'     => array(

								array(
									'type'             => 'textfield',
									'heading'          => __( 'Label', 'js_composer' ),
									'param_name'       => 'label',
									'edit_field_class' => 'vc_col-sm-6 vc_column',
									'admin_label'      => true,
								),

								array(
									'type'             => 'dropdown',
									'heading'          => __( 'Font', 'berserk' ),
									'value'            => array(
										__( 'Open Sans', 'berserk' )             => 'open-sans',
										__( 'Montserrat', 'berserk' )            => 'montserrat',
										__( 'Montserrat Alternates', 'berserk' ) => 'montserrat-alt',
										__( 'Playfair Display', 'berserk' )      => 'playfair',
										__( 'Poppins', 'berserk' )               => 'poppins',
										__( 'Pacifico', 'berserk' )              => 'pacifico',
										__( 'Roboto', 'berserk' )                => 'roboto',
										__( 'Roboto Slab', 'berserk' )           => 'roboto-slab',
										__( 'Oxygen', 'berserk' )                => 'oxygen',
										__( 'Times New Roman', 'berserk' )       => 'times-new-roman',
									),
									'param_name'       => 'brs_font',
									'edit_field_class' => 'vc_col-sm-6 vc_column',
									"std"              => "montserrat",

								),

								array(
									'heading'          => __( 'Font Size', 'js_composer' ),
									"param_name"       => "font_size",
									"type"             => "dropdown",
									"value"            => BRS_Shortcodes_VCParams::get_font_size(),
									'admin_label'      => true,
									'edit_field_class' => 'vc_col-sm-6 vc_column',

								),
								array(
									'type'             => 'dropdown',
									'heading'          => esc_html__( 'Font weight', 'berserk' ),
									'value'            => BRS_Shortcodes_VCParams::get_font_weight(),
									'param_name'       => 'font_weight',
									'edit_field_class' => 'vc_col-sm-6 vc_column',
								),
								array(
									'type'             => 'dropdown',
									'heading'          => esc_html( 'Text transform', 'berserk' ),
									'param_name'       => 'text_transform',
									'value'            => BRS_Shortcodes_VCParams::get_text_transform(),
									'edit_field_class' => 'vc_col-sm-6 vc_column',
								),

								array(
									'type'             => 'dropdown',
									'heading'          => esc_html__( 'Text Color', 'berserk' ),
									'value'            => BRS_Shortcodes_VCParams::get_text_colors(),
									'std'              => '',
									'param_name'       => 'text_color',
									'edit_field_class' => 'vc_col-sm-6 vc_column',
								),

								array(
									"param_name"       => "show_inline",
									"type"             => "checkbox",
									"value"            => array(
										"Show Inline" => "y",
									),
									'admin_label'      => true,
									'edit_field_class' => 'vc_col-sm-6 vc_column',
								),

							),
						),

						array(
							'type'             => 'textarea',
							'heading'          => __( 'Description', 'js_composer' ),
							'value'            => 'Some description goes here',
							'param_name'       => 'st_description',
							"edit_field_class" => "vc_col-sm-6 vc_column",
						),
						array(
							'type'             => 'textfield',
							'heading'          => __( 'Background Heading', 'js_composer' ),
							'value'            => 'Control',
							'param_name'       => 'st_bg_heading',
							"edit_field_class" => "vc_col-sm-6 vc_column",
						),

						array(
							'type'       => 'param_group',
							'heading'    => __( 'Items', 'js_composer' ),
							'param_name' => 'itens_values',
							'value'      => urlencode( json_encode( array(
								array(
									'label' => __( 'Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. ', 'js_composer' ),

								),
								array(
									'label' => __( 'Duis arcu tortor, suscipit eget, imperdiet *', 'js_composer' ),

								),
								array(
									'label' => __( 'Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue', 'js_composer' ),

								),

							) ) ),
							'params'     => array(

								array(
									'type'             => 'textarea',
									'heading'          => __( 'Label', 'js_composer' ),
									'param_name'       => 'label',
									'edit_field_class' => 'vc_col-sm-6 vc_column',
									'admin_label'      => true,
								),

							),
						),

						array(
							"type"             => "textfield",
							"heading"          => __( "Link URL", 'berserk' ),
							"param_name"       => "st_link_url",
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							"value"            => "#"
						),

						array(
							"type"             => "textfield",
							"heading"          => __( "Link Title", 'berserk' ),
							"param_name"       => "st_link_title",
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							"value"            => "Read More"
						),

						array(
							'type'             => 'dropdown',
							'heading'          => esc_html__( 'Text Color', 'berserk' ),
							'value'            => BRS_Shortcodes_VCParams::get_text_colors(),
							'std'              => '',
							'param_name'       => 'text_color',
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

						// Addintional CSS Class
						array(
							'type'             => 'textfield',
							'heading'          => esc_html__( 'Additional CSS Class', 'berserk' ),
							'group'            => esc_html__( 'Advanced', 'berserk' ),
							'param_name'       => 'css_class',
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

					)
				) );
			}
		}

		public function shortcode( $atts, $content = null ) {

			brs_add_libraries(array('component__title_section', 'fancybox'));

			extract( shortcode_atts( array(
				'titles_section_type' => 'extra_heading_1',
				'title_values'        => '',
				'st_description'      => 'Some description goes here',
				'st_bg_heading'       => 'Control',
				'itens_values'        => '',
				'st_link_url'         => '#',
				'st_link_title'       => 'Read More',
				'text_color'          => 'default',
				'css_class'           => '',

			), $atts ) );

			$output = '';

			$title_values = vc_param_group_parse_atts( $title_values );
			$itens_values = vc_param_group_parse_atts( $itens_values );

			vc_icon_element_fonts_enqueue( 'fontawesome' );


			switch ( $titles_section_type ) {

				case "extra_heading_1":

					$extra_heading_class = array( 'extra__heading-1' );
					if( $css_class ) {
						$css_class = explode( ' ', $css_class );
						$extra_heading_class = array_merge( $extra_heading_class, $css_class );
					}
					$extra_heading_class = implode( ' ', $extra_heading_class );

					$output = '<div class="' . esc_attr( $extra_heading_class ) . '">';

					foreach ( $title_values as $value ) {
						$classes   = array();
						$classes[] = 'font__family-' . $value['brs_font'];
						$classes[] = 'font__size-' . $value['font_size'];
						if ( isset( $value['font_weight'] ) ) {
							if ( $value['font_weight'] != 'default' ) {
								$classes[] = 'font__weight-' . $value['font_weight'];
							}
						}
						$class = implode( ' ', $classes );

						$output .= '<h2 class="' . esc_attr( $class ) . '">' . esc_html( $value['label'] ) . '</h2>';
					}

					$output .= '<div class="video-btn mt-20">
						            <a href="' . esc_url( $st_link_url ) . '" class="icon__btn icon__btn-anim icon__btn-lg fancybox-media">
						              <span class="before"></span>
						              <i class="fa fa-play" aria-hidden="true"></i>
						              <span class="after"></span>
						            </a>
						            <p class="font__family-montserrat font__weight-bold font__size-12 letter-spacing-100 text-uppercase">' . $st_link_title . '</p>
						          </div>
						        </div>';

					break;

				case "extra_heading_2":

					$extra_heading_class = array( 'extra__heading-2' );
					if( $css_class ) {
						$css_class = explode( ' ', $css_class );
						$extra_heading_class = array_merge( $extra_heading_class, $css_class );
					}
					$text_color_class = '';
					$extra_heading_class = implode( ' ', $extra_heading_class );
					if ( $text_color != 'default' ){
						$text_color_class = ' ' . $text_color;
					}

					$output = '<div class="' . esc_attr( $extra_heading_class ) . '">
					            <div class="heading">';

					foreach ( $title_values as $value ) {
						$classes   = array();
						$classes[] = 'font__family-' . $value['brs_font'];
						$classes[] = 'font__size-' . $value['font_size'];
						if ( isset( $value['font_weight'] ) ) {
							if ( $value['font_weight'] != 'default' ) {
								$classes[] = 'font__weight-' . $value['font_weight'];
							}
						}
						if ( isset( $value['text_transform'] ) ) {
							if ( $value['text_transform'] != 'default' ) {
								$classes[] = $value['text_transform'];
							}
						}
						if ( isset( $value['text_color'] ) ) {
							if ( $value['text_color'] != 'default' ) {
								$classes[] = $value['text_color'];
							}
						}
						if ( isset( $value['show_inline'] ) && $value['show_inline'] == 'y' ) {
							$classes[] = 'show-inline-block';
						}
						$class = implode( ' ', $classes );

						$output .= '<h2 class="' . $class . '">' . $value['label'] . '</h2>';
					}

					$output .= '</div>
							<h2 class="font__family-montserrat font__weight-semibold letter-spacing-20 after-heading' . esc_attr( $text_color_class ) . '">' . esc_html( $st_bg_heading ) . '</h2>
								<p class="font__family-open-sans font__size-18' . esc_attr( $text_color_class ) . '">' . $st_description . '</p>
									<ul class="list-check mt-40' . esc_attr( $text_color_class ) . '">';

									foreach ( $itens_values as $value ) {
										$output .= '<li>' . $value['label'] . '</li>';
									}

								$output .= '</ul>
							<a href="' . esc_url( $st_link_url ) . '" class="btn btn-lg border-radius-10 font__family-open-sans font__weight-bold btn-inside-out btn-inside-out-invert mt-50 brk_bold_icon">
									<span class="before">' . $st_link_title . '</span>
									<span class="text">' . $st_link_title . '</span>
									<span class="after">' . $st_link_title . '</span>
									<i class="icon-left icon-inside icon-inline fa fa-angle-right"></i>
							</a>
						</div>';

					break;

				case "extra_heading_3":

					$extra_heading_class = array( 'extra__heading-3' );
					if( $css_class ) {
						$css_class = explode( ' ', $css_class );
						$extra_heading_class = array_merge( $extra_heading_class, $css_class );
					}
					$extra_heading_class = implode( ' ', $extra_heading_class );

					$output = '<div class="' . esc_attr( $extra_heading_class ) . '">
						          <div class="heading">';

					foreach ( $title_values as $value ) {
						$classes   = array();
						$classes[] = 'font__family-' . $value['brs_font'];
						$classes[] = 'font__size-' . $value['font_size'];
						if ( isset( $value['font_weight'] ) ) {
							if ( $value['font_weight'] != 'default' ) {
								$classes[] = 'font__weight-' . $value['font_weight'];
							}
						}
						if ( isset( $value['text_transform'] ) ) {
							if ( $value['text_transform'] != 'default' ) {
								$classes[] = $value['text_transform'];
							}
						}
						if ( isset( $value['show_inline'] ) && $value['show_inline'] == 'y' ) {
							$classes[] = 'd-inline';
						}
						$class = implode( ' ', $classes );

						$output .= '<h2 class="' . $class . '">' . $value['label'] . '</h2>';
					}

					$output .= '</div>
						          <h2 class="font__family-montserrat font__weight-semibold letter-spacing-20 after-heading">' . $st_bg_heading . '</h2>
						          <p class="font__family-open-sans font__size-16">' . $st_description . '</p>
						          <a href="' . esc_url( $st_link_url ) . '" class="font__family-montserrat font__weight-medium font__size-13 text-uppercase letter-spacing-100 text-blue link-icon mt-20">' . $st_link_title . '</a>
						        </div>';

					break;

			}

			return $output;
		}


	}

	// create shortcode
	BRS_Title_Section::get_instance();

}
