<?php
/**
 * BRS_Gallery_Sliders shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Gallery_Sliders', false ) ) {

	require_once BERSERK_SHORTCODES_PATH . 'shortcodes/includes/shortcodes-ext.php';

	class BRS_Gallery_Sliders extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Gallery_Sliders();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_gallery_sliders', array( $this, 'shortcode_gallery_sliders' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				$params = array();

				$params[] = array(
					"heading"    => __( "Main Settings", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);
				$params[] = array(
					'heading'    => __( 'Gallery Sliders Type', 'berserk' ),
					'param_name' => 'gallery_sliders_type',
					'type'       => 'brs_radio',
					'value'      => array(
						"Gradient"  => "gradient",
						"Solid"     => "solid",
						"Strict"    => "strict",
						"Dark"      => "dark",
						'Gallery 1' => 'gallery_1',
						'Gallery 2' => 'gallery_2',
						'Gallery 3' => 'gallery_3',
						'Gallery 4' => 'gallery_4',
						'Gallery 5' => 'gallery_5',
						'Gallery 6' => 'gallery_6',
					),
					'images'     => array(
						"gradient"  => 'gallery_sliders/001.png',
						"solid"     => 'gallery_sliders/002.png',
						"strict"    => 'gallery_sliders/003.png',
						"dark"      => 'gallery_sliders/004.png',
						"gallery_1" => 'Gallery/001.png',
						"gallery_2" => 'Gallery/002.png',
						"gallery_3" => 'Gallery/003.png',
						"gallery_4" => 'Gallery/004.png',
						"gallery_5" => 'Gallery/005.png',
						"gallery_6" => 'Gallery/006.png',
					),
					'images_dim' => array(
						'w' => '310',
						'h' => '150'
					)
				);

				// Columns
				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Grid Type', 'js_composer' ),
					'param_name'       => 'grid_type',
					'value'            => array(
						'Default Bootstrap' => '',
						'Masonry'           => 'masonry',
					),
					'edit_field_class' => 'vc_col-sm-4 vc_column brk-dependency__gallery_sliders_type gallery_1 gallery_2 gallery_3 gallery_4 gallery_5',
				);
				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Columns Count', 'js_composer' ),
					'param_name'       => 'columns_count',
					'value'            => array(
						'1 column'   => '12',
						'2 columns'  => '6',
						'3 columns'  => '4',
						'4 columns'  => '3',
						'6 columns'  => '2',
						'12 columns' => '1'
					),
					'edit_field_class' => 'vc_col-sm-4 vc_column brk-dependency__gallery_sliders_type gallery_1 gallery_2 gallery_3 gallery_4 gallery_5',
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Column Paddings', 'js_composer' ),
					'param_name'       => 'columns_padding',
					'value'            => array(
						'Default' => '',
						'0px'     => 'no-gutters',
						'10px'    => 'brk-gutters-10',
						'15px'    => 'brk-gutters-15'
					),
					'edit_field_class' => 'vc_col-sm-4 vc_column brk-dependency__gallery_sliders_type gallery_1 gallery_2 gallery_3 gallery_4 gallery_5',
				);

				// Image sizes
				$image_sizes = berserk_shortcodes_image_size_options();
				$params      = array_merge( $params, $image_sizes );

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Card Style', 'js_composer' ),
					'param_name'       => 'card_style',
					'value'            => array(
						'Default'    => 'default',
						'Gray Scale' => 'gray_scale',
					),
					'edit_field_class' => 'vc_col-sm-4 vc_column brk-dependency__gallery_sliders_type gallery_1 gallery_2 gallery_3 gallery_4 gallery_5',
				);

				// Backgrounds
				$options  = array( 'edit_field_class' => 'brk-dependency__gallery_sliders_type gradient' );
				$patterns = berserk_shortcodes_patterns( $options );
				$params   = array_merge( $params, $patterns );

				$backgrounds                                 = berserk_shortcodes_backgrounds();
				$backgrounds['bg_color']['edit_field_class'] = "vc_col-sm-12 vc_column  brk-dependency__gallery_sliders_type gradient";
				$backgrounds['opacity']['edit_field_class']  = "vc_col-sm-6 vc_column  brk-dependency__gallery_sliders_type gradient";

				$params = array_merge( $params, $backgrounds );

				$params[] = array(
					"heading"    => __( "Dynamic Content", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$params = array_merge( $params, berserk_shortcodes_dynamic_filter() );

				$params[] = array(
					"heading"          => __( "Content Values", 'berserk' ),
					"param_name"       => "brs_title",
					"type"             => "brs_title",
					'edit_field_class' => 'vc_col-sm-12 vc_column brk-dependency__gallery_sliders_type strict dark gallery_3'
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => esc_html__( 'Ajax Load Button Type', 'berserk' ),
					'param_name'       => 'ajax_btn_display',
					'value'            => array(
						'None'        => 'none',
						'Icon Button' => 'icon',
						'Text Button' => 'text',
					),
					'edit_field_class' => 'vc_col-sm-6 vc_column',
				);

				$params[] = array(
					'type'             => 'textfield',
					'heading'          => __( 'AJAX: Items Per Load', 'js_composer' ),
					'param_name'       => 'items_per_load',
					"value"            => '4',
					'edit_field_class' => 'vc_col-sm-6 vc_column dependency__gallery_sliders_type type_4 type_5',
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Get title from', 'js_composer' ),
					'param_name'       => 'title_val',
					'value'            => array(
						'Post Title'  => 'post_title',
						'Post Date'   => 'post_date',
						'Post Author' => 'post_author'
					),
					'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__gallery_sliders_type strict dark',
				);

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Gallery", 'berserk' ),
					"base"     => "brs_gallery_sliders",
					"icon"     => "brs_vc_ico_gallery_sliders",
					"class"    => "brs_vc_sc_gallery_sliders",
					"category" => __( 'Berserk', 'berserk' ),
					"params"   => $params
				) );

			}
		}

		public static function shortcode_gallery_sliders( $atts, $content = null ) {

			$atts = shortcode_atts( array(
				'gallery_sliders_type'  => 'gradient',
				'dynamic_content'       => 'no',
				'image_size'            => 'gallery-sliders-gradient',
				'custom_items'          => '',
				'orderby'               => 'date',
				'order_direction'       => 'ASC',
				'filters'               => '',
				'title_val'             => 'post_title',
				'description_val'       => 'post_content',
				'bg_image'              => '',
				'pattern_type'          => '',
				'background_size'       => 'bg-cover',
				'background_repeat'     => '',
				'background_position'   => '',
				'use_custom_background' => 'no',
				'gradient'              => 'brk-base-bg-gradient-10deg',
				'columns_count'         => 1,
				'items_per_load'        => 4,
				'image_custom_width'    => '400',
				'image_custom_height'   => '300',
				'columns_padding'       => '',
				'grid_type'             => '',
				'card_style'            => '',
				'ajax_btn_display'      => 'none'
			), $atts );

			$atts['image_size'] = berserk_shortcodes_image_size_render( $atts );

			$pattern_style = '';
			$pattern_class = '';
			if ( $atts['use_custom_background'] == 'yes' ) {
				$image         = wp_get_attachment_image_src( $atts['bg_image'], 'full' );
				$image         = $image[0];
				$pattern_style = 'background-image: url(' . esc_url( $image ) . ');';
			} else {
				$pattern_class = $atts['pattern_type'];
			}

			if ( isset( $atts['background_size'] ) && ( $atts['background_size'] != 'none' ) ) {
				$pattern_class = $atts['background_size'];
			}
			if ( isset( $atts['background_repeat'] ) && ( $atts['background_repeat'] != 'none' ) ) {
				$pattern_class = $atts['background_repeat'];
			}
			if ( isset( $atts['background_position'] ) && ( $atts['background_position'] != 'none' ) ) {
				$pattern_class = $atts['background_position'];
			}


			if ( $atts['dynamic_content'] == 'y' ) {
				$args  = array();
				$args  = array_merge( $args, berserk_shortcodes_dynamic_filter_process( $atts['filters'], $atts['orderby'], $atts['order_direction'] ) );
				$posts = get_posts( $args );
			} else {
				$posts        = array();
				$custom_items = explode( ',', $atts['custom_items'] );
				foreach ( $custom_items as $item ) {
					$posts[] = get_post( $item );
				}
			}

			$terms = Shortcodes_Helper::get_all_posts_terms( $posts );

			switch ( $atts['gallery_sliders_type'] ) {
				case 'gradient':

					brs_add_libraries( array( 'component__gallery_sliders', 'fancybox' ) );

					$overlay_class   = array();
					$overlay_class[] = 'brk-abs-overlay';
					$overlay_class[] = $atts['gradient'];
					$overlay_class   = implode( ' ', $overlay_class );

					$output = '<div class="brk-gradien-carousel position-relative">

				                <ul class="brk-sort-list font__family-montserrat font__size-15 font__weight-bold text-uppercase letter-spacing-20 brk-sort-list_full-width brk-sort-list_bottom-indicators mb-40">
				                    <li class="brk-sort-list__item active" data-filter="all">
				                        <span>' . esc_html__( 'All', 'berserk' ) . '</span> <span class="brk-sort-list__item-counter brk-base-font-color font__weight-light"></span>
				                    </li>';

					foreach ( $terms as $key => $term ) {
						$output .= '<li class="brk-sort-list__item" data-filter="' . $key . '">
				                        <span>' . $term . '</span>
				                        <span class="brk-sort-list__item-counter brk-base-font-color font__weight-light"></span>
				                    </li>';
					}

					$output .= '</ul>

				                <div class="brk-bordered-bg pt-100 pb-130">
				                    <div class="brk-bordered-bg__img brk-bg-pattern brk-abs-overlay ' . $pattern_class . '" style="' . $pattern_style . '"></div>
				                    <div class="' . $overlay_class . '"></div>

				                    <div class="brk-gradien-carousel__items slick-loading">';

					foreach ( $posts as $post ) {

						$tax         = ( get_object_taxonomies( $post ) );
						$terms_array = array();
						foreach ( $tax as $taxonomy ) {
							$terms = get_the_terms( $post->ID, $taxonomy );
							if ( ! empty( $terms ) ) {
								foreach ( $terms as $term ) {
									$terms_array[] = $term->slug;
								}
							}
						}
						$image_size = array( 400, 300 );
						if ( ! empty( $atts['image_size'][0] ) ) {
							$image_size = $atts['image_size'];
						}
						$terms_array   = implode( ' ', $terms_array );
						$bg_image      = get_the_post_thumbnail_url( $post->ID, $image_size );
						$bg_image_full = get_the_post_thumbnail_url( $post->ID, 'full' );

						$count = get_comment_meta( $post->ID, 'post_image_likes', true );
						$count = ( $count == '' ) ? '0' : $count;

						$output .= '<div>
		                            <div class="brk-gradient-card brk-gradient-card_hover-sizer ' . $terms_array . '" data-filter="' . $terms_array . '">
		                                <img class="brk-gradient-card__img" src="' . esc_url( $bg_image ) . '">
		                                <div class="brk-gradient-card__overlay brk-base-bg-gradient-6-black"></div>
		                                <div class="brk-gradient-card__body">
		                                    <a href="' . esc_url( $bg_image_full ) . '" class="brk-gradient-card__img-frame fancybox">
		                                        <i class="fal fa-plus font__size-23 brk-base-font-color"></i>
		                                    </a>
		                                    <a href="" class="brk-gradient-card__link text-uppercase font__family-montserrat brk-white-font-color gallery-like-btn" data-post-id="' . $post->ID . '">
		                                        <i class="fal fa-heart font__size-17"></i>
		                                        <span class="font__size-15 font__weight-light">' . $count . '</span>
		                                    </a>
		                                    <a href="' . get_permalink( $post->ID ) . '"
		                                       class="brk-gradient-card__link text-uppercase font__family-montserrat brk-white-font-color">
		                                        <i class="fal fa-long-arrow-right font__size-17"></i>
		                                    </a>
		                                </div>
		                            </div>
		                        </div>';
					}

					$output .= '</div>

				                </div>

				            </div>';
					break;

				case 'solid':
					brs_add_libraries( array( 'component__gallery_sliders', 'fancybox' ) );

					$output = '<div class="brk-gallery-solid">
				                <ul class="brk-sort-list font__family-montserrat font__size-15 font__weight-bold text-uppercase letter-spacing-20 brk-gallery-solid__sort">
				                    <li class="brk-sort-list__item active" data-filter="all">
				                        <span>' . esc_html__( 'All', 'berserk' ) . '</span> <span
				                            class="brk-sort-list__item-counter brk-base-font-color font__weight-light"></span>
				                    </li>';
					foreach ( $terms as $key => $term ) {
						$output .= '<li class="brk-sort-list__item" data-filter="' . $key . '">
				                        <span>' . $term . '</span> <span class="brk-sort-list__item-counter brk-base-font-color font__weight-light"></span>
				                    </li>';
					}

					$output .= '</ul>
				                <div class="brk-gallery-solid__slider slick-loading">';

					foreach ( $posts as $post ) {

						$tax         = ( get_object_taxonomies( $post ) );
						$terms_array = array();
						foreach ( $tax as $taxonomy ) {
							$terms = get_the_terms( $post->ID, $taxonomy );
							if ( ! empty( $terms ) ) {
								foreach ( $terms as $term ) {
									$terms_array[] = $term->slug;
								}
							}
						}
						$terms_array   = implode( ' ', $terms_array );
						$bg_image      = get_the_post_thumbnail_url( $post->ID, $atts['image_size'] );
						$bg_image_full = get_the_post_thumbnail_url( $post->ID, 'full' );

						$count = get_comment_meta( $post->ID, 'post_image_likes', true );
						$count = ( $count == '' ) ? '0' : $count;

						$output .= '<div>
				                        <div class="brk-liked-card  ' . $terms_array . '" data-filter="' . $terms_array . '">
				                            <img class="brk-liked-card__img" src="' . esc_url( $bg_image ) . '">
				                            <div class="brk-liked-card__overlay brk-base-bg-1"></div>
				                            <div class="brk-liked-card__body">
				                                <a href="' . esc_url( $bg_image_full ) . '" class="brk-liked-card__img-frame fancybox">
				                                    <i class="fal fa-plus font__size-23 brk-base-font-color"></i>
				                                </a>
				                                <a href="" class="brk-liked-card__link text-uppercase font__family-montserrat brk-white-font-color gallery-like-btn" data-post-id="' . $post->ID . '">
				                                    <i class="fal fa-heart font__size-17"></i>
				                                    <span class="font__size-15 font__weight-light">' . $count . '</span>
				                                </a>
				                            </div>
				                        </div>
				                    </div>';
					}

					$output .= '</div>
				                <div class="brk-gallery-solid__slider-control">
				                    <!-- Append donts and arrows -->
				                </div>
				            </div>';

					break;

				case 'strict':
					brs_add_libraries( array( 'component__gallery_sliders', 'fancybox' ) );

					$output = '<div class="brk-strict-carousel pb-20">
					                <div class="container">
					                    <div class="brk-strict-carousel__items slick-loading">';

					foreach ( $posts as $post ) {

						$bg_image      = get_the_post_thumbnail_url( $post->ID, $atts['image_size'] );
						$bg_image_full = get_the_post_thumbnail_url( $post->ID, 'full' );

						$output .= '<div>
					                            <div class="brk-card-fill">
					                                <img src="' . esc_url( $bg_image ) . '" alt="" class="brk-card-fill__img">
					                                <h3 class="brk-card-fill__title font__family-montserrat font__size-50 line__height-52 font__weight-bold text-uppercase">
													    <span class="brk-card-fill__title-text" style="background-image: url(' . esc_url( $bg_image ) . ')">
													      ' . esc_html( $post->post_title ) . '
													    </span>
					                                </h3>
					                                <div class="brk-card-fill__links text-right">
					                                    <a href="' . esc_url( $bg_image_full ) . '" class="brk-card-fill__link brk-base-font-color mr-10 fancybox">
					                                        <i class="far fa-search font__size-16"></i>
					                                    </a>
					                                    <a href="' . get_permalink( $post->ID ) . '" class="brk-card-fill__link brk-base-font-color">
					                                        <i class="fal fa-angle-right font__size-27"></i>
					                                    </a>
					                                </div>
					                            </div>
					                        </div>';
					}

					$output .= '</div>

					                    <div class="brk-strict-carousel__control">
					                    </div>
					                </div>

					            </div>';

					break;

				case 'dark':
					brs_add_libraries( array( 'component__gallery_sliders', 'fancybox' ) );

					$output = '<div class="brk-carousel-dark">
					                <div class="container">
					                    <div class="brk-carousel-dark__items slick-loading">';

					foreach ( $posts as $post ) {

						$bg_image      = get_the_post_thumbnail_url( $post->ID, $atts['image_size'] );
						$bg_image_full = get_the_post_thumbnail_url( $post->ID, 'full' );

						$tax         = ( get_object_taxonomies( $post ) );
						$terms_array = array();
						foreach ( $tax as $taxonomy ) {
							$terms = get_the_terms( $post->ID, $taxonomy );
							if ( ! empty( $terms ) ) {
								foreach ( $terms as $term ) {
									$terms_array[] = $term->name;
								}
							}
						}
						$terms_array = implode( ',', $terms_array );

						$output .= '<div>
			                            <div class="brk-card-out">
			                                <img src="' . esc_url( $bg_image ) . '" alt="" class="brk-card-out__img">
			                                <div class="brk-card-out__overlay"></div>
			                                <a href="' . esc_url( $bg_image_full ) . '" class="brk-card-out__link fancybox">
			                                    <span class="font__family-playfair font__size-56 font__weight-bold brk-white-font-color">+</span>
			                                </a>
			                                <div class="brk-card-out__info">
			                                    <h3 class="font__family-playfair brk-white-font-color font__size-56 line__height-56 font__weight-bold mb-10">' . esc_html( $post->post_title ) . '</h3>
			                                    <span class="brk-white-font-color font__family-montserrat font__size-14 font__weight-bold line__height-14 brk-bg-primary brk-card-out__category">' . $terms_array . '</span>
			                                </div>
			                            </div>
			                        </div>';
					}

					$output .= '</div>
					                </div>
					            </div>';

					break;

				case 'gallery_1':
				case 'gallery_2':
				case 'gallery_3':
				case 'gallery_4':
				case 'gallery_5':

					brs_add_libraries( 'component__gallery' );

					if ( $atts['grid_type'] == 'masonry' ) {

						brs_add_libraries( 'component__portfolio_isotope' );

						$output = '
            <div class="brk-js-parent">
              <div class="brk-gallery brk-js-append brk-gallery_masonry brk-grid ' . $atts['columns_padding'] . '" data-grid-cols="' . $atts['columns_count'] . '" data-grid-cols-tablet="' . $atts['columns_count'] . '">
                <div class="brk-grid__sizer">
                </div>';
					} else {
						$output = '
            <div class="brk-gallery brk-js-parent">
              <div class="row brk-js-append ' . $atts['columns_padding'] . '">';
					}

					foreach ( $posts as $i => $post ) {

						$image_size = $atts['image_size'];

						if ( $atts['grid_type'] == 'masonry' ) {

							$masonry_sizes = array( 12, 11, 11, 22, 11, 11, 11 );
							$width         = $masonry_sizes[ $i % count( $masonry_sizes ) ] % 10;
							$height        = (int) ( $masonry_sizes[ $i % count( $masonry_sizes ) ] / 10 );

							// Increase the image size so it will not be small for 2x 3x and etc sizes
							if ( is_array( $atts['image_size'] ) ) {
								$image_size = array(
									$atts['image_size'][0] * $width,
									$atts['image_size'][1] * $height
								);
							}

							$output .= '
              <div class = "brk-grid__item brk-grid__item_width-' . $width . ' brk-grid__item_height-' . $height . '">';

						} else {
							$output .= '<div class = "col-12 col-sm-' . $atts['columns_count'] . '">';
						}

						$bg_image      = get_the_post_thumbnail_url( $post->ID, $image_size );
						$bg_image_full = get_the_post_thumbnail_url( $post->ID, 'full' );
						$card_style    = isset( $atts['card_style'] ) && $atts['card_style'] == 'gray_scale' ? ' brk-gallery-card_grayscale' : '';

						switch ( $atts['gallery_sliders_type'] ) {
							case 'gallery_1':
								$output .= '
                <div class="brk-gallery-card' . $card_style . '">
                  <img src="' . esc_url( $bg_image ) . '" alt="" class="brk-gallery-card__img">
                  <span class="brk-gallery-card__overlay-angle"></span>
                  <a href="' . esc_url( $bg_image_full ) . '" data-fancybox="gallery" class="brk-gallery-card__fancy_angle"></a>
                  <span class="brk-gallery-card__angle-btn pr-15 pb-15 justify-content-end align-items-end d-flex">
                    <i class="fal fa-search font__size-16 brk-white-font-color" aria-hidden="true"></i>
                  </span>
                </div>';
								break;
							case 'gallery_2':
								$output .= '
                <div class="brk-gallery-card' . $card_style . '">
                  <img src="' . esc_url( $bg_image ) . '" alt="" class="brk-gallery-card__img">
                  <span class="brk-gallery-card__overlay-angle-top bg-black opacity-70"></span>
                  <a href="' . esc_url( $bg_image_full ) . '" data-fancybox="gallery" class="brk-gallery-card__fancy_angle"></a>
                  <span class="brk-gallery-card__angle-btn-top pr-15 pt-15 justify-content-end align-items-start d-flex">
                    <i class="fal fa-search font__size-16 brk-white-font-color" aria-hidden="true"></i>
                  </span>
                </div>';
								break;
							case 'gallery_3':
								$output .= '
                <div class="brk-gallery-card brk-gallery-card_shadow' . $card_style . '">
                  <img src="' . esc_url( $bg_image ) . '" alt="" class="brk-gallery-card__img">
                    <a href="' . esc_url( $bg_image_full ) . '" data-fancybox="gallery" class="fancybox brk-gallery-card__overlay-full brk-bg-gradient-40deg-85-28 d-flex align-items-center justify-content-center">
                      <i class="fal fa-plus font__size-36 brk-white-font-color"></i>
                    </a>
                </div>';
								break;
							case 'gallery_4':
								$output .= '
									<div class="brk-gallery-card brk-gallery-card_overflow' . $card_style . '">
										<img src="' . esc_url( $bg_image ) . '" alt="" class="brk-gallery-card__img">
										<span class="brk-gallery-card__add-1"></span>
										<span class="brk-gallery-card__add-2"></span>
										<span class="brk-gallery-card__add-3"></span>
										<span class="brk-gallery-card__add-4"></span>
										<span class="brk-gallery-card__add-5"></span>
										<span class="brk-gallery-card__add-6"></span>
										<span class="brk-gallery-card__overlay brk-bg-gradient-40deg-60"></span>
										<a href="' . esc_url( $bg_image_full ) . '" data-fancybox="gallery" class="brk-gallery-card__fancy fancybox brk-white-font-color d-flex align-items-center justify-content-center">
											<i class="fal fa-plus font__size-36"></i>
										</a> 
									</div>';
								break;
							case 'gallery_5':
								$output .= '
                <div class="brk-gallery-card' . $card_style . '">
                  <img src="' . esc_url( $bg_image ) . '" alt="" class="brk-gallery-card__img">
                  <a href="' . esc_url( $bg_image_full ) . '" data-fancybox="gallery" class="icon__btn icon__btn-white icon__btn-lg icon__btn-circled brk-gallery-card__central-btn">
                      <i class="fa fa-search icon-inside" aria-hidden="true"></i>
                      <span class="before"></span>
                      <span class="after"></span>
                    </a>
                </div>';
								break;
						}

						$output .= '
              </div>';
					}

					$output .= '
            </div>';

					if ( $atts['ajax_btn_display'] == 'show' || $atts['ajax_btn_display'] == 'icon' ) {
						$output .= '
					<div class="text-center mt-80 mb-80">
						<a href="#" class="icon__btn icon__btn-anim icon__btn-md icon__btn-invert brk-shortcode-pagination-ajax" data-shortcode = "gallery_sliders" data-numberposts = "' . $atts['items_per_load'] . '">
							<span class="before"></span>
							<i class="fa fa-refresh" aria-hidden="true"></i>
							<span class="after"></span>
							<span class="bg"></span>
						</a>
					' . berserk_shortcodes_dynamic_filter_data( $atts ) . '
					</div>';
					}

					if ( $atts['ajax_btn_display'] == 'text' ) {
						$output .= '
						<div class="text-center">
							<a href="#" class="btn btn-inside-out btn-md btn-icon-abs border-radius-25 font__family-open-sans font__weight-bold mt-30 brk-shortcode-pagination-ajax" data-shortcode="gallery_sliders" data-numberposts="' . $atts['items_per_load'] . '">
								<span class="before">' . esc_html__( 'Load More', 'berserk' ) . '</span>
								<span class="text">' . esc_html__( 'Click Me', 'berserk' ) . '</span>
								<span class="after">' . esc_html__( 'Load More', 'berserk' ) . '</span>
							</a>
							' . berserk_shortcodes_dynamic_filter_data( $atts ) . '
						</div>';
					}

					$output .= '
          </div>';
					break;

				case "gallery_6":
					brs_add_libraries( array( 'component__portfolio_galleries', 'component__social_links' ) );

					foreach ( $posts as $post ) {
						$bg_image      = get_the_post_thumbnail_url( $post->ID, $atts['image_size'] );
						$gallery_items = get_post_meta( $post->ID, 'post-gallery', true );
						$custom_values = get_post_custom( $post->ID );

						$output = '<div class="brk-portfolio-galleries__card">
									  <img class="brk-abs-img lazyload" alt="alt" src="' . esc_attr( BRK_DATA_IMAGE ) . '" data-src="' . esc_url( $bg_image ) . '">
									  <div class="brk-portfolio-galleries__label pt-60 pl-70 pr-60 pb-50">
									    <h2 class="font__family-roboto font__size-56 font__weight-thin mb-2">' . esc_html( $post->post_title ) . '</h2>
									      <h3 class="brk-dark-font-color font__family-montserrat font__size-12 font__weight-normal text-uppercase letter-spacing-100 mb-auto">' . count( $gallery_items ) . esc_html__( 'photos', 'berserk' ) . '</h3>
											    <div class="brk-social-links brk-black-font-color font__size-13 brk-social-links_opacity brk-location-screen-left">';

						$meta = Berserk_Portfolio::postMeta();

						foreach ( $custom_values as $key => $value ) {

							if ( ! empty( $value[0] ) && isset( $meta[ $key ] ) && $meta[ $key ]['group'] == 'socials' ) {
								$icon       = $meta[ $key ]['icon'];
								$class_icon = 'fab';
								if ( $icon == 'phone' ) {
									$class_icon = 'fas';
								}
								$class_icon .= ' fa-' . $icon;
								$output .= '<a href="' . esc_url( @$meta[ $key ]['prefix'] . $value[0] ) . '"
										   class="brk-social-links__item">
											<i class="' . esc_attr( $class_icon ) . '"></i>
										</a>';
								unset( $custom_values[ $key ] );
							}
						}

						$output .= '</div>
										    <a href="' . get_permalink( $post->ID ) . '" class="text-uppercase font__family-montserrat font__size-12 font__weight-bold text-underline letter-spacing-100 mt-30"><u>' . esc_html__( 'read more', 'berserk' ) . '</u></a>
										  </div>

										</div>';
					}
					break;

			}

			return $output;
		}


	}

	// create shortcode
	BRS_Gallery_Sliders::get_instance();

}
