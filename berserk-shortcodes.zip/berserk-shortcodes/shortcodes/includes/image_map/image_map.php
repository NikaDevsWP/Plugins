<?php
/**
 * BRS Image Map shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Image_Map', false ) ) {

	require_once BERSERK_SHORTCODES_PATH . 'shortcodes/includes/shortcodes-ext.php';

	class BRS_Image_Map extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Image_Map();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_image_map', array( $this, 'shortcode_image_map' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				$params = array();

				$params[] = array(
					"heading"    => __( "Main Settings", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$params[] = array(
					'type'             => 'dropdown',
					'param_name'       => 'image_map',
					'heading'          => esc_html__( 'Select Image Map', 'berserk' ),
					'description'      => esc_html__( 'Choose image map from the drop down list.', 'berserk' ),
					'value'            => BRS_Shortcodes_VCParams::get_image_map_shortcodes(),
					'edit_field_class' => 'vc_col-sm-6 vc_column'
				);

				$params[] = array(
					'type'             => 'dropdown',
					'param_name'       => 'image_map_type',
					'heading'          => esc_html__( 'Image Map type', 'berserk' ),
					'description'      => esc_html__( 'Choose image map type', 'berserk' ),
					'value'            => array(
						'Default'                             => 'default',
						'Background (with absolute position)' => 'background',
						'Zoom'                                => 'zoom',
					),
					'edit_field_class' => 'vc_col-sm-6 vc_column'
				);

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Image map", 'berserk' ),
					"base"     => "brs_image_map",
					"icon"     => "brs_vc_ico_image_map",
					"class"    => "brs_vc_sc_image_map",
					"category" => __( 'Berserk', 'berserk' ),
					"params"   => $params
				) );
			}
		}

		public function shortcode_image_map( $atts, $content = null ) {

			brs_add_libraries( array( 'component__image_map' ) );

			$atts = shortcode_atts( array(
				'image_map'      => '',
				'image_map_type' => 'default'
			), $atts );

			$output = '';

			if ( $atts['image_map'] != '' ) {

				$before_image_map = '';
				$after_image_map = '';

				switch($atts['image_map_type']){
					case "background":
						$image_map_class = 'brk-image-map_absolute-top';
						break;

					case "zoom":
						$before_image_map = '<div class="brk-z-index-10 position-static position-xl-absolute image-map-creative_agency pt-20">';
						$image_map_class = 'brk-image-map';
						$after_image_map = '</div>';
						break;

					default:
						$image_map_class = 'brk-image-map';
						break;
				}

				$output          = do_shortcode( '[' . $atts['image_map'] . ']' );
				$output          = $before_image_map.'<div class="' . $image_map_class . '">' . $output . '</div>'.$after_image_map;
			}

			return $output;
		}
	}

	// create shortcode
	BRS_Image_Map::get_instance();

}
