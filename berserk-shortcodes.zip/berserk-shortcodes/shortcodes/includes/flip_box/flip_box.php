<?php
/**
 * BRS_Flip_Box Box shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Flip_Box', false ) ) {

	class BRS_Flip_Box extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Flip_Box();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_flip_box', array( $this, 'shortcode_flip_box' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Flip Box", 'berserk' ),
					"base"     => "brs_flip_box",
					"icon"     => "brs_vc_ico_flip_box",
					"class"    => "brs_vc_sc_flip_box",
					"category" => __( 'Berserk', 'berserk' ),
					"params"   => array(

						array(
							"heading"    => __( "Main Settings", 'berserk' ),
							"param_name" => "brs_title",
							"type"       => "brs_title",
						),
						array(
							'heading'    => __( 'Flip Box Type', 'berserk' ),
							'param_name' => 'flip_box_type',
							'type'       => 'brs_radio',
							'value'      => array(
								"Strict"   => "strict",
								"Gradient" => "gradient",
								"Multiply" => "multiply",
								"Split"    => "split",
								"Overlay"  => "overlay",
								"Circle"   => "circle",
								'Shop 1'   => 'shop_1',
								'Shop 2'   => 'shop_2',
								'Shop 3'   => 'shop_3',
								'Shop 4'   => 'shop_4',
							),
							'images'     => array(
								"strict"   => 'flip_box/strict.jpg',
								"gradient" => 'flip_box/gradient.jpg',
								"multiply" => 'flip_box/multiply.jpg',
								"split"    => 'flip_box/split.jpg',
								"overlay"  => 'flip_box/overlay.jpg',
								"circle"   => 'flip_box/circle.jpg',
								'shop_1'   => 'flip_box/shop_1.jpg',
								'shop_2'   => 'flip_box/shop_2.jpg',
								'shop_3'   => 'flip_box/shop_3.jpg',
								'shop_4'   => 'flip_box/shop_4.jpg',
							),
							'images_dim' => array(
								'w' => '150',
								'h' => '150'
							)
						),
						array(
							'type'             => 'textfield',
							'heading'          => __( 'First title', 'js_composer' ),
							'param_name'       => 'first_title',
							"value"            => "This is my boss",
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__flip_box_type strict gradient circle',
						),
						array(
							'type'             => 'textfield',
							'heading'          => __( 'Title', 'js_composer' ),
							'param_name'       => 'title',
							"value"            => "Jonathan",
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__flip_box_type strict gradient multiply overlay circle',
						),
						array(
							'type'             => 'textarea',
							'heading'          => __( 'Description', 'js_composer' ),
							'param_name'       => 'description',
							"value"            => "Makin' their way, the only way they know how, that's just a little bit more than.",
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__flip_box_type strict gradient multiply overlay circle',
						),

						array(
							'type'             => 'param_group',
							'heading'          => __( 'Items', 'js_composer' ),
							'param_name'       => 'values',
							'value'            => urlencode( json_encode( array(
								array(
									'item' => __( 'Maecenas vestibulum mollis', 'js_composer' ),
								),
								array(
									'item' => __( 'Pellentesque ut neque', 'js_composer' ),
								),
								array(
									'item' => __( 'Fellentesque habitant morbi', 'js_composer' ),
								)
							) ) ),
							'params'           => array(
								array(
									'type'        => 'textfield',
									'heading'     => __( 'Item', 'js_composer' ),
									'param_name'  => 'item',
									'admin_label' => true,
								)

							),
							'edit_field_class' => 'vc_col-sm-12 vc_column brk-dependency__flip_box_type overlay',

						),

						array(
							'type'             => 'vc_link',
							'heading'          => __( 'Link URL', 'js_composer' ),
							'param_name'       => 'url',
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__flip_box_type strict gradient multiply overlay',
						),
						array(
							'type'             => 'textfield',
							'heading'          => __( 'Number', 'js_composer' ),
							'param_name'       => 'number',
							"value"            => "01",
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__flip_box_type strict multiply circle',
						),
						array(
							"heading"          => __( "Product", 'berserk' ),
							"param_name"       => "brs_title",
							"type"             => "brs_title",
							'edit_field_class' => 'vc_col-sm-12 vc_column brk-dependency__flip_box_type split shop_1 shop_2 shop_3 shop_4',
						),
						array(
							"heading"          => __( "Add Product", 'berserk' ),
							"param_name"       => "product",
							"type"             => "brs_add_product",
							'edit_field_class' => 'vc_col-sm-12 vc_column brk-dependency__flip_box_type split shop_1 shop_2 shop_3 shop_4',
						),

						array(
							'type'             => 'dropdown',
							'heading'          => __( 'List style', 'berserk' ),
							'value'            => array(
								__( 'Default', 'berserk' ) => 'default',
								__( 'White', 'berserk' )   => 'white',
							),
							'param_name'       => 'list_style',
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__flip_box_type split',
						),
						array(
							"heading"          => __( "Background", 'berserk' ),
							"param_name"       => "brs_title",
							"type"             => "brs_title",
							'edit_field_class' => 'vc_col-sm-12 vc_column brk-dependency__flip_box_type gradient multiply overlay circle',
						),
						array(
							'type'             => 'attach_image',
							'heading'          => __( 'Background Image', 'js_composer' ),
							'param_name'       => 'bg_image',
							'value'            => '',
							'description'      => __( 'Select image from media library.', 'js_composer' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__flip_box_type gradient multiply overlay circle',
						),

						array(
							'type'             => 'dropdown',
							'heading'          => __( 'Flip Effect', 'berserk' ),
							'value'            => array(
								__( 'Horizontal', 'berserk' ) => 'horizontal',
								__( 'Vertical', 'berserk' )   => 'vertical',
							),
							'param_name'       => 'flip_effect',
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

						array(
							'type'             => 'dropdown',
							'heading'          => esc_html__( 'Overlay Hue type', 'berserk' ),
							'param_name'       => 'hue_type',
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__flip_box_type multiply',
							'value'            => array(
								esc_html__( 'Default', 'berserk' ) => '',
								esc_html__( 'Dark', 'berserk' )    => 'dark',
							),
						),

						array(
							"heading"          => __( "Background Color", 'berserk' ),
							"param_name"       => "brs_title",
							"type"             => "brs_title",
							'edit_field_class' => 'vc_col-xs-12 vc_column color_option brk-dependency__flip_box_type gradient overlay circle shop_3',
						),

						array(
							'type'             => 'dropdown',
							'heading'          => __( 'Hover Overlay', 'berserk' ),
							'value'            => array(
								__( 'Default', 'berserk' ) => 'brk-base-bg-gradient-50deg-a',
								__( 'Black', 'berserk' )   => 'bg-black opacity-80',
							),
							'param_name'       => 'hover_overlay',
							'edit_field_class' => 'vc_col-sm-6 vc_column color_option brk-dependency__flip_box_type shop_3',
						),

						array(
							'type'             => 'dropdown',
							'heading'          => __( 'Background Type', 'berserk' ),
							'value'            => array(
								__( 'Color Scheme', 'berserk' ) => 'color_scheme',
								__( 'Custom Color', 'berserk' ) => 'custom_color',
								__( 'Gradient', 'berserk' )     => 'gradient',
							),
							'param_name'       => 'bg_type',
							'edit_field_class' => 'vc_col-sm-6 vc_column color_option brk-dependency__flip_box_type gradient overlay circle',
						),

						array(
							"heading"          => __( "Color Scheme", 'berserk' ),
							"param_name"       => "color_scheme",
							"type"             => "brs_color_scheme",
							'colors'           => array(
								"Blue"   => 'blue',
								"Purple" => 'purple',
								//"Pink"   => 'pink',
								//"Aqua"   => 'aqua',
								//"Gray"   => 'gray',
								//"Brown"  => 'brown',
								//"Black"  => 'black'
							),
							'edit_field_class' => 'vc_col-xs-12 vc_column color_option brk-dependency__flip_box_type gradient overlay circle',
							'dependency'       => array(
								'element' => 'bg_type',
								'value'   => 'color_scheme',
							),
						),
						array(
							'type'             => 'colorpicker',
							'heading'          => __( 'Color', 'js_composer' ),
							'param_name'       => 'f_color',
							'value'            => '#2775ff',
							'edit_field_class' => 'vc_col-sm-6 vc_column color_option brk-dependency__flip_box_type gradient overlay circle',
							'dependency'       => array(
								'element' => 'bg_type',
								'value'   => array( 'custom_color', 'gradient' ),
							),
						),
						array(
							'type'             => 'colorpicker',
							'heading'          => __( 'Second Color', 'js_composer' ),
							'param_name'       => 's_color',
							'value'            => '#7202BB',
							'edit_field_class' => 'vc_col-sm-6 vc_column color_option brk-dependency__flip_box_type gradient overlay circle',
							'dependency'       => array(
								'element' => 'bg_type',
								'value'   => 'gradient',
							),
						),

						array(
							"heading"    => __( "Icon", 'berserk' ),
							"param_name" => "brs_title",
							"type"       => "brs_title vc_col-sm-6 vc_column icon_option brk-dependency__flip_box_type overlay",
						),


						array(
							'type'             => 'dropdown',
							'heading'          => __( 'Icon library', 'berserk' ),
							'value'            => array(
								__( 'Font Awesome', 'berserk' ) => 'fontawesome',
								__( 'Open Iconic', 'berserk' )  => 'openiconic',
								__( 'Typicons', 'berserk' )     => 'typicons',
								__( 'Entypo', 'berserk' )       => 'entypo',
								__( 'Linecons', 'berserk' )     => 'linecons',
								__( 'Mono Social', 'berserk' )  => 'monosocial',
								__( 'Livicon', 'berserk' )      => 'livicon',
							),
							'param_name'       => 'btn_icon_type',
							'edit_field_class' => 'vc_col-sm-6 vc_column icon_option brk-dependency__flip_box_type overlay',
						),
						array(
							'type'             => 'iconpicker',
							'heading'          => __( 'Icon', 'berserk' ),
							'param_name'       => 'icon_fontawesome',
							'value'            => 'fa fa-adjust',
							'settings'         => array(
								'emptyIcon'    => false,
								'iconsPerPage' => 4000,
							),
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'fontawesome',
							),
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column brk-dependency__flip_box_type overlay',
						),
						array(
							'type'             => 'iconpicker',
							'heading'          => __( 'Icon', 'berserk' ),
							'param_name'       => 'icon_openiconic',
							'value'            => 'vc-oi vc-oi-dial',
							'settings'         => array(
								'emptyIcon'    => false,
								'type'         => 'openiconic',
								'iconsPerPage' => 4000,
							),
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'openiconic',
							),
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column brk-dependency__flip_box_type overlay',
						),
						array(
							'type'             => 'iconpicker',
							'heading'          => __( 'Icon', 'berserk' ),
							'param_name'       => 'icon_typicons',
							'value'            => 'typcn typcn-adjust-brightness',
							'settings'         => array(
								'emptyIcon'    => false,
								'type'         => 'typicons',
								'iconsPerPage' => 4000,
							),
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'typicons',
							),
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column brk-dependency__flip_box_type overlay',
						),
						array(
							'type'             => 'iconpicker',
							'heading'          => __( 'Icon', 'berserk' ),
							'param_name'       => 'icon_entypo',
							'value'            => 'entypo-icon entypo-icon-note',
							'settings'         => array(
								'emptyIcon'    => false,
								'type'         => 'entypo',
								'iconsPerPage' => 4000,
							),
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'entypo',
							),
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column brk-dependency__flip_box_type overlay',
						),
						array(
							'type'             => 'iconpicker',
							'heading'          => __( 'Icon', 'berserk' ),
							'param_name'       => 'icon_linecons',
							'value'            => 'vc_li vc_li-heart',
							'settings'         => array(
								'emptyIcon'    => false,
								'type'         => 'linecons',
								'iconsPerPage' => 4000,
							),
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'linecons',
							),
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column brk-dependency__flip_box_type overlay',
						),
						array(
							'type'             => 'iconpicker',
							'heading'          => __( 'Icon', 'berserk' ),
							'param_name'       => 'icon_monosocial',
							'value'            => 'vc-mono vc-mono-fivehundredpx',
							'settings'         => array(
								'emptyIcon'    => false,
								'type'         => 'monosocial',
								'iconsPerPage' => 4000,
							),
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'monosocial',
							),
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column brk-dependency__flip_box_type overlay',
						),
						array(
							"heading"          => __( "Add livicon", 'berserk' ),
							"param_name"       => "brs_btn_icon",
							"type"             => "brs_btn_icon",
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'livicon',
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column icon_option brk-dependency__flip_box_type overlay',
						)

					)
				) );

			}
		}

		public function shortcode_flip_box( $atts, $content = null ) {

			$libraries = array( 'component__shop_flip', 'component__flip_box' );

			extract( shortcode_atts( array(
				'flip_box_type'    => 'strict',
				'first_title'      => 'This is my boss',
				'title'            => 'Jonathan',
				'description'      => "Makin' their way, the only way they know how, that's just a little bit more than.",
				'url'              => '',
				'btn_icon_type'    => 'livicon',
				'icon_fontawesome' => '',
				'icon_openiconic'  => '',
				'icon_typicons'    => '',
				'icon_entypo'      => '',
				'icon_linecons'    => '',
				'icon_monosocial'  => '',
				'brs_btn_icon'     => '',
				'bg_image'         => '',
				'flip_effect'      => 'horizontal',
				'number'           => '01',
				'product'          => '',
				//'brs_product'      => '',
				'values'           => '',
				'bg_type'          => 'color_scheme',
				'color_scheme'     => '',
				'f_color'          => '#2775ff',
				's_color'          => '#7202BB',
				'hue_type'         => '',
				'hover_overlay'    => '',
				'list_style'       => 'default'
			), $atts ) );

			// store atts
			$atts_backup = self::$atts;


			$bg_image = wp_get_attachment_image_src( $bg_image, 'full' );
			$bg_image = $bg_image[0];

			$url      = ( $url == '||' ) ? '' : $url;
			$url      = vc_build_link( $url );
			$link_url = $url['url'];
			$a_title  = ( $url['title'] == '' ) ? '' : $url['title'];
			$a_target = ( $url['target'] == '' ) ? '' : 'target="' . $url['target'] . '"';

			switch ( $flip_box_type ) {
				case "strict":
					$output = '<div class="flip-box text-sm-left">
								<div class="flip flip_' . $flip_effect . ' flip-box__strict">
									<div class="flip__front">
										<div class="flip-box__strict-number font__family-montserrat brk-base-font-color">' . esc_html( $number ) . '</div>
										<div class="flip-box__strict-title">
											<div class="font__family-montserrat font__weight-light font__size-21 text-uppercase">' . esc_html( $first_title ) . ' <span class="font__weight-bold">' . esc_html( $title ) . '</span></div>
										</div>
									</div>
									<div class="flip__back">
										<div class="flip-box__strict-number font__family-montserrat brk-base-font-color">' . esc_html( $number ) . '</div>
										<div class="flip-box__strict-item">
											<h4 class="font__family-montserrat font__weight-light font__size-21 text-uppercase">' . esc_html( $first_title ) . ' <span class="font__weight-bold">' . esc_html( $title ) . '</span></h4>
											<p class="font__family-open-sans font__size-16 text-gray mt-25">' . esc_html( $description ) . '</p>
											<a href="' . esc_url( $link_url ) . '" target="' . $a_target . '" class="font__family-open-sans font__weight-bold font__size-16 text-uppercase letter-spacing-100 link-icon mt-25">' . esc_html( $a_title ) . '<i class="icon fa fa-long-arrow-right"></i></a>
										</div>
									</div>
								</div>
							</div>';

					break;

				case "gradient":

					$bg_color = '';
					$bg_style = '';
					if ( $bg_type == 'color_scheme' ) {

						switch ( $color_scheme ) {
							case "blue":
								$bg_color = 'brk-base-bg-1';
								break;
							case "purple":
								$bg_color = 'brk-base-bg-2';
								break;
						}
					}
					if ( $bg_type == 'custom_color' ) {
						$bg_style = 'background-color: rgba(' . brs_hex2rgb( $f_color ) . ', 0.84);';
					}
					if ( $bg_type == 'gradient' ) {
						$bg_style = 'background-image: linear-gradient(to right, rgba(' . brs_hex2rgb( $f_color ) . ', 0.84), rgba(' . brs_hex2rgb( $s_color ) . ', 0.84));';
					}

					$output = '<div class="flip-box">
									<div class="flip flip_' . $flip_effect . ' flip-box__gradient text-center">
										<div class="flip__front flip-box__bg flip-box__gradient-pb100" style="background-image: url(' . $bg_image . ')">
											<span style="' . $bg_style . '" class="overlay-position-full ' . $bg_color . '"></span>
											<div class="flip-box__gradient-title font__family-montserrat font__weight-light font__size-28 text-capitalize"><span class="font__weight-bold">' . esc_html( $first_title ) . '</span> ' . esc_html( $title ) . '</div>
										</div>
										<div class="flip__back">
											<div class="flip-box__position flip-box__position_75">
												<h4 class="flip-box__gradient-h4 font__family-montserrat font__weight-light font__size-28 text-capitalize"><span class="font__weight-bold">' . esc_html( $first_title ) . '</span> ' . esc_html( $title ) . '</h4>
												<p class="font__family-open-sans font__size-14 line__height-21 text-gray mt-25 pr-30 pl-30">' . esc_html( $description ) . '</p>
												<a href="' . esc_url( $link_url ) . '" target="' . $a_target . '" class="btn btn-md border-radius-25 font__family-open-sans font__size-16 font__weight-bold btn-gradient mt-35">' . esc_html( $a_title ) . ' <span class="after"></span></a>
											</div>
										</div>
									</div>
								</div>';

					break;

				case "multiply":

					$flip_class = 'flip flip_' . $flip_effect . ' flip-box__multiply';
					if ( $hue_type != '' ) {
						$flip_class .= ' flip-box__multiply_' . $hue_type;
					}
					$output = '<div class="flip-box">
									<div class="' . esc_attr( $flip_class ) . '">
										<div class="flip__front">
											<div class="flip-box__multiply-title font__family-montserrat font__weight-light font__size-78 text-uppercase mt-35 pl-lg-50 pr-lg-50 pl-20 pr-20 lazyload" style="background-image: url(' . $bg_image . ')">' . esc_html( $title ) . '</div>
											<div class="flip-box__multiply-decoration flip-box__multiply-decoration_square border-radius-25 ml-xl-50 ml-20 mt-90 mb-40 lazyload" style="background-image: url(' . $bg_image . ')"><i class="fal fa-angle-right font__size-28 font__weight-thin" aria-hidden="true"></i></div>
										</div>
										<div class="flip__back flip-box__bg flip-box__bg_overlay" style="background-image: url(' . $bg_image . ')">
											<div class="flip-box__position flip-box__position_35 text-center">
												<h4 class="flip-box__multiply-h4 font__family-montserrat font__weight-bold font__size-78">' . esc_html( $number ) . '</h4>
												<p class="font__family-open-sans font__size-14 line__height-21 text-white mt-40 pr-30 pl-30">' . esc_html( $description ) . '</p>
												<a href="' . esc_url( $link_url ) . '" target="' . $a_target . '" class="btn btn-md font__family-open-sans font__size-16 font__weight-bold btn-inside-out btn-shadow flip-box__multiply-btn mt-40">
												  <span class="before">' . esc_html( $a_title ) . '</span>
												  <span class="text">' . esc_html( $a_title ) . '</span>
												  <span class="after">' . esc_html( $a_title ) . '</span>
												</a>
											</div>
										</div>
									</div>
								</div>';

					break;

				case "split":

					brs_add_libraries( array( 'component__elements', 'fancybox' ) );

					ob_start();
					$product = wc_get_product( $product );

					//$list = $list_style;
					include( locate_template( 'woocommerce/template-parts/product-grid.php' ) );
					$output = ob_get_clean();

					break;

				case "overlay":

					$bg_color = '';
					$bg_style = '';
					if ( $bg_type == 'color_scheme' ) {

						switch ( $color_scheme ) {
							case "blue":
								$bg_color = 'brk-base-bg-1';
								break;
							case "purple":
								$bg_color = 'brk-base-bg-2';
								break;
						}
					}
					if ( $bg_type == 'custom_color' ) {
						$bg_style = 'background-color: rgba(' . brs_hex2rgb( $f_color ) . ', 0.92);';
					}
					if ( $bg_type == 'gradient' ) {
						$bg_style = 'background-image: linear-gradient(10deg, rgba(' . brs_hex2rgb( $f_color ) . ', 0.92), rgba(' . brs_hex2rgb( $s_color ) . ', 0.92));';
					}

					$icon_class                     = array();
					$icon_class['type']             = $btn_icon_type;
					$icon_class['icon_livicon']     = '';
					$icon_class['icon_fontawesome'] = $icon_fontawesome;
					$icon_class['icon_openiconic']  = $icon_openiconic;
					$icon_class['icon_typicons']    = $icon_typicons;
					$icon_class['icon_entypo']      = $icon_entypo;
					$icon_class['icon_linecons']    = $icon_linecons;
					$icon_class['icon_monosocial']  = $icon_monosocial;
					$icon_class                     = $this->get_icon_class( $icon_class );
					$icon_html                      = ' <i class="' . $icon_class . '"></i>';

					if ( isset( $brs_btn_icon ) && $btn_icon_type == 'livicon' ) {

						$icon      = vc_param_group_parse_atts( $brs_btn_icon );
						$find      = "\\";
						$svg_icon  = do_shortcode( str_replace( $find, '', $icon['val'] ) );
						$icon_html = $svg_icon;
					}

					$items = vc_param_group_parse_atts( $values );

					$output = '<div class="flip-box">
								<div class="flip flip_' . $flip_effect . ' flip-box__overlay">
									<div class="flip__front text-center pt-70 pb-70">
										<div class="flip-box__overlay-shortdesc flip-box__bg" style="background-image: url(' . $bg_image . ')">
											<span style="' . $bg_style . '" class="overlay-position-full ' . $bg_color . '"></span>
											<div class="flip-box__overlay-front pt-sm-60 pt-30 pr-15 pl-15">
												' . $icon_html . '
												<div class="flip-box__overlay-title font__family-montserrat font__weight-semibold font__size-28 text-capitalize mt-sm-15 mt-10">' . esc_html( $title ) . '</div>
												<p class="flip-box__overlay-excerpt font__family-open-sans font__size-14 line__height-21 mt-sm-25 mt-10">' . esc_html( $description ) . '</p>
											</div>
										</div>
									</div>
									<div class="flip__back text-center box-shadow-base flip-box__bg" style="background-image: url(' . $bg_image . ')">
										<span class="overlay-position-full flip-box__overlay-bg"></span>
										<div class="flip-box__overlay-item">
											' . $icon_html . '
											<h3 class="font__family-montserrat font__weight-semibold font__size-28 text-capitalize mt-sm-15 mt-10">' . esc_html( $title ) . '</h3>
											<p class="flip-box__overlay-description font__family-open-sans font__size-14 line__height-21 mt-sm-25 mt-10">' . esc_html( $description ) . '</p>
											<ul class="flip-box__overlay-list font__family-open-sans font__size-15 line__height-26 font__weight-light text-left">';
					foreach ( $items as $item ) {
						$output .= '<li><i class="fal fa-check"></i>' . $item['item'] . '</li>';
					}
					$output .= '</ul>
										</div>
										<a href="' . esc_url( $link_url ) . '" target="' . $a_target . '" class="flip-box__overlay-btn btn btn-md btn-icon border-radius-25 font__family-open-sans font__weight-bold btn-inside-out">
										  <i class="fa fa-angle-right icon-inside" aria-hidden="true"></i>
										  <span class="before">' . esc_html( $a_title ) . '</span>
										  <span class="text">' . esc_html( $a_title ) . '</span>
										  <span class="after">' . esc_html( $a_title ) . '</span>
										</a>
									</div>
								</div>
							</div>';

					break;

				case "circle":

					$bg_color = '';
					$bg_style = '';
					if ( $bg_type == 'color_scheme' ) {

						switch ( $color_scheme ) {
							case "blue":
								$bg_color = 'brk-base-bg-1';
								break;
							case "purple":
								$bg_color = 'brk-base-bg-2';
								break;
						}
					}
					if ( $bg_type == 'custom_color' ) {
						$bg_style = 'background-color: rgba(' . brs_hex2rgb( $f_color ) . ', 0.84);';
					}
					if ( $bg_type == 'gradient' ) {
						$bg_style = 'background-image: linear-gradient(to bottom, rgba(' . brs_hex2rgb( $f_color ) . ', 0.84), rgba(' . brs_hex2rgb( $s_color ) . ', 0.84));';
					}

					$output = '<div class="flip-box">
								<div class="flip-box__circle flip-box__bg" style="background-image: url(' . $bg_image . ')">
									<span style="' . $bg_style . '" class="overlay-position-full ' . $bg_color . '"></span>
									<div class="flip-box__circle-item text-center">
										<div class="flip flip_' . $flip_effect . '">
											<div class="flip__front flip-box__circle-front">
												<div class="flip-box__circle-pretitle font__family-montserrat font__weight-ultralight">' . $number . '</div>
											</div>
											<div class="flip__back flip-box__circle-back">
												<div class="flip-box__circle-content">
													<h4>
														<strong class="font__family-montserrat font__weight-bold font__size-19 text-uppercase">' . esc_html( $first_title ) . '</strong>
														<span class="font__family-playfair font__style-italic font__size-19">' . esc_html( $title ) . '</span>
													</h4>
													<div class="divider-cross">
													  <span></span>
													  <span></span>
													</div>
													<p class="flip-box__circle-excerpt font__family-playfair font__weight-normal font__size-15 line__height-22">' . esc_html( $description ) . '</p>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>';
					break;

				case "shop_1":

					$libraries[] = 'slider__swiper';

					$product = wc_get_product( $product );

					$image_thumb = wp_get_attachment_image_src( get_post_thumbnail_id( $product->get_id() ), 'carousel-tiled-slide' );

					$price     = wc_price( $product->get_price() );
					$old_price = $product->get_sale_price() !== '' ? '<span class="old-price font__weight-light brk-dark-font-color">' . wc_price( $product->get_regular_price() ) . '</span>' : '';

					$label_terms = get_the_terms( $product->get_id(), 'brs_product_type' );
					$labels      = array();
					if ( is_array( $label_terms ) && ! empty( $label_terms ) ) {
						foreach ( $label_terms as $term ) {
							$labels[] = $term->name;
						}
					}

					$categories = $product->get_category_ids();
					$terms      = array();
					foreach ( $categories as $cat_id ) {
						$term    = get_term( $cat_id );
						$terms[] = $term->name;
					}

					$gallery_ids = $product->get_gallery_image_ids();

					$buy_now = apply_filters( 'woocommerce_loop_add_to_cart_link',
						sprintf( '<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="btn btn-inside-out btn-md btn-icon border-radius-25 font__family-open-sans font__weight-bold add-cart ajax_add_to_cart %s product_type_%s">
						<i class="fa fa-shopping-basket icon-inside" aria-hidden="true"></i>
									<span class="before">' . esc_html__( 'Buy Now', 'berserk' ) . '</span><span class="text">' . esc_html__( 'Buy Now', 'berserk' ) . '</span><span class="after">' . esc_html__( 'Buy Now', 'berserk' ) . '</span></a>',
							esc_url( $product->add_to_cart_url() ),
							esc_attr( $product->get_id() ),
							esc_attr( $product->get_sku() ),
							$product->is_purchasable() ? 'add_to_cart_button' : '',
							esc_attr( $product->get_type() )
						),
						$product );

					$output = '<div class="flip-box brk-sc-flip-one text-center">
									<div class="flip flip_' . $flip_effect . '">
										<div class="flip__front brk-sc-flip-one__front">';
					if ( ! empty( $labels ) ) {
						foreach ( $labels as $label ) {
							$output .= '<div class="brk-sc-flip-one__stick brk-sc-flip-one__stick_style-1 font__family-montserrat font__weight-bold">
												' . $label . '
											</div>';
						}
					}
					$output .= '<div class="brk-sc-flip-one__thumb"><img src="' . esc_url( $image_thumb[0] ) . '" alt="" class="brk-abs-img"></div>
											<div class="brk-sc-flip-one__description">';
					foreach ( $terms as $term ) {
						$output .= '<div class="brk-sc-flip-one__cat font__family-montserrat font__weight-bold text-uppercase brk-white-font-color brk-bg-primary brk-base-box-shadow-primary">' . $term . '</div>';
					}

					$output .= '<div class="brk-sc-flip-one__title">
													<h4 class="font__family-montserrat font__weight-bold">' . esc_html( $product->get_name() ) . '</h4>
												</div>
												<div class="brk-sc-flip-one__price font__family-montserrat">
													<div class="price font__weight-bold brk-base-font-color">' . $price . '</div>
													' . $old_price . '
												</div>
											</div>
										</div>
										<div class="flip__back brk-sc-flip-one__back">';
					if ( ! empty( $labels ) ) {
						foreach ( $labels as $label ) {

							$output .= '<div class="brk-sc-flip-one__stick brk-sc-flip-one__stick_style-1 font__family-montserrat font__weight-bold">
												' . $label . '
											</div>';
						}
					}

					if ( ! empty( $gallery_ids ) ) {

						$output .= '<div class="brk-swiper-default brk-sc-flip-one__slider">
									<div class="swiper-container">
										<div class="swiper-wrapper">';

						foreach ( $gallery_ids as $id ) {
							$image_src = wp_get_attachment_image_src( $id, array( 270, 385 ) );
							$output .= '<div class="swiper-slide"><img src="' . esc_url( $image_src[0] ) . '" alt=""></div>';
						}

						$output .= '</div>
									</div>

									<div class="brk-swiper-default-nav-light brk-swiper-default-nav-prev"><i class="fal fa-angle-left"></i></div>
									<div class="brk-swiper-default-nav-light brk-swiper-default-nav-next"><i class="fal fa-angle-right"></i></div>
								</div>';
					}

					$output .= $buy_now . '</div>
						</div>
					</div>';

					break;

				case 'shop_2':

					$product = wc_get_product( $product );

					$image_thumb = wp_get_attachment_image_src( get_post_thumbnail_id( $product->get_id() ), array(
						124,
						215
					) );

					$price = wc_price( $product->get_price() );

					$label_terms = get_the_terms( $product->get_id(), 'brs_product_type' );
					$labels      = array();
					if ( is_array( $label_terms ) && ! empty( $label_terms ) ) {
						foreach ( $label_terms as $term ) {
							$labels[] = $term->name;
						}
					}

					$categories = $product->get_category_ids();
					$terms      = array();
					foreach ( $categories as $cat_id ) {
						$term    = get_term( $cat_id );
						$terms[] = $term->name;
					}

					$buy_now = apply_filters( 'woocommerce_loop_add_to_cart_link',
						sprintf( '<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="btn btn-inside-out btn-md btn-icon border-radius-25 font__family-open-sans font__weight-semibold add-cart ajax_add_to_cart %s product_type_%s">
						<i class="fa fa-shopping-basket icon-inside"></i>
						<span class="before">' . $price . '</span><span class="text">' . $price . '</span><span class="after">' . $price . '</span></a>',
							esc_url( $product->add_to_cart_url() ),
							esc_attr( $product->get_id() ),
							esc_attr( $product->get_sku() ),
							$product->is_purchasable() ? 'add_to_cart_button' : '',
							esc_attr( $product->get_type() )
						),
						$product );

					$product_attributes = $product->get_attributes();
					$desc               = $product->get_description();

					$output = '<div class="flip-box brk-sc-flip-two text-center">
									<div class="flip flip_' . $flip_effect . '">
										<div class="flip__front brk-sc-flip-two__front">
											<div class="brk-sc-flip-two__thumb"><img src="' . esc_url( $image_thumb[0] ) . '" alt=""></div>
											<div class="brk-sc-flip-two__description">';
					if ( ! empty( $labels ) ) {
						foreach ( $labels as $label ) {
							$output .= '<div class="brk-sc-flip-two__stick font__family-montserrat font__weight-light brk-white-font-color brk-bg-primary">
													' . $label . '
												</div>';
						}
					}
					$output .= '<div class="brk-sc-flip-two__price font__family-montserrat font__weight-medium brk-base-font-color">
													' . $price . '
												</div>
												<div class="brk-sc-flip-two__front-title font__family-montserrat font__weight-light brk-dark-font-color">
													' . esc_html( $product->get_name() ) . '
												</div>
											</div>
										</div>
										<div class="flip__back brk-sc-flip-two__back">
											<div class="brk-sc-flip-two__back-layer">
												<div class="brk-sc-flip-two__back-title font__family-montserrat font__weight-medium">
												   ' . esc_html( $product->get_name() ) . '
												</div>';

					if ( ! empty( $product_attributes ) ) {


						$output .= '<div class="brk-sc-flip-two__list scrollbar-inner">
										<ul class="pl-15 pr-15">';

						foreach ( $product_attributes as $key => $attribute ) {
							$value = implode( ',', $attribute['options'] );
							$output .= '<li><i class="far fa-check brk-base-font-color"></i> ' . $value . '</li>';

						}
						$output .= '</ul></div>';
					} else {
						$output .= '<p class="pl-15 pr-15">' . $desc . '</p>';
					}

					$output .= '<div class="brk-sc-flip-two__button">
													' . $buy_now . '
												</div>
											</div>
										</div>
									</div>
								</div>';

					break;

				case "shop_3":

					$product = wc_get_product( $product );

					$image_thumb = wp_get_attachment_image_src( get_post_thumbnail_id( $product->get_id() ), array(
						263,
						270
					) );

					$price = wc_price( $product->get_price() );

					$label_terms = get_the_terms( $product->get_id(), 'brs_product_type' );
					$labels      = array();
					if ( is_array( $label_terms ) && ! empty( $label_terms ) ) {
						foreach ( $label_terms as $term ) {
							$labels[] = $term->name;
						}
					}
					$labels = implode( ', ', $labels );

					$categories = $product->get_category_ids();
					$terms      = array();
					foreach ( $categories as $cat_id ) {
						$term    = get_term( $cat_id );
						$terms[] = $term->name;
					}

					$buy_now = apply_filters( 'woocommerce_loop_add_to_cart_link',
						sprintf( '<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="btn btn-inside-out btn-lg btn-icon font__family-open-sans font__weight-bold add-cart ajax_add_to_cart %s product_type_%s">
							<i class="fa fa-shopping-basket icon-inside" aria-hidden="true"></i><span class="before"> </span><span class="text"> </span><span class="after"> </span>
						</a>',
							esc_url( $product->add_to_cart_url() ),
							esc_attr( $product->get_id() ),
							esc_attr( $product->get_sku() ),
							$product->is_purchasable() ? 'add_to_cart_button' : '',
							esc_attr( $product->get_type() )
						),
						$product );

					$product_attributes = $product->get_attributes();
					$desc               = $product->get_description();

					$rate = $product->get_average_rating() * 20;


					$output = '<div class="flip-box brk-sc-flip-three text-center">
							<div class="flip flip_' . $flip_effect . '">
								<div class="flip__front brk-sc-flip-three__front">';

					$stick_class = ( $hover_overlay == 'bg-black opacity-80' ) ? 'brk-base-bg-gradient-90deg' : 'brk-bg-primary brk-base-bg-8';
					if ( ! empty( $labels ) ) {
						$output .= '<div class="brk-sc-flip-three__stick font__family-montserrat">
										<span class="' . $stick_class . '">' . $labels . '</span>
									</div>';
					}

					$output .= '<div class="brk-sc-flip-three__thumb"><img src="' . esc_url( $image_thumb[0] ) . '" alt="">
									</div>
									<div class="brk-sc-flip-three__price font__family-montserrat font__weight-bold brk-white-font-color brk-bg-primary brk-base-box-shadow-primary">
										' . $price . '
									</div>
								</div>
								<div class="flip__back brk-sc-flip-three__back">
									<div class="brk-abs-bg-overlay z-index-2 ' . $hover_overlay . '"></div>
									<div class="brk-sc-flip-three__thumb">
										<img src="' . esc_url( $image_thumb[0] ) . '" alt="">
									</div>';

					if ( ! empty( $labels ) ) {
						$output .= '<div class="brk-sc-flip-three__stick font__family-montserrat">
										<span class="' . $stick_class . '">' . $labels . '</span>
									</div>';
					}

					$output .= '<div class="brk-sc-flip-three__description">';

					if ( ! empty( $product_attributes ) ) {

						$output .= '<div class="brk-sc-flip-three__description-scroll scrollbar-inner"><ul class="pr-15">';

						foreach ( $product_attributes as $key => $attribute ) {
							$value = implode( ',', $attribute['options'] );
							$output .= '<li class="brk-white-font-color"><i class="far fa-check"></i> ' . $value . '</li>';
						}

						$output .= '</ul></div>';
					} else {
						$output .= '<p>' . $desc . '</p>';
					}

					$output .= '<div class="brk-sc-flip-three__rating mt-30">
											<div class="brk-rating">
												<div class="brk-rating__layer">
													<i class="fal fa-star brk-dark-font-color"></i>
													<i class="fal fa-star brk-dark-font-color"></i>
													<i class="fal fa-star brk-dark-font-color"></i>
													<i class="fal fa-star brk-dark-font-color"></i>
													<i class="fal fa-star brk-dark-font-color"></i>
												</div>
												<div class="brk-rating__imposition" style="width: ' . $rate . '%">
													<div class="visible">
														<i class="fas fa-star brk-base-font-color"></i>
														<i class="fas fa-star brk-base-font-color"></i>
														<i class="fas fa-star brk-base-font-color"></i>
														<i class="fas fa-star brk-base-font-color"></i>
														<i class="fas fa-star brk-base-font-color"></i>
													</div>
												</div>
											</div>
										</div>
									</div>
									' . $buy_now . '</div>
							</div>

							<div class="brk-sc-flip-three__title">
								<h4 class="font__family-montserrat font__weight-medium">' . esc_html( $product->get_name() ) . '</h4>
							</div>
						</div>';
					break;

				case "shop_4":

					$product = wc_get_product( $product );

					$image_thumb = wp_get_attachment_image_src( get_post_thumbnail_id( $product->get_id() ), array(
						122,
						205
					) );

					$price     = wc_price( $product->get_price() );
					$old_price = $product->get_sale_price() !== '' ? '<div class="brk-sc-flip-four__old-price font__family-montserrat font__weight-medium">' . wc_price( $product->get_regular_price() ) . '</div>' : '';

					$label_terms = get_the_terms( $product->get_id(), 'brs_product_type' );
					$labels      = array();
					if ( is_array( $label_terms ) && ! empty( $label_terms ) ) {
						foreach ( $label_terms as $term ) {
							$labels[] = $term->name;
						}
					}

					$categories = $product->get_category_ids();
					$terms      = array();
					foreach ( $categories as $cat_id ) {
						$term    = get_term( $cat_id );
						$terms[] = $term->name;
					}
					//$terms = implode( ', ', $terms );

					$gallery_ids = $product->get_gallery_image_ids();

					$buy_now = apply_filters( 'woocommerce_loop_add_to_cart_link',
						sprintf( '<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="btn btn-inside-out btn-lg btn-icon font__family-open-sans font__weight-bold add-cart ajax_add_to_cart %s product_type_%s">
						<i class="fa fa-shopping-basket icon-inside" aria-hidden="true"></i><span class="before"> </span><span class="text"> </span><span class="after"> </span></a>',
							esc_url( $product->add_to_cart_url() ),
							esc_attr( $product->get_id() ),
							esc_attr( $product->get_sku() ),
							$product->is_purchasable() ? 'add_to_cart_button' : '',
							esc_attr( $product->get_type() )
						),
						$product );

					$output = '<div class="flip-box brk-sc-flip-four">
							<div class="flip flip_' . $flip_effect . '">
								<div class="flip__front brk-sc-flip-four__front">
									<div class="brk-sc-flip-four__col">';


					$output .= '<div class="d-flex flex-wrap">';

					if ( ! empty( $terms ) ) {
						foreach ( $terms as $term ) {
							$output .= '<span class="brk-sc-flip-four__cat font__family-montserrat brk-bg-primary brk-white-font-color">' . $term . '</span>';
						}
					}

					if ( ! empty( $labels ) ) {
						foreach ( $labels as $label ) {
							$output .= '<span class="brk-sc-flip-four__stick">' . $label . '</span>';
						}
					}
					$output .= '</div>';

					$output .= '<div class="brk-sc-flip-four__title">
											<h4 class="font__family-montserrat font__weight-bold">' . esc_html( $product->get_name() ) . '</h4>
										</div>
										' . $old_price . '
										<div class="brk-sc-flip-four__price brk-base-font-color font__family-montserrat font__weight-bold">
											' . $price . '
										</div>
									</div>
									<div class="brk-sc-flip-four__thumb"><img src="' . esc_url( $image_thumb[0] ) . '" alt=""></div>
								</div>
								<div class="flip__back brk-sc-flip-four__back brk-base-bg-gradient-5">
									<div class="brk-sc-flip-four__col-back">
										<div>
											<div class="d-flex flex-wrap">';

					if ( ! empty( $terms ) ) {
						foreach ( $terms as $term ) {
							$output .= '<span class="brk-sc-flip-four__cat font__family-montserrat brk-bg-primary brk-white-font-color">' . $term . '</span>';
						}
					}

					if ( ! empty( $labels ) ) {
						foreach ( $labels as $label ) {
							$output .= '<span class="brk-sc-flip-four__stick">' . $label . '</span>';
						}
					}

					$desc = $product->get_description();
					$txt  = mb_substr( $desc, 0, 100 ) . " ...";
					$output .= '</div>
											<div class="brk-sc-flip-four__title brk-sc-flip-four__title_back">
												<h4 class="font__family-montserrat font__weight-bold">' . esc_html( $product->get_name() ) . '</h4>
											</div>
										</div>' . $buy_now . '</div>
									<div class="brk-sc-flip-four__description">' . $txt . '
									</div>
									<div class="brk-sc-flip-four__thumb-back"><img src="' . esc_url( $image_thumb[0] ) . '" alt=""></div>
								</div>
							</div>
						</div>';
					break;

			}

			brs_add_libraries( $libraries );

			return $output;
		}

		protected function get_icon_class( $atts ) {
			$icon_class = '';

			$icon_class = $atts[ 'icon_' . $atts['type'] ];

			if ( empty( $icon_class ) ) {
				$icon_class = 'fa fa-trophy';
			}

			return $icon_class;
		}


	}

	// create shortcode
	BRS_Flip_Box::get_instance();

}
