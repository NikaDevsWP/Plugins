<?php
/**
 * Portfolio shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Portfolio', false ) ) {

	class BRS_Portfolio_Shortcode extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Portfolio_Shortcode();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_portfolio', array( $this, 'shortcode_portfolio' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Portfolio", 'berserk' ),
					"base"     => "brs_portfolio",
					"icon"     => "brs_vc_ico_portfolio",
					"class"    => "brs_vc_sc_portfolio",
					"category" => __( 'Berserk', 'berserk' ),
					"params"   => array(
						array(
							'heading'    => __( 'Portfolio Type', 'berserk' ),
							'param_name' => 'portfolio_type',
							'type'       => 'brs_radio',
							'value'      => array(
								"List"               => "list",
								"Grid"               => "grid",
								"Category"           => "category",
								"Row"                => "row",
								"Isotope"            => "isotope",
								"Isotope Alternate"  => "isotope_2",
								"Swipe card masonry" => "swipe_card_masonry",

							),
							'images'     => array(
								"list"               => 'portfolio/list.png',
								"grid"               => 'portfolio/grid.png',
								"category"           => 'portfolio/category.png',
								"row"                => 'portfolio/row.png',
								"isotope"            => 'portfolio/isotope.png',
								"isotope_2"          => 'portfolio/isotope_2.png',
								"swipe_card_masonry" => 'portfolio/swipe_card_masonry.png',
							),
							'images_dim' => array(
								'w' => '310',
								'h' => '150'
							)
						),

						array(
							"heading"    => __( "Main Settings", 'berserk' ),
							"param_name" => "brs_title",
							"type"       => "brs_title",
						),

						array(
							'type'             => 'dropdown',
							'heading'          => __( 'Layout', 'berserk' ),
							'value'            => array(
								'Default'            => 'default',
								'Transparent button' => 'transparent_button',
							),
							'param_name'       => 'folio_type_layout',
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__portfolio_type swipe_card_masonry',
						),


						array(
							'type'             => 'textfield',
							'heading'          => __( 'Items Per Page', 'js_composer' ),
							'param_name'       => 'items_per_page',
							"value"            => '4',
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

						array(
							'type'             => 'textfield',
							'heading'          => __( 'Items Per Load', 'js_composer' ),
							'param_name'       => 'items_per_load',
							"value"            => '4',
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

						array(
							'type'             => 'dropdown',
							'heading'          => __( 'Columns', 'berserk' ),
							'value'            => array(
								'1 Columns' => '1',
								'2 Columns' => '2',
								'3 Columns' => '3',
								'4 Columns' => '4',
								'6 Columns' => '6',
							),
							'std'              => '3',
							'param_name'       => 'folio_columns',
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__portfolio_type grid category',
						),
						array(
							'type'             => 'dropdown',
							'heading'          => __( 'Grid Columns', 'berserk' ),
							'value'            => array(
								'1 Columns' => '1',
								'2 Columns' => '2',
								'3 Columns' => '3',
								'4 Columns' => '4',
								'5 Columns' => '5',
								'6 Columns' => '6',
							),
							'std'              => '5',
							'param_name'       => 'grid_folio_columns',
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__portfolio_type row isotope isotope_2 swipe_card_masonry',
						),

						array(
							'type'             => 'dropdown',
							'heading'          => __( 'Pagination Type', 'berserk' ),
							'value'            => array(
								esc_attr__( 'Default', 'berserk' ) => 'default',
								esc_attr__( 'Ajax', 'berserk' )    => 'ajax',
								esc_attr__( 'Slider', 'berserk' )  => 'slider',
								esc_attr__( 'None', 'berserk' )    => 'none',
							),
							'param_name'       => 'pagination_type',
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),


						array(
							'heading'    => __( 'Default Pagination Type', 'berserk' ),
							'param_name' => 'default_pagination_type',
							'type'       => 'brs_radio',
							'value'      => array(
								"Layout 1"  => "layout_1",
								"Layout 2"  => "layout_2",
								"Layout 3"  => "layout_3",
								"Layout 4"  => "layout_4",
								"Layout 5"  => "layout_5",
								"Layout 6"  => "layout_6",
								"Layout 7"  => "layout_7",
								"Layout 8"  => "layout_8",
								"Layout 9"  => "layout_9",
								"Layout 10" => "layout_10",
							),
							'images'     => array(
								"layout_1"  => 'pagination/001.jpg',
								"layout_2"  => 'pagination/002.jpg',
								"layout_3"  => 'pagination/003.jpg',
								"layout_4"  => 'pagination/004.jpg',
								"layout_5"  => 'pagination/005.jpg',
								"layout_6"  => 'pagination/006.jpg',
								"layout_7"  => 'pagination/007.jpg',
								"layout_8"  => 'pagination/008.jpg',
								"layout_9"  => 'pagination/009.jpg',
								"layout_10" => 'pagination/010.jpg',

							),
							'images_dim' => array(
								'w' => '310',
								'h' => '150'
							),
							"dependency" => array(
								"element" => "pagination_type",
								"value"   => array( 'default' ),
							),
						),

						array(
							'heading'    => __( 'Ajax Button Type', 'berserk' ),
							'param_name' => 'ajax_button_type',
							'type'       => 'brs_radio',
							'value'      => array(
								"Round"          => "round",
								"Default Button" => "default",
							),
							'images'     => array(
								"round"   => 'pagination/round.jpg',
								"default" => 'pagination/default.jpg',
							),
							'images_dim' => array(
								'w' => '310',
								'h' => '150'
							),
							"dependency" => array(
								"element" => "pagination_type",
								"value"   => array( 'ajax' ),
							),
						),

						array(
							'type'             => 'checkbox',
							'heading'          => esc_html__( 'Grayscale', 'berserk' ),
							'value'            => array(
								esc_html__( 'Image Grayscale', 'berserk' ) => 'true',
							),
							'param_name'       => 'image_grayscale',
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

						array(
							"heading"    => __( "Taxonomies", 'berserk' ),
							"param_name" => "brs_title",
							"type"       => "brs_title",
						),

						array(
							'type'             => 'dropdown',
							'heading'          => __( 'Category', 'berserk' ),
							'value'            => BRS_Shortcodes_VCParams::get_terms( 'folio-category' ),
							'param_name'       => 'folio_category',
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

						array(
							"heading"          => __( "Filter", 'berserk' ),
							"param_name"       => "brs_title",
							"type"             => "brs_title",
							'edit_field_class' => 'vc_col-sm-12 vc_column brk-dependency__portfolio_type isotope isotope_2'
						),

						array(
							'heading'          => __( 'Show portfolio filter', 'berserk' ),
							'param_name'       => 'portfolio_filter',
							'type'             => 'brs_switch',
							'value'            => 'n',
							'options'          => array(
								'Yes' => 'y',
								'No'  => 'n',
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__portfolio_type isotope isotope_2'
						),

						array(
							'heading'          => __( 'Filter Type', 'berserk' ),
							'param_name'       => 'filter_type',
							'type'             => 'brs_radio',
							'value'            => array(
								"Layout 1" => "layout_1",
								"Layout 2" => "layout_2",
							),
							'images'           => array(
								"layout_1" => 'filter_type/001.png',
								"layout_2" => 'filter_type/002.png',
							),
							'images_dim'       => array(
								'w' => '310',
								'h' => '150'
							),
							"dependency"       => array(
								"element" => "portfolio_filter",
								"value"   => array( 'y' ),
							),
							'edit_field_class' => 'vc_col-sm-12 vc_column brk-dependency__portfolio_type isotope isotope_2'
						),

					)
				) );
			}
		}

		public function shortcode_portfolio( $atts, $content = null ) {

			//brs_add_libraries( array( 'component__portfolio_list', 'fancybox' ) );

			$before_output  = '';
			$after_output   = '';
			$before_article = '';
			$after_article  = '';
			$output         = '';
			$pagination     = '';
			$filter         = '';
			$args           = array();

			$attributes = shortcode_atts( array(
				'portfolio_type'          => 'list',
				'items_per_page'          => '4',
				'items_per_load'          => '4',
				'pagination_type'         => 'default',
				'ajax_button_type'        => 'round',
				'default_pagination_type' => 'layout_1',
				'folio_category'          => 'all',
				'folio_columns'           => '3',
				'grid_folio_columns'      => '5',
				'portfolio_filter'        => 'n',
				'filter_type'             => 'layout_1',
				'folio_type_layout'       => 'default',
				'image_grayscale'         => '',
			), $atts );

			$folio_columns = $attributes['folio_columns'];
			$folio_type_layout = $attributes['folio_type_layout'];

			define( 'BRK_PORTFOLIO_ATTRIBUTES', $attributes );

			$post_type = Berserk_Portfolio::postType();
			$paged     = Shortcodes_Helper::get_paged();

			$args = array(
				'posts_per_page' => $attributes['items_per_page'],
				'post_type'      => $post_type,
				'paged'          => $paged
			);

			$args['tax_query'] = array();

			if ( $attributes['folio_category'] != 'all' || isset( $_GET['portfolio_category'] ) ) {

				$terms = ( isset( $_GET['portfolio_category'] ) ) ? $_GET['portfolio_category'] : $attributes['folio_category'];

				$args['tax_query'][] = array(
					'taxonomy' => 'folio-category',
					'field'    => 'slug',
					'terms'    => array( $terms ),
				);
			}

			$args['tax_query']['relation'] = 'AND';

			$posts       = Shortcodes_Helper::get_posts( $args );
			$found_posts = Shortcodes_Helper::get_found_posts( $args );

			$folio_type      = $attributes['portfolio_type'];
			$data_folio_type = 'data-folio-type="' . $folio_type . '"';

			if ( $attributes['portfolio_filter'] == 'y' ) {
				//dpm( $terms );
				echo Shortcodes_Helper::get_portfolio_filter( $attributes['filter_type'] );
			}

			switch ( $folio_type ) {
				case "list":
					$before_output = '<div class="posts_content" ' . $data_folio_type . '>';
					$after_output  = '</div>';
					break;
				case "grid":
					$before_output = '<div class="row brk-gutters-5 posts_content" ' . $data_folio_type . '>';
					$after_output  = '</div>';
					break;
				case "category":
					if ( $attributes['pagination_type'] == 'slider' ) {
						$before_output = '<div class="brs-portfolio-carousel-item dots-rounded-skin posts_content" ' . $data_folio_type . '>';
						$after_output  = '</div>';
					} else {
						$before_output = '<div class="row brk-gutters-5 posts_content" ' . $data_folio_type . '>';
						$after_output  = '</div>';
					}
					break;
				case "row":
					$before_output = '<div class="container-fluid mt-15">
            							<div class="brk-grid-fitrows posts_content" data-grid-cols="' . $attributes['grid_folio_columns'] . '" data-grid-cols-tablet="3" data-grid-height="380" ' . $data_folio_type . '>';
					$after_output  = '</div></div>';
					break;
				case "isotope":

					$before_output = '<div class="brk-grid" data-grid-cols="' . $attributes['grid_folio_columns'] . '" data-grid-cols-tablet="2">
						<div class="brk-grid__sizer"></div>';

					$after_output  = '</div>';

					break;
				case "isotope_2":
					$before_output = '<div class="brk-grid brk-grid_portfolio_isotope_2 posts_content" data-grid-cols="' . $attributes['grid_folio_columns'] . '" data-grid-cols-tablet="3" style="position: relative; height: 1170px;" ' . $data_folio_type . '>
                						<div class="brk-grid__sizer"></div>';
					$after_output  = '</div>';
					break;

				case "swipe_card_masonry":

					$before_output = '<div class="brk-grid brk-grid_portfolio_swipe_card_masonry posts_content" data-grid-cols="' . $attributes['grid_folio_columns'] . '" data-grid-cols-tablet="3" ' . $data_folio_type . '>
                						<div class="brk-grid__sizer"></div>';
					$after_output  = '</div>';
					break;
			}

			$pagination_type = $attributes['pagination_type'];

			$counter = 0;
			foreach ( $posts as $post ) {

				if( $folio_type == 'isotope' ) {

					brs_add_libraries( array( 'component__portfolio_isotope' ) );

					$brk_grid_class = array(
						'brk-grid__item',
					);

					$cols = $attributes['grid_folio_columns'];
					/*print_r($counter);
					echo '-';
					print_r(( $counter + 3 ) % 7);
					echo '<br>';
					*/
					if ( $cols == '3') {
						// nth sixth start at 1 and 4
						if( ( $counter % 6 ) == 0 || ( ( $counter + 2 ) % 6 ) == 0 ) {
							$brk_grid_class[] = 'brk-grid__item_width-2';
							$brk_grid_class[] = 'brk-grid__item_height-2';
						}
					}
					if ( $cols == '4') {
						// nth seventh start at 1
						if( ( $counter % 7 ) == 0 ) {
							$brk_grid_class[] = 'brk-grid__item_width-2';
							$brk_grid_class[] = 'brk-grid__item_height-2';
						}
						// nth seventh start at 4 and 5
						if( ( ( $counter + 3 ) % 7 ) == 0 || ( ( $counter + 4 ) % 7 ) == 0 ) {
							$brk_grid_class[] = 'brk-grid__item_width-2';
						}
					}
					if ( $cols == '5') {
						// nth ninth start at 2
						if( ( ( $counter + 8 ) % 9 ) == 0 ) {
							$brk_grid_class[] = 'brk-grid__item_width-2';
							$brk_grid_class[] = 'brk-grid__item_height-2';
						}
						// nth ninth start at 5 and 7
						if( ( ( $counter + 3 ) % 9 ) == 0 || ( ( $counter + 5 ) % 9 ) == 0 ) {
							$brk_grid_class[] = 'brk-grid__item_width-2';
						}
						// nth ninth start at 6
						if( ( $counter + 4 ) % 9 == 0 ) {
							$brk_grid_class[] = 'brk-grid__item_height-2';
						}
					}
					$counter++;

					// Return first folio category
					$folio_category = '';
					$categories_output = '';
					$folio_categories = get_the_terms( $post->ID, 'folio-category' );
					if ( !empty( $folio_categories ) && !is_wp_error( $folio_categories ) ) {
						$folio_category = array_shift( $folio_categories );
						$brk_grid_class[] = $folio_category->slug;

						$categories_output = '<a href="' . esc_url( get_term_link( $folio_category ) ) . '" class="font__familt-montserrat font__weight-bold font__size-14 text-uppercase text-center text-light-soft brk-simple-card__category">' . esc_html( $folio_category->name ) . '</a>';

					}
					$image_url = get_the_post_thumbnail_url( $post->ID, 'woo-masonry-type_1_first' );

			

					$brk_grid_class = implode( ' ', $brk_grid_class );
					$output .= '<div class="' . esc_attr( $brk_grid_class ) .'" data-category="' . esc_attr( $folio_category->slug ) . '">
									<div class="brk-simple-card">
										<div class="brk-simple-card__animation-wrapper">
											<img class="brk-simple-card__img lazyload" src="' . esc_attr( BRK_DATA_IMAGE ) . '" data-src="' . esc_url( $image_url ) . '" alt="alt">
										<div class="brk-simple-card__overlay brk-base-bg-gradient-10deg"></div>
										<div class="brk-simple-card__info">
											<a href="' . esc_url( get_permalink( $post->ID ) ) . '" class="font__family-montserrat font__weight-bold font__size-24 text-uppercase text-center text-white brk-simple-card__title">' . get_the_title( $post->ID ) . '</a>';
											
											$output .= $categories_output;
									
										$output .= '</div>
										<a href="' . esc_url( get_permalink( $post->ID ) ) . '" class="brk-simple-card__link font__family-montserrat font__weight-bold font__size-18 text-white brk-bg-primary">+</a>
										</div>
									</div>
								</div>';
				} else {

					ob_start();
					Berserk_Portfolio::get_folio_article( $post->ID, $folio_type, $pagination_type, $folio_columns, $folio_type_layout );
					$output .= ob_get_clean();
				}
			}

			if ( $attributes['pagination_type'] != 'slider' ) {
				switch ( $attributes['pagination_type'] ) {
					case "default":
						ob_start();
						$wp_query            = new WP_Query( $args );
						$GLOBALS['wp_query'] = $wp_query;

						$shortcode_pagination_type = $attributes['default_pagination_type'];
						//get_template_part( 'content', 'pagenavi' );

						include( locate_template( 'templates/layouts/pagination/content-pagenavi.php' ) );

						$pagination .= ob_get_clean();
						break;
					case "ajax":

						if ( $found_posts > $attributes['items_per_page'] ) {
							$data = 'data-layout_type="' . $folio_type . '" ';
							$data .= 'data-offset="' . $attributes['items_per_page'] . '" ';
							$data .= 'data-post_type="' . $post_type . '" ';
							$data .= 'data-posts_per_load="' . $attributes['items_per_load'] . '" ';
							$data .= 'data-posts_per_page="' . $attributes['items_per_page'] . '" ';
							$data .= 'data-columns="' . $attributes['folio_columns'] . '"';
							$data .= 'data-folio_type_layout="' . $attributes['folio_type_layout'] . '"';

							if ( $attributes['folio_category'] != 'all' || isset( $_GET['portfolio_category'] ) ) {
								$terms = ( isset( $_GET['portfolio_category'] ) ) ? $_GET['portfolio_category'] : $attributes['folio_category'];
								$data .= 'data-categories="' . $terms . '" ';
							}

							switch ( $attributes['ajax_button_type'] ) {
								case "default":
									$pagination = '<div class="text-center pb-100">
														<a href="#" ' . $data . ' class="btn btn-inside-out btn-lg btn-inside-out-invert pr-50 pl-50 ml-auto mr-auto mt-0 mb-0 border-radius-25 brk-library-rendered load-more" data-brk-library="component__button">
															<span class="before">' . esc_html__( 'load more', 'berserk' ) . '</span>
															<span class="text">' . esc_html__( 'load more', 'berserk' ) . '</span>
															<span class="after">' . esc_html__( 'load more', 'berserk' ) . '</span>
														</a>
													</div>';
									break;
								default:
									$pagination = '<div class="col-12 text-center mt-lg-100 mt-40">
														 <a href="#" ' . $data . ' class="icon__btn icon__btn-anim icon__btn-lg icon__btn-invert load-more">
												          <span class="before"></span>
												          <i class="fa fa-refresh icon-inside" aria-hidden="true"></i>
												          <span class="after"></span>
												          <span class="bg"></span>
												        </a>
			                                        </div>';
									break;

							}

						}

						break;
					case "slider":
						break;

					case "none":
						break;
				}
			}

			return $filter . $before_output . $output . $after_output . $pagination;
		}
	}

	// create shortcode
	BRS_Portfolio_Shortcode::get_instance();

}
