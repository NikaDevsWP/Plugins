<?php
/**
 * Team shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


if ( ! class_exists( 'BRS_Map', false ) ) {

  require_once BERSERK_SHORTCODES_PATH . 'shortcodes/includes/shortcodes-ext.php';

	class BRS_Map extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();

		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Map();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_map', array( $this, 'shortcode_map' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

        $params = array();

        $params[] = array(
          "heading"    => __( "Map Type", 'berserk' ),
          "param_name" => "brs_title",
          "type"       => "brs_title",
        );

        $params[] = array(
          //'heading'    => __( 'Pricing Table', 'berserk' ),
          'param_name' => 'type',
          'type'       => 'brs_radio',
          'value'       => array(
            "Layout 1" => "layout_1",
            "Layout 2" => "layout_2",
            "Layout 3" => "layout_3",
            "Layout 4" => "layout_4",
            "Layout 5" => "layout_5",
            "Layout 6" => "layout_6",
            "Layout 7" => "layout_7",
            "Hidden 1" => "hidden_1",
            "Hidden 2" => "hidden_2",
            "Hidden 3" => "hidden_3",
          ),
          'images'     => array(
            "layout_1" => 'maps/001.jpg',
            "layout_2" => 'maps/002.jpg',
            "layout_3" => 'maps/003.jpg',
            "layout_4" => 'maps/004.jpg',
            "layout_5" => 'maps/005.jpg',
            "layout_6" => 'maps/006.jpg',
            "layout_7" => 'maps/007.jpg',
            "hidden_1" => 'maps/008.jpg',
            "hidden_2" => 'maps/009.jpg',
            "hidden_3" => 'maps/010.jpg',
          ),
          'images_dim' => array(
            'w' => '310',
            'h' => '150'
          )
        );

        $params[] = array(
          "heading"    => __( "Main Settings", 'berserk' ),
          "param_name" => "brs_title",
          "type"       => "brs_title",
        );

        $params[] = array(
          'type'             => 'textfield',
          'heading'          => __( 'Google Map Address', 'js_composer' ),
          'param_name'       => 'address',
          "value"            => '',
        );

        $params[] = array(
          'type'             => 'textfield',
          'heading'          => __( 'Title', 'js_composer' ),
          'param_name'       => 'title',
          "value"            => '',
          'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__type layout_1 layout_2 layout_3 layout_4 layout_6 layout_7 hidden_3',
        );

        $params[] = array(
          'type'             => 'textfield',
          'heading'          => __( 'Second Title', 'js_composer' ),
          'param_name'       => 'second_title',
          "value"            => '',
          'edit_field_class' => 'vc_col-sm-6 vc_column',
          'dependency' => array(
            'element' => 'type',
            'value'   => array('layout_4', 'layout_6', 'layout_7'),
          )
        );

        $params[] = array(
          'type'             => 'textarea',
          'heading'          => __( 'Info', 'js_composer' ),
          'param_name'       => 'info',
          "value"            => '',
        );

        $params[] = array(
          'type'             => 'textfield',
          'heading'          => __( 'Phone', 'js_composer' ),
          'param_name'       => 'phone',
          "value"            => '',
          'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__type layout_1 layout_3 layout_4 layout_6 layout_7',
        );  

        $params[] = array(
          'type'             => 'textfield',
          'heading'          => __( 'Email', 'js_composer' ),
          'param_name'       => 'email',
          "value"            => '',
          'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__type layout_7',
        );

        $params[] = array(
          'type'             => 'textfield',
          'heading'          => __( 'Working Hours', 'js_composer' ),
          'param_name'       => 'hours',
          "value"            => '',
          'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__type layout_7',
        );

        $params[] = array(
          'type'             => 'textfield',
          'heading'          => __( 'Local Address', 'js_composer' ),
          'param_name'       => 'local_address',
          "value"            => '',
          'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__type layout_7',
        );

        $params[] = array(
          'type'             => 'textfield',
          'heading'          => __( 'Map text', 'js_composer' ),
          'param_name'       => 'map_text',
          "value"            => "Find Us",
          'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__type layout_1 layout_2 hidden_1 hidden_2 hidden_3',
        );

        $params[] = array(
          'type'        => 'dropdown',
          'param_name'  => 'form_id',
          'heading'     => esc_html__( 'Select contact form', 'berserk' ),
          'value'       => BRS_Shortcodes_VCParams::get_wpcf7(),
          'edit_field_class' => 'brk-dependency__type layout_7',
        );

        $params[] = array(
          "heading"    => __( "Marker", 'berserk' ),
          "param_name" => "brs_title_marker",
          "type"       => "brs_title",
        );

        $options = array('edit_field_class' => 'brk-dependency__type layout_1 layout_2 layout_3 layout_5');
        $icons = berserk_shortcodes_icons($options);

        $params = array_merge($params, $icons);

        $params[] = array(
          'type'        => 'attach_image',
          'heading'     => __( 'Image', 'js_composer' ),
          'param_name'  => 'marker_image',
          'value'       => '',
          'description' => __( 'Select image from media library.', 'js_composer' ),
          'edit_field_class' => 'brk-dependency__type layout_1 layout_2 layout_3 layout_5 layout_7'
        );

        $params[] = array(
          'type'             => 'dropdown',
          'heading'          => __( 'Image size', 'berserk' ),
          'value'            => BRS_Shortcodes_VCParams::get_image_sizes_names(),
          'param_name'       => 'image_size',
          'std'              => 'image-frames',
          'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__type layout_1 layout_2 layout_3 layout_5 layout_7',
        );

        $params[] = array(
          "heading"    => __( "Configuration", 'berserk' ),
          "param_name" => "brs_title_configuration",
          "type"       => "brs_title",
        );

        $params[] = array(
          'type'             => 'textfield',
          'heading'          => __( 'Map Height', 'js_composer' ),
          'param_name'       => 'height',
          "value"            => '520',
          'edit_field_class' => 'vc_col-sm-6 vc_column',
        );

        $params[] = array(
          'type'             => 'textfield',
          'heading'          => __( 'Zoom', 'js_composer' ),
          'param_name'       => 'zoom',
          "value"            => '13',
          'edit_field_class' => 'vc_col-sm-6 vc_column',
        );

        $params[] = array(
          'type'             => 'dropdown',
          'heading'          => __( 'Map type', 'js_composer' ),
          'param_name'       => 'map_type',
          'value'            => array(
            'RoadMap'   => 'roadmap',
            'Satellite' => 'satellite',
            'Hybrid'    => 'hybrid',
            'Terrain'   => 'terrain',
          ),
          'edit_field_class' => 'vc_col-sm-6 vc_column',
        );

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Map", 'berserk' ),
					"base"     => "brs_map",
					"icon"     => "brs_vc_ico_team",
					"class"    => "brs_vc_sc_team",
					"category" => __( 'Berserk', 'berserk' ),
					"params"   => $params
				));
			}
		}

		public function shortcode_map( $atts, $content = null ) {

      brs_add_libraries('component__map');

      $icon = berserk_shortcodes_icons_process($atts);

      $atts =  shortcode_atts( array(
        'type'           => 'layout_1',
        'address'        => '', 
        'title'          => '',
        'second_title'   => '', 
        'phone'          => '',
        'info'           => '',
        'email'          => '',
        'local_address'  => '',
        'hours'          => '',
        'map_text'       => 'Find Us',
        'form_id'        => '',
        'height'         => 520,
        'marker_image'   => '',
        'image_size'     => '',
        'zoom'           => 13,
        'map_type'       => 'roadmap'
      ), $atts );

      $image_marker = $atts['marker_image'] ? wp_get_attachment_image_src( $atts['marker_image'], $atts['image_size'] ) : '';
      $data_marker = $image_marker ? $image_marker[0]  : '';
      $marker = $image_marker ? '<img src="' . $image_marker[0] . '" alt="">' : ($icon ? $icon : '');
      $info = 
      $output = '
        <div class="brk-map" data-height="' . $atts['height'] .'" data-brk-library="component__map">';

			switch ( $atts['type'] ) {
        case 'layout_1':
          $output .= '
            <div class="brk-map__section">
              <div class="brk-map__canvas"
                data-address="' . $atts['address'] . '"
                data-zoom="' . $atts['zoom'] . '"
                data-type="' . $atts['map_type'] . '"
                data-marker="' . $data_marker . '"
                data-offset-lat="0.0047"
                data-style="silver">
              </div>
            </div>
          
            <div class="brk-map__infoicon brk-map__infoicon_layout-one text-center">
              <span class="marker">
                ' . $marker . '
              </span>
          
              <h4 class="font__family-montserrat font__weight-bold font__size-21 line__height-22">' . $atts['title'] . '</h4>
          
              <div class="brk-map__infoicon--text">
                <ul class="font__size-15 line__height-21">
                  <li><i class="fa fa-phone"></i><a href="tel:' . $atts['phone'] . '">' . $atts['phone'] . '</a></li>
                  <li><i class="fa fa-clock-o"></i> <span>' . $atts['info'] .'</span></li>
                </ul>
              </div>
          
              <a href="#" class="btn border-radius-25 font__family-open-sans font__weight-bold btn-inside-out">
                <span class="before">' . $atts['map_text'] . '</span>
                <span class="text">' . $atts['map_text'] . '</span>
                <span class="after">' . $atts['map_text'] . '</span>
              </a>
            </div>';
          break;

        case 'layout_2':
          $output .= '
          <div class="brk-map__section">
            <div class="brk-map__canvas"
              data-address="' . $atts['address'] . '"
              data-zoom="' . $atts['zoom'] . '"
              data-type="' . $atts['map_type'] . '"
              data-marker="' . $data_marker . '"
              data-offset-lat="-0.0112"
              data-offset-lng=""
              data-style="dark">
            </div>
          </div>

          <div class="brk-map__infoicon brk-map__infoicon_layout-two text-center" style="background-image: url(' . BERSERK_SHORTCODES_URL . '/shortcodes/img/gm-bg-1.jpg)">
            <span class="marker">
              ' . $marker . '
            </span>
        
            <div class="brk-map__infoicon--text">
              <h4 class="font__family-montserrat font__weight-bold font__size-21 line__height-22">' . $atts['title'] . '</h4>
              <p class="font__family-playfair font__size-16 line__height-24">' . $atts['info'] .'</p>
              <a class="font__family-playfair font__size-16 line__height-24" href="#">' . $atts['map_text'] . '</a>
            </div>
          </div>';
          break;

        case 'layout_3':
          $output .= '
            <div class="brk-map__section">
              <div class="brk-map__canvas"
                data-address="' . $atts['address'] . '"
                data-zoom="' . $atts['zoom'] . '"
                data-type="' . $atts['map_type'] . '"
                data-marker="' . $data_marker . '"
                data-offset-lat=""
                data-offset-lng=""
                data-style="silver">
              </div>
            </div>
          
            <div class="brk-map__infoicon brk-map__infoicon_layout-three">
              <span class="marker">
                ' . $marker . '
              </span>
          
              <div class="brk-map__infoicon--text">
                <h4 class="font__family-montserrat font__weight-bold font__size-21 line__height-22 mb-15">' . $atts['title'] . '</h4>
                <p class="font__size-16 line__height-28">' . $atts['info'] .'</p>
                <a href="tel:' . $atts['phone'] .'"><span><i class="fa fa-phone" aria-hidden="true"></i></span>' . $atts['phone'] .'</a>
              </div>
            </div>';
          break;
        case 'layout_4':
          $output .= '
            <div class="brk-map__section">
              <div class="brk-map__canvas"
                data-address="' . $atts['address'] . '"
                data-zoom="' . $atts['zoom'] . '"
                data-type="' . $atts['map_type'] . '"
                data-marker="' . $data_marker . '"
                data-offset-lat=""
                data-offset-lng=""
                data-style="dark">
              </div>
            </div>
          
            <div class="brk-map__infoicon brk-map__infoicon_layout-four">
              <div class="brk-map__infoicon--text text-left">
                <h4 class="font__family-montserrat font__weight-light font__size-32 line__height-34 text-uppercase">' . $atts['title'] . '<br> <span class="font__weight-bold">' . $atts['second_title'] . '</span></h4>
                <ul class="font__size-16 line__height-21 text-uppercase mt-10">
                  <li><i class="fa fa-phone"></i><a href="tel:' . $atts['phone'] .'">' . $atts['phone'] .'</a></li>
                  <li><i class="fa fa-map-marker" aria-hidden="true"></i> <span>' . $atts['info'] .'</span></li>
                </ul>
              </div>
            </div>';
          break;

        case 'layout_5':
          $output .= '

            <div class="brk-map__section">
              <div class="brk-map__canvas"
                data-address="' . $atts['address'] . '"
                data-zoom="' . $atts['zoom'] . '"
                data-type="' . $atts['map_type'] . '"
                data-marker="' . $data_marker . '"
                data-offset-lat="-0.003"
                data-offset-lng="-0.0065"
                data-style="silver">
              </div>
            </div>
          
            <div class="brk-map__infoicon brk-map__infoicon_layout-five">
              <span class="marker">
                ' . $marker . '
              </span>
              <div class="brk-map__infoicon--text text-left">
                <h4 class="font__size-14 line__height-21">' . $atts['info'] .'</h4>
              </div>
            </div>';
          break;

        case 'layout_6':
          $output .= '
            <div class="brk-map__section">
              <div class="brk-map__canvas"
                data-address="' . $atts['address'] . '"
                data-zoom="' . $atts['zoom'] . '"
                data-type="' . $atts['map_type'] . '"
                data-marker="' . $data_marker . '"
                data-offset-lat=""
                data-offset-lng=""
                data-style="silver">
              </div>
            </div>
          
            <div class="brk-map__infoicon brk-map__infoicon_layout-six text-center">
              <h4 class="font__family-montserrat font__weight-medium font__size-21 mb-20">' . $atts['title'] .' <span class="brk-base-font-color">' . $atts['second_title'] .'</span></h4>
              <p class="font__family-oxygen font__weight-light font__size-16 line__height-21">' . $atts['info'] .'</p>
              <a class="font__family-oxygen font__weight-light font__size-16 line__height-21" href="tel:' . $atts['phone'] .'">' . $atts['phone'] .'</a>
            </div>';
          break;

        case 'layout_7':
          
          $form = $atts['form_id'] ? do_shortcode( sprintf( '[contact-form-7 id="%d"]', intval( $atts['form_id'] ) ) ) : '';

          $output .= '
            <div class="brk-map__canvas"
              data-address="' . $atts['address'] . '"
              data-zoom="' . $atts['zoom'] . '"
              data-type="' . $atts['map_type'] . '"
              data-marker="' . $data_marker . '"
              data-offset-lat=""
              data-offset-lng=""
              data-style="silver"
              data-info-window=".info-map">
            </div>
          
            <div class="brk-map__subscribe brk-bg-grad">
              <div class="font__family-montserrat font__size-28 font__weight-light text-uppercase mb-35">' . $atts['title'] . ' <span class="font__weight-bold">' . $atts['second_title'] . '</span></div>
              ' . $form . '
              <ul class="brk-map__subscribe--contacts mt-20">
                <li><i class="fa fa-envelope" aria-hidden="true"></i><a href="mailto:' . $atts['email'] .'">' . $atts['email'] .'</a></li>
                <li><i class="fa fa-map-marker" aria-hidden="true"></i><span>' . $atts['local_address'] .'</span></li>
                <li><i class="fa fa-clock-o" aria-hidden="true"></i><span>' . $atts['hours'] .'</span></li>
                <li><i class="fa fa-phone" aria-hidden="true"></i><a href="tel:' . $atts['phone'] .'">' . $atts['phone'] .'</a></li>
              </ul>
            </div>';
          break;

       case 'hidden_1':
          $output .= '
            <div class="brk-map__opener-section brk-map__opener-section_classic">
              <div class="brk-map__opener brk-map__opener_classic font__family-montserrat font__weight-semibold">
                <div class="brk-map__second"><i class="fa fa-map-marker" aria-hidden="true"></i><span class="brk-lightning-effect">' . $atts['map_text'] . '</span><i class="fa fa-angle-down" aria-hidden="true"></i></div>
                <div class="brk-map__second"><i class="fa fa-map-marker" aria-hidden="true"></i><span class="brk-lightning-effect">' . __('close the map', 'berserk') . '</span><i class="fa fa-angle-up" aria-hidden="true"></i></div>
              </div>
            </div>
          
            <div class="brk-map__section">
              <div class="brk-map__canvas"
                data-address="' . $atts['address'] . '"
                data-zoom="' . $atts['zoom'] . '"
                data-type="' . $atts['map_type'] . '"
                data-marker="' . $data_marker . '"
                data-style="silver"
                data-info-window=".info-map">
              </div>
            </div>
          
            <div class="info-map">' . $atts['info'] .'</div>';
          break;

       case 'hidden_2':
          $output .= '
            <div class="brk-map__opener brk-map__opener_simple font__family-montserrat font__weight-medium font__size-16">
              <span>' . $atts['map_text'] . '</span>
              <div class="trigger">
                <i class="fa fa-angle-down" aria-hidden="true"></i>
              </div>
            </div>
          
            <div class="brk-map__section">
              <div class="brk-map__canvas"
                data-address="' . $atts['address'] . '"
                data-zoom="' . $atts['zoom'] . '"
                data-type="' . $atts['map_type'] . '"
                data-marker="' . $data_marker . '"
                data-style="silver"
                data-info-window=".info-map">
              </div>
            </div>
          
            <div class="info-map">' . $atts['info'] .'</div>';
          break;

       case 'hidden_3':
          $output .= '
            <svg class="brk-map__layer-top" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 45"><path d="M1920,0Q1439.37,45.06,958.77,45,479.39,44.94,0,0H1920Z"/></svg>
            <svg class="brk-map__layer-bottom" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 45"><path d="M1920,45H0Q478.82.11,957.63,0,1438.82-.11,1920,45Z"/></svg>
          
            <div class="brk-map__opener-section brk-map__opener-section_round">
              <h4 class="font__family-montserrat font__weight-bold font__size-21">' . $atts['title'] . '</h4>
          
              <div class="brk-map__opener brk-map__opener_round font__family-montserrat font__weight-semibold font__size-14">
                <i class="fa fa-map-marker" aria-hidden="true"></i><span>' . $atts['map_text'] . '</span>
              </div>
            </div>
          
            <div class="brk-map__section">
              <div class="brk-map__canvas"
                data-address="' . $atts['address'] . '"
                data-zoom="' . $atts['zoom'] . '"
                data-type="' . $atts['map_type'] . '"
                data-marker="' . $data_marker . '"
                data-style="dark"
                data-info-window=".info-map">
              </div>
            </div>';
          break;          
			}

			$output .= '</div>';

			return $output;
		}


	}

	// create shortcode
	BRS_Map::get_instance();

}
