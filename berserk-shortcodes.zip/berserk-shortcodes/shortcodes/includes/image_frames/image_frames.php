<?php
/**
 * CountDown shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Image_Frames', false ) ) {

	class BRS_Image_Frames extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Image_Frames();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_image_frames', array( $this, 'shortcode_image_frames' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Image Frames", 'berserk' ),
					"base"     => "brs_image_frames",
					"icon"     => "brs_vc_ico_image_frames",
					"class"    => "brs_vc_sc_image_frames",
					"category" => __( 'Berserk', 'berserk' ),
					"params"   => array(
						array(
							'heading'    => __( 'Image Frames Type', 'berserk' ),
							'param_name' => 'image_frames_type',
							'type'       => 'brs_radio',
							'value'      => array(
								"Rounded Corner"            => "rounded_corner",
								"Square"                    => "square",
								"Double Type 1"             => "double_type_1",
								"Double Type 2"             => "double_type_2",
								"Double Type 3"             => "double_type_3",
								"Circle"                    => "circle",
								"Hover Gradient"            => "hover_gradient",
								"Hover Triangle"            => "hover_triangle",
								"Border Type 1"             => "border_type_1",
								"Border Type 2"             => "border_type_2",
								"Border Type 3"             => "border_type_3",
								"Angle Shadow"              => "angle_shadow",
								"Angle Shadow Left"         => "angle_shadow_left",
								"Angle Shadow Right"        => "angle_shadow_right",
								"Angle Shadow Rotate Left"  => "angle_shadow_rotate_left",
								"Angle Shadow Rotate Right" => "angle_shadow_rotate_right",

							),
							'images'     => array(
								"rounded_corner"            => 'image_frames/rounded_corner.jpg',
								"square"                    => 'image_frames/square.jpg',
								"double_type_1"             => 'image_frames/double_type_1.jpg',
								"double_type_2"             => 'image_frames/double_type_2.jpg',
								"double_type_3"             => 'image_frames/double_type_3.jpg',
								"circle"                    => 'image_frames/circle.jpg',
								"hover_gradient"            => 'image_frames/hover_gradient.jpg',
								"hover_triangle"            => 'image_frames/hover_triangle.jpg',
								"border_type_1"             => 'image_frames/border_type_1.jpg',
								"border_type_2"             => 'image_frames/border_type_2.jpg',
								"border_type_3"             => 'image_frames/border_type_3.jpg',
								"angle_shadow"              => 'image_frames/angle_shadow.jpg',
								"angle_shadow_left"         => 'image_frames/angle_shadow_left.jpg',
								"angle_shadow_right"        => 'image_frames/angle_shadow_right.jpg',
								"angle_shadow_rotate_left"  => 'image_frames/angle_shadow_rotate_left.jpg',
								"angle_shadow_rotate_right" => 'image_frames/angle_shadow_rotate_right.jpg',

							),
							'images_dim' => array(
								'w' => '210',
								'h' => '150'
							)
						),
						array(
							'type'        => 'attach_image',
							'heading'     => __( 'Image', 'js_composer' ),
							'param_name'  => 'image_1',
							'value'       => '',
							'description' => __( 'Select image from media library.', 'js_composer' ),
						),
						array(
							'type'             => 'dropdown',
							'heading'          => __( 'Image size', 'berserk' ),
							'value'            => BRS_Shortcodes_VCParams::get_image_sizes_names(),
							'param_name'       => 'f_image_size',
							'std'              => 'image-frames',
							'edit_field_class' => 'vc_col-sm-6 vc_column'
						),
						array(
							'heading'          => __( 'Use custom image size', 'berserk' ),
							'param_name'       => 'f_use_custom_size',
							'type'             => 'brs_switch',
							'value'            => 'n',
							'options'          => array(
								'Yes' => 'y',
								'No'  => 'n',
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column'
						),
						array(
							"type"             => "textfield",
							"heading"          => __( "Custom size", 'berserk' ),
							"param_name"       => "f_custom_size",
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							"value"            => "",
							'dependency'       => array(
								'element' => 'f_use_custom_size',
								'value'   => 'y',
							),
							'description'      => __( 'Alternatively enter size in pixels (Example: 200x100 (Width x Height)).', 'js_composer' ),
						),
						array(
							'type'        => 'attach_image',
							'heading'     => __( 'Second Image', 'js_composer' ),
							'param_name'  => 'image_2',
							'value'       => '',
							'description' => __( 'Select image from media library.', 'js_composer' ),
							'edit_field_class' => 'vc_col-sm-12 vc_column brk-dependency__image_frames_type double_type_1 double_type_2 double_type_3',
						),
						array(
							'type'             => 'dropdown',
							'heading'          => __( 'Image size', 'berserk' ),
							'value'            => BRS_Shortcodes_VCParams::get_image_sizes_names(),
							'param_name'       => 's_image_size',
							'std'              => 'image-frames',
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__image_frames_type double_type_1 double_type_2 double_type_3'
						),

						array(
							'heading'          => __( 'Use custom image size', 'berserk' ),
							'param_name'       => 's_use_custom_size',
							'type'             => 'brs_switch',
							'value'            => 'n',
							'options'          => array(
								'Yes' => 'y',
								'No'  => 'n',
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__image_frames_type double_type_1 double_type_2 double_type_3'
						),
						array(
							"type"             => "textfield",
							"heading"          => __( "Custom size", 'berserk' ),
							"param_name"       => "s_custom_size",
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__image_frames_type double_type_1 double_type_2 double_type_3',
							"value"            => "",
							'dependency'       => array(
								'element' => 's_use_custom_size',
								'value'   => 'y',
							),
							'description'      => __( 'Alternatively enter size in pixels (Example: 200x100 (Width x Height)).', 'js_composer' ),
						),

						array(
							'type'             => 'dropdown',
							'heading'          => __( 'Link Type', 'berserk' ),
							'value'            => array(
								__( 'None', 'berserk' )                   => 'none',
								__( 'Open Image in Fancybox', 'berserk' ) => 'fancybox',
								__( 'Custom Link', 'berserk' )            => 'custom',
							),
							'admin_label'      => true,
							'param_name'       => 'link_type',
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__image_frames_type rounded_corner square circle hover_gradient hover_triangle border_type_1 border_type_2 border_type_3 angle_shadow angle_shadow_left angle_shadow_right angle_shadow_rotate_left angle_shadow_rotate_right',
						),
						array(
							'type'       => 'vc_link',
							'heading'    => __( 'Link URL', 'mozel' ),
							'param_name' => 'url',
							"dependency" => array(
								"element" => "link_type",
								"value"   => array( 'custom' ),
							),
						),

						array(
							'type'             => 'checkbox',
							'heading'          => esc_html__( 'Show Inner Border', 'berserk' ),
							'value'            => array(
								'Yes' => 'true',
							),
							'param_name'       => 'inner_square',
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__image_frames_type square',
						),
					)
				) );
			}
		}

		public function shortcode_image_frames( $atts, $content = null ) {

			$libraries = array( 'component__image_frames', 'fancybox' );
			brs_add_libraries( $libraries );

			extract( shortcode_atts( array(
				'image_frames_type' => 'rounded_corner',
				'image_1'           => '',
				'f_image_size'      => 'image-frames',
				'f_use_custom_size' => 'n',
				'f_custom_size'     => '',
				's_image_size'      => 'image-frames',
				's_use_custom_size' => 'n',
				's_custom_size'     => '',
				'image_2'           => '',
				'link_type'         => 'none',
				'url'               => '',
				'inner_square'      => '',
			), $atts ) );


			// store atts
			$atts_backup = self::$atts;

			$image_id   = $image_1;
			$image_id_2 = $image_2;
			$image_1    = wp_get_attachment_image_src( $image_1, 'full' );
			$image_1    = $image_1[0];
			$image_2    = wp_get_attachment_image_src( $image_2, 'full' );
			$image_2    = $image_2[0];
			$image_url  = wp_get_attachment_image_url( $image_id, $f_image_size );

			$link_class = "";
			$link_url   = "";
			$a_title    = "";
			$a_target   = "";
			$tag        = "a ";
			$link_href  = "";
			$img_html   = '<img src="' . esc_attr( BRK_DATA_IMAGE ) . '" data-src="' . esc_url( $image_url ) . '" class="lazyload" alt="">';

			if ( isset( $f_use_custom_size ) && $f_use_custom_size == 'y' && ! empty( $image_id ) && ! empty( $f_custom_size ) ) {

				$f_custom_size = explode( 'x', $f_custom_size );
				$width         = $f_custom_size[0];
				$height        = $f_custom_size[1];
				$image         = wpb_resize( $image_id, '', $width, $height, true );

				$img_html      = '<img src="' . esc_attr( BRK_DATA_IMAGE ) . '" data-src="' . esc_url( $image['url'] ) . '" width="' . $image['width'] . '" height="' . $image['height'] . '" class="lazyload" alt="">';

			}

			$inner_square_html = '';
			if ( $inner_square == 'true' ) {
				$inner_square_html = '<span class="square"></span>';
			}

			switch ( $link_type ) {
				case "fancybox":
					$link_class = "image-popup fancybox";
					$link_url   = esc_url( $image_1 );
					$link_href  = ( $link_url == '' ) ? '' : 'href="' . $link_url . '"';
					break;
				case "custom":
					$link_class = "image-link";

					$url       = ( $url == '||' ) ? '' : $url;
					$url       = vc_build_link( $url );
					$link_url  = $url['url'];
					$link_href = ( $url['url'] == '' ) ? '' : 'href="' . $url['url'] . '"';
					$a_title   = ( $url['title'] == '' ) ? '' : 'title="' . $url['title'] . '"';
					$a_target  = ( $url['target'] == '' ) ? '' : 'target="' . $url['target'] . '"';

					break;
				case "none":
					$tag = "span ";
					break;

			}

			switch ( $image_frames_type ) {
				case "rounded_corner":

					$output = '<' . $tag . $link_href . $a_title . ' ' . $a_target . ' class="rounded-bottom-left shadow ' . $link_class . '">' . $img_html . '</' . $tag . '>';
					break;

				case "square":
					$output = '<' . $tag . $link_href . $a_title . ' ' . $a_target . ' class="img-square shadow ' . $link_class . '">' . $img_html . $inner_square_html . '</' . $tag . '>';

					break;

				case "double_type_1":

					$img_html_2_url  = wp_get_attachment_image_url( $image_id_2, $s_image_size );
					$img_html_2      = '<img src="' . esc_attr( BRK_DATA_IMAGE ) . '" data-src="' . esc_url( $img_html_2_url ) . '" class="lazyload" alt="">';

					if ( isset( $s_use_custom_size ) && $s_use_custom_size == 'y' && ! empty( $image_id_2 ) && ! empty( $s_custom_size ) ) {
						$s_custom_size = explode( 'x', $s_custom_size );
						$width         = $s_custom_size[0];
						$height        = $s_custom_size[1];
						$image         = wpb_resize( $image_id_2, '', $width, $height, true );
						$img_html_2    = '<img src="' . esc_attr( BRK_DATA_IMAGE ) . '" data-src="' . esc_url( $image['url'] ) . '" width="' . $image['width'] . '" height="' . $image['height'] . '" class="lazyload" alt="">';
					}

					$output = '<div class="frame-image img-double">
					              <div class="img">' . $img_html . '</div>
					              <div class="img">' . $img_html_2 . '</div>
					            </div>';
					break;

				case "double_type_2":

					$img_html_2_url  = wp_get_attachment_image_url( $image_id_2, $s_image_size );
					$img_html_2      = '<img src="' . esc_attr( BRK_DATA_IMAGE ) . '" data-src="' . esc_url( $img_html_2_url ) . '" class="lazyload" alt="">';
					if ( isset( $s_use_custom_size ) && $s_use_custom_size == 'y' && ! empty( $image_id_2 ) && ! empty( $s_custom_size ) ) {
						$s_custom_size = explode( 'x', $s_custom_size );
						$width         = $s_custom_size[0];
						$height        = $s_custom_size[1];
						$image         = wpb_resize( $image_id_2, '', $width, $height, true );
						$img_html_2    = '<img src="' . esc_attr( BRK_DATA_IMAGE ) . '" data-src="' . esc_url( $image['url'] ) . '" width="' . $image['width'] . '" height="' . $image['height'] . '" class="lazyload" class="" alt="">';
					}

					$output = '<div class="frame-image img-double-bigger">
					                <div class="img">' . $img_html . '</div>
                                    <div class="img">' . $img_html_2 . '</div>
					            </div>';

					break;
				case "double_type_3":

					$img_html_2_url  = wp_get_attachment_image_url( $image_id_2, $s_image_size );
					$img_html_2      = '<img src="' . esc_attr( BRK_DATA_IMAGE ) . '" data-src="' . esc_url( $img_html_2_url ) . '" class="lazyload" alt="">';
					if ( isset( $s_use_custom_size ) && $s_use_custom_size == 'y' && ! empty( $image_id_2 ) && ! empty( $s_custom_size ) ) {
						$s_custom_size = explode( 'x', $s_custom_size );
						$width         = $s_custom_size[0];
						$height        = $s_custom_size[1];
						$image         = wpb_resize( $image_id_2, '', $width, $height, true );
						$img_html_2    = '<img src="' . esc_attr( BRK_DATA_IMAGE ) . '" src="' . esc_url( $image['url'] ) . '" width="' . $image['width'] . '" height="' . $image['height'] . '" class="lazyload" alt="">';
					}

					$output = '<div class="brk-img-double-wide" data-brk-library="component__image_frames">
									<div class="brk-img-double-wide__container">' . $img_html . '</div>
									<div class="brk-img-double-wide__container">' . $img_html_2 . '</div>
								</div>';


					break;
				case "circle":

					$output = '<' . $tag . $link_href . $a_title . ' ' . $a_target . ' class="rounded-all shadow ' . $link_class . '">' . $img_html . '</' . $tag . '>';

					break;
				case "hover_gradient":

					switch ( $link_type ) {
						case "fancybox":
							$link_class = "popup fancybox";
							break;
						case "custom":
							$link_class = "link";
							break;
					}

					$output = '<' . $tag . $link_href . $a_title . ' ' . $a_target . ' class="img-figure-gradient link mt-30 ' . $link_class . '">
					              <span class="before"></span>
					              ' . $img_html . '
					              <span class="after"></span>
					            </' . $tag . '>';

					break;
				case "hover_triangle":

					switch ( $link_type ) {
						case "fancybox":
							$link_class = "popup fancybox";
							break;
						case "custom":
							$link_class = "link";
							break;
					}

					$output = '<' . $tag . $link_href . $a_title . ' ' . $a_target . ' class="img-figure-triangle link mt-30 ' . $link_class . '">
					              <span class="before"></span>
					              ' . $img_html . '
					              <span class="after"></span>
					              <span class="bg-after"></span>
					            </' . $tag . '>';

					break;
				case "border_type_1":
					//$img_html = wp_get_attachment_image( $image_id, 'image-frames-border' );

					$output = '<' . $tag . $link_href . $a_title . ' ' . $a_target . ' class="image-border-1 mb-40 mt-40 mt-lg-60 ' . $link_class . '">' . $img_html . '</' . $tag . '>';

					break;
				case "border_type_2":
					//$img_html = wp_get_attachment_image( $image_id, 'image-frames-border' );

					$output = '<' . $tag . $link_href . $a_title . ' ' . $a_target . ' class="image-border-2 mb-40 mt-40 mt-lg-60 ' . $link_class . '">
								' . $img_html . '<span class="grad-border"></span><span class="white-border"></span>
								</' . $tag . '>';

					break;
				case "border_type_3":
					//$img_html = wp_get_attachment_image( $image_id, 'image-frames-border' );

					$output = '<' . $tag . $link_href . $a_title . ' ' . $a_target . ' class="image-border-3 mb-40 mt-40 mt-lg-60 ' . $link_class . '">' . $img_html . '</' . $tag . '>';

					break;
				case "angle_shadow":
					$image_url  = wp_get_attachment_image_url( $image_id, $f_image_size );
					$img_html      = '<img src="' . esc_attr( BRK_DATA_IMAGE ) . '" data-src="' . esc_url( $image_url ) . '" class="lazyload image-border-1" alt="">';

					$output = '<' . $tag . $link_href . $a_title . ' ' . $a_target . ' class="angle-shadow-2 mb-40 ' . $link_class . '">' . $img_html . '<span class="angle-shadow"></span></' . $tag . '>';

					break;
				case "angle_shadow_left":

					$image_url  = wp_get_attachment_image_url( $image_id, $f_image_size );
					$img_html      = '<img src="' . esc_attr( BRK_DATA_IMAGE ) . '" data-src="' . esc_url( $image_url ) . '" class="lazyload image-border-1" alt="">';

					$output = '<' . $tag . $link_href . $a_title . ' ' . $a_target . ' class="angle-shadow-1 mb-40 ' . $link_class . '">' . $img_html . '<span class="angle-shadow"></span></' . $tag . '>';

					break;
				case "angle_shadow_right":

					$image_url  = wp_get_attachment_image_url( $image_id, $f_image_size );
					$img_html      = '<img src="' . esc_attr( BRK_DATA_IMAGE ) . '" data-src="' . esc_url( $image_url ) . '" class="lazyload image-border-1" alt="">';

					$output = '<' . $tag . $link_href . $a_title . ' ' . $a_target . ' class="angle-shadow-3 mb-40 ' . $link_class . '">' . $img_html . '<span class="angle-shadow"></span></' . $tag . '>';

					break;
				case "angle_shadow_rotate_left":
					
					$image_url  = wp_get_attachment_image_url( $image_id, $f_image_size );
					$img_html      = '<img src="' . esc_attr( BRK_DATA_IMAGE ) . '" data-src="' . esc_url( $image_url ) . '" class="lazyload image-border-1" alt="">';

					$output = '<' . $tag . $link_href . $a_title . ' ' . $a_target . ' class="angle-shadow-2 rotate-left ' . $link_class . '">' . $img_html . '<span class="angle-shadow"></span></' . $tag . '>';

					break;
				case "angle_shadow_rotate_right":
					$image_url  = wp_get_attachment_image_url( $image_id, $f_image_size );
					$img_html      = '<img src="' . esc_attr( BRK_DATA_IMAGE ) . '" data-src="' . esc_url( $image_url ) . '" class="lazyload image-border-1" alt="">';

					$output = '<' . $tag . $link_href . $a_title . ' ' . $a_target . ' class="angle-shadow-2 rotate-right ' . $link_class . '">' . $img_html . '<span class="angle-shadow"></span></' . $tag . '>';

					break;
			}


			// restore atts
			self::$atts = $atts_backup;

			return $output;
		}


	}

	// create shortcode
	BRS_Image_Frames::get_instance();

}
