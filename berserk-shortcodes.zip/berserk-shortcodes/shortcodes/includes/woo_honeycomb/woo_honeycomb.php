<?php
/**
 * BRS Woocommerce Honeycomb shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Woo_Honeycomb', false ) ) {

	require_once BERSERK_SHORTCODES_PATH . 'shortcodes/includes/shortcodes-ext.php';

	class BRS_Woo_Honeycomb extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Woo_Honeycomb();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_woo_honeycomb', array( $this, 'shortcode_honeycomb' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				$params = array();

				$params[] = array(
					"heading"    => __( "Main Settings", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$params[] = array(
					'heading'    => __( 'Woocommerce Honeycomb Type', 'berserk' ),
					'param_name' => 'woo_honeycomb_type',
					'type'       => 'brs_radio',
					'value'      => array(
						"Type 1" => "type_1",
						"Type 2" => "type_2",
						"Type 3" => "type_3",
						"Type 4" => "type_4",
						"Type 5" => "type_5",
					),
					'images'     => array(
						"type_1" => 'woo_honeycomb/001.png',
						"type_2" => 'woo_honeycomb/002.png',
						"type_3" => 'woo_honeycomb/003.png',
						"type_4" => 'woo_honeycomb/004.png',
						"type_5" => 'woo_honeycomb/005.png',
					),
					'images_dim' => array(
						'w' => '310',
						'h' => '150'
					)
				);

				$params[] = array(
					"heading"          => __( "Please use four items for proper display!", 'berserk' ),
					"param_name"       => "brs_notice",
					"type"             => "brs_notice",
					"edit_field_class" => "vc_col-sm-12 vc_column brk-dependency__woo_honeycomb_type type_1",
				);
				$params[] = array(
					"heading"          => __( "Please use three items for proper display!", 'berserk' ),
					"param_name"       => "brs_notice",
					"type"             => "brs_notice",
					"edit_field_class" => "vc_col-sm-12 vc_column brk-dependency__woo_honeycomb_type type_4",
				);
				$params[] = array(
					"heading"          => __( "Please use seven items for proper display!", 'berserk' ),
					"param_name"       => "brs_notice",
					"type"             => "brs_notice",
					"edit_field_class" => "vc_col-sm-12 vc_column brk-dependency__woo_honeycomb_type type_5",
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Image size', 'berserk' ),
					'value'            => BRS_Shortcodes_VCParams::get_image_sizes_names(),
					'param_name'       => 'image_size',
					'std'              => 'image-frames',
					'edit_field_class' => 'vc_col-sm-6 vc_column'
				);

				$params[] = array(
					"heading"          => __( "Excerpt Symbols Count", 'berserk' ),
					'type'             => 'textfield',
					'param_name'       => 'excerpt_symbols_count',
					'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__woo_honeycomb_type type_1 type_2 type_3 type_5',
				);

				$params[] = array(
					'type'             => 'param_group',
					'heading'          => __( 'Values', 'js_composer' ),
					'param_name'       => 'values',
					'value'            => urlencode( json_encode( array(
						array(
							'title_item' => __( 'We are Awesome', 'js_composer' ),
						),
						array(
							'title_item' => __( 'AWESOME SHOP', 'js_composer' ),
						),
						array(
							'title_item' => __( '& Best items', 'js_composer' ),
						),
					) ) ),
					'params'           => array(
						array(
							'type'             => 'textfield',
							'heading'          => __( 'Title Value', 'js_composer' ),
							'param_name'       => 'title_item',
							'admin_label'      => true,
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						)
					),
					'edit_field_class' => 'vc_col-sm-12 vc_column brk-dependency__woo_honeycomb_type type_4',
				);

				$params[] = array(
					"heading"    => __( "Choose Items", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$params[] = array(
					"heading"          => __( "Add Product", 'berserk' ),
					"param_name"       => "products",
					"type"             => "brs_add_product_multiple",
					'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__woo_honeycomb_type type_1 type_2 type_3 type_4',
				);

				$options    = array(
					'edit_field_class' => 'brk-dependency__woo_honeycomb_type type_5'
				);
				$categories = berserk_shortcodes_product_categories( $options );
				$params     = array_merge( $params, $categories );

				$params[] = array(
					"heading"    => __( "Backgrounds", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$backgrounds                                 = berserk_shortcodes_backgrounds();
				$backgrounds['bg_color']['edit_field_class'] = "vc_col-sm-12 vc_column  brk-dependency__woo_honeycomb_type type_1 type_2 type_3 type_4";
				$backgrounds['opacity']['edit_field_class']  = "vc_col-sm-6 vc_column  brk-dependency__woo_honeycomb_type type_1 type_2 type_3 type_4";

				$params = array_merge( $params, $backgrounds );

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Woo: Honeycomb", 'berserk' ),
					"base"     => "brs_woo_honeycomb",
					"icon"     => "brs_vc_ico_honeycomb",
					"class"    => "brs_vc_sc_honeycomb",
					"category" => __( 'Woocommerce Berserk', 'berserk' ),
					"params"   => $params
				) );
			}
		}

		public function shortcode_honeycomb( $atts, $content = null ) {

			brs_add_libraries( array( 'component__shop_honeycomb' ) );

			$product_categories = BRS_Shortcodes_VCParams::get_terms( 'product_cat' );

			$pairs = array(
				'woo_honeycomb_type'    => 'type_1',
				'image_size'            => '',
				'products'              => '',
				'gradient'              => 'brk-base-bg-gradient-5',
				'opacity'               => '',
				"values"                => '',
				'excerpt_symbols_count' => ''
			);

			foreach ( $product_categories as $name => $slug ) {
				$pairs[ 'category_' . $slug ] = '';
			}

			$atts = shortcode_atts( $pairs, $atts );

			$categories = array();

			foreach ( $atts as $key => $option ) {
				if ( stripos( $key, 'category_' ) !== false ) {
					if ( $option == 'y' ) {
						$cat_slug     = explode( '_', $key );
						$cat_slug     = $cat_slug['1'];
						$categories[] = $cat_slug;
					}
				}
			}

			//dpm($categories);

			$currency = get_woocommerce_currency_symbol();

			//Gradient
			$overlay_class   = array();
			//$overlay_class[] = 'brk-backgrounds__before';
			$overlay_class[] = $atts['gradient'];
			$overlay_class[] = $atts['opacity'];
			$overlay_class   = implode( ' ', $overlay_class );


			switch ( $atts['woo_honeycomb_type'] ) {

				case "type_1":

					$output = '';

					$products = explode( ',', $atts['products'] );
					if ( ! empty( $products ) ) {

						$output .= '<div class="brk-sc-honeycomb">';

						$j = 1;

						foreach ( $products as $product ) {

							$post       = wc_get_product( $product );
							$rate       = $post->get_average_rating() * 20;
							$categories = $post->get_category_ids();

							$terms = array();
							foreach ( $categories as $cat_id ) {
								$term    = get_term( $cat_id );
								$terms[] = $term->name;
							}
							$terms = implode( ', ', $terms );

							$label_terms = get_the_terms( $post->get_id(), 'brs_product_type' );
							$labels      = array();
							if ( is_array( $label_terms ) && ! empty( $label_terms ) ) {
								foreach ( $label_terms as $term ) {
									$labels[] = $term->name;
								}
							}

							$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $product ), $atts['image_size'] );

							$symbols_count = ( $atts['excerpt_symbols_count'] !== '' ) ? $atts['excerpt_symbols_count'] : 50;
							$desc          = $post->get_description();
							if ( ! empty( $desc ) ) {
								$desc = ( strlen( $desc ) > $symbols_count ) ? mb_substr( $desc, 0, $symbols_count ) . " etc." : $desc;
							}
							$price = wc_price( $post->get_price() );

							$buy_now = apply_filters( 'woocommerce_loop_add_to_cart_link',
								sprintf( '<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="brk-sc-honeycomb-one__buy brk-bg-primary font__family-montserrat add-cart ajax_add_to_cart %s product_type_%s">
													<span class="price">' . $price . '</span>
					                                <i class="fa fa-shopping-cart"></i></a>',
									esc_url( $post->add_to_cart_url() ),
									esc_attr( $post->get_id() ),
									esc_attr( $post->get_sku() ),
									$post->is_purchasable() ? 'add_to_cart_button' : '',
									esc_attr( $post->get_type() )
								),
								$post );


							$item_class = '';

							switch ( $j ) {
								case 1:
								case 2:
									$item_class = 'brk-sc-honeycomb-one_center';
									break;
								case 3:
									$item_class = 'brk-sc-honeycomb-one_left';
									break;
								case 4:
									$item_class = 'brk-sc-honeycomb-one_right';
									break;
								default:
									$item_class = 'brk-sc-honeycomb-one_center';
									break;
							}

							$output .= '<div class="brk-sc-honeycomb-one ' . $item_class . '">
					                        <div class="brk-sc-honeycomb-one__content">
					                            <div class="brk-sc-honeycomb-one__title font__family-montserrat">' . esc_html( $post->get_name() ) . '
					                            </div>
					                            <div class="brk-sc-honeycomb-one__thumb"><img src="' . esc_url( $image_url[0] ) . '" alt=""></div>
					                            <div class="brk-sc-honeycomb-one__desc">
					                            ' . esc_html( $desc ) . '
					                            </div>
					                            ' . $buy_now . '
					                        </div>';
							$i = 1;
							foreach ( $labels as $label ) {
								$position = ( $i == 1 ) ? 'right' : 'left';
								$output .= '<div class="brk-sc-honeycomb-one__' . $position . '-sticker">
					                            <div class="brk-sc-honeycomb-one__' . $position . '-sticker-layer">
					                                <div class="brk-sc-honeycomb-one__' . $position . '-sticker-value font__family-montserrat">
					                                <span class="brk-white-font-color">' . $label . '</span></div>
					                            </div>
					                        </div>';
								$i ++;
							}

							$output .= '<div class="brk-sc-honeycomb-one__layer ' . $overlay_class . '"></div>
					                        <div class="brk-sc-honeycomb-one__hex-1"></div>
					                        <div class="brk-sc-honeycomb-one__hex-2"></div>
					                    </div>';
							$j ++;
						}

						$output .= '</div>';
					}

					break;

				case "type_2":

					$output = '';

					$products = explode( ',', $atts['products'] );
					if ( ! empty( $products ) ) {

						$output .= '<div class="brk-sc-honeycomb brk-sc-honeycomb_line">';

						$j = 1;

						foreach ( $products as $product ) {

							$post       = wc_get_product( $product );
							$rate       = $post->get_average_rating() * 20;
							$categories = $post->get_category_ids();

							$terms = array();
							foreach ( $categories as $cat_id ) {
								$term    = get_term( $cat_id );
								$terms[] = $term->name;
							}
							$terms = implode( ', ', $terms );

							$label_terms = get_the_terms( $post->get_id(), 'brs_product_type' );
							$labels      = array();
							if ( is_array( $label_terms ) && ! empty( $label_terms ) ) {
								foreach ( $label_terms as $term ) {
									$labels[] = $term->name;
								}
							}

							$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $product ), $atts['image_size'] );

							$symbols_count = ( $atts['excerpt_symbols_count'] !== '' ) ? $atts['excerpt_symbols_count'] : 50;
							$desc          = $post->get_description();
							if ( ! empty( $desc ) ) {
								$desc = ( strlen( $desc ) > $symbols_count ) ? mb_substr( $desc, 0, $symbols_count ) . " etc." : $desc;
							}

							$price = wc_price( $post->get_price() );


							$buy_now = apply_filters( 'woocommerce_loop_add_to_cart_link',
								sprintf( '<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="brk-sc-honeycomb-two__buy font__family-montserrat add-cart ajax_add_to_cart %s product_type_%s">
													<span class="price">' . $price . '</span>
					                                <span class="buy"><i class="fa fa-shopping-basket"></i>' . esc_html__( 'Buy', 'berserk' ) . '</span></a>',
									esc_url( $post->add_to_cart_url() ),
									esc_attr( $post->get_id() ),
									esc_attr( $post->get_sku() ),
									$post->is_purchasable() ? 'add_to_cart_button' : '',
									esc_attr( $post->get_type() )
								),
								$post );

							$item_class = ( $j % 2 ) ? '' : 'brk-sc-honeycomb-two_cell';

							$output .= '<div class="brk-sc-honeycomb-two ' . $item_class . '">
					                        <div class="brk-sc-honeycomb-two__thumb"><img src="' . esc_url( $image_url[0] ) . '" alt=""></div>
					                        <div class="brk-sc-honeycomb-two__content d-flex flex-column justify-content-center text-center">
					                            <h4 class="brk-sc-honeycomb-two__title brk-white-font-color font__family-montserrat">' . esc_html( $post->get_name() ) . '</h4>
					                            <div class="brk-sc-honeycomb-two__desc">' . esc_html( $desc ) . '
					                            </div>
					                        </div>';

							foreach ( $labels as $label ) {
								$output .= '<div class="brk-sc-honeycomb-two__sticker brk-bg-primary font__family-montserrat">' . $label . '</div>';
							}

							$output .= $buy_now . '
					                        <div class="brk-sc-honeycomb-two__layer ' . $overlay_class . '"></div>
					                        <div class="brk-sc-honeycomb-two__hex-1"></div>
					                        <div class="brk-sc-honeycomb-two__hex-2"></div>
					                    </div>';
							$j ++;

						}
						$output .= '</div>';
					}

					break;

				case "type_3":

					$output = '';

					$products = explode( ',', $atts['products'] );
					if ( ! empty( $products ) ) {

						$output .= '<div class="brk-sc-honeycomb brk-sc-honeycomb_line">';

						foreach ( $products as $product ) {

							$post       = wc_get_product( $product );
							$rate       = $post->get_average_rating() * 20;
							$categories = $post->get_category_ids();

							$terms = array();
							foreach ( $categories as $cat_id ) {
								$term    = get_term( $cat_id );
								$terms[] = $term->name;
							}
							$terms = implode( ', ', $terms );

							$label_terms = get_the_terms( $post->get_id(), 'brs_product_type' );
							$labels      = array();
							if ( is_array( $label_terms ) && ! empty( $label_terms ) ) {
								foreach ( $label_terms as $term ) {
									$labels[] = $term->name;
								}
							}

							$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $product ), $atts['image_size'] );

							$symbols_count = ( $atts['excerpt_symbols_count'] !== '' ) ? $atts['excerpt_symbols_count'] : 50;
							$desc          = $post->get_description();
							if ( ! empty( $desc ) ) {
								$desc = ( strlen( $desc ) > $symbols_count ) ? mb_substr( $desc, 0, $symbols_count ) . " etc." : $desc;
							}

							$price = wc_price( $post->get_price() );

							$buy_now = apply_filters( 'woocommerce_loop_add_to_cart_link',
								sprintf( '<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="brk-sc-honeycomb-three__buy font__family-montserrat add-cart ajax_add_to_cart %s product_type_%s">
													<span class="price">' . $price . '</span>
					                                <span class="buy"><i class="fa fa-shopping-basket"></i>' . esc_html__( 'Buy', 'berserk' ) . '</span></a>',
									esc_url( $post->add_to_cart_url() ),
									esc_attr( $post->get_id() ),
									esc_attr( $post->get_sku() ),
									$post->is_purchasable() ? 'add_to_cart_button' : '',
									esc_attr( $post->get_type() )
								),
								$post );

							$output .= '<div class="brk-sc-honeycomb-three">
					                        <div class="brk-sc-honeycomb-three__thumb"><img src="' . esc_url( $image_url[0] ) . '" alt=""></div>
					                        <div class="brk-sc-honeycomb-three__content d-flex flex-column justify-content-center text-center">
					                            <h4 class="brk-sc-honeycomb-three__title brk-white-font-color font__family-montserrat">' . esc_html( $post->get_name() ) . '</h4>
					                            <div class="brk-sc-honeycomb-three__desc">' . esc_html( $desc ) . '
					                            </div>
					                        </div>';

							foreach ( $labels as $label ) {
								$output .= '<div class="brk-sc-honeycomb-three__sticker brk-bg-primary font__family-montserrat">' . $label . '</div>';
							}

							$output .= $buy_now . '
					                        <div class="brk-sc-honeycomb-three__layer ' . $overlay_class . '"></div>
					                        <div class="brk-sc-honeycomb-three__hex-1"></div>
					                        <div class="brk-sc-honeycomb-three__hex-2"></div>
					                        <div class="brk-sc-honeycomb-three__before"></div>
					                        <div class="brk-sc-honeycomb-three__after"></div>
					                    </div>';
						}

						$output .= '</div>';
					}

					break;

				case "type_4":

					$values = vc_param_group_parse_atts( $atts['values'] );

					$output = '<div class="text-center">';
					$i      = 1;
					foreach ( $values as $value ) {
						switch ( $i ) {
							case 1:
								$item_class = 'font__family-montserrat highlight-trend font__size-14';
								break;
							case 2:
								$item_class = 'font__family-montserrat font__weight-bold font__size-48 line__height-52 mt-30';
								break;
							case 3:
								$item_class = 'font__family-playfair font__style-italic font__weight-normal font__size-48 line__height-52';
								break;
							default:
								$item_class = 'brk-sc-honeycomb-four__title font__family-montserrat';
								break;
						}
						$output .= '<h5 class="' . $item_class . '">' . esc_html( $value['title_item'] ) . '</h5>';
						$i ++;
					}
					$output .= '<div class="divider-cross wow zoomIn">
				                        <span></span>
				                        <span></span>
				                    </div>
				                </div>';

					$products = explode( ',', $atts['products'] );
					if ( ! empty( $products ) ) {

						$output .= '<div class="brk-sc-honeycomb brk-sc-honeycomb_line flex-column" style="margin-top: -90px;">';

						$j = 1;

						foreach ( $products as $product ) {

							$post       = wc_get_product( $product );
							$rate       = $post->get_average_rating() * 20;
							$categories = $post->get_category_ids();

							$terms = array();
							foreach ( $categories as $cat_id ) {
								$term    = get_term( $cat_id );
								$terms[] = $term->name;
							}
							$terms = implode( ', ', $terms );

							$label_terms = get_the_terms( $post->get_id(), 'brs_product_type' );
							$labels      = array();
							if ( is_array( $label_terms ) && ! empty( $label_terms ) ) {
								foreach ( $label_terms as $term ) {
									$labels[] = $term->name;
								}
							}

							$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $product ), $atts['image_size'] );
							$old_price = $post->get_sale_price() !== '' ? $currency . $post->get_regular_price() : '';

							$price = wc_price( $post->get_price() );

							$buy_now = apply_filters( 'woocommerce_loop_add_to_cart_link',
								sprintf( '<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="font__family-montserrat brk-bg-primary brk-white-font-color add-cart ajax_add_to_cart %s product_type_%s">
													' . $price . '</a>',
									esc_url( $post->add_to_cart_url() ),
									esc_attr( $post->get_id() ),
									esc_attr( $post->get_sku() ),
									$post->is_purchasable() ? 'add_to_cart_button' : '',
									esc_attr( $post->get_type() )
								),
								$post );

							switch ( $j ) {
								case 1:
									$item_class = 'brk-sc-honeycomb-four_left';
									break;
								case 2:
									$item_class = 'brk-sc-honeycomb-four_center';
									break;
								case 3:
									$item_class = 'brk-sc-honeycomb-four_right';
									break;
								default:
									$item_class = 'brk-sc-honeycomb-four_center';
									break;
							}

							$output .= '<div class="brk-sc-honeycomb-four ' . $item_class . '">
					                        <div class="brk-sc-honeycomb-four__thumb"><img src="' . esc_url( $image_url[0] ) . '" alt=""></div>

					                        <div class="brk-sc-honeycomb-four__content d-flex flex-column justify-content-center">
					                            <div class="brk-sc-honeycomb-four__sticker brk-white-font-color font__family-montserrat">
					                                <span class="category brk-bg-primary">' . $terms . '</span>';

							foreach ( $labels as $label ) {
								$output .= '<span class="stic scrollbar-range">' . $label . '</span>';
							}

							$output .= '</div>
					                            <h4 class="brk-sc-honeycomb-four__title font__family-montserrat">' . esc_html( $post->get_name() ) . '</h4>
					                            <div class="brk-rating">
					                                <div class="brk-rating__layer">
					                                    <i class="fal fa-star brk-dark-font-color"></i>
					                                    <i class="fal fa-star brk-dark-font-color"></i>
					                                    <i class="fal fa-star brk-dark-font-color"></i>
					                                    <i class="fal fa-star brk-dark-font-color"></i>
					                                    <i class="fal fa-star brk-dark-font-color"></i>
					                                </div>
					                                <div class="brk-rating__imposition" style="width: ' . $rate . '%">
					                                    <div class="visible">
					                                        <i class="fas fa-star brk-base-font-color"></i>
					                                        <i class="fas fa-star brk-base-font-color"></i>
					                                        <i class="fas fa-star brk-base-font-color"></i>
					                                        <i class="fas fa-star brk-base-font-color"></i>
					                                        <i class="fas fa-star brk-base-font-color"></i>
					                                    </div>
					                                </div>
					                            </div>
					                            <div class="brk-sc-honeycomb-four__price">' . $buy_now . '
					                            </div>
					                        </div>

					                        <div class="brk-sc-honeycomb-four__layer">
					                            <div class="brk-sc-honeycomb-four__layer-over ' . $overlay_class . '"></div>
					                        </div>

					                    </div>';
							$j ++;
						}
						$output .= '</div>';
					}

					break;

				case "type_5":

					$output = '';
					if ( ! empty( $categories ) ) {
						$output = '<div class="brk-sc-honeycomb">';
						$i      = 1;
						foreach ( $categories as $category ) {
							$term = get_term_by( 'slug', $category, 'product_cat' );

							$thumbnail_id = get_term_meta( $term->term_id, 'thumbnail_id', true );
							$bg_image     = wp_get_attachment_image_src( $thumbnail_id, $atts['image_size'] );

							$term_custom_fields = get_option( "taxonomy_$term->term_id" );
							$label              = $term_custom_fields['product_cat_label'];

							$symbols_count = ( $atts['excerpt_symbols_count'] !== '' ) ? $atts['excerpt_symbols_count'] : 50;
							$desc          = $term->description;
							if ( ! empty( $desc ) ) {
								$desc = ( strlen( $desc ) > $symbols_count ) ? mb_substr( $desc, 0, $symbols_count ) . " etc." : $desc;
							}

							$item_class = '';
							switch ( $i ) {
								case 1:
									$item_class = 'brk-sc-honeycomb-five_center';
									break;
								case 2:
									$item_class = 'brk-sc-honeycomb-five_white-style brk-sc-honeycomb-five_center';
									break;
								case 3:
									$item_class = 'brk-sc-honeycomb-five_center';
									break;
								case 4:
									$item_class = 'brk-sc-honeycomb-five_left-top';
									break;
								case 5:
									$item_class = 'brk-sc-honeycomb-five_left-bottom';
									break;
								case 6:
									$item_class = 'brk-sc-honeycomb-five_right-top';
									break;
								case 7:
									$item_class = 'brk-sc-honeycomb-five_right-bottom';
									break;
								default:
									$item_class = 'brk-sc-honeycomb-five_center';
									break;
							}

							switch ( $i ) {
								case 2:

									$output .= '<div class="brk-sc-honeycomb-five ' . $item_class . '">
					                        <div class="brk-sc-honeycomb-five__thumb" style="background-image: url(' . esc_url( $bg_image[0] ) . ')"></div>

					                        <div class="brk-sc-hexagon">
												<div class="brk-sc-hexagon__img-main">
													<img src="' . esc_url( $bg_image[0] ) . '" alt="" class="brk-sc-hexagon__main-img">
													<div class="brk-sc-hexagon__overlay"></div>
												</div>
												<div class="brk-sc-hexagon__angle-1"><img src="' . esc_url( $bg_image[0] ) . '" class="brk-sc-hexagon__add-img" alt="">
													<div class="brk-sc-hexagon__overlay"></div>
												</div>
												<div class="brk-sc-hexagon__angle-2"><img src="' . esc_url( $bg_image[0] ) . '" class="brk-sc-hexagon__add-img" alt="">
												<div class="brk-sc-hexagon__overlay"></div>
												</div>
												<div class="brk-sc-hexagon__angle-3"><img src="' . esc_url( $bg_image[0] ) . '" class="brk-sc-hexagon__add-img" alt="">
													<div class="brk-sc-hexagon__overlay"></div>
												</div>
												<div class="brk-sc-hexagon__angle-4"><img src="' . esc_url( $bg_image[0] ) . '" class="brk-sc-hexagon__add-img" alt="">
													<div class="brk-sc-hexagon__overlay"></div>
												</div>
											</div>

					                        <div class="brk-sc-honeycomb-five__content d-flex flex-wrap flex-column justify-content-center align-items-center text-center">
					                            <h4 class="brk-sc-honeycomb-five__title font__family-montserrat font__weight-bold text-uppercase">
					                                ' . esc_html( $term->name ) . '</h4>
					                            <div class="brk-sc-honeycomb-five__desc brk-dark-font-color">
					                            ' . esc_html( $desc ) . '
                                                </div>
					                            <a href="' . esc_url( get_term_link( $term->term_id ) ) . '" class="btn btn-inside-out btn-md border-radius-25 font__family-open-sans font__weight-bold">
					                                <span class="before">' . esc_html__( 'Read More', 'berserk' ) . '</span><span class="text">' . esc_html__( 'Read More', 'berserk' ) . '</span><span class="after">' . esc_html__( 'Read More', 'berserk' ) . '</span>
					                            </a>

					                        </div>
					                    </div>';

									break;
								default:

									$output .= '<div class="brk-sc-honeycomb-five ' . $item_class . '">
					                        <div class="brk-sc-honeycomb-five__thumb" style="background-image: url(' . esc_url( $bg_image[0] ) . ')"></div>

					                        <div class="brk-sc-hexagon">
												<div class="brk-sc-hexagon__img-main">
													<img src="' . esc_url( $bg_image[0] ) . '" alt="" class="brk-sc-hexagon__main-img">
													<div class="brk-sc-hexagon__overlay"></div>
												</div>
												<div class="brk-sc-hexagon__angle-1"><img src="' . esc_url( $bg_image[0] ) . '" class="brk-sc-hexagon__add-img" alt="">
													<div class="brk-sc-hexagon__overlay"></div>
												</div>
												<div class="brk-sc-hexagon__angle-2"><img src="' . esc_url( $bg_image[0] ) . '" class="brk-sc-hexagon__add-img" alt="">
												<div class="brk-sc-hexagon__overlay"></div>
												</div>
												<div class="brk-sc-hexagon__angle-3"><img src="' . esc_url( $bg_image[0] ) . '" class="brk-sc-hexagon__add-img" alt="">
													<div class="brk-sc-hexagon__overlay"></div>
												</div>
												<div class="brk-sc-hexagon__angle-4"><img src="' . esc_url( $bg_image[0] ) . '" class="brk-sc-hexagon__add-img" alt="">
													<div class="brk-sc-hexagon__overlay"></div>
												</div>
											</div>

					                        <div class="brk-sc-honeycomb-five__content d-flex flex-wrap flex-column justify-content-center align-items-center text-center">
					                            <div class="brk-sc-honeycomb-five__link-sticker">
					                                <a href="' . esc_url( get_term_link( $term->term_id ) ) . '" class="brk-sc-honeycomb-five__read-more"><i class="far fa-angle-right"></i></a>';
									if ( isset( $label ) && ! empty( $label ) ) {
										$output .= '<div class="sticker brk-white-font-color brk-base-bg-gradient-14">' . $label . '</div>';
									}
									$output .= '</div>

					                            <a href="' . esc_url( get_term_link( $term->term_id ) ) . '">
					                                <h4 class="brk-sc-honeycomb-five__title brk-white-font-color font__family-montserrat font__weight-bold text-uppercase">
					                                ' . esc_html( $term->name ) . '</h4>
					                                <div class="brk-sc-honeycomb-five__desc brk-blue-font-color">' . esc_html( $desc ) . '</div>
					                            </a>
					                        </div>
					                    </div>';


									break;

							}


							$i ++;
						}

						$output .= '</div>';
					}

					break;

			}

			return $output;
		}
	}

	// create shortcode
	//if(class_exists( 'WooCommerce' )) {
		BRS_Woo_Honeycomb::get_instance();
	//}
}
