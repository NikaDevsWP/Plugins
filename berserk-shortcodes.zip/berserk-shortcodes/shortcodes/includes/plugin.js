(function () {

    tinymce.PluginManager.add('vogue_shortcodes', function (editor, url) {

        /*editor.addButton('vogue_chortcodes_megabutton', {

            type: 'menubutton',

            text: 'Shortcodes',
            tooltip: 'Theme shortcodes',

            icon: false,

            menu: [

                // Button
                {
                    text: 'Button',
                    menu: [

                        {
                            text: 'Full button syntax',
                            onclick: function () {

                                var attr = [
                                        'link=""',
                                        'brs_type="default"',
                                        'target_blank="false"',
                                        'button_alignment="default"',
                                        'animation="fadeIn"',
                                        'size="medium"',
                                        'style="default"',
                                        'bg_color_style="custom"',
                                        'bg_color="#333333"',
                                        'bg_hover_color_style="custom"',
                                        'bg_hover_color="#444444"',
                                        'text_color_style="custom"',
                                        'text_color="#ffffff"',
                                        'text_hover_color_style="custom"',
                                        'text_hover_color="#dddddd"',
                                        'icon="fa fa-chevron-circle-right"',
                                        'icon_align="left"'
                                    ],
                                    attr_str = attr.join(' ');


                                editor.insertContent('[brs_button' + attr_str + ']BUTTON_NAME[/brs_button]');
                            }
                        }

                    ]
                }
            ]

        });*/

    });

})();