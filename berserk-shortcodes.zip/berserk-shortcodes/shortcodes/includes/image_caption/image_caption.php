<?php
/**
 * BRS_Image_Caption shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Image_Caption', false ) ) {

	require_once BERSERK_SHORTCODES_PATH . 'shortcodes/includes/shortcodes-ext.php';

	class BRS_Image_Caption extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Image_Caption();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_image_caption', array( $this, 'shortcode_image_caption' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				$params = array();

				$params[] = array(
					"heading"    => __( "Main Settings", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);
				$params[] = array(
					'heading'    => __( 'Image Type', 'berserk' ),
					'param_name' => 'type',
					'type'       => 'brs_radio',
					'value'      => array(
						"Block 1" => "block_1",
						"Block 2" => "block_2",
						"Block 3" => "block_3",
						"Block 4" => "block_4",
						"Card 1"  => "card_1",
						"Card 2"  => "card_2",
						"Card 3"  => "card_3",
						"Card 4"  => "card_4",
						"Card 5"  => "card_5",
						"Card 6"  => "card_6",
					),
					'images'     => array(
            "block_1" => '/image-caption/001.png',
            "block_2" => '/image-caption/002.png',
            "block_3" => '/image-caption/003.png',
            "block_4" => '/image-caption/004.png',
            "card_1" => '/image-caption/005.png',
            "card_2" => '/image-caption/006.png',
            "card_3" => '/image-caption/007.png',
            "card_4" => '/image-caption/008.png',
            "card_5" => '/image-caption/009.png',
            "card_6" => '/image-caption/010.png',
					),
					'images_dim' => array(
						'w' => '320',
						'h' => '100'
					)
				);

				$params[] = array(
          'type'        => 'attach_image',
          'heading'     => __( 'Image', 'js_composer' ),
          'param_name'  => 'image',
          'value'       => ''
        );

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Image size', 'berserk' ),
					'value'            => BRS_Shortcodes_VCParams::get_image_sizes_names(),
					'param_name'       => 'image_size',
					'std'              => 'testimonials-avatar',
					'edit_field_class' => 'vc_col-sm-6 vc_column'
				);

				$params[] = array(
					'type'             => 'textfield',
					'heading'          => __( 'Title', 'js_composer' ),
					'param_name'       => 'title',
					'value'            => '',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
				);

        $params[] = array(
          'type'             => 'textfield',
          'heading'          => __( 'Sub Title', 'js_composer' ),
          'param_name'       => 'sub_title',
          "value"            => "",
          'edit_field_class' => 'vc_col-sm-6 vc_column',
        );

        $params[] = array(
          'type'             => 'textfield',
          'heading'          => __( 'Sub Title Suffix', 'js_composer' ),
          'param_name'       => 'sub_title_suffix',
          "value"            => "",
          'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__type block_1',
        );

        $params[] = array(
          'type'             => 'textarea',
          'heading'          => __( 'Info', 'js_composer' ),
          'param_name'       => 'info',
          'value'            => '',
          'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__type card_1 card_5 card_6',
        );

        $params[] = array(
          'type'       => 'vc_link',
          'heading'    => __( 'Link URL', 'js_composer' ),
          'param_name' => 'url',
        );

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Image Caption", 'berserk' ),
					"base"     => "brs_image_caption",
					"icon"     => "brs_vc_ico_image",
					"class"    => "brs_vc_sc_image_caption",
					"category" => __( 'Berserk', 'berserk' ),
					"params"   => $params
				) );

			}
		}

		public function shortcode_image_caption( $atts, $content = null ) {

      $libraries = array('component__image_caption');
			
      $atts = shortcode_atts( array(
				'type'       => 'block_1',
				'image'      => '',
				'image_size' => 'full',
				'title'      => '',
				'sub_title'  => '',
        'sub_title_suffix' => '',
				'info'       => '',
				'url'        => '',
			), $atts );


			$image = wp_get_attachment_image_src( $atts['image'], $atts['image_size'] );
			$image_url = $image[0];

      $url      = ( $atts['url'] == '||' ) ? '' : $atts['url'];
      $url      = vc_build_link( $url );
      $link_url = $url['url'];
      $a_title  = ( $url['title'] == '' ) ? '' : $url['title'];
      $a_target = ( $url['target'] == '' ) ? '' : 'target="' . $url['target'] . '"';

      $vars = array(
        'image_url' => $image_url,
        'title' => esc_html( $atts['title'] ),
        'sub_title' => esc_html( $atts['sub_title'] ),
        'sub_title_suffix' => esc_html( $atts['sub_title_suffix'] ),
        'link_url' => esc_url( $link_url ),
        'a_target' => $a_target,
      );

			switch ( $atts['type'] ) {

				case "block_1":
          $output = theme_brk__image_caption__block_1($vars);
					break;

        case "block_2":
          $output = '
            <div class="brk-ic-left-slide">
                <img src="' . $image_url . '" class="brk-ic-left-slide__img"/>
                <div class="brk-ic-left-slide__overlay brk-base-bg-gradient-7-transperent"></div>
                <div class="brk-ic-left-slide__wrapper brk-ic-left-slide__wrapper_vertical-line">
                    <h3 class="brk-ic-left-slide__title font__size-21 line__height-24 brk-bl-color-2">
                        <span class="font__family-montserrat font__weight-normal uppercase">' . esc_html( $atts['title'] ) .'</span> <br>
                        <span class="font__family-montserrat font__weight-bold uppercase letter-spacing--20">' . esc_html( $atts['sub_title'] ) . '</span>
                    </h3>
                </div>
                <a href="' . esc_url( $link_url ) . '" ' . $a_target . ' class="icon__btn icon__btn-anim icon__btn-md brk-ic-left-slide__btn brk-ic-left-slide__btn_reverse">
                    <span class="before"></span>
                    <i class="fa fa-angle-right" aria-hidden="true"></i>
                    <span class="after"></span>
                </a>
            </div>';
          break;

        case "block_3":
          $output = '
            <div class="brk-ic-left-slide">
                <img src="' . $image_url . '" class="brk-ic-left-slide__img"/>
                <div class="brk-ic-left-slide__overlay brk-base-bg-gradient-6-black"></div>
                <a href="' . esc_url( $link_url ) . '" ' . $a_target . ' class="brk-ic-left-slide__wrapper brk-ic-left-slide__wrapper_gradient brk-base-bg-gradient-50deg-a">
                    <h3 class="brk-ic-left-slide__title font__size-21 line__height-28">
                        <span class="font__family-montserrat font__weight-light">' . esc_html( $atts['title'] ) .'</span> <br>
                        <span class="font__family-montserrat font__weight-bold letter-spacing--20">' . esc_html( $atts['sub_title'] ) . '</span>
                    </h3>
                </a>
            </div>';
          break;

        case "block_4":
          $output = '
            <div class="brk-ic-left-slide">
                <img src="' . $image_url . '" class="brk-ic-left-slide__img"/>
                <div class="brk-ic-left-slide__overlay brk-base-bg-gradient-9"></div>
                <div class="brk-ic-left-slide__wrapper brk-ic-left-slide__wrapper_btn-left">
                    <h3 class="brk-ic-left-slide__title brk-ic-left-slide__title_video line__height-21">
                        <span class="font__family-montserrat font__weight-semibold font__size-21 letter-spacing--60  uppercase">' . esc_html( $atts['title'] ) .'</span> <br>
                        <span class="font__family-open-sans font__size-16 font__weight-normal line__height-21 brk-ic-left-slide__title__link">' . esc_html( $atts['sub_title'] ) . '</span>
                    </h3>
                </div>
                <a href="' . esc_url( $link_url ) . '" ' . $a_target . ' class="icon__btn icon__btn_ icon__btn-anim icon__btn-md brk-ic-left-slide__btn brk-ic-left-slide__btn_left brk-ic-left-slide__btn_reverse">
                    <span class="before"></span>
                    <i class="fa fa-play" aria-hidden="true"></i>
                    <span class="after"></span>
                </a>
            </div>';
          break;

        case "card_1":
          $libraries[] = 'assets__image_caption';
          $output = '
            <a href="' . esc_url( $link_url ) . '" ' . $a_target . ' class="brk-tilter brk_hover3d_2 brk-tilter--2">
                <figure class="brk-tilter__figure">
                    <img class="brk-tilter__image" src="' . $image_url . '" alt=""/>
                    <div class="brk-tilter__deco brk-tilter__deco--shine"></div>
                    <div class="brk-tilter__deco brk-base-bg-gradient-0deg-a"></div>
                    <figcaption class="brk-tilter__caption brk-tilter__caption--1">
                        <h3 class="brk-tilter__title font__family-montserrat font__size-42 font__weight-normal line__height-42 text-left mb-15 letter-spacing--20">
                            ' . esc_html( $atts['title'] ) .'</h3>
                        <h4 class="brk-tilter__subtitle font__family-montserrat font__size-14 font__weight-medium line__height-16 text-left ">' . esc_html( $atts['sub_title'] ) . '</h4>
                        <p class="brk-tilter__description font__family-open-sans font__size-16 font__weight-light line__height-26 letter-spacing-20">' . $atts['info'] .'</p>
                    </figcaption>
                    <span class="brk-tilter__deco brk-tilter__deco--lines brk-tilter__deco--lines__test"></span>
                </figure>
            </a>';
          break;

        case "card_2":
          $libraries[] = 'assets__image_caption';
          $output = '
            <a href="' . esc_url( $link_url ) . '" ' . $a_target . '  class="brk-tilter brk_hover3d_4 brk-tilter--6">
                <figure class="brk-tilter__figure">
                    <img class="brk-tilter__image" src="' . $image_url . '" alt="img11">
                    <div class="brk-tilter__deco brk-tilter__deco--shine"></div>
                    <div class="brk-tilter__deco brk-base-bg-gradient-10"></div>
                    <figcaption class="brk-tilter__caption">
                        <h4 class="brk-tilter__subtitle font__family-montserrat font__size-14 font__weight-medium line__height-16 text-left letter-spacing-100">' . esc_html( $atts['sub_title'] ) . '</h4>
                        <h3 class="brk-tilter__title font__family-montserrat-alt font__size-34 font__weight-medium line__height-40 text-left">' . esc_html( $atts['title'] ) .'</h3>
                    </figcaption>
                    <span class="brk-tilter__deco brk-tilter__deco--lines"></span>
                </figure>
            </a>';
          break;

        case "card_3":
          $libraries[] = 'assets__image_caption';
          $output = '
            <a href="' . esc_url( $link_url ) . '" ' . $a_target . ' class="brk-tilter brk-tilter--7">
                <figure class="brk-tilter__figure">
                    <img class="brk-tilter__image" src="' . $image_url . '" alt="img13">
                    <div class="brk-tilter__deco brk-tilter__deco--shine">
                    </div>
                    <div class="brk-tilter__deco brk-base-bg-gradient-0deg-a"></div>
                    <figcaption class="brk-tilter__caption brk-tilter__caption--2" >
                        <h3 class="brk-tilter__title font__family-playfair font__size-42 font__weight-bold line__height-42 text-left">' . esc_html( $atts['sub_title'] ) . '</h3>
                        <h4 class="brk-tilter__subtitle font__family-montserrat font__size-16 font__weight-normal line__height-18 text-left">' . esc_html( $atts['title'] ) .'</h4>
                    </figcaption>
                    <span class="brk-tilter__deco brk-tilter__deco--lines"></span>
                </figure>
            </a>';
          break;

        case "card_4":
          $libraries[] = 'assets__image_caption';
          $output = '
            <a href="' . esc_url( $link_url ) . '" ' . $a_target . '  class="brk-tilter brk-tilter--8">
                <figure class="brk-tilter__figure">
                    <img class="brk-tilter__image" src="' . $image_url . '" alt="img15">
                    <div class="brk-tilter__deco brk-tilter__deco--shine"></div>
                    <div class="brk-tilter__deco brk-tilter__deco--overlay brk-base-bg-gradient-bottom-blue"></div>
                    <figcaption class="brk-tilter__caption">
                        <h3 class="brk-tilter__title font__family-playfair font__size-42 font__weight-bold line__height-42 text-center">' . esc_html( $atts['sub_title'] ) . '</h3>
                        <h4 class="brk-tilter__subtitle font__family-montserrat font__size-16 font__weight-light line__height-18 text-center letter-spacing-100">' . esc_html( $atts['title'] ) .'</h4>
                    </figcaption>
                    <span class="brk-tilter__deco brk-tilter__deco--lines"></span>
                </figure>
            </a>';
          break;

        case "card_5":
          $libraries[] = 'assets__image_caption';
          $output = '
            <a class="brk-ip-angle brk-tilter brk-tilter--2" href="' . esc_url( $link_url ) . '" ' . $a_target . ' >
                <figure class="brk-tilter__figure">
                    <div class="brk-ip-angle__overlay brk-base-bg-gradient-0deg-a"></div>
                    <img class="brk-ip-angle__img" src="' . $image_url . '" alt="">
                    <figcaption class="brk-tilter__caption">
                        <p class="brk-ip-angle__paragraph font__family-open-sans font__size-16 font-weight-light line__height-26 text-right letter-spacing-20">' . esc_html( $atts['info'] ) .'</p>
                    </figcaption>
                    <div class="brk-ip-angle__content">
                        <h4 class="brk-ip-angle__subtitle font__family-montserrat font__size-16 font__weight-light line__height-16 text-left brk-base-bg-gradient-50deg-a">' . esc_html( $atts['sub_title'] ) . '</h4>
                        <h3 class="brk-ip-angle__title font__family-montserrat font__size-32 font__weight-light line__height-42 text-left">' . esc_html( $atts['title'] ) .'</h3>
                    </div>
                </figure>
                <button type="button" class="brk-ip-angle__heart">
                    <i class="fa fa-heart-o" aria-hidden="true"></i>
                </button>
            </a>';
          break;

        case "card_6":
          $libraries[] = 'assets__image_caption';
          $output = '
            <a class="brk-ip-simple brk-tilter brk-tilter--2" href="' . esc_url( $link_url ) . '" ' . $a_target . ' >
                <figure class="brk-tilter__figure">
                    <div class="brk-ip-simple__overlay brk-base-bg-gradient-10"></div>
                    <img class="brk-ip-simple__img" src="' . $image_url . '" alt="">
                    <figcaption class="brk-tilter__caption">
                        <h3 class="brk-ip-simple__title font__family-montserrat font__size-32 line__height-42 text-left"><span class="font__weight-light">' . esc_html( $atts['title'] ) .'</span>  <span class="font__weight-bold">' . esc_html( $atts['sub_title'] ) . '</span></h3>
                    </figcaption>
                    <p class="brk-ip-simple__paragraph font__family-open-sans font__size-16 font-weight-light line-height-26 text-left">' . esc_html( $atts['info'] ) . '</p>
                    <span class="brk-ip-simple__paragraph__angle"></span>
                </figure>
            </a>';
          break;
			}

      brs_add_libraries($libraries);
			return $output;
		}

	}

  function theme_brk__image_caption__block_1($vars) {
    $output = '
      <div class="brk-ic-left-slide">
          <img src="' . $vars['image_url'] . '" class="brk-ic-left-slide__img"/>
          <div class="brk-ic-left-slide__overlay brk-base-bg-gradient-6-black"></div>
          <div class="brk-ic-left-slide__wrapper">
              <h4 class="brk-ic-left-slide__subtitle font__family-open-sans font__size-14 font__weight-light line__height-21 letter-spacing-60">' . $vars['title'] .'</h4>
              <h3 class="brk-ic-left-slide__title font__size-28 line__height-30">
                  <span class="font__family-montserrat-alt font__weight-normal">' . $vars['sub_title'] . '</span>
                  <span class="font__family-playfair font__weight-light font__style-italic">' . $vars['sub_title_suffix'] . '</span>
              </h3>
          </div>
          <a href="' . $vars['link_url'] . '" ' . $vars['a_target'] . ' class="icon__btn icon__btn-anim icon__btn-md brk-ic-left-slide__btn">
              <span class="before"></span>
              <i class="fa fa-angle-right" aria-hidden="true"></i>
              <span class="after"></span>
          </a >
      </div>';
    return $output;
  }

	// create shortcode
	BRS_Image_Caption::get_instance();

}
