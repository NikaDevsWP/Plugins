<?php
/**
 * BRS Woocommerce Banner shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Woo_Banner', false ) ) {

	require_once BERSERK_SHORTCODES_PATH . 'shortcodes/includes/shortcodes-ext.php';

	class BRS_Woo_Banner extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Woo_Banner();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_woo_banner', array( $this, 'shortcode_woo_banner' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				$params = array();

				$params[] = array(
					"heading"    => __( "Main Settings", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$params[] = array(
					'type'       => 'textfield',
					'heading'    => __( 'Title', 'js_composer' ),
					'param_name' => 'title',
				);

				$params[] = array(
					'type'       => 'vc_link',
					'heading'    => __( 'Link URL', 'js_composer' ),
					'param_name' => 'url',
				);

				$params[] = array(
					"heading"    => __( "Choose product categories", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$categories = berserk_shortcodes_product_categories();
				$params     = array_merge( $params, $categories );

				$patterns = berserk_shortcodes_patterns();
				$params   = array_merge( $params, $patterns );

				$params[] = array(
					'type'             => 'attach_image',
					'heading'          => __( 'Single Image', 'js_composer' ),
					'param_name'       => 'single_image',
					'edit_field_class' => 'vc_col-xs-12 vc_column',
					'value'            => '',
				);

				// Image sizes
				$image_sizes = berserk_shortcodes_image_size_options();
				$params      = array_merge( $params, $image_sizes );

				$params[] = array(
					"heading"    => __( "Values", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$params[] = array(
					'type'             => 'param_group',
					'heading'          => __( 'Values', 'js_composer' ),
					'param_name'       => 'values',
					'value'            => urlencode( json_encode( array(
						array(
							'caption' => __( '01', 'js_composer' ),
							'label'   => __( '-10%', 'js_composer' ),
						),
						array(
							'caption' => __( '02', 'js_composer' ),
							'label'   => __( '-10%', 'js_composer' ),
						),
						array(
							'caption' => __( '03', 'js_composer' ),
							'label'   => __( '', 'js_composer' ),
						),
					) ) ),
					'params'           => array(
						array(
							'type'             => 'textfield',
							'heading'          => __( 'Caption', 'js_composer' ),
							'param_name'       => 'caption',
							'admin_label'      => true,
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),
						array(
							'type'             => 'textfield',
							'heading'          => __( 'Label', 'js_composer' ),
							'param_name'       => 'label',
							'admin_label'      => true,
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),
						array(
							'type'       => 'vc_link',
							'heading'    => __( 'Link URL', 'js_composer' ),
							'param_name' => 'url',
						)

					),
					'edit_field_class' => 'vc_col-sm-12 vc_column',
				);

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Woo: Banner", 'berserk' ),
					"base"     => "brs_woo_banner",
					"icon"     => "brs_vc_ico_banner",
					"class"    => "brs_vc_sc_banner",
					"category" => __( 'Woocommerce Berserk', 'berserk' ),
					"params"   => $params
				) );
			}
		}

		public function shortcode_woo_banner( $atts, $content = null ) {

			brs_add_libraries( array( 'component__flip_box' ) );

			$product_categories = BRS_Shortcodes_VCParams::get_terms( 'product_cat' );

			$pairs = array(
				'title'                 => '',
				'url'                   => '',
				'values'                => '',
				'bg_image'              => '',
				'pattern_type'          => '',
				'background_size'       => 'bg-cover',
				'background_repeat'     => '',
				'background_position'   => '',
				'use_custom_background' => 'no',
				'single_image'          => '',
				'image_custom_width'    => '',
				'image_custom_height'   => '',
				'image_size'            => 'gallery-sliders-gradient',
			);

			$atts['image_size'] = berserk_shortcodes_image_size_render( $atts );

			foreach ( $product_categories as $name => $slug ) {
				$pairs[ 'category_' . $slug ] = '';
			}

			$atts = shortcode_atts( $pairs, $atts );

			$categories = array();

			foreach ( $atts as $key => $option ) {
				if ( stripos( $key, 'category_' ) !== false ) {
					if ( $option == 'y' ) {
						$cat_slug     = explode( '_', $key );
						$cat_slug     = $cat_slug['1'];
						$categories[] = $cat_slug;
					}
				}
			}

			//Pattern or custom Image
			$pattern_style = '';
			$pattern_class = '';
			if ( $atts['use_custom_background'] == 'yes' ) {
				$image         = wp_get_attachment_image_src( $atts['bg_image'], 'full' );
				$image         = $image[0];
				$pattern_style = 'background-image: url(' . esc_url( $image ) . ');';

			} else {
				$pattern_class = $atts['pattern_type'];
			}

			if(isset( $atts['background_size']) && ( $atts['background_size'] !='none')){
				$pattern_class = $atts['background_size'];
			}
			if(isset( $atts['background_repeat']) && ( $atts['background_repeat'] !='none')){
				$pattern_class = $atts['background_repeat'];
			}
			if(isset( $atts['background_position']) && ( $atts['background_position'] !='none')){
				$pattern_class = $atts['background_position'];
			}

			$single_image = wp_get_attachment_image_src( $atts['single_image'], $atts['image_size'] );

			$url      = ( $atts['url'] == '||' ) ? '' : $atts['url'];
			$url      = vc_build_link( $url );
			$link_url = $url['url'];
			$a_title  = ( $url['title'] == '' ) ? '' : $url['title'];
			$a_target = ( $url['target'] == '' ) ? '' : 'target="' . $url['target'] . '"';

			$values = vc_param_group_parse_atts( $atts['values'] );


			$output = '<div class="brk-sc-tiles-banner shadow">
                        <div style="'.$pattern_style.'" class="brk-sc-tiles-banner__bg '.$pattern_class.'"></div>
                        <div class="brk-sc-tiles-banner__overlay "></div>
                        <div class="row">
                            <div class="col-12 col-sm-8 col-lg-5">
                                <div class="brk-sc-tiles-banner__info">
                                    <h1 class="brk-sc-tiles-banner__title brk-white-font-color font__family-montserrat font__size-36 font__weight-bold line__height-42 mb-25 letter-spacing--20">
                                        ' . $atts['title'] . '
                                    </h1>

                                    <div class="brk-sc-tags font__family-open-sans font__size-16 font__weight-normal line__height-26 d-flex align-items-center flex-wrap mb-20">';
			foreach ( $categories as $category ) {
				$term = get_term_by( 'slug', $category, 'product_cat' );
				$output .= '<a href="' . esc_url( get_term_link( $term->term_id ) ) . '" class="brk-sc-tags__item">' . $term->name . '</a>';
			}
			$output .= '
                                    </div>

                                    <a href="' . esc_url( $link_url ) . '" ' . $a_target . ' class="btn btn-inside-out btn-inside-out-invert btn-lg border-radius-50 font__family-open-sans font__weight-bold brk-sc-tiles-banner__btn">
                                        <span class="before">' . esc_html( $a_title ) . '</span>
                                        <span class="text">' . esc_html( $a_title ) . '</span>
                                        <span class="after">' . esc_html( $a_title ) . '</span>
                                    </a>

                                </div>
                            </div>
                            <div class="col-12 col-sm-4 col-lg-4">
                                <div class="brk-sc-tiles-banner__img">
                                    <img src="' . esc_url( $single_image[0] ) . '" alt="">
                                </div>
                            </div>
                            <div class="col-12 col-lg-3">
                                <div class="brk-sc-tiles-banner__links">';
			$i = 1;
			foreach ( $values as $value ) {

				$url      = ( $value['url'] == '||' ) ? '' : $value['url'];
				$url      = vc_build_link( $url );
				$link_url = $url['url'];
				$a_title  = ( $url['title'] == '' ) ? '' : $url['title'];
				$a_target = ( $url['target'] == '' ) ? '' : 'target="' . $url['target'] . '"';

				$output .= '<a href="' . esc_url( $link_url ) . '" ' . $a_target . ' class="brk-sc-tiles-banner__link" >
                                        <span class="font__family-montserrat brk-white-font-color font__size-42 font__weight-light line__height-42 mr-35">' . esc_html( $value['caption'] ) . '</span >
                                        <span class="brk-white-font-color font__size-16 font__weight-normal line__height-21" >' . esc_html( $a_title ) . '</span >';

				if ( isset( $value['label'] ) ) {
					$label_class = '';
					switch ( $i ) {
						case 1:
							$label_class = 'brk-fill-primary';
							break;
						case 2:
							$label_class = 'brk-fill-secondary';
							break;
					}

					$output .= '<div class="brk-sc-tiles-banner__discount" >
                                            <svg vxmlns:xlink = "http://www.w3.org/1999/xlink" viewBox = "0 0 461 483" >
                                                <g>
                                                    <path class="' . $label_class . '" d = "M198.7,16.9c17-19.2,44.8-19.2,61.8,0c17,19.2,51.4,30.4,76.4,24.8c25-5.5,47.5,10.8,50,36.3
                  c2.5,25.5,23.7,54.8,47.2,65c23.5,10.2,32.1,36.7,19.1,58.8c-13,22.1-13,58.2,0,80.3c13,22.1,4.4,48.5-19.1,58.8
                  c-23.5,10.2-44.8,39.5-47.2,65c-2.5,25.5-25,41.9-50,36.3c-25-5.5-59.4,5.6-76.4,24.8c-17,19.2-44.8,19.2-61.8,0
                  s-51.4-30.4-76.4-24.8c-25,5.5-47.5-10.8-50-36.3c-2.5-25.5-23.7-54.8-47.2-65s-32.1-36.7-19.1-58.8c13-22.1,13-58.2,0-80.3
                  c-13-22.1-4.4-48.5,19.1-58.8s44.8-39.5,47.2-65c2.5-25.5,25-41.9,50-36.3C147.3,47.3,181.7,36.1,198.7,16.9z" />
                                                </g>
                                            </svg>
                                            <span class="brk-white-font-color font__family-montserrat font__size-14 font__weight-bold brk-sc-tiles-banner__discount-value">' . esc_html( $value['label'] ) . '</span>
                                        </div>';
				}
				$output .= '</a>';
				$i ++;
			}

			$output .= '</div >
                            </div >
                        </div >
                    </div >';


			return $output;
		}
	}

	// create shortcode
	include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
	if( is_plugin_active( 'woocommerce/woocommerce.php' )){
		BRS_Woo_Banner::get_instance();
	}

}
