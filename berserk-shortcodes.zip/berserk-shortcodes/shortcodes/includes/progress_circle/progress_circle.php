<?php
/**
 * Progress Circles shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Progress_Circle', false ) ) {

	class BRS_Progress_Circle extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Progress_Circle();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_progress_circle', array( $this, 'shortcode_progress_circle' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Progress Circle", 'berserk' ),
					"base"     => "brs_progress_circle",
					"icon"     => "brs_vc_ico_progress_circle",
					"class"    => "brs_vc_sc_progress_circle",
					"category" => __( 'Berserk', 'berserk' ),
					"params"   => array(
						array(
							'heading'    => __( 'Progress Circle Type', 'berserk' ),
							'param_name' => 'progress_circle_type',
							'type'       => 'brs_radio',
							'value'      => array(
								"Minimal"     => "minimal",
								"Light"       => "light",
								"Triangled"   => "triangled",
								"Vertical"    => "vertical",
								"Two circles" => "two_circles",
								"Icon"        => "icon"
							),
							'images'     => array(
								"minimal"     => 'progress_circle/001.jpg',
								"light"       => 'progress_circle/002.jpg',
								"triangled"   => 'progress_circle/003.jpg',
								"vertical"    => 'progress_circle/004.jpg',
								"two_circles" => 'progress_circle/005.jpg',
								"icon"        => 'progress_circle/006.jpg'
							),
							'images_dim' => array(
								'w' => '150',
								'h' => '150'
							)
						),

						array(
							'type'             => 'dropdown',
							'heading'          => __( 'Progress Circle Skin Type', 'berserk' ),
							'value'            => array(
								__( 'Default', 'berserk' ) => 'default',
								__( 'Light', 'berserk' )   => 'light',
							),
							'param_name'       => 'progress_circle_stroke_type',
							'edit_field_class' => 'vc_col-sm-4 vc_column brk-dependency__progress_circle_type icon',
						),


						array(
							'type'             => 'textfield',
							'heading'          => __( 'Label', 'js_composer' ),
							'param_name'       => 'label',
							"value"            => "Hard Work",
							'edit_field_class' => 'vc_col-sm-4 vc_column',
						),
						array(
							'type'             => 'textfield',
							'heading'          => __( 'Value (%)', 'berserk' ),
							'param_name'       => 'value',
							"value"            => "75",
							'edit_field_class' => 'vc_col-sm-4 vc_column',
						),
						array(
							'type'             => 'checkbox',
							'heading'          => esc_html__( 'Label White Color', 'berserk' ),
							'param_name'       => 'label_color',
							'value'            => '#2775ff',
							'value'       => array(
								esc_html__( 'Yes', 'berserk' ) => 'brk-white-font-color'
							),
							'edit_field_class' => 'vc_col-sm-4 vc_column',
						),
						array(
							'type'             => 'checkbox',
							'heading'          => esc_html__( 'Custom Colors', 'berserk' ),
							'param_name'       => 'custom_colors',
							'value'            => array(
								esc_html__( 'Use Custom Colors', 'berserk' ) => 'true',
							),
							'edit_field_class' => 'vc_col-sm-4 vc_column',
						),
						array(
							'type'             => 'colorpicker',
							'heading'          => __( 'First Gradient Color', 'berserk' ),
							'param_name'       => 'f_color',
							'value'            => '#2775ff',
							'edit_field_class' => 'vc_col-sm-2 vc_column',
							'dependency'       => array(
								'element' => 'custom_colors',
								'value'   => 'true',
							),
						),
						array(
							'type'             => 'colorpicker',
							'heading'          => __( 'Second Gradient Color', 'berserk' ),
							'param_name'       => 's_color',
							'value'            => '#2775ff',
							'edit_field_class' => 'vc_col-sm-2 vc_column',
							'dependency'       => array(
								'element' => 'custom_colors',
								'value'   => 'true',
							),
						),
						
						array(
							"heading"          => __( "Icon", 'berserk' ),
							"param_name"       => "brs_title",
							"type"             => "brs_title",
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
						),
						array(
							'type'             => 'dropdown',
							'heading'          => __( 'Icon library', 'berserk' ),
							'value'            => array(
								__( 'Font Awesome', 'berserk' ) => 'fontawesome',
								__( 'Open Iconic', 'berserk' )  => 'openiconic',
								__( 'Typicons', 'berserk' )     => 'typicons',
								__( 'Entypo', 'berserk' )       => 'entypo',
								__( 'Linecons', 'berserk' )     => 'linecons',
								__( 'Mono Social', 'berserk' )  => 'monosocial',
								__( 'Livicon', 'berserk' )      => 'livicon',
							),
							'param_name'       => 'btn_icon_type',
							'edit_field_class' => 'vc_col-sm-6 vc_column icon_option',
						),
						array(
							'type'             => 'iconpicker',
							'heading'          => __( 'Icon', 'berserk' ),
							'param_name'       => 'icon_fontawesome',
							'value'            => 'fa fa-adjust', // default value to backend editor admin_label
							'settings'         => array(
								'emptyIcon'    => false,
								'iconsPerPage' => 4000,
							),
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'fontawesome',
							),
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
						),
						array(
							'type'             => 'iconpicker',
							'heading'          => __( 'Icon', 'berserk' ),
							'param_name'       => 'icon_openiconic',
							'value'            => 'vc-oi vc-oi-dial', // default value to backend editor admin_label
							'settings'         => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'openiconic',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'openiconic',
							),
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
						),
						array(
							'type'             => 'iconpicker',
							'heading'          => __( 'Icon', 'berserk' ),
							'param_name'       => 'icon_typicons',
							'value'            => 'typcn typcn-adjust-brightness',
							// default value to backend editor admin_label
							'settings'         => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'typicons',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'typicons',
							),
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
						),
						array(
							'type'             => 'iconpicker',
							'heading'          => __( 'Icon', 'berserk' ),
							'param_name'       => 'icon_entypo',
							'value'            => 'entypo-icon entypo-icon-note',
							// default value to backend editor admin_label
							'settings'         => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'entypo',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'entypo',
							),
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
						),
						array(
							'type'             => 'iconpicker',
							'heading'          => __( 'Icon', 'berserk' ),
							'param_name'       => 'icon_linecons',
							'value'            => 'vc_li vc_li-heart', // default value to backend editor admin_label
							'settings'         => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'linecons',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'linecons',
							),
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
						),
						array(
							'type'             => 'iconpicker',
							'heading'          => __( 'Icon', 'berserk' ),
							'param_name'       => 'icon_monosocial',
							'value'            => 'vc-mono vc-mono-fivehundredpx',
							// default value to backend editor admin_label
							'settings'         => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'monosocial',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'monosocial',
							),
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
						),
						/*
						array(
							"heading"    => __( "Add livicon", 'berserk' ),
							"param_name" => "brs_btn_icon",
							"type"       => "brs_btn_icon",
							'dependency' => array(
								'element' => 'btn_icon_type',
								'value'   => 'livicon',
							),
						)*/
						array(
							"type"             => "textarea_html",
							"holder"           => "div",
							"class"            => "",
							"param_name"       => "content",
							"value"            => __( "", 'berserk' ),
							"description"      => "",
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'livicon',
							),
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
						),

						// Additional CSS Class
						array(
							'type'             => 'textfield',
							'heading'          => esc_html__( 'Additional CSS Class', 'berserk' ),
							'group'            => esc_html__( 'Advanced', 'berserk' ),
							'param_name'       => 'css_class',
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__services_type info',
						),

					)
				) );
			}
		}

		public function shortcode_progress_circle( $atts, $content = null ) {

			brs_add_libraries( 'component__progress_circle' );

			extract( shortcode_atts( array(
				'progress_circle_type'        => 'minimal',
				'progress_circle_stroke_type' => 'default',
				'label'                       => 'Hard Work',
				'value'                       => '75',
				'custom_colors'               => '',
				'f_color'                     => '#2775ff',
				's_color'                     => '#2775ff',
				'btn_icon_type'               => 'fontawesome',
				'icon_monosocial'             => '',
				'icon_linecons'               => '',
				'icon_entypo'                 => '',
				'icon_typicons'               => '',
				'icon_openiconic'             => '',
				'icon_fontawesome'            => 'fa fa-trophy',
				'label_color'                 => '',
				'css_class'                   => '',

			), $atts ) );

			// store atts
			$atts_backup = self::$atts;

			vc_icon_element_fonts_enqueue( $btn_icon_type );

			$icon_class                     = array();
			$icon_class['type']             = $btn_icon_type;
			$icon_class['icon_livicon']     = '';
			$icon_class['icon_fontawesome'] = $icon_fontawesome;
			$icon_class['icon_openiconic']  = $icon_openiconic;
			$icon_class['icon_typicons']    = $icon_typicons;
			$icon_class['icon_entypo']      = $icon_entypo;
			$icon_class['icon_linecons']    = $icon_linecons;
			$icon_class['icon_monosocial']  = $icon_monosocial;
			$icon_class                     = $this->get_icon_class( $icon_class );
			$icon_html                      = ' <i class="' . $icon_class . '" aria-hidden="true"></i>';
			$label_class                    = '';
			if ( $label_color ) {
				$label_class = ' ' . $label_color;
			}

			if ( isset( $content ) && $btn_icon_type == 'livicon' ) {

				$svg_icon  = do_shortcode( $content );
				$icon_html = $svg_icon;
			}

			$class = array(
				'chart__wrapper',
				'align-items-center',
				'flex-row',
			);
			if( $css_class ) {
				$css_class = explode( ' ', $css_class );
				$class = array_merge( $class, $css_class );
			}

			switch ( $progress_circle_type ) {
				case "minimal":

					$class[] = 'chart-minimal';
					$class[] = 'text-center';
					$class = implode( ' ', $class );

					$output = '<div class="' . esc_attr( $class ) . '">
				                <div class="chart mx-auto">
				                  <div class="chart__circle" data-valuenow="' . esc_attr( $value ) . '" data-color="' . esc_attr( $f_color ) . '" data-color-end="' . esc_attr( $s_color ) . '">
				                    <span class="font__family-montserrat font__size-21 chart__circle-counter"><span class="percents">0</span>%</span>
				                    <h5 class="font__family-montserrat font__size-16 font__weight-bold chart__title' . esc_attr($label_class) . '">' . esc_html( $label ) . '</h5>
				                  </div>
				                </div>
				              </div>';

					break;

				case "light":

					$class[] = 'chart-light';
					$class = implode( ' ', $class );

					$output = '<div class="' . esc_attr( $class ) . '">
				                <div class="chart mx-auto">
				                  <div class="chart__circle mb-35" data-valuenow="' . esc_attr( $value ) . '" data-color="' . esc_attr( $f_color ) . '" data-color-end="' . esc_attr( $s_color ) . '">
				                    <span class="font__family-montserrat font__size-26 chart__circle-counter"><span class="percents">0</span>%</span>
				                  </div>
				                  <h5 class="font__family-montserrat font__size-16 font__weight-bold chart__title' . esc_attr($label_class) . '">' . esc_html( $label ) . '</h5>
				                </div>
				              </div>';

					break;

				case "triangled":

					$class[] = 'chart-triangled';
					$class = implode( ' ', $class );

					$output = '<div class="' . esc_attr( $class ) . '">
				                <div class="chart mx-auto">
				                  <div class="chart__circle mb-20" data-valuenow="' . esc_attr( $value ) . '" data-color="' . esc_attr( $f_color ) . '" data-color-end="' . esc_attr( $s_color ) . '">
				                    <span class="font__family-montserrat font__size-38 font__weight-light chart__circle-counter"><span class="percents">0</span>%</span>
				                  </div>
				                  <h5 class="font__family-montserrat font__size-16 font__weight-light chart__title' . esc_attr($label_class) . '">' . esc_html( $label ) . '</h5>
				                </div>
				              </div>';
					break;

				case "vertical":

					$class[] = 'chart-vertical';
					$class = implode( ' ', $class );

					$output = '<div class="' . esc_attr( $class ) . '">
				                <div class="chart mx-auto">
				                  <div class="chart__circle mb-25" data-valuenow="' . esc_attr( $value ) . '" data-color="' . esc_attr( $f_color ) . '" data-color-end="' . esc_attr( $s_color ) . '">
				                    <span class="chart__circle-counter chart__circle-counter-over"><span class="percents">0</span>%</span>
				                    <div class="gradient">
				                      <div class="gradient-bg"></div>
				                      <span class="font__family-montserrat font__size-42 font__weight-thin chart__circle-counter"><span class="percents">0</span>%</span>
				                    </div>
				                  </div>
				                  <h5 class="font__family-montserrat font__size-16 font__weight-light chart__title text-center' . esc_attr($label_class) . '">' . esc_html( $label ) . '</h5>
				                </div>
				              </div>';

					break;
				case "two_circles":

					$class[] = 'chart-2circles';
					$class = implode( ' ', $class );

					$output = '<div class="' . esc_attr( $class ) . '">
				                <div class="chart mx-auto">
				                  <div class="chart__circle mb-35" data-valuenow="' . esc_attr( $value ) . '" data-color="' . esc_attr( $f_color ) . '" data-color-end="' . esc_attr( $s_color ) . '">
				                    <span class="font__family-montserrat font__size-14 font__weight-bold chart__circle-counter"><span class="percents">0</span>%</span>
				                    <span class="icon icon__centered">' . $icon_html . '</span>
				                  </div>
				                  <h5 class="font__family-montserrat font__size-16 font__weight-bold chart__title text-center' . esc_attr($label_class) . '">' . esc_html( $label ) . '</h5>
				                </div>
				              </div>';

					break;
				case "icon":

					$class[] = 'chart-icon';
					if ( $progress_circle_stroke_type == 'light' ) {
						$class[] = 'chart__wrapper_light';
					}
					$class = implode( ' ', $class );

					if ( $custom_colors != 'true' ) {
						$f_color = 'var(--brand-primary)';
						$s_color = 'var(--brk-base-2)';
					}

					$output = '<div class="' . esc_attr( $class ) . '">
				                <div class="chart mx-auto">
				                  <div class="chart__circle mb-20" data-valuenow="' . esc_attr( $value ) . '" data-color="' . esc_attr( $f_color ) . '" data-color-end="' . esc_attr( $s_color ) . '">
				                    <span class="icon icon__centered">' . $icon_html . '</span>
				                  </div>
				                  <h5 class="font__family-montserrat font__size-16 chart__title text-center' . esc_attr($label_class) . '">' . esc_html( $label ) . '</h5>
				                </div>
				              </div>';

					break;
			}


			// restore atts
			self::$atts = $atts_backup;

			return $output;
		}

		protected function get_icon_class( $atts ) {
			$icon_class = '';

			$icon_class = $atts[ 'icon_' . $atts['type'] ];

			if ( empty( $icon_class ) ) {
				$icon_class = 'fa fa-trophy';
			}

			return $icon_class;
		}


	}

	// create shortcode
	BRS_Progress_Circle::get_instance();

}
