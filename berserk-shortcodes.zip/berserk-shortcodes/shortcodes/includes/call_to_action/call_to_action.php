<?php
/**
 * Call to action shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_CallToAction', false ) ) {

	class BRS_CallToAction extends BRS_Shortcode {

		static protected $instance;

		protected $shortcode_name = 'brs_call_to_action';
		protected $atts = array();

		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_CallToAction();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( $this->shortcode_name, array( $this, 'shortcode' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {
				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Call to Action", 'berserk' ),
					"base"     => "brs_call_to_action",
					"icon"     => "brs_vc_ico_call_to_action",
					"class"    => "brs_vc_call_to_action",
					"category" => __( 'Berserk', 'berserk' ),
					"params"   => array(

						array(
							"heading"          => __( "Call to Action types", 'berserk' ),
							"param_name"       => "brs_title_type",
							"type"             => "brs_title",
							'edit_field_class' => 'vc_col-xs-12 vc_column'
						),
						array(
							'heading'          => __( '', 'berserk' ),
							'param_name'       => 'call_to_action_type',
							'type'             => 'brs_radio',
							'value'            => array(
								"Container" => "container",
								"Minimal"   => "minimal",
								"Hot"       => "hot",
								"Outer"     => "outer",
								"Email"     => "email",
								"Trend"     => "trend",
								"Video"     => "video",
								"Image"     => "image",
								"Icon"      => "icon"
							),
							'images'           => array(
								"container" => 'call_to_action/cta_container.png',
								"minimal"   => 'call_to_action/cta_minimal.png',
								"hot"       => 'call_to_action/cta_hot.png',
								"outer"     => 'call_to_action/cta_outer.png',
								"email"     => 'call_to_action/cta_email.png',
								"trend"     => 'call_to_action/cta_trend.png',
								"video"     => 'call_to_action/cta_video.png',
								"image"     => 'call_to_action/cta_image.png',
								"icon"      => 'call_to_action/cta_icon.png'
							),
							'images_dim'       => array(
								'w' => '320',
								'h' => '100'
							),
							'edit_field_class' => 'vc_col-xs-12 vc_column'
						),
						array(
							"heading"    => __( "Heading Options", 'berserk' ),
							"param_name" => "brs_title",
							"type"       => "brs_title",
						),
						array(
							'type'             => 'textfield',
							'heading'          => __( 'Title', 'js_composer' ),
							'value'            => 'CFA Heading',
							'param_name'       => 'cta_title',
							"edit_field_class" => "vc_col-sm-6 vc_column",
						),
						array(
							'type'             => 'textfield',
							'heading'          => esc_attr__( 'Hot Panel Caption', 'berserk' ),
							'value'            => 'HOT!',
							'param_name'       => 'cta_hot',
							"edit_field_class" => "vc_col-sm-3 vc_column",
						),
						array(
							'type'             => 'checkbox',
							'heading'          => esc_attr__( 'Hot Panel Primary Color', 'berserk' ),
							'value'            => array(
								'Use Primary Color' => 'true',
							),
							'param_name'       => 'cta_hot_color',
							"edit_field_class" => "vc_col-sm-3 vc_column brk-dependency__call_to_action_type hot",
						),
						array(
							'heading'          => __( 'Use multiple title', 'berserk' ),
							'param_name'       => 'multiple_title',
							'type'             => 'brs_switch',
							'value'            => 'n',
							'options'          => array(
								'Yes' => 'y',
								'No'  => 'n',
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column'
						),
						array(
							'type'       => 'param_group',
							'heading'    => __( 'Values', 'js_composer' ),
							'param_name' => 'values',
							'value'      => urlencode( json_encode( array(
								array(
									'label'             => __( 'Call for action', 'js_composer' ),
									//'label_google_font' => 'font_family:Montserrat%3Aregular%2C700|font_style:700%20bold%20regular%3A700%3Anormal',
									'font_size'         => '25',
									'brs_font'          => 'montserrat',
									'brs_font_weight'   => 'normal',
									'font_style_italic' => 'n',
									//'enable_font'       => 'n'

								),
								array(
									'label'             => __( 'Block heading title goes here', 'js_composer' ),
									//'label_google_font' => 'font_family:Montserrat%3Aregular%2C700|font_style:400%20regular%3A400%3Anormal',
									'font_size'         => '25',
									'brs_font'          => 'montserrat',
									'brs_font_weight'   => 'normal',
									'font_style_italic' => 'n',
									//'enable_font'       => 'n'

								)
							) ) ),
							'params'     => array(
								array(
									'type'        => 'textfield',
									'heading'     => __( 'Label', 'js_composer' ),
									'param_name'  => 'label',
									'admin_label' => true,
								),

								array(
									"heading"    => __( "Fonts", 'berserk' ),
									"param_name" => "brs_title",
									"type"       => "brs_title",
								),

								array(
									'type'             => 'dropdown',
									'heading'          => __( 'Font', 'berserk' ),
									'value'            => array(
										__( 'Open Sans', 'berserk' )             => 'open-sans',
										__( 'Montserrat', 'berserk' )            => 'montserrat',
										__( 'Montserrat Alternates', 'berserk' ) => 'montserrat-alt',
										__( 'Playfair Display', 'berserk' )      => 'playfair',
										__( 'Poppins', 'berserk' )               => 'poppins',
										__( 'Pacifico', 'berserk' )              => 'pacifico',
										__( 'Roboto', 'berserk' )                => 'roboto',
										__( 'Roboto Slab', 'berserk' )           => 'roboto-slab',
										__( 'Oxygen', 'berserk' )                => 'oxygen',
										__( 'Times New Roman', 'berserk' )       => 'times-new-roman',
									),
									'param_name'       => 'brs_font',
									'edit_field_class' => 'vc_col-sm-6 vc_column',
									"std"              => "montserrat",
								),

								array(
									'type'             => 'dropdown',
									'heading'          => __( 'Font weight', 'berserk' ),
									'value'            => array(
										__( 'Normal', 'berserk' )     => 'normal',
										__( 'Light', 'berserk' )      => 'light',
										__( 'Ultralight', 'berserk' ) => 'ultralight',
										__( 'Bold', 'berserk' )       => 'bold'
									),
									'param_name'       => 'brs_font_weight',
									'edit_field_class' => 'vc_col-sm-6 vc_column',

								),

								array(
									"param_name"       => "font_style_italic",
									"type"             => "checkbox",
									"value"            => array(
										"Font style italic" => "y",
									),
									'admin_label'      => true,
									'edit_field_class' => 'vc_col-sm-6 vc_column',
								),

								array(
									'heading'          => __( 'Font Size', 'js_composer' ),
									"param_name"       => "font_size",
									"type"             => "dropdown",
									"value"            => BRS_Shortcodes_VCParams::get_font_size(),
									'admin_label'      => true,
									'edit_field_class' => 'vc_col-sm-6 vc_column',

								),
								array(
									'type'        => 'colorpicker',
									'heading'     => __( 'Color', 'js_composer' ),
									'param_name'  => 'title_color',
									'value'       => '#292B2C',
									'admin_label' => true,

								),

							),
							'dependency' => array(
								'element' => 'multiple_title',
								'value'   => 'y',
							),
						),

						array(
							"type"             => "textfield",
							"heading"          => __( "Link URL", 'berserk' ),
							"param_name"       => "cta_link_url",
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							"value"            => "#"
						),

						array(
							"type"             => "textfield",
							"heading"          => __( "Link Title", 'berserk' ),
							"param_name"       => "cta_link_title",
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							"value"            => "Read More"
						),
						array(
							"type"             => "textfield",
							"heading"          => __( "Hover Link Title", 'berserk' ),
							"param_name"       => "cta_hover_link_title",
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__call_to_action_type hot container',
							"value"            => "Read More"
						),

						array(
							"param_name"       => "hide_button",
							"type"             => "checkbox",
							"value"            => array(
								"Hide Button" => "y",
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

						array(
							'heading'          => __( 'Title Font Size', 'js_composer' ),
							"param_name"       => "cta_font_size",
							"type"             => "dropdown",
							"value"            => BRS_Shortcodes_VCParams::get_font_size(),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

						array(
							'heading'          => __( 'Button CSS Class', 'berserk' ),
							'param_name'       => 'button_class',
							'type'             => 'textfield',
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__call_to_action_type icon',
						),

						array(
							'param_name'       => 'square_button',
							'type'             => 'checkbox',
							'value'            => array(
								esc_attr__( 'Square button', 'berserk') => 'true',
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__call_to_action_type icon',
						),

						array(
							'heading'          => __( 'Padding Top&Bottom', 'js_composer' ),
							"param_name"       => "padding_top_bottom",
							"type"             => "dropdown",
							"value"            => array(
								'10px'  => '10',
								'15px'  => '15',
								'20px'  => '20',
								'25px'  => '25',
								'30px'  => '30',
								'35px'  => '35',
								'40px'  => '40',
								'45px'  => '45',
								'50px'  => '50',
								'60px'  => '60',
								'70px'  => '70',
								'80px'  => '80',
								'90px'  => '90',
								'100px' => '100',
								'150px' => '150',
							),
							'edit_field_class' => 'vc_col-sm-3 vc_column brk-dependency__call_to_action_type hot image',
						),

						array(
							'heading'          => esc_html__( 'Padding Left&Right', 'berserk' ),
							'param_name'       => 'padding_left_right',
							'type'             => 'dropdown',
							'value'            => array(
								'10px'  => '10',
								'15px'  => '15',
								'20px'  => '20',
								'25px'  => '25',
								'30px'  => '30',
								'35px'  => '35',
								'40px'  => '40',
								'45px'  => '45',
								'50px'  => '50',
								'60px'  => '60',
								'70px'  => '70',
								'80px'  => '80',
								'90px'  => '90',
								'100px' => '100',
								'150px' => '150',
							),
							'std'              => '40px',
							'edit_field_class' => 'vc_col-sm-3 vc_column brk-dependency__call_to_action_type image',
						),

						array(
							"heading"    => __( "Description", 'berserk' ),
							"param_name" => "brs_title",
							"type"       => "brs_title",
						),
						array(
							'type'             => 'textfield',
							'heading'          => __( 'Description', 'js_composer' ),
							'value'            => 'Some description goes here',
							'param_name'       => 'cta_description',
							"edit_field_class" => "vc_col-sm-6 vc_column",
						),
						array(
							"heading"    => __( "Background Image", 'berserk' ),
							"param_name" => "brs_title",
							"type"       => "brs_title",
						),
						array(
							'type'        => 'attach_image',
							'heading'     => __( 'Background Image', 'js_composer' ),
							'param_name'  => 'cta_bg_image',
							'value'       => '',
							'description' => __( 'Select image from media library.', 'js_composer' ),
						),
						array(
							"param_name"       => "with_fixed_bg",
							"type"             => "checkbox",
							"value"            => array(
								"With fixed Background" => "y",
							),
							'edit_field_class' => 'vc_col-sm-12 vc_column',
						),
						array(
							'param_name'       => 'border_radius',
							'type'             => 'dropdown',
							'heading'          => esc_html__( 'Border Radius', 'berserk' ),
							'value'            => BRS_Shortcodes_VCParams::get_border_radius(),
							'std'              => 'none',
							'admin_label'      => false,
							'edit_field_class' => 'vc_col-sm-3 vc_column brk-dependency__call_to_action_type container minimal outer',
						),
						array(
							'param_name'       => 'bottom_shadow',
							'type'             => 'dropdown',
							'heading'          => esc_html__( 'Bottom Shadow', 'berserk' ),
							'value'            => array(
								esc_attr__( 'None', 'berserk' )     => 'none',
								esc_attr__( 'Dark', 'berserk' )     => 'dark-shadow',
								esc_attr__( 'Colored', 'berserk' )  => 'violet-shadow',
							),
							'std'              => 'none',
							'admin_label'      => false,
							'edit_field_class' => 'vc_col-sm-3 vc_column brk-dependency__call_to_action_type container minimal outer',
						),
						array(
							'param_name'       => 'custom_class',
							'type'             => 'textfield',
							'heading'          => esc_html__( 'Custom css class', 'berserk' ),
							'admin_label'      => false,
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),
						array(
							"heading"    => __( "Video", 'berserk' ),
							"param_name" => "brs_title",
							"type"       => "brs_title",
						),
						array(
							'type'       => 'textfield',
							'heading'    => __( 'YouTube link', 'js_composer' ),
							'param_name' => 'cta_video',
							'value'      => 'https://www.youtube.com/embed/6v2L2UGZJAM'
						),
						array(
							"heading"    => __( "Icon", 'berserk' ),
							"param_name" => "brs_title",
							"type"       => "brs_title",
						),

						array(
							'type'             => 'dropdown',
							'heading'          => __( 'Icon library', 'berserk' ),
							'value'            => array(
								__( 'Font Awesome', 'berserk' ) => 'fontawesome',
								__( 'Open Iconic', 'berserk' )  => 'openiconic',
								__( 'Typicons', 'berserk' )     => 'typicons',
								__( 'Entypo', 'berserk' )       => 'entypo',
								__( 'Linecons', 'berserk' )     => 'linecons',
								__( 'Mono Social', 'berserk' )  => 'monosocial',
							),
							"std"              => "fontawesome",
							'admin_label'      => true,
							'param_name'       => 'type',
							'description'      => __( 'Select icon library.', 'berserk' ),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),
						array(
							'type'       => 'iconpicker',
							'heading'    => __( 'Icon', 'berserk' ),
							'param_name' => 'icon_fontawesome',
							'value'      => 'fa fa-trophy', // default value to backend editor admin_label
							'settings'   => array(
								'emptyIcon'    => false,
								// default true, display an "EMPTY" icon?
								'iconsPerPage' => 100,
								// default 100, how many icons per/page to display, we use (big number) to display all icons in single page
							),

							'dependency'  => array(
								'element' => 'type',
								'value'   => 'fontawesome',
							),
							'description' => __( 'Select icon from library.', 'berserk' ),
						),
						array(
							'type'        => 'iconpicker',
							'heading'     => __( 'Icon', 'berserk' ),
							'param_name'  => 'icon_openiconic',
							'value'       => 'vc-oi vc-oi-dial', // default value to backend editor admin_label
							'settings'    => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'openiconic',
								'iconsPerPage' => 100, // default 100, how many icons per/page to display
							),
							'dependency'  => array(
								'element' => 'type',
								'value'   => 'openiconic',
							),
							'description' => __( 'Select icon from library.', 'berserk' ),
						),
						array(
							'type'        => 'iconpicker',
							'heading'     => __( 'Icon', 'berserk' ),
							'param_name'  => 'icon_typicons',
							'value'       => 'typcn typcn-adjust-brightness',
							// default value to backend editor admin_label
							'settings'    => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'typicons',
								'iconsPerPage' => 100, // default 100, how many icons per/page to display
							),
							'dependency'  => array(
								'element' => 'type',
								'value'   => 'typicons',
							),
							'description' => __( 'Select icon from library.', 'berserk' ),
						),
						array(
							'type'       => 'iconpicker',
							'heading'    => __( 'Icon', 'berserk' ),
							'param_name' => 'icon_entypo',
							'value'      => 'entypo-icon entypo-icon-note',
							// default value to backend editor admin_label
							'settings'   => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'entypo',
								'iconsPerPage' => 100, // default 100, how many icons per/page to display
							),
							'dependency' => array(
								'element' => 'type',
								'value'   => 'entypo',
							),
						),
						array(
							'type'        => 'iconpicker',
							'heading'     => __( 'Icon', 'berserk' ),
							'param_name'  => 'icon_linecons',
							'value'       => 'vc_li vc_li-heart', // default value to backend editor admin_label
							'settings'    => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'linecons',
								'iconsPerPage' => 100, // default 100, how many icons per/page to display
							),
							'dependency'  => array(
								'element' => 'type',
								'value'   => 'linecons',
							),
							'description' => __( 'Select icon from library.', 'berserk' ),
						),
						array(
							'type'        => 'iconpicker',
							'heading'     => __( 'Icon', 'berserk' ),
							'param_name'  => 'icon_monosocial',
							'value'       => 'vc-mono vc-mono-fivehundredpx',
							// default value to backend editor admin_label
							'settings'    => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'monosocial',
								'iconsPerPage' => 100, // default 100, how many icons per/page to display
							),
							'dependency'  => array(
								'element' => 'type',
								'value'   => 'monosocial',
							),
							'description' => __( 'Select icon from library.', 'berserk' ),
						),
					)
				) );
			}
		}

		public function shortcode( $atts, $content = null ) {

			brs_add_libraries( 'component__call_to_action' );

			extract( shortcode_atts( array(
				'call_to_action_type'   => 'container',
				'cta_title'             => 'CFA Heading',
				'cta_hot'               => 'HOT!',
				'cta_hot_color'         => '',
				'cta_description'       => 'Some description goes here',
				'cta_link_url'          => '#',
				'cta_link_title'        => 'Read More',
				'cta_hover_link_title'  => 'Click Me',
				'cta_font_size'         => '',
				'cta_bg_image'          => '',
				'hide_button'           => 'n',
				'border_radius'         => 'none',
				'bottom_shadow'         => 'none',
				'with_fixed_bg'         => 'n',
				'multiple_title'        => '',
				'values'                => '',
				'cta_video'             => 'https://www.youtube.com/embed/6v2L2UGZJAM',
				'type'                  => 'fontawesome',
				'icon_monosocial'       => '',
				'icon_linecons'         => '',
				'icon_entypo'           => '',
				'icon_typicons'         => '',
				'icon_openiconic'       => '',
				'icon_fontawesome'      => 'fa fa-trophy',
				'padding_top_bottom'    => '30',
				'padding_left_right'    => '40',
				'square_button'         => '',
				'button_class'          => '',
				'custom_class'          => '',

			), $atts ) );

			$output = '';
			vc_icon_element_fonts_enqueue( 'fontawesome' );
			vc_icon_element_fonts_enqueue( $type );

			$cta_bg_image = wp_get_attachment_image_src( $cta_bg_image, 'full' );
			$cta_bg_image = $cta_bg_image[0];

			$cta_title_style = 'font-size:' . $cta_font_size . 'px;';
			$cta_title_size  = 'font__size-' . $cta_font_size;

			$custom_class_arr = explode( ' ', $custom_class );

			switch ( $call_to_action_type ) {

				case "container":

					$wrap_class = array(
						'cfa__wrapper',
						'cfa__container',
						'bg__style',
						'overlay__gradient',
						'all-light',
					);
					if( $border_radius != 'none' ) {
						$wrap_class[] = 'border-radius-' . $border_radius;
					}
					if( $bottom_shadow != 'none' ) {
						$wrap_class[] = $bottom_shadow;
					}
					$wrap_class = array_merge( $wrap_class, $custom_class_arr );
					$wrap_class = implode(' ', $wrap_class );

					$output	= '<div class="' . esc_attr( $wrap_class ) . '" style="background-image: url(' . esc_url( $cta_bg_image ) . ');">
								<h4 style="' . esc_attr( $cta_title_style ) . '" class="font__family-montserrat font__size-21 font__weight-bold no-wrap">' . esc_html( $cta_title ) . '</h4>
									<p class="font__family-open-sans font__size-14 brk-white-font-color opacity-70 text-center text-lg-left">' . $cta_description . '</p>';

						if ( isset( $hide_button ) && $hide_button != 'y' ) {
							$output .= '<a href="' . esc_url( $cta_link_url ) . '" class="btn btn-inside-out btn-lg border-radius-25 btn-min-width-200 font__weight-bold btn-inside-out-invert">
									<span class="before">' . esc_html( $cta_link_title ) . '</span>
									<span class="text">' . esc_html( $cta_hover_link_title ) . '</span>
									<span class="after">' . esc_html( $cta_link_title ) . '</span>
								</a>';
						}
					$output .= '<span class="overlay_after"></span>
							</div>';
					break;

				case "minimal":

					$wrap_class = array(
						'cfa__wrapper',
						'cfa__minimal',
						'bg__style',
						'overlay__white',
						'atext-center',
						'text-lg-left',
					);
					if( $border_radius != 'none' ) {
						$wrap_class[] = 'border-radius-' . $border_radius;
					}
					if( $bottom_shadow != 'none' ) {
						$wrap_class[] = $bottom_shadow;
					}
					$wrap_class = array_merge( $wrap_class, $custom_class_arr );
					$wrap_class = implode(' ', $wrap_class );

					$output	= '<div class="' . esc_attr( $wrap_class ) . '" style="background-image: url(' . esc_url( $cta_bg_image ) . ');">
								  <h4 style="' . esc_attr( $cta_title_style ) . '" class="font__family-montserrat font__size-21 font__weight-bold no-wrap">' . esc_html( $cta_title ) . '</h4>
									<p class="font__family-open-sans font__size-14 text-dark text-center text-lg-left">' . $cta_description . '</p>';
					if ( isset( $hide_button ) && $hide_button != 'y' ) {
						$output .= '<a href="' . esc_url( $cta_link_url ) . '" class="btn btn-lg border-radius-25 font__family-open-sans font__weight-bold btn-inside-out btn-min-width-200 btn-inside-out-invert">
									<span class="before">' . $cta_link_title . '</span>
									<span class="text">' . $cta_link_title . '</span>
									<span class="after">' . $cta_link_title . '</span>
								  </a>';
					}
					$output .= '</div>';
					break;

				case "hot":

					$title = $cta_title;

					if ( $multiple_title == 'y' ) {
						$title_values = vc_param_group_parse_atts( $values );

						$title = '';

						foreach ( $title_values as $value ) {
							$classes   = array();
							$classes[] = 'font__family-' . $value['brs_font'];
							if ( $value['brs_font_weight'] != 'normal' ) {
								$classes[] = 'font__weight-' . $value['brs_font_weight'];
							}
							if ( isset( $value['font_style_italic'] ) && $value['font_style_italic'] == 'y' ) {
								$classes[] = 'font__style-italic';
							}
							if ( $value['font_size'] ) {
								$classes[] = 'font__size-' . $value['font_size'];
							}
							// ion 1 get_font_size

							$classes = implode( ' ', $classes );

							$style = '';
							//$style .= 'font-size:' . $value['font_size'] . 'px;';
							$style .= 'color:' . $value['title_color'] . ';';
							$title .= ' <span class="' . esc_attr( $classes ) . '" style="' . $style . '">' . $value['label'] . '</span> ';

						}
					}

					$wrap_class = array(
						'cfa__wrapper',
						'cfa__hot',
						'all-light',
						'pl-20',
						'pr-20'
					);
					if ( isset( $padding_top_bottom ) ) {
						$wrap_class[] = 'pt-' . $padding_top_bottom;
						$wrap_class[] = 'pb-' . $padding_top_bottom;
					}

					$wrap_class = array_merge( $wrap_class, $custom_class_arr );
					$wrap_class = implode(' ', $wrap_class );

					$hot_panel_class = 'hot-panel';
					if ( $cta_hot_color ) {
						$hot_panel_class .= ' hot-panel_primary';
					}

					if ( isset( $with_fixed_bg ) && $with_fixed_bg == 'y' ) {
						$output = '<div class="bg__style overlay__gradient all-light" style="background-image: url(' . esc_url( $cta_bg_image ) . ');">
										<div class="container">
											<div class="' . esc_attr( $wrap_class ) . '">
												<div><span class="font__family-open-sans font__size-13 font__weight-bold ' . esc_attr( $hot_panel_class ) . '">' . $cta_hot . '</span></div>
												<h4 class="font__family-montserrat font__size-25 font__weight-bold text-uppercase">' . $title . '</h4>';
						if ( isset( $hide_button ) && $hide_button != 'y' ) {
							$output .= '<a href="' . esc_url( $cta_link_url ) . '" class="btn btn-inside-out btn-lg btn-inside-out-invert border-radius-25 font__family-open-sans font__weight-bold btn-min-width-200 brk-library-rendered"><span class="before">' . $cta_link_title . '</span><span class="text">' . $cta_hover_link_title . '</span><span class="after">' . $cta_link_title . '</span></a>';
						}
						$output .= '</div>
										</div>
										<span class="overlay_after brk-base-bg-gradient-14 opacity-90"></span>
									</div>';

					} else {

						$output = '<div class="' . esc_attr( $wrap_class ) . '">
								<div><span class="font__family-open-sans font__size-13 font__weight-bold ' . esc_attr( $hot_panel_class ) . '">' . $cta_hot . '</span></div>
								<h4 style="' . $cta_title_style . '" class="font__family-montserrat font__weight-bold text-uppercase">' . $title . '</h4>';
						if ( isset( $hide_button ) && $hide_button != 'y' ) {
							$output .= '<a href="' . esc_url( $cta_link_url ) . '" class="btn btn-inside-out btn-lg btn-inside-out-invert border-radius-25 font__family-open-sans font__weight-bold btn-min-width-200 brk-library-rendered"><span class="before">' . $cta_link_title . '</span><span class="text">' . $cta_hover_link_title . '</span><span class="after">' . $cta_link_title . '</span></a>';
						}
						$output .= '</div>';


					}

					break;

				case "outer":

					$wrap_class = array(
						'cfa__wrapper',
						'cfa__outer',
						'text-center',
					);
					if( $border_radius != 'none' ) {
						$wrap_class[] = 'border-radius-' . $border_radius;
					}
					if( $bottom_shadow != 'none' ) {
						$wrap_class[] = $bottom_shadow;
					}
					$wrap_class = array_merge( $wrap_class, $custom_class_arr );
					$wrap_class = implode(' ', $wrap_class );

					$output = '<div class="' . esc_attr( $wrap_class ) . '">
								  <h4 style="' . $cta_title_style . ' background-image: url(' . esc_url( $cta_bg_image ) . ');" class="font__family-montserrat font__weight-light cfa__heading text-uppercase bg__style overlay__gradient letter-spacing-20 all-light violet">' . $cta_title . '
								  <span class="overlay_after" style="background: linear-gradient(to right, #1158DF, #7401BA); opacity: 0.94;"></span></h4>
								  <p class="font__family-open-sans font__size-14 font__weight-light text-gray">' . $cta_description . '</p>
								  <a href="' . esc_url( $cta_link_url ) . '" class="btn btn-lg border-radius-25 font__family-open-sans font__weight-bold btn-inside-out">
									<span class="before">' . $cta_link_title . '</span>
									<span class="text">' . $cta_link_title . '</span>
									<span class="after">' . $cta_link_title . '</span>
								  </a>
								</div>';
					break;

				case "email":

					$wrap_class = array(
						'cfa__wrapper',
						'cfa__email',
						'pb-70',
						'pt-70',
						'maxw-770',
						'all-light'
					);
					$wrap_class = array_merge( $wrap_class, $custom_class_arr );
					$wrap_class = implode(' ', $wrap_class );

					$output = '<div class="' . esc_attr( $wrap_class ) . '">
								<h4 style="' . $cta_title_style . '" class="font__family-montserrat font__weight-bold text-uppercase">' . $cta_title . '</h4>
								<p class="font__family-open-sans font__size-14 font__weight-light text-gray">' . $cta_description . '</p>
								<form class="subscr__form cfa_subscr__form">
								  <input autocomplete="off" required type="email" name="email" id="email" class="form-control" placeholder="Your mail">
								  <div><button type="submit" class="btn-subscr fa fa-send"></button></div>
								  <div class="cfa_form_responce" style="display: none;"><ul></ul></div>
								</form>
							  </div>';

					break;

				case "trend":

					$title = $cta_title;

					if ( $multiple_title == 'y' ) {
						$title_values = vc_param_group_parse_atts( $values );

						$title = '';

						foreach ( $title_values as $value ) {

							$classes   = array();
							$classes[] = 'font__family-' . $value['brs_font'];
							if ( $value['brs_font_weight'] != 'normal' ) {
								$classes[] = 'font__weight-' . $value['brs_font_weight'];
							}
							if ( isset( $value['font_style_italic'] ) && $value['font_style_italic'] == 'y' ) {
								$classes[] = 'font__style-italic';
							}

							$classes = implode( ' ', $classes );
							$style   = '';
							$style .= 'font-size:' . $value['font_size'] . 'px;';
							$style .= 'color:' . $value['title_color'] . ';';

							$title .= ' <span class="' . $classes . '" style="' . $style . '">' . $value['label'] . '</span> ';

						}
					}

					$wrap_class = array(
						'cfa__wrapper',
						'cfa__trend',
						'indent__1',
						'text-left',
					);
					$wrap_class = array_merge( $wrap_class, $custom_class_arr );
					$wrap_class = implode(' ', $wrap_class );

					$output = '<div class="' . esc_attr( $wrap_class ) . '">
								  <span class="grad-border"></span>
								  <div class="maxw-770">
									<h2 style="' . $cta_title_style . '" class="font__family-montserrat-alt font__weight-bold line__height-40 text-uppercase">' . $title . '</h2>
									<div class="divider-layers"><span class="before"></span></div>
									<p class="font__size-16 font__family-oxygen font__weight-light line__height-26 text-dark">' . $cta_description . '</p>
									<a href="' . esc_url( $cta_link_url ) . '" class="icon-go fa fa-long-arrow-right"></a>
								  </div>
								  <span style="background-image: url(' . esc_url( $cta_bg_image ) . ');" class="bg-after"></span>
								</div>';

					break;

				case "video":

					$overlay_image_style = '';
					if ( $cta_bg_image ) {
						$overlay_image_style = ' style="background-image: url(' . esc_url( $cta_bg_image ) . ')"';
					}
					$output = '<div class="container z-index-high">
								<div class="maxw-770">
								  <div class="embed-responsive embed-responsive-16by9 border-radius-30 video-wrap">
									<div class="overlay-image"' . wp_kses_post( $overlay_image_style ) . '>
									  <a href="#" class="icon__btn icon__btn-anim icon__btn-lg">
											<span class="before"></span>
												<i class="fa fa-play" aria-hidden="true"></i>
											<span class="after"></span>
									  </a>
									</div>
									<iframe id="yt-iframe" src="' . esc_url( $cta_video ) . '" allowfullscreen></iframe>
								  </div>
								</div>
							  </div>
							<div class="cfa__wrapper cfa__video bg__style overlay__gradient all-light" style="background-image: url(' . esc_url( $cta_bg_image ) . ');">
								<div class="container">
								  <div class="maxw-770">
									<h4 style="' . $cta_title_style . '" class="font__family-montserrat font__weight-bold text-uppercase border-left">' . $cta_title . '</h4>
									<a href="' . esc_url( $cta_link_url ) . '" class="btn btn-md border-radius-25 font__family-open-sans font__weight-bold btn-inside-out btn-inside-out-invert">
										<span class="before">' . $cta_link_title . '</span>
										<span class="text">' . $cta_link_title . '</span>
										<span class="after">' . $cta_link_title . '</span>
									</a>
								  </div>
								</div>
								<span class="overlay_after brk-base-bg-gradient-14 opacity-90"></span>
							  </div>';

					break;

				case "image":

					brs_add_libraries( 'component__button' );

					$title = $cta_title;

					if ( $multiple_title == 'y' ) {
						$title_values = vc_param_group_parse_atts( $values );

						$title = '';

						foreach ( $title_values as $value ) {
							$classes = array();

							$classes[] = 'font__family-' . $value['brs_font'];
							if ( $value['brs_font_weight'] != 'normal' ) {
								$classes[] = 'font__weight-' . $value['brs_font_weight'];
							}
							if ( isset( $value['font_style_italic'] ) && $value['font_style_italic'] == 'y' ) {
								$classes[] = 'font__style-italic';
							}

							$classes = implode( ' ', $classes );

							$style = '';
							if ( isset( $value['font_size'] ) ) {
								$style .= 'font-size:' . $value['font_size'] . 'px;';
							}
							$style .= 'color:' . $value['title_color'] . ';';
							$title .= '<span class="' . $classes . '" style="' . $style . '">' . $value['label'] . '</span> ';

						}
					}

					$wrap_class = array(
						'cfa__wrapper',
						'cfa__image',
						'bg__style',
						'overlay__gradient',
						'text-left',
					);
					$custom_class_arr = array(
						'pt-' . $padding_top_bottom,
						'pb-' . $padding_top_bottom,
						'pl-' . $padding_left_right,
						'pr-' . $padding_left_right,
					);

					$wrap_class = array_merge( $wrap_class, $custom_class_arr );
					$wrap_class = implode(' ', $wrap_class );

					$output = '<div class="' . esc_attr( $wrap_class ) . '" style="background-image: url(' . BERSERK_SHORTCODES_URL . '/shortcodes/images/bg-2.jpg);">
								<h2 class="font__family-montserrat font__weight-bold ' . $cta_title_size . '">' . $title . '</h2>
								<a href="' . esc_url( $cta_link_url ) . '" class="btn btn-gradient btn-lg border-radius-25 btn-min-width-200">
									<span>' . $cta_link_title . '</span>
								</a>
								<span class="bg-after bg__style" style="background-image: url(' . esc_url( $cta_bg_image ) . ');"></span>
								<span class="overlay_after brk-base-bg-gradient-14 opacity-90"></span>
							</div>';

					break;

				// Icon Type
				case "icon":

					$icon_class = $this->get_icon_class( $atts );

					$default_class = array(
						'btn',
						'btn-lg',
						'font__family-open-sans',
						'font__weight-bold',
						'btn-inside-out',
						'btn-inside-out-invert',
						'mt-50',
					);
					if ( $square_button == 'true' ) {
						$default_class[] = 'border-radius-0';
					} else {
						$default_class[] = 'border-radius-25';
					}

					if( $button_class ) {
						$button_class = explode( ' ', $button_class );
						$default_class = array_merge( $default_class, $button_class );
					}
					$button_class = implode( ' ', $default_class );

					$output = '<i class="main-icon ' . $icon_class . '"></i>';
					$output .= '<h3 class="font__family-montserrat font__weight-light brk-white-font-color opacity-60">' . $cta_description . '</h3>';
					$output .= '<h2 class="font__family-montserrat font__weight-bold">' . $cta_title . '</h2>';
					$output .= '<a href="' . esc_url( $cta_link_url ) . '" class="' . esc_attr( $button_class ) . '">';
					$output .= '<span class="before">' . $cta_link_title . '</span>';
					$output .= '<span class="text">' . $cta_link_title . '</span>';
					$output .= '<span class="after">' . $cta_link_title . '</span>';
					$output .= '</a>';

					break;

			}


			return $output;
		}

		protected function get_icon_class( $atts ) {
			$icon_class = '';

			if ( ! empty( $atts['icon_fontawesome'] ) ) {
				$icon_class = $atts['icon_fontawesome'];
			}
			if ( ! empty( $atts['icon_openiconic'] ) ) {
				$icon_class = $atts['icon_openiconic'];
			}
			if ( ! empty( $atts['icon_typicons'] ) ) {
				$icon_class = $atts['icon_typicons'];
			}
			if ( ! empty( $atts['icon_entypo'] ) ) {
				$icon_class = $atts['icon_entypo'];
			}
			if ( ! empty( $atts['icon_linecons'] ) ) {
				$icon_class = $atts['icon_linecons'];
			}
			if ( ! empty( $atts['icon_monosocial'] ) ) {
				$icon_class = $atts['icon_monosocial'];
			}

			if ( empty( $icon_class ) ) {
				$icon_class = 'fa fa-trophy';
			}

			return $icon_class;
		}

		public function get_font_style( $google_fonts ) {
			$style = '';
			if ( ! empty( $google_fonts ) ) {
				$fontsData         = $google_fonts;
				$googleFontsStyles = $this->googleFontsStyles( $fontsData );
				$font_family       = explode( ':', $googleFontsStyles[0] );
				$font_family_e     = explode( ' ', $font_family[1] );
				$font_family_count = count( $font_family_e );

				if ( $font_family_count > 1 ) {
					$googleFontsStyles[0] = 'font-family:"' . implode( " ", $font_family_e ) . '"';
				}

				$style = esc_attr( implode( ';', $googleFontsStyles ) );
			}

			return $style;
		}

		protected function googleFontsStyles( $fontsData ) {
			// Inline styles
			$fontFamily = BRS_Font::_vc_google_fonts_parse_attributes( '', $fontsData );
			$fontStyles = explode( ':', $fontFamily['values']['font_style'] );
			$fontFamily = explode( ':', $fontFamily['values']['font_family'] );
			$styles[]   = 'font-family:' . $fontFamily[0];
			$styles[]   = 'font-weight:' . $fontStyles[1];
			$styles[]   = 'font-style:' . $fontStyles[2];

			return $styles;
		}


	}

	// create shortcode
	BRS_CallToAction::get_instance();

}
