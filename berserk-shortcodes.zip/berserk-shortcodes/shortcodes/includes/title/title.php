<?php
/**
 * Shape Box shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Title', false ) ) {

	class BRS_Title extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Title();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_title', array( $this, 'shortcode_title' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				// Responsive Spacing
				$brk_vc_screen_sizes      = array( '', 'xl', 'lg', 'md', 'sm' );
				$brk_spacing_options      = array(
					'margin_top'     => esc_html__( 'Margin Top', 'berserk' ),
					'margin_bottom'  => esc_html__( 'Margin Bottom', 'berserk' ),
					'padding_top'    => esc_html__( 'Padding Top', 'berserk' ),
					'padding_bottom' => esc_html__( 'Padding Bottom', 'berserk' )
				);
				$responsive_spacing_group = esc_html__( 'Group Options', 'berserk' );
				$attributes_spacing       = array(
					array(
						'heading'          => esc_html__( 'Group Aligment', 'berserk' ),
						'param_name'       => 'brk_title_group_aligment',
						'group'            => $responsive_spacing_group,
						'type'             => 'brs_title',
						'edit_field_class' => 'brs_vc_row-param vc_col-xs-12 vc_column',
					),
					array(
						'type'             => 'dropdown',
						'heading'          => esc_html__( 'Group Text Align', 'berserk' ),
						'param_name'       => 'group_text_align',
						'group'            => $responsive_spacing_group,
						'admin_label'      => false,
						'edit_field_class' => 'vc_col-sm-3 vc_column',
						'value'            => array(
							esc_html__( 'None', 'berserk' )   => 'none',
							esc_html__( 'Left', 'berserk' )   => 'left',
							esc_html__( 'Right', 'berserk' )  => 'right',
							esc_html__( 'Center', 'berserk' ) => 'center',
						),
					),
					array(
						'type'             => 'checkbox',
						'heading'          => esc_html__( 'Heading Style', 'berserk' ),
						'param_name'       => 'group_style_left',
						'group'            => $responsive_spacing_group,
						'admin_label'      => false,
						'value'            => array(
							esc_html__( 'Heading Style Left', 'berserk' ) => 'true'
						),
						'edit_field_class' => 'brs_vc_row-param vc_col-xs-3 vc_column',
					),
					array(
						'type'             => 'textfield',
						'heading'          => esc_html__( 'Custom CSS Class', 'berserk' ),
						'param_name'       => 'group_custom_class',
						'group'            => $responsive_spacing_group,
						'admin_label'      => false,
						'edit_field_class' => 'brs_vc_row-param vc_col-xs-6 vc_column',
					),
					array(
						'heading'          => esc_html__( 'Group Responsive Spacing', 'berserk' ),
						'param_name'       => 'brk_title_group_aligment',
						'group'            => $responsive_spacing_group,
						'type'             => 'brs_title',
						'edit_field_class' => 'brs_vc_row-param vc_col-xs-12 vc_column',
					),
					array(
						'param_name'       => 'brk_group_adaptive_spacing',
						'group'            => $responsive_spacing_group,
						'type'             => 'brk_devices',
						'images'           => array(
							'devices' => 'devices.png',
							'screen'  => 'screen.png',
							'desktop' => 'desktop.png',
							'tablet'  => 'tablet.png',
							'mobile'  => 'mobile.png',
						),
						'images_dim'       => array(
							'w' => '76',
							'h' => '42'
						),
						'edit_field_class' => 'brs_vc_row-param brk-xs-3 brk-xs',
					)
				);

				foreach ( $brk_spacing_options as $option => $option_title ) {
					$attributes_spacing[] = array(
						'heading'          => $option_title,
						'group'            => $responsive_spacing_group,
						'param_name'       => 'group_title_' . $option,
						'type'             => 'brs_title',
						'edit_field_class' => 'brs_vc_row-param vc_col-xs-12 vc_column',
					);
					foreach ( $brk_vc_screen_sizes as $size ) {
						if ( $size ) {
							$size = '_' . $size;
						}
						${'group_responsive_' . $option} = array(
							'param_name'       => 'group_' . $option . $size,
							'group'            => $responsive_spacing_group,
							'type'             => 'dropdown',
							'value'            => BRS_Shortcodes_VCParams::get_margin_top(),
							'edit_field_class' => 'brs_vc_row-param vc_col-xs-3 vc_col-xs-five vc_column',
						);
						$attributes_spacing[]            = ${'group_responsive_' . $option};
					}

				}

				// Rpeater title params

				$params   = array();
				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Element Type', 'berserk' ),
					'value'            => array(
						'H1'      => 'h1',
						'H2'      => 'h2',
						'H3'      => 'h3',
						'H4'      => 'h4',
						'H5'      => 'h5',
						'H6'      => 'h6',
						'Span'    => 'span',
						'p'       => 'p',
						'divider' => 'divider',
					),
					'admin_label'      => true,
					'param_name'       => 'item_type',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Divider Type', 'berserk' ),
					'value'            => array(
						__( 'Default', 'berserk' ) => 'default',
						__( 'Line', 'berserk' )    => 'line',
						__( 'Dashed', 'berserk' )  => 'dashed',
						__( 'Cross', 'berserk' )   => 'cross',
						__( 'Layers', 'berserk' )  => 'layers',
						__( 'Lines', 'berserk' )   => 'lines',
						__( 'Dots', 'berserk' )    => 'dots',

					),
					"dependency"       => array(
						"element" => "item_type",
						"value"   => array( 'divider' ),
					),
					'param_name'       => 'divider_type',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Divider Align', 'berserk' ),
					'value'            => array(
						__( 'Default', 'berserk' ) => 'default',
						__( 'Left', 'berserk' )    => 'left',
						__( 'Right', 'berserk' )   => 'right',
					),
					"dependency"       => array(
						"element" => "item_type",
						"value"   => array( 'divider' ),
					),
					'param_name'       => 'divider_align',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
				);

				$params[] = array(
					'type'             => 'textfield',
					'heading'          => __( 'Label', 'js_composer' ),
					'param_name'       => 'label',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					'admin_label'      => true,
					"dependency"       => array(
						"element" => "item_type",
						"value"   => array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'span', 'p' ),
					),
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Font', 'berserk' ),
					'value'            => array(
						__( 'Open Sans', 'berserk' )             => 'open-sans',
						__( 'Montserrat', 'berserk' )            => 'montserrat',
						__( 'Montserrat Alternates', 'berserk' ) => 'montserrat-alt',
						__( 'Playfair Display', 'berserk' )      => 'playfair',
						__( 'Poppins', 'berserk' )               => 'poppins',
						__( 'Pacifico', 'berserk' )              => 'pacifico',
						__( 'Roboto', 'berserk' )                => 'roboto',
						__( 'Roboto Slab', 'berserk' )           => 'roboto-slab',
						__( 'Oxygen', 'berserk' )                => 'oxygen',
						__( 'Times New Roman', 'berserk' )       => 'times-new-roman',
					),
					'param_name'       => 'brs_font',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					"std"              => "montserrat",
					"dependency"       => array(
						"element" => "item_type",
						"value"   => array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'span', 'p' ),
					),
				);

				$params[] = array(
					'heading'          => __( 'Font Size', 'js_composer' ),
					"param_name"       => "font_size",
					"type"             => "dropdown",
					"value"            => BRS_Shortcodes_VCParams::get_font_size(),
					'admin_label'      => true,
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					"dependency"       => array(
						"element" => "item_type",
						"value"   => array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'span', 'p' ),
					),

				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Line Height', 'berserk' ),
					"value"            => BRS_Shortcodes_VCParams::get_line_height(),
					'param_name'       => 'brs_line_height',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					"dependency"       => array(
						"element" => "item_type",
						"value"   => array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'span', 'p' ),
					),
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Letter Spacing', 'berserk' ),
					"value"            => BRS_Shortcodes_VCParams::get_letter_spacing(),
					'param_name'       => 'brs_letter_spacing',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					"dependency"       => array(
						"element" => "item_type",
						"value"   => array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'span', 'p' ),
					),
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Margin Top', 'berserk' ),
					"value"            => BRS_Shortcodes_VCParams::get_margin_top(),
					'param_name'       => 'margin_top',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					"dependency"       => array(
						"element" => "item_type",
						"value"   => array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'span', 'p', 'divider' ),
					),
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Margin Right', 'berserk' ),
					"value"            => BRS_Shortcodes_VCParams::get_margin_top(),
					'param_name'       => 'margin_right',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					"dependency"       => array(
						"element" => "item_type",
						"value"   => array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'span', 'p' ),
					),
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Margin Bottom', 'berserk' ),
					"value"            => BRS_Shortcodes_VCParams::get_margin_top(),
					'param_name'       => 'margin_bottom',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					"dependency"       => array(
						"element" => "item_type",
						"value"   => array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'span', 'p', 'divider' ),
					),
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Font weight', 'berserk' ),
					'value'            => BRS_Shortcodes_VCParams::get_font_weight(),
					'param_name'       => 'brs_font_weight',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					"dependency"       => array(
						"element" => "item_type",
						"value"   => array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'span', 'p' ),
					),
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Highlight', 'berserk' ),
					'value'            => array(
						__( 'None', 'berserk' )                  => 'none',
						__( 'Underline', 'berserk' )             => 'massive',
						__( 'Background', 'berserk' )            => 'trend',
						__( 'Vertical Line Default', 'berserk' ) => 'vertical_line_default',
						__( 'Vertical Line Custom', 'berserk' )  => 'underline',
					),
					'param_name'       => 'highlight',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					"dependency"       => array(
						"element" => "item_type",
						"value"   => array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'span', 'p' ),
					),

				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Line color', 'berserk' ),
					'value'            => array(
						__( 'Blue', 'berserk' ) => 'blue',
						__( 'Gray', 'berserk' ) => 'gray',
						__( 'Dark', 'berserk' ) => 'dark'

					),
					'param_name'       => 'line_color',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					"dependency"       => array(
						"element" => "highlight",
						"value"   => array( 'massive', 'underline' ),
					),

				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Animation', 'berserk' ),
					'value'            => array(
						__( 'None', 'berserk' )       => 'none',
						__( 'zoomIn', 'berserk' )     => 'zoomIn',
						__( 'fadeIn', 'berserk' )     => 'fadeIn',
						__( 'fadeInLeft', 'berserk' ) => 'fadeInLeft',
						__( 'fadeInUp', 'berserk' )   => 'fadeInUp',
					),
					'param_name'       => 'animation',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					"dependency"       => array(
						"element" => "item_type",
						"value"   => array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'span', 'p', 'divider' ),
					),

				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Text Align Default', 'berserk' ),
					'value'            => array(
						__( 'None', 'berserk' )   => 'none',
						__( 'Left', 'berserk' )   => 'left',
						__( 'Right', 'berserk' )  => 'right',
						__( 'Center', 'berserk' ) => 'center',
					),
					'param_name'       => 'text_align',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					"dependency"       => array(
						"element" => "item_type",
						"value"   => array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'span', 'p' ),
					),

				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Text Align Large devices', 'berserk' ),
					'value'            => array(
						__( 'None', 'berserk' )   => 'none',
						__( 'Left', 'berserk' )   => 'left',
						__( 'Right', 'berserk' )  => 'right',
						__( 'Center', 'berserk' ) => 'center',
					),
					'param_name'       => 'text_align_lg',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					"dependency"       => array(
						"element" => "item_type",
						"value"   => array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'span', 'p' ),
					),

				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Lines Type', 'berserk' ),
					'value'            => array(
						__( 'None', 'berserk' )   => 'none',
						__( 'Hatch', 'berserk' )  => 'hatch',
						__( 'Solid', 'berserk' )  => 'solid',
						__( 'Double', 'berserk' ) => 'double',
						__( 'Bottom', 'berserk' ) => 'bottom',
						__( 'Dotted', 'berserk' ) => 'dotted',
					),
					'param_name'       => 'lines_type',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					"dependency"       => array(
						"element" => "item_type",
						"value"   => array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'span', 'p' ),
					),

				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Lines Color', 'berserk' ),
					'value'            => array(
						__( 'Default', 'berserk' )   => 'default',
						__( 'Primary', 'berserk' )   => 'brand-primary-rgb',
						__( 'Secondary', 'berserk' ) => 'secondary-rgb',
						__( 'White', 'berserk' )     => 'white-rgb',
						__( 'Black', 'berserk' )     => 'black-rgb',
						__( 'Dark Base', 'berserk' ) => 'brk-dark-base-rgb',
					),
					'param_name'       => 'lines_color',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					"dependency"       => array(
						"element" => "lines_type",
						"value"   => array( 'solid' ),
					),

				);

				$params[] = array(
					'heading'          => __( 'Text Uppercase', 'js_composer' ),
					"param_name"       => "text_uppercase",
					"type"             => "dropdown",
					"value"            => array(
						//"Text Uppercase" => "y",
						__( 'Default', 'berserk' )   => 'default',
						__( 'Uppercase', 'berserk' ) => 'uppercase',
						__( 'Lowercase', 'berserk' ) => 'lowercase',
						__( 'None', 'berserk' )      => 'none',
					),
					//'admin_label'      => true,
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					"dependency"       => array(
						"element" => "item_type",
						"value"   => array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'span', 'p' ),
					),
				);

				$params[] = array(
					'type'             => 'textfield',
					'heading'          => __( 'Opacity', 'js_composer' ),
					'param_name'       => 'opacity',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					'admin_label'      => true,
					"dependency"       => array(
						"element" => "item_type",
						"value"   => array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'span', 'p' ),
					),
				);

				$params[] = array(
					'type'             => 'textfield',
					'heading'          => __( 'Custom css class', 'js_composer' ),
					'param_name'       => 'custom_css_class',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					'admin_label'      => false,
					"dependency"       => array(
						"element" => "item_type",
						"value"   => array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'span', 'p', 'divider' ),
					),
				);

				$params[] = array(
					'type'             => 'textfield',
					'heading'          => esc_html__( 'Use Inner Span with Custom CSS Class', 'berserk' ),
					'param_name'       => 'span_custom_class',
					'admin_label'      => false,
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					'dependency'       => array(
						'element' => 'item_type',
						'value'   => array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'span', 'p' ),
					),
				);

				$params[] = array(
					'type'       => 'colorpicker',
					'heading'    => __( 'Text Color', 'js_composer' ),
					'param_name' => 'text_color',
					'value'      => '#292b2c',
					"dependency" => array(
						"element" => "item_type",
						"value"   => array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'span', 'p' ),
					),
				);

				$params[] = array(
					"param_name"       => "font_style_italic",
					"type"             => "checkbox",
					"value"            => array(
						"Font style italic" => "y",
					),
					'admin_label'      => true,
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					"dependency"       => array(
						"element" => "item_type",
						"value"   => array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'span', 'p' ),
					),
				);

				$params[] = array(
					"param_name"       => "show_inline",
					"type"             => "checkbox",
					"value"            => array(
						"Show Inline" => "y",
					),
					'admin_label'      => true,
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					"dependency"       => array(
						"element" => "item_type",
						"value"   => array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'span', 'p' ),
					),
				);

				$params[] = array(
					"heading"    => __( "Dividers", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$params[] = array(
					"param_name"       => "title_dividers",
					"type"             => "checkbox",
					"value"            => array(
						"Title Dividers" => "y",
					),
					'admin_label'      => true,
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					"dependency"       => array(
						"element" => "item_type",
						"value"   => array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' ),
					),
				);

				$params[] = array(
					'heading'    => __( 'Divider Type', 'berserk' ),
					'param_name' => 'title_divider_type',
					'type'       => 'brs_radio',
					'value'      => array(
						"Divider Line"     => "line",
						"Divider Chevron"  => "chevron",
						"Divider Square"   => "square",
						"Divider Circle"   => "circle",
						"Divider Gradient" => "gradient",
						"Divider Angle"    => "angle",
						"Divider shadow"   => "shadow",
					),
					'images'     => array(
						"line"     => 'divider/line.png',
						"chevron"  => 'divider/chevron.png',
						"square"   => 'divider/square.png',
						"circle"   => 'divider/circle.png',
						"gradient" => 'divider/gradient.png',
						"angle"    => 'divider/angle.png',
						"shadow"   => 'divider/shadow.png',
					),
					'images_dim' => array(
						'w' => '310',
						'h' => '150'
					),
					"dependency" => array(
						"element" => "title_dividers",
						"value"   => array( 'y' ),
					),
				);

				$params[] = array(
					"heading"    => __( "Icon", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$params[] = array(
					'heading'          => __( 'Title Icon', 'js_composer' ),
					"param_name"       => "title_icon",
					"type"             => "dropdown",
					"value"            => array(
						__( 'Hide', 'berserk' ) => 'hide',
						__( 'Show', 'berserk' ) => 'show'
					),
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					"dependency"       => array(
						"element" => "item_type",
						"value"   => array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' ),
					),
				);

				$params[] = array(
					'type'       => 'vc_link',
					'heading'    => __( 'Link URL', 'js_composer' ),
					'param_name' => 'url',
					'dependency' => array(
						"element" => "title_icon",
						"value"   => array( 'show' ),
					)
				);

				$options = array(
					'dependency' => array(
						"element" => "title_icon",
						"value"   => array( 'show' ),
					)
				);
				$icons   = berserk_shortcodes_icons( $options );

				$params = array_merge( $params, $icons );

				$title_attributes = array(
					array(
						'type'       => 'param_group',
						'heading'    => __( 'Title Items', 'js_composer' ),
						'param_name' => 'values',
						'value'      => urlencode( json_encode( array(
							array(
								'label'     => __( 'We are Awesome', 'js_composer' ),
								'item_type' => 'h5',
							),
							array(
								'label'     => __( 'Engaging, purposeful and', 'js_composer' ),
								'item_type' => 'h1',
							),
							array(
								'label'     => __( 'creative', 'js_composer' ),
								'item_type' => 'h1',
							),

						) ) ),
						'params'     => $params
					),

					array(
						'type'             => 'dropdown',
						'heading'          => __( 'Titles Background', 'berserk' ),
						'value'            => array(
							__( 'None', 'berserk' )      => 'none',
							__( 'Sota', 'berserk' )      => 'sota',
							__( 'Rectangle', 'berserk' ) => 'rectangle',

						),
						'param_name'       => 'titles_background',
						'edit_field_class' => 'vc_col-sm-6 vc_column',

					),

					array(
						"heading"    => __( "Rotation", 'berserk' ),
						"param_name" => "brs_title",
						"type"       => "brs_title",
					),

					array(
						"param_name"       => "show_in_mask",
						"type"             => "checkbox",
						"value"            => array(
							"Show in mask" => "y",
						),
						'edit_field_class' => 'vc_col-sm-6 vc_column',
					),

					array(
						'heading'    => __( 'Rotation Type', 'berserk' ),
						'param_name' => 'rotation_type',
						'type'       => 'brs_radio',
						'value'      => array(
							__( 'None', 'berserk' )     => 'none',
							__( 'Rotate 1', 'berserk' ) => 'rotate-1',
							__( 'Rotate 2', 'berserk' ) => 'rotate-2',
							__( 'Rotate 3', 'berserk' ) => 'rotate-3',
							__( 'Scale', 'berserk' )    => 'scale',
							__( 'Slide', 'berserk' )    => 'slide',
							__( 'Type', 'berserk' )     => 'type',
							__( 'Clip', 'berserk' )     => 'clip',
							__( 'Zoom', 'berserk' )     => 'zoom',
						),
						'images'     => array(
							"none"     => 'typing_rotator/none.jpg',
							"rotate-1" => 'typing_rotator/001.jpg',
							"rotate-2" => 'typing_rotator/002.jpg',
							"rotate-3" => 'typing_rotator/003.jpg',
							"scale"    => 'typing_rotator/004.jpg',
							"slide"    => 'typing_rotator/005.jpg',
							"type"     => 'typing_rotator/005.jpg',
							"clip"     => 'typing_rotator/005.jpg',
							"zoom"     => 'typing_rotator/005.jpg',
						),
						'images_dim' => array(
							'w' => '310',
							'h' => '150'
						),

					),

				);

				$title_attributes = array_merge( $title_attributes, $attributes_spacing );

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Title", 'berserk' ),
					"base"     => "brs_title",
					"icon"     => "brs_vc_ico_title",
					"class"    => "brs_vc_sc_title",
					"category" => __( 'Berserk', 'berserk' ),
					"params"   => $title_attributes,
				) );
			}
		}

		public function shortcode_title( $atts, $content = null ) {

			$libraries = array( 'component__title', 'component__title_section', 'wow', 'component__dividers' );
			brs_add_libraries( $libraries );

			extract( shortcode_atts( array(
				'values'                  => '',
				'titles_background'       => 'none',
				//'rotate_title'         => 'n',
				'custom_css_class'        => '',
				'rotation_type'           => 'none',
				'show_in_mask'            => 'n',
				'group_style_left'        => 'false',
				'group_text_align'        => 'none',
				'group_margin_top'        => '',
				'group_margin_top_xl'     => '',
				'group_margin_top_lg'     => '',
				'group_margin_top_md'     => '',
				'group_margin_top_sm'     => '',
				'group_margin_bottom'     => '',
				'group_margin_bottom_xl'  => '',
				'group_margin_bottom_lg'  => '',
				'group_margin_bottom_md'  => '',
				'group_margin_bottom_sm'  => '',
				'group_padding_top'       => '',
				'group_padding_top_xl'    => '',
				'group_padding_top_lg'    => '',
				'group_padding_top_md'    => '',
				'group_padding_top_sm'    => '',
				'group_padding_bottom'    => '',
				'group_padding_bottom_xl' => '',
				'group_padding_bottom_lg' => '',
				'group_padding_bottom_md' => '',
				'group_padding_bottom_sm' => '',
				'group_custom_class'      => '',
			), $atts ) );

			// store atts
			$atts_backup = self::$atts;

			$values = vc_param_group_parse_atts( $values );

			$output = "";
			$before = "";
			$after  = "";

			if ( isset( $titles_background ) && $titles_background != 'none' ) {
				switch ( $titles_background ) {
					case "sota":
						$before = '<div class="title-lines-sota">
						              <span class="sota-1">
						                <div class="svg wow fadeIn" data-wow-delay="0.0s"><svg><path fill="none" d="M6.968,17.036 L13.088,27.498 L25.326,27.498 L31.446,17.036 L25.326,6.575 L13.088,6.575 L6.968,17.036 Z"/></svg></div>
						                <div class="svg wow fadeIn" data-wow-delay="0.1s"><svg><path fill="none" d="M6.968,17.036 L13.088,27.498 L25.326,27.498 L31.446,17.036 L25.326,6.575 L13.088,6.575 L6.968,17.036 Z"/></svg></div>
						                <div class="svg wow fadeIn" data-wow-delay="0.2s"><svg><path fill="none" d="M6.968,17.036 L13.088,27.498 L25.326,27.498 L31.446,17.036 L25.326,6.575 L13.088,6.575 L6.968,17.036 Z"/></svg></div>
						                <div class="svg wow fadeIn" data-wow-delay="0.3s"><svg><path fill="none" d="M6.968,17.036 L13.088,27.498 L25.326,27.498 L31.446,17.036 L25.326,6.575 L13.088,6.575 L6.968,17.036 Z"/></svg></div>
						                <div class="svg wow fadeIn" data-wow-delay="0.4s"><svg><path fill="none" d="M6.968,17.036 L13.088,27.498 L25.326,27.498 L31.446,17.036 L25.326,6.575 L13.088,6.575 L6.968,17.036 Z"/></svg></div>
						              </span>';
						$after  = '<span class="sota-2">
					                <div class="svg wow fadeIn" data-wow-delay="0.6s"><svg><path fill="none" d="M6.968,17.036 L13.088,27.498 L25.326,27.498 L31.446,17.036 L25.326,6.575 L13.088,6.575 L6.968,17.036 Z"/></svg></div>
					                <div class="svg wow fadeIn" data-wow-delay="0.7s"><svg><path fill="none" d="M6.968,17.036 L13.088,27.498 L25.326,27.498 L31.446,17.036 L25.326,6.575 L13.088,6.575 L6.968,17.036 Z"/></svg></div>
					                <div class="svg wow fadeIn" data-wow-delay="0.8s"><svg><path fill="none" d="M6.968,17.036 L13.088,27.498 L25.326,27.498 L31.446,17.036 L25.326,6.575 L13.088,6.575 L6.968,17.036 Z"/></svg></div>
					                <div class="svg wow fadeIn" data-wow-delay="0.9s"><svg><path fill="none" d="M6.968,17.036 L13.088,27.498 L25.326,27.498 L31.446,17.036 L25.326,6.575 L13.088,6.575 L6.968,17.036 Z"/></svg></div>
					                <div class="svg wow fadeIn" data-wow-delay="1.0s"><svg><path fill="none" d="M6.968,17.036 L13.088,27.498 L25.326,27.498 L31.446,17.036 L25.326,6.575 L13.088,6.575 L6.968,17.036 Z"/></svg></div>
					              </span>
					            </div>';
						break;
					case "rectangle":
						$before = '<div class="mb-100 title-lines-four">
						              <span></span>
						              <span></span>
						              <span></span>
						              <span></span>';
						$after  = '</div>';

						break;
				}
			}

			foreach ( $values as $key => $value ) {
				if ( $value['item_type'] !== 'divider' ) {

					$classes      = array();
					$before_title = "";
					$after_title  = "";
					$before_item  = "";
					$after_item   = "";
					$style        = "";

					$classes[] = 'font__family-' . $value['brs_font'];

					if ( isset( $value['font_size'] ) && $value['font_size'] != '' ) {
						$classes[] = 'font__size-' . $value['font_size'];
						//$style .= 'font-size: ' . $value['font_size'] . 'px;';
					}

					if ( isset( $value['brs_line_height'] ) && $value['brs_line_height'] != '' ) {
						$classes[] = 'line__height-' . $value['brs_line_height'];
					}

					if ( isset( $value['brs_letter_spacing'] ) && $value['brs_letter_spacing'] != '' ) {
						$classes[] = 'letter-spacing-' . $value['brs_letter_spacing'];
						if ( $value['brs_letter_spacing'] == '-1' ) {
							$style .= 'letter-spacing: -1px;';
						}
					}

					if ( $value['brs_font_weight'] != 'initial' || $value['brs_font_weight'] != 'normal' ) {
						$classes[] = 'font__weight-' . $value['brs_font_weight'];
					}

					if ( isset( $value['text_uppercase'] ) && $value['text_uppercase'] == 'uppercase' ) {
						$classes[] = 'text-uppercase';
					}
					if ( isset( $value['text_uppercase'] ) && $value['text_uppercase'] == 'none' ) {
						$style .= 'text-transform: none;';
					}
					if ( isset( $value['show_inline'] ) && $value['show_inline'] == 'y' ) {
						//$classes[] = 'show-inline-block';
						$classes[] = 'show-inline';
					}
					if ( isset( $value['font_style_italic'] ) && $value['font_style_italic'] == 'y' ) {
						$classes[] = 'font__style-italic';
					}
					if ( isset( $value['custom_css_class'] ) && ! empty( $value['custom_css_class'] ) ) {
						$classes[] = $value['custom_css_class'];
					}

					if ( isset( $value['text_align'] ) && $value['text_align'] != 'none' && empty( $value['title_dividers'] ) ) {
						$classes[] = 'text-' . $value['text_align'];
					}

					if ( isset( $value['text_align_lg'] ) && $value['text_align_lg'] != 'none' && empty( $value['title_dividers'] ) ) {
						$classes[] = 'text-lg-' . $value['text_align_lg'];
					}


					if ( isset( $value['text_align'] ) && $value['text_align'] != 'none' && ( isset( $value['title_dividers'] ) && $value['title_dividers'] == 'y' ) ) {

						switch ( $value['text_align'] ) {
							case "left":
								$classes[] = 'text-left';
								break;
							case "right":
								$classes[] = 'text-right';
								break;
							case "center":
								$classes[] = 'text-center';
								break;
						}
					}

					if ( isset( $value['margin_top'] ) && $value['margin_top'] != '' ) {
						$pos = strpos( $value['margin_top'], '-' );
						if ( $pos === false ) {
							$classes[] = 'mt-' . $value['margin_top'];
						} else {

							$style .= 'margin-top: ' . $value['margin_top'] . 'px;';
						}
					}

					if ( isset( $value['margin_right'] ) && $value['margin_right'] != '' ) {
						$style .= 'margin-right: ' . $value['margin_right'] . 'px;';
					}

					if ( isset( $value['margin_bottom'] ) && $value['margin_bottom'] != '' ) {
						$pos = strpos( $value['margin_bottom'], '-' );
						if ( $pos === false ) {
							$classes[] = 'mb-' . $value['margin_bottom'];
						} else {

							$style .= 'margin-bottom: ' . $value['margin_bottom'] . 'px;';
						}
					}

					if ( isset( $value['opacity'] ) && ! empty( $value['opacity'] ) ) {
						$style .= 'opacity: ' . $value['opacity'] . ';';
					}

					if ( isset( $value['animation'] ) && $value['animation'] != 'none' ) {
						$classes[] = 'wow ' . $value['animation'];
					}

					if ( $value['highlight'] != 'none' ) {
						$classes[] = 'highlight-' . $value['highlight'];


						if ( $value['highlight'] == 'massive' ) {
							//$before_item = "<div>";
							//$after_item  = "</div>";
							if ( isset( $value['line_color'] ) && $value['line_color'] == 'gray' ) {
								$classes[] = 'highlight-massive-gray';
							}
							$after_title = '<span class="after wow zoomIn"></span>';
						}
						if ( $value['highlight'] == 'underline' ) {
							$style_line = '';

							if ( $value['line_color'] == 'gray' ) {
								$style_line = 'background: #E8E8E8';
							}
							if ( $value['line_color'] == 'dark' ) {
								$style_line = 'background: rgb(39, 39, 39)';
							}

							$after_title = '<span class="before wow fadeInUp" style="visibility: visible; animation-name: fadeInUp; ' . $style_line . '"></span>';
						}

						if ( $value['highlight'] == 'vertical_line_default' ) {
							$classes[]   = 'vert-line';
							$before_item = '<div class="line-heading">';
							$after_item  = '</div>';
						}
					}

					if ( isset( $value['lines_type'] ) && $value['lines_type'] != 'none' ) {
						switch ( $value['lines_type'] ) {
							case "hatch":
								$classes[]    = 'title-lines-ridget';
								$classes[]    = 'title-lines-main';
								$before_title = "<span class='line'></span><span class='text'>";
								$after_title  = "</span><span class='line'></span>";
								break;
							case "solid":
								$line_style = '';
								if ( isset( $value['lines_color'] ) && $value['lines_color'] !== 'default' ) {
									$line_style = 'style="background:rgba(var(--' . $value['lines_color'] . '), 0.2)"';
								}
								$classes[]    = 'title-lines-solid';
								$classes[]    = 'title-lines-main';
								$before_title = "<span class='line' " . $line_style . "></span><span class='text'>";
								$after_title  = "</span><span class='line' " . $line_style . "></span>";
								break;
							case "double":
								$classes[]    = 'title-lines-double';
								$classes[]    = 'title-lines-main';
								$before_title = '<span class="line"></span><span class="text">';
								$after_title  = '</span><span class="line"></span>';
								break;
							case "bottom":
								$classes[]    = 'title-lines-bottom';
								$classes[]    = 'title-lines-main';
								$before_title = '<span>';
								$after_title  = "</span>";
								break;
							case "dotted":
								$classes[]    = 'title-lines-dotted';
								$before_title = "<span class='line'></span><span class='text'>";
								$after_title  = "</span><span class='line'></span>";
								break;
						}
					}

					//dpm($value);

					if ( isset( $value['title_dividers'] ) && $value['title_dividers'] == 'y' ) {
						$divider_type = $value['title_divider_type'];

						if ( isset( $value['text_align'] ) && $value['text_align'] != 'none' ) {

						}

						switch ( $divider_type ) {
							case "line":
								$classes[]    = 'title__divider';
								$classes[]    = 'title__divider--line';
								$before_title = '<span class="title__divider__wrapper">';
								$after_title  = '<span class="line brk-base-bg-gradient-right"></span>
						                </span>';
								break;
							case "chevron":
								$classes[]    = 'title__divider';
								$classes[]    = 'title__divider--chevron';
								$before_title = '<span class="title__divider__wrapper">';
								$after_title  = '<span class="line brk-base-bg-gradient-chevron-pseudo"></span>
						                </span>';
								break;
							case "square":
								$classes[]    = 'title__divider';
								$classes[]    = 'title__divider--square';
								$before_title = '<span class="title__divider__wrapper">';
								$after_title  = '<span class="line brk-base-font-color"></span>
						                </span>';
								break;
							case "circle":
								$classes[]    = 'title__divider';
								$classes[]    = 'title__divider--circle';
								$before_title = '<span class="title__divider__wrapper">';
								$after_title  = '<span class="line-left brk-base-bg-1"></span><span class="line-right brk-base-bg-1"></span>
						                </span>';
								break;
							case "gradient":
								$classes[]    = 'title__divider';
								$classes[]    = 'title__divider--gradient';
								$before_title = '<span class="title__divider__wrapper">';
								$after_title  = '<span class="line-left brk-base-bg-gradient-12"></span><span class="line-right brk-base-bg-gradient-11"></span>
						                </span>';
								break;
							case "angle":
								$classes[]    = 'title__divider';
								$classes[]    = 'title__divider--angle';
								$before_title = '<span class="title__divider__wrapper">';
								$after_title  = '<span class="line-left brk-base-font-color-2 brk-base-bg-gradient-13"></span><span class="line-right brk-base-font-color-2 brk-base-bg-gradient-14"></span>
						                </span>';
								break;
							case "shadow":
								$classes[]    = 'title__divider';
								$classes[]    = 'title__divider--shadow';
								$before_title = '<span class="title__divider__wrapper">';
								$after_title  = '<span class="shadow"></span>
					                </span>';
								break;

						}
					}

					if ( isset( $value['span_custom_class'] ) ) {
						if ( ! empty( $value['span_custom_class'] ) ) {
							$before_title = '<span class="' . esc_attr( $value['span_custom_class'] ) . '">';
							$after_title  = '</span>';
						}
					}

					if ( isset( $value['title_icon'] ) && $value['title_icon'] == 'show' ) {
						$atts = array(
							'btn_icon_type'    => $value['btn_icon_type'],
							'icon_fontawesome' => $value['icon_fontawesome'],
							'icon_openiconic'  => $value['icon_openiconic'],
							'icon_typicons'    => $value['icon_typicons'],
							'icon_entypo'      => $value['icon_entypo'],
							'icon_linecons'    => $value['icon_linecons'],
							'icon_monosocial'  => $value['icon_monosocial'],
							'brs_btn_icon'     => $value['brs_btn_icon'],
							'option_type'      => 'parsed_shortcode'
						);
						$icon = berserk_shortcodes_icons_process( $atts );

						if ( isset( $value['url'] ) ) {
							$url = $value['url'];
						} else {
							$url = '';
						}
						$url      = vc_build_link( $url );
						$link_url = $url['url'];
						$a_title  = ( $url['title'] == '' ) ? '' : $url['title'];
						$a_target = ( $url['target'] == '' ) ? '' : 'target="' . $url['target'] . '"';

						$before_item = '<div class="text-xl-left z-index-high">
									<div class="inline-wrap inline-wrap-second">
										<a href="' . esc_url( $link_url ) . '" ' . $a_target . ' class="icon__btn icon__btn-anim icon__btn-center icon__btn-md_1 flex-lg-last mr-20 icon__btn-svg">
											<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 65.21 65.21">
												<defs>
													<style>.a {
														fill: url(#i1);
													}</style>
													<linearGradient id="i1" y1="65" y2="0" gradientUnits="userSpaceOnUse">
														<stop offset="0%" stop-color="#15bdff"></stop>
														<stop offset="50%" stop-color="#00f6ff"></stop>
													</linearGradient>
												</defs>
												<path class="a" d="M65.21,32.6l-1.82,1.86L65,36.53l-2,1.63,1.32,2.24-2.21,1.37,1,2.39-2.36,1.1.74,2.5-2.48.8.44,2.57-2.55.5.12,2.6-2.6.19L54.22,57l-2.6-.12-.5,2.55L48.56,59l-.8,2.48-2.49-.74-1.1,2.36-2.39-1-1.37,2.21-2.24-1.32-1.63,2-2.07-1.58L32.6,65.21l-1.86-1.82L28.67,65l-1.63-2L24.8,64.27l-1.37-2.21L21,63.1l-1.1-2.36-2.49.74L16.65,59l-2.57.44-.5-2.55L11,57l-.19-2.6-2.6-.19.12-2.6-2.55-.5.44-2.57-2.48-.8.74-2.49-2.36-1.1,1-2.39L.94,40.41l1.32-2.24-2-1.63,1.58-2.07L0,32.6l1.82-1.86L.23,28.67l2-1.63L.94,24.8l2.21-1.38L2.11,21l2.36-1.1-.74-2.5,2.48-.8-.44-2.57,2.55-.5L8.2,11l2.6-.19L11,8.2l2.6.13.5-2.55,2.57.44.8-2.48,2.49.74L21,2.11l2.39,1L24.8.94,27,2.26l1.63-2,2.07,1.58L32.6,0l1.86,1.82L36.53.23l1.63,2L40.41.94l1.37,2.21,2.39-1,1.1,2.36,2.49-.74.8,2.48,2.57-.44.5,2.55,2.6-.13.19,2.6L57,11l-.12,2.6,2.55.5L59,16.65l2.48.8-.74,2.5L63.1,21l-1,2.39,2.21,1.37L62.95,27l2,1.63-1.58,2.07Z"></path>
											</svg>' . $icon . '
										</a>
										<div>';

						$after_item = '</div>
									</div>
								</div>';

					}

					$label = $value['label'];

					if ( isset( $rotation_type ) && ( $rotation_type != 'none' ) ) {
						$classes[]          = ( $key == 0 ) ? 'is-visible' : '';
						$value['item_type'] = 'b';
					}

					$item_class = implode( ' ', $classes );

					if ( isset( $value['text_color'] ) ) {
						if ( $value['text_color'] != '#292b2c' ) {
							$style .= 'color:' . $value['text_color'] . ';';
						}
					}

					$style_attr = '';
					if ( $style ) {
						$style_attr = ' style="' . $style . '"';
					}

					$output .= $before_item . ' <' . $value['item_type'] . ' class="' . $item_class . '"' . $style_attr . '>' . $before_title . $label . $after_title . '</' . $value['item_type'] . '>' . $after_item;

				} else {

					$align_class   = '';
					$divider_class = '';
					if ( isset( $value['divider_align'] ) ) {
						switch ( $value['divider_align'] ) {
							case "left":
								$align_class = ' ml-0';
								break;
							case "right":
								$align_class = ' mr-0';
								break;
						}
					}

					if ( isset( $value['margin_top'] ) && $value['margin_top'] != '' ) {
						$pos = strpos( $value['margin_top'], '-' );
						if ( $pos === false ) {
							$divider_class .= ' mt-' . $value['margin_top'];
						}
					}

					if ( isset( $value['margin_bottom'] ) && $value['margin_bottom'] != '' ) {
						$pos = strpos( $value['margin_bottom'], '-' );
						if ( $pos === false ) {
							$divider_class .= ' mb-' . $value['margin_bottom'];
						}
					}


					if ( isset( $value['animation'] ) && $value['animation'] != 'none' ) {
						$divider_class .= $align_class . ' wow ' . $value['animation'];
					}
					if ( isset( $value['custom_css_class'] ) ) {
						$divider_class .= ' ' . $value['custom_css_class'] . $divider_class;
					}

					switch ( $value['divider_type'] ) {
						case "default":
							$output .= '<hr class="divider' . $divider_class . '">';
							break;

						case "line":
							$output .= '<hr class="horiz-line' . $divider_class . '">';
							break;

						case "dashed":
							$output .= '<div class="divider-dashed' . $divider_class . '"></div>';
							break;

						case "cross":
							$output .= '<div class="divider-cross' . $divider_class . '">
								          <span></span>
								          <span></span>
								        </div>';
							break;

						case "layers":
							$output .= '<div class="divider-layers' . $divider_class . '"><span class="before"></span></div>';
							break;

						case "lines":
							$output .= '<div class="divider-lines' . $divider_class . '"><span></span><span></span></div>';
							break;

						case "dots":
							$output .= '<div class="divider-dots' . $align_class . '">
							              <span class="wow fadeIn" data-wow-delay="0.4s"></span>
							              <span class="wow fadeIn" data-wow-delay="0.5s"></span>
							              <span class="wow fadeIn" data-wow-delay="0.6s"></span>
							            </div>';
							break;
					}
				}

			}

			if ( isset( $rotation_type ) && ( $rotation_type != 'none' ) ) {

				brs_add_libraries( 'component__typing_rotator' );

				$classes   = array();
				$classes[] = 'brk-headline';
				$classes[] = 'show-inline';
				$classes[] = $rotation_type;

				switch ( $rotation_type ) {
					case "rotate-1":
						$classes[] = 'pl-15';
						break;
					case "rotate-2":
					case "rotate-3":
					case "scale":
					case "type":
						$classes[] = 'letters';
						$classes[] = 'text-center';
						break;
					case "slide":
					case "zoom":
						$classes[] = 'text-center';
						break;
					case "clip":
						$classes[] = 'is-full-width';
						break;

				}

				if ( isset( $show_in_mask ) && $show_in_mask == 'y' ) {
					$classes[] = 'brk-headline_mask';
				}
				$item_class = implode( ' ', $classes );
				$tag        = ( ! empty( $values ) ) ? $values[0]['item_type'] : 'h2';

				$before = '<' . $tag . ' class="' . $item_class . '">
					        <span class="brk-words-rotators">';

				$after = ' </span>
						</' . $tag . '>';
			}

			// Group Markup
			$group_before               = '';
			$group_after                = '';
			$group_class                = array();
			$group_class_margin_top     = array();
			$group_class_margin_bottom  = array();
			$group_class_padding_top    = array();
			$group_class_padding_bottom = array();
			if ( $group_text_align != 'none' ) {
				$group_class[] = 'text-' . $group_text_align;
			}
			if ( $group_custom_class ) {
				$group_class[] = esc_attr( $group_custom_class );
			}


			$devices_sizes = array( '', 'xl', 'lg', 'md', 'sm' );
			foreach ( $devices_sizes as $size ) {
				$size_class = '';
				if ( $size ) {
					$size_class = $size . '-';
					$size       = '_' . $size;
				}
				$group_margin_top     = ${'group_margin_top' . $size};
				$group_margin_bottom  = ${'group_margin_bottom' . $size};
				$group_padding_top    = ${'group_padding_top' . $size};
				$group_padding_bottom = ${'group_padding_bottom' . $size};
				if ( $group_margin_top ) {
					$group_class_margin_top[] = 'mt-' . $size_class . $group_margin_top;
				}
				if ( $group_margin_bottom ) {
					$group_class_margin_bottom[] = 'mb-' . $size_class . $group_margin_bottom;
				}
				if ( $group_padding_top ) {
					$group_class_padding_top[] = 'pt-' . $size_class . $group_padding_top;
				}
				if ( $group_padding_bottom ) {
					$group_class_padding_bottom[] = 'pb-' . $size_class . $group_padding_bottom;
				}
			}
			$group_class = array_merge( $group_class, $group_class_margin_top, $group_class_margin_bottom, $group_class_padding_top, $group_class_padding_bottom );

			$group_class = implode( ' ', $group_class );
			if ( ! empty( $group_class ) ) {
				$group_before = '<div class="' . esc_attr( $group_class ) . '">';
				$group_after  = '</div>';
			}

			$sub_group_class = 'heading-style-left';
			if ( $group_style_left == 'true' ) {
				$group_before .= '<div class="' . esc_attr( $sub_group_class ) . '">';
				$group_after = '</div>' . $group_after;
			}

			// colors
			// text-gray, .text-blue, .text-dark, text-gray-light

			$output = $group_before . $before . $output . $after . $group_after;

			// restore atts
			self::$atts = $atts_backup;

			return $output;
		}

	}

	// create shortcode
	BRS_Title::get_instance();

}