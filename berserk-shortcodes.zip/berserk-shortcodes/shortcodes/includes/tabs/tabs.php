<?php
/**
 * Tabs shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Tabs', false ) ) {

	class BRS_Tabs extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();

		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Tabs();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_tabs', array( $this, 'shortcode_tabs' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				$params   = array();
				$params[] = array(
					'heading'    => __( 'Tabs Type', 'berserk' ),
					'param_name' => 'tabs_type',
					'type'       => 'brs_radio',
					'value'      => array(
						"Simple"               => "simple",
						"Hover"                => "hover",
						"Side"                 => "side",
						"Icon"                 => "icon",
						"Bottom"               => "bottom",
						"Parallax"             => "parallax",
						"Smooth"               => "smooth",
						"Simple Type 2"        => "simple_type_2",
						"Icon Type 2"          => "icon_type_2",
						"Large Icon"           => "large_icon",
						"Filter"               => "filter",
						"Intro"                => "intro",
						"Icons Gradient"       => "icons_gradient",
						"Simple Smooth"        => "simple_smooth",
						"Tabs canted"          => "tabs_canted",
						"Simple Smooth Type 2" => "simple_smooth_type_2"
					),
					'images'     => array(
						"simple"               => 'tabs/simple.jpg',
						"hover"                => 'tabs/hover.jpg',
						"side"                 => 'tabs/side.jpg',
						"icon"                 => 'tabs/icon.jpg',
						"bottom"               => 'tabs/bottom.jpg',
						"parallax"             => 'tabs/parallax.jpg',
						"smooth"               => 'tabs/smooth.jpg',
						"simple_type_2"        => 'tabs/simple_type_2.jpg',
						"icon_type_2"          => 'tabs/icon_type_2.jpg',
						"large_icon"           => 'tabs/large_icon.jpg',
						"filter"               => 'tabs/filter.jpg',
						"intro"                => 'tabs/intro.jpg',
						"icons_gradient"       => 'tabs/icons_gradient.jpg',
						"simple_smooth"        => 'tabs/simple_smooth.jpg',
						"tabs_canted"          => 'tabs/tabs_canted.jpg',
						"simple_smooth_type_2" => 'tabs/simple_smooth_type_2.jpg',
					),
					'images_dim' => array(
						'w' => '310',
						'h' => '150'
					)
				);

				$params[] = array(
					"type"             => "dropdown",
					"class"            => "",
					"heading"          => __( "Direction Top / Bottom", 'berserk' ),
					"param_name"       => "direction_tb",
					'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__tabs_type simple bottom',
					"value"            => array(
						"Top"    => "top",
						"Bottom" => "bottom"
					)
				);

				$params[] = array(
					"type"             => "dropdown",
					"class"            => "",
					"heading"          => __( "Direction Left / Right", 'berserk' ),
					"param_name"       => "direction_lr",
					'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__tabs_type side icon',
					"value"            => array(
						"Left"  => "left",
						"Right" => "right"
					)
				);

				$params[] = array(
					"type"             => "dropdown",
					"class"            => "",
					"heading"          => __( "Style Type 1 / 2", 'berserk' ),
					"param_name"       => "style_type",
					'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__tabs_type hover',
					"value"            => array(
						"Style One" => "1",
						"Style Two" => "2"
					)
				);

				$params[] = array(
					'type'             => 'checkbox',
					'heading'          => esc_html__( 'Enable Overlay', 'berserk' ),
					'value'            => array(
						'Yes' => 'y',
					),
					'param_name'       => 'overlay',
					'edit_field_class' => 'vc_col-sm-3 vc_column brk-dependency__tabs_type intro',
				);

				$options = array( 'edit_field_class' => 'brk-dependency__tabs_type smooth icon_type_2 filter intro' );

				$patterns = berserk_shortcodes_patterns( $options );
				$params   = array_merge( $params, $patterns );

				$backgrounds                                 = berserk_shortcodes_backgrounds();
				$backgrounds['bg_color']['edit_field_class'] = "vc_col-sm-12 vc_column  brk-dependency__tabs_type icons_gradient";
				$backgrounds['opacity']['edit_field_class']  = "vc_col-sm-6 vc_column  brk-dependency__tabs_type icons_gradient";

				$params = array_merge( $params, $backgrounds );

				$params[] = array(
					'type'             => 'dropdown',
					'class'            => '',
					'heading'          => esc_html__( 'Overlay Type', 'berserk' ),
					'param_name'       => 'overlay_type',
					'edit_field_class' => 'vc_column vc_col-sm-6 brk-dependency__tabs_type filter',
					'value'            => array(
						esc_attr__( 'None', 'berserk' )       => '',
						esc_attr__( 'Gradient', 'berserk' )   => 'brk-bg-grad',
						esc_attr__( 'Color Dark', 'berserk' ) => 'brk-bg-black',
					),
					'dependency'       => array(
						'element' => 'tabs_type',
						'value'   => 'filter'
					),
				);

				// Opacity
				$params[] = array(
					'heading'          => esc_html__( 'Opacity', 'berserk' ),
					'param_name'       => 'overlay_opacity',
					'type'             => 'dropdown',
					'value'            => array(
						'1'   => '100',
						'0.9' => '90',
						'0.8' => '80',
						'0.7' => '70',
						'0.6' => '60',
						'0.5' => '50',
						'0.4' => '40',
						'0.3' => '30',
						'0.2' => '20',
						'0.1' => '10',
					),
					'std'              => '80',
					'edit_field_class' => 'vc_column vc_col-sm-3 brk-dependency__tabs_type filter',
					'dependency'       => array(
						'element' => 'tabs_type',
						'value'   => 'filter'
					),
				);

				$params[] = array(
					'type'             => 'textarea_raw_html',
					'heading'          => __( 'Tabs title', 'js_composer' ),
					'param_name'       => 'title',
					//"value"            => "Some Title Goes Here",
					'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__tabs_type icon_type_2 simple_smooth_type_2',
				);

				vc_map( array(
					"weight"                  => - 1,
					"name"                    => __( "Tabs", 'berserk' ),
					"base"                    => "brs_tabs",
					"icon"                    => "brs_vc_ico_tabs",
					"class"                   => "brs_vc_sc_tabs",
					"category"                => __( 'Berserk', 'berserk' ),
					"is_container"            => true,
					"show_settings_on_create" => false,
					"js_view"                 => "VcBackendTtaTabsView",
					"as_parent"               => array( 'only' => 'brs_tab_section' ),
					"scripts"                 => array( 'in-view', 'SplitText' ),

					"custom_markup"    => '<div class="vc_tta-container" data-vc-action="collapse">
											<div class="vc_general vc_tta vc_tta-tabs vc_tta-color-backend-tabs-white vc_tta-style-flat vc_tta-shape-rounded vc_tta-spacing-1 vc_tta-tabs-position-top vc_tta-controls-align-left">
												<div class="vc_tta-tabs-container">'
					                      . '<ul class="vc_tta-tabs-list">'
					                      . '<li class="vc_tta-tab" data-vc-tab data-vc-target-model-id="{{ model_id }}" data-element_type="brs_tab_section"><a href="javascript:;" data-vc-tabs data-vc-container=".vc_tta" data-vc-target="[data-model-id=\'{{ model_id }}\']" data-vc-target-model-id="{{ model_id }}"><span class="vc_tta-title-text">{{ section_title }}</span></a></li>'
					                      . '</ul>
												</div>
												<div class="vc_tta-panels vc_clearfix {{container-class}}">
													{{ content }}
												</div>
											</div>
										</div>',
					"default_content"  => '[brs_tab_section title="' . sprintf( '%s %d', 'Tab', 1 ) . '"][/brs_tab_section]
											[brs_tab_section title="' . sprintf( '%s %d', 'Tab', 2 ) . '"][/brs_tab_section]',
					"admin_enqueue_js" => array( vc_asset_url( 'lib/vc_tabs/vc-tabs.min.js' ) ),

					"params" => $params
				) );
			}
		}

		public function shortcode_tabs( $atts, $content = null ) {

			brs_add_libraries( 'component__tabs' );
			brs_add_libraries( 'component__tabbed_contents' );

			$attributes = shortcode_atts( array(
				'tabs_type'             => 'simple',
				'style_type'            => '1',
				'direction_tb'          => 'top',
				'direction_lr'          => 'left',
				'bg_image'              => '',
				'title'                 => 'Some Title Goes Here',
				'use_custom_background' => 'no',
				'pattern_type'          => 'brk-bgi-1',
				'background_size'       => 'bg-cover',
				'background_repeat'     => '',
				'background_position'   => '',
				'overlay_type'          => 'brk-bg-grad',
				'overlay_opacity'       => '80',
				'gradient'              => '',
				'opacity'               => '',
				'overlay'               => '',
			), $atts );

			$pattern_class = array();
			$pattern_style = '';
			if ( $attributes['use_custom_background'] == 'yes' ) {
				$image         = wp_get_attachment_image_src( $attributes['bg_image'], 'full' );
				$image         = $image[0];
				$pattern_style = 'background-image: url(' . esc_url( $image ) . ');';
			} else {
				$pattern_class[] = $attributes['pattern_type'];
			}

			if(isset( $atts['background_size']) && ( $atts['background_size'] !='none')){
				$pattern_class[] = $atts['background_size'];
			}
			if(isset( $atts['background_repeat']) && ( $atts['background_repeat'] !='none')){
				$pattern_class[] = $atts['background_repeat'];
			}
			if(isset( $atts['background_position']) && ( $atts['background_position'] !='none')){
				$pattern_class[] = $atts['background_position'];
			}
			$pattern_class = implode( ' ', $pattern_class );

			BRS_Tab_Section::$items = array();
			do_shortcode( $content );
			$output = '';
			$items  = BRS_Tab_Section::$items;

			switch ( $attributes['tabs_type'] ) {
				case "simple":

					$tabs_class = ( $attributes['direction_tb'] == 'top' ) ? 'brk-tabs-simple-top' : 'brk-tabs-simple-bottom';

					$output .= '<div class="brk-tabs ' . $tabs_class . '" data-hash="true">';

					$output .= '<ul class="brk-tabs-nav font__family-montserrat">';
					foreach ( $items as $item ) {
						$output .= '<li class="brk-tab">' . $item['icon'] . '<span>' . esc_html( $item['title'] ) . '</span></li>';
					}
					$output .= '</ul>';
					$output .= '<div class="brk-tabs-content">';

					$i = 1;
					foreach ( $items as $item ) {
						$output .= '<div id="tab-' . $i . '" class="brk-tab-item">' . $item['content'] . '
					                  </div>';
						$i ++;
					}

					$output .= '</div>';
					$output .= '</div>';

					break;

				case "hover":

					// Attributes
					$tabs_class = ( $attributes['style_type'] == '1' ) ? '1' : '2';

					// Tabs Container
					$output .= '<div class="brk-tabs brk-tabs-hovers brk-tabs-hovers_style-' . esc_attr( $tabs_class ) . '" data-index="0">';

					// Tabs Nav
					$output .= '<ul class="brk-tabs-nav font__family-open-sans">';
					foreach ( $items as $item ) {
						$output .= '<li class="brk-tab font__weight-bold">' . $item['icon'] . ' ' . esc_html( $item['title'] ) . ' <span class="brk-tab__icon"><i class="fa fa-angle-right"></i></span></li>';
					}
					$output .= '</ul>';

					// Tabs Content
					$output .= '<div class="brk-tabs-content">';

					$i = 1;
					foreach ( $items as $item ) {
						$output .= '<div class="brk-tab-item text-center text-lg-left">' . $item['content'] . '</div>';
						$i ++;
					}

					$output .= '</div>';

					$output .= '</div>';

					break;

				case "side":

					$tabs_class = ( $attributes['direction_lr'] == 'left' ) ? 'brk-tabs-side-left' : 'brk-tabs-side-right';

					$output .= '<div class="brk-tabs ' . $tabs_class . '" data-hash="true">';
					$output .= '<ul class="brk-tabs-nav font__family-montserrat">';
					foreach ( $items as $item ) {
						if ( $attributes['direction_lr'] == 'left' ) {
							$output .= '<li class="brk-tab">' . $item['icon'] . '<span>' . esc_html( $item['title'] ) . '</span><span class="after"></span></li>';
						} else {
							$output .= '<li class="brk-tab"><span>' . esc_html( $item['title'] ) . '</span>' . $item['icon'] . '<span class="after"></span></li>';
						}

					}
					$output .= '</ul>';
					$output .= '<div class="brk-tabs-content">';

					$i = 4;
					foreach ( $items as $item ) {
						$output .= '<div id="tab-' . $i . '" class="brk-tab-item">' . $item['content'] . '
					                  </div>';
						$i ++;
					}

					$output .= '</div>';
					$output .= '</div>';

					break;

				case "icon":

					$tabs_class = ( $attributes['direction_lr'] == 'left' ) ? 'brk-tabs-icon-left' : 'brk-tabs-icon-right';

					$output .= '<div class="brk-tabs ' . $tabs_class . '" data-hash="true">';
					$output .= '<ul class="brk-tabs-nav font__family-montserrat">';
					foreach ( $items as $item ) {
						$output .= '<li class="brk-tab"><span class="font__weight-bold">' . esc_html( $item['title'] ) . '</span>' . $item['icon'] . '</li>';
					}
					$output .= '</ul>';
					$output .= '<div class="brk-tabs-content">';

					$i = 1;
					foreach ( $items as $item ) {
						$output .= '<div id="tab-' . $i . '" class="brk-tab-item">' . $item['content'] . '
					                  </div>';
						$i ++;
					}

					$output .= '</div>';
					$output .= '</div>';

					break;
				case "bottom":

					$tabs_class = ( $attributes['direction_tb'] == 'top' ) ? 'brk-tabs-bottom-top' : 'brk-tabs-bottom-bottom';

					$output .= '<div class="brk-tabs ' . $tabs_class . '" data-hash="true">';
					$output .= '<ul class="brk-tabs-nav font__family-montserrat">';
					foreach ( $items as $item ) {
						$output .= '<li class="brk-tab">' . $item['icon'] . '<span>' . esc_html( $item['title'] ) . '</span></li>';

					}
					$output .= '</ul>';
					$output .= '<div class="brk-tabs-content">';

					$i = 1;
					foreach ( $items as $item ) {
						$output .= '<div id="tab-' . $i . '" class="brk-tab-item">' . $item['content'] . '
					                  </div>';
						$i ++;
					}

					$output .= '</div>';
					$output .= '</div>';

					break;
				case "parallax":

					$tabs_class = 'brk-tabs-parallax';

					$output .= '<div class="brk-tabs ' . $tabs_class . '" data-hash="true">';
					$output .= '<ul class="brk-tabs-nav font__family-montserrat">';
					foreach ( $items as $item ) {
						$output .= '<li class="brk-tab">' . $item['icon'] . '<span>' . esc_html( $item['title'] ) . '</span></li>';
					}
					$output .= '</ul>';
					$output .= '<div class="brk-tabs-content">';

					$i = 1;
					foreach ( $items as $item ) {
						$output .= '<div id="tab-' . $i . '" class="brk-tab-item" style="background: url(' . esc_url( $item['image'] ) . ') 100% center;background-repeat: no-repeat;">' . $item['content'] . '
					                  </div>';
						$i ++;
					}

					$output .= '</div>';
					$output .= '</div>';

					break;
				case "smooth":

					$tabs_class = 'brk-tabs-smooth';

					$output .= '<div class="brk-tabs ' . $tabs_class . '" data-hash="true">';
					$output .= '<ul class="brk-tabs-nav font__family-montserrat font__weight-light ' . $pattern_class . '" style="' . $pattern_style . '">';

					foreach ( $items as $item ) {
						$output .= '<li class="brk-tab"><span>' . esc_html( $item['title'] ) . '</span></li>';
					}
					$output .= '</ul>';
					$output .= '<div class="brk-tabs-content">';

					$i = 1;
					foreach ( $items as $item ) {
						$output .= '<div id="tab-' . $i . '" class="brk-tab-item">' . $item['content'] . '
					                  </div>';
						$i ++;
					}

					$output .= '</div>';
					$output .= '</div>';

					$output .= '<script>
									jQuery(function() {
										setTimeout(function(){
											jQuery(".brk-tabs.rendered.brk-tabs-smooth").each(function(){
											 	var _ = jQuery(this),
            									tab = _.find(".brk-tab"),
            									tabItem = _.find(".brk-tab-item");
            									 tabItem.hide().eq(1).fadeIn();
            									 tab.siblings(".active").removeClass("active");
            									 tab.eq(1).addClass("active");
											});
										},100);
									});
                                </script>';

					break;
				case "simple_type_2":

					$tabs_class = 'brk-tabs-simple';

					$output .= '<div class="brk-tabs ' . $tabs_class . '" data-hash="true">';
					$output .= '<ul class="brk-tabs-nav font__family-montserrat font__weight-bold">';
					foreach ( $items as $item ) {
						$output .= '<li class="brk-tab">' . $item['icon'] . '<span>' . esc_html( $item['title'] ) . '</span></li>';
					}
					$output .= '</ul>';
					$output .= '<div class="brk-tabs-content">';

					$i = 1;
					foreach ( $items as $item ) {
						$output .= '<div id="tab-' . $i . '" class="brk-tab-item">' . $item['content'] . '
					                  </div>';
						$i ++;
					}

					$output .= '</div>';
					$output .= '</div>';
					break;
				case "icon_type_2":
					$output .= '<div class="brk-tabs bg-white brk-tabs_tabbed-icon">
								  <div class="brk-tabs_tabbed-icon--header brk-base-bg-gradient-5 font__family-montserrat ' . $pattern_class . '" style="' . $pattern_style . '">
								    <div class="brk-tabs_tabbed-icon--title">' . rawurldecode( base64_decode( $attributes['title'] ) ) . '</div>
								    <ul class="brk-tabs-nav">';
					foreach ( $items as $item ) {
						$output .= '<li class="brk-tab">' . $item['icon'] . '<span>' . esc_html( $item['title'] ) . '</span></li>';
					}
					$output .= '</ul>
								  </div>
								  <div class="brk-tabs-content">';
					$i = 1;
					foreach ( $items as $item ) {
						$output .= '<div id="tab-' . $i . '" class="brk-tab-item">' . $item['content'] . '</div>';
						$i ++;
					}
					$output .= '</div>
								</div>';
					break;
				case "large_icon":
					$output .= '<div class="brk-tabs brk-tabs_tabbed-large-icon" data-index="1">
								  <ul class="brk-tabs-nav">';
					foreach ( $items as $item ) {
						$output .= '<li class="brk-tab">' . $item['icon'] . '<span>' . esc_html( $item['title'] ) . '</span></li>';
					}
					$output .= '</ul>
								  <div class="brk-tabs-content brk-base-bg-gradient-5 brk-bgi-2">';

					$i = 1;
					foreach ( $items as $item ) {
						$output .= '<div id="tab-' . $i . '" class="brk-tab-item"><div class="container">' . $item['content'] . '</div></div>';
						$i ++;
					}
					$output .= '</div>
								</div>';
					break;

				// Tabs Tabbed Filter
				case "filter":

					// Tabs Class
					$tabs_class   = array( 'brk-tabs-content' );
					$tabs_class[] = 'bg-' . $attributes['background_size'];
					if ( $attributes['background_size'] == 'cover' ) {
						$tabs_class[] = 'bg-position_center';
					}
					$tabs_class[] = $pattern_class;
					$tabs_class[] = 'lazyload';

					$tabs_class   = implode( ' ', $tabs_class );
					
					// Bg Image
					$image_url = '';
					if ( wp_get_attachment_image_url( $attributes['bg_image'] ) ) {
						$image_url = wp_get_attachment_image_url( $attributes['bg_image'], 'full' );
					}

					// Overlay Class
					$overlay_class   = array( 'brk-layer' );
					$overlay_class[] = $attributes['overlay_type'];
					if ( $attributes['overlay_opacity'] != '100' ) {
						$overlay_class[] = 'opacity-' . $attributes['overlay_opacity'];
					}
					$overlay_class = implode( ' ', $overlay_class );

					$output .= '<div class="brk-tabs brk-tabs_tabbed-filter" data-index="1">
								  <ul class="brk-tabs-nav">';
					foreach ( $items as $item ) {
						$output .= '<li class="brk-tab">' . $item['icon'] . '<span>' . esc_html( $item['title'] ) . '</span></li>';
					}
					$output .= '</ul>
								  <div class="' . esc_attr( $tabs_class ) . '" data-bg="' . esc_attr( $image_url ) . '">';
					$i = 1;
					foreach ( $items as $item ) {
						$output .= '<div id="tab-' . $i . '" class="brk-tab-item"><div class="container">' . $item['content'] . '</div></div>';
						$i ++;
					}
					if ( $attributes['overlay_type'] != '' ) {
						$output .= '<div class="' . esc_attr__( $overlay_class ) . '"></div>';
					}
					$output .= '</div>
								</div>';
					break;

				case "intro":
					// brk-tabs_tabbed-intro-shaped
					$output .= '<div class="brk-tabs brk-tabs_tabbed-intro" data-index="1">
								  <ul class="brk-tabs-nav">';
					foreach ( $items as $item ) {
						$output .= '<li class="brk-tab">' . $item['icon'] . '<span>' . esc_html( $item['title'] ) . '</span></li>';
					}
					$output .= '</ul>
								<div class="brk-tabs-content position-relative">';
					if ( $attributes['overlay'] ) {
						$output .= '<div class="brk-abs-overlay ' . esc_attr( $pattern_class ) . '" style="' . $pattern_style . '">
									<span class="brk-abs-overlay brk-base-bg-gradient-90deg"></span>
								</div>';
					}

					$i = 1;
					foreach ( $items as $item ) {
						$output .= '<div id="tab-' . $i . '" class="brk-tab-item"><div class="container">' . $item['content'] . '</div></div>';
						$i ++;
					}

					$output .= '</div>
								</div>';
					break;
				case "icons_gradient":
					$overlay_class   = array();
					$overlay_class[] = isset( $atts['gradient'] ) ? $atts['gradient'] : "";
					$overlay_class[] = isset( $atts['opacity'] ) ? $atts['opacity'] : "";
					$overlay_class   = implode( ' ', $overlay_class );

					$overlay_class = ! empty( $overlay_class ) && ! empty( $atts['gradient'] ) ? $overlay_class : 'brk-bg-grad';

					$output .= '<div class="brk-gradient-circle brk-abs-overlay ' . $pattern_class . '"  style="' . $pattern_style . '">
									<span class="brk-abs-overlay  ' . $overlay_class . '"></span>
									<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 136"><path d="M1920,136A3691.84,3691.84,0,0,0,0,136V0H1920Z"/></svg>
									<div class="brk-tabs brk-tabs_tabbed-icons-gradient " data-index="1">
								  <div class="container">
								    <ul class="brk-tabs-nav row font__family-montserrat">';
					foreach ( $items as $item ) {
						$output .= '<li class="brk-tab col-md-3">' . $item['icon'] . '<span>' . esc_html( $item['title'] ) . '</span></li>';
					}

					$output .= '</ul>
								  </div>
								  <div class="brk-tabs-content" >';

					$i = 1;
					foreach ( $items as $item ) {
						$output .= '<div id="tab-' . $i . '"  class="brk-tab-item"><div class="container">' . $item['content'] . '</div></div>';
						$i ++;
					}
					$output .= '</div>
								 </div>
								</div>';
					break;

				case "simple_smooth":
					$output .= '<div class="brk-tabs brk-tabs-simple-smooth">
					                <ul class="brk-tabs-nav font__family-montserrat font__size-16 font__weight-400 line__height-16 pt-10">';

					foreach ( $items as $item ) {
						$output .= '<li class="brk-tab">
				                        <span>' . esc_html( $item['title'] ) . '</span>
				                    </li>';

					}
					$output .= '</ul>
					                <div class="brk-tabs-content">';

					$i = 1;
					foreach ( $items as $item ) {
						$output .= '<div id="tab-' . $i . '" class="brk-tab-item">' . $item['content'] . '</div>';
						$i ++;
					}

					$output .= '</div>
					            </div>';

					break;
				case "tabs_canted":
					$output .= '<div class="brk-tabs brk-tabs_canted">
									<ul class="brk-tabs-nav font__family-montserrat font__size-14 font__weight-semibold line__height-14 text-uppercase">';
					foreach ( $items as $item ) {
						$output .= '<li class="brk-tab">
				                        <span>' . esc_html( $item['title'] ) . '</span>
				                    </li>';
					}

					$output .= '</ul>
									<div class="brk-tabs-content">';
					$i = 1;
					foreach ( $items as $item ) {
						$output .= '<div id="tab-' . $i . '" class="brk-tab-item pt-40">' . $item['content'] . '</div>';
						$i ++;
					}


					$output .= '</div>
								</div>';
					break;
				case "simple_smooth_type_2":
					$output = '<div class="brk-sc-item-page-tabs pb-90">
			                        <h5 class="brk-sc-item-page-tabs__title brk-black-font-color font__family-montserrat font__size-36 line__height-42 font__weight-normal d-inline-flex flex-wrap">
			                            ' . rawurldecode( base64_decode( $attributes['title'] ) ) . '
			                        </h5>
			                        <div class="brk-tabs brk-tabs-simple-smooth">
			                            <ul class="brk-tabs-nav font__family-montserrat font__size-16 font__weight-400 line__height-16 pt-10">';

					foreach ( $items as $item ) {
						$output .= '<li class="brk-tab">
	                                    <span>' . esc_html( $item['title'] ) . '</span>
	                                </li>';
					}


					$output .= '</ul>
			                            <div class="brk-tabs-content">';
					$i = 1;
					foreach ( $items as $item ) {
						$output .= '<div id="tab-' . $i . '"  class="brk-tab-item">
	                                    ' . $item['content'] . '
	                                </div>';
						$i ++;
					}

					$output .= '</div>
			                        </div>
			                    </div>';
					break;
			}

			return $output;
		}
	}

	// create shortcode
	BRS_Tabs::get_instance();

}
