<?php
/**
 * Servises shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Servises', false ) ) {

	class BRS_Servises extends BRS_Shortcode {

		static protected $instance;

		protected $shortcode_name = 'brs_services';
		protected $atts = array();

		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Servises();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( $this->shortcode_name, array( $this, 'shortcode' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				$params   = array();
				$params[] = array(
					'type'        => 'textfield',
					'heading'     => __( 'First Title', 'js_composer' ),
					'param_name'  => 'first_title',
					'admin_label' => true,
				);
				$params[] = array(
					'type'       => 'textfield',
					'heading'    => __( 'Second Title', 'js_composer' ),
					'param_name' => 'second_title',
					//'admin_label' => true,
				);

				$params[] = array(
					'type'       => 'param_group',
					'heading'    => __( 'Second Title', 'js_composer' ),
					'param_name' => 'values',
					'value'      => urlencode( json_encode( array(
						array(
							'label'             => __( 'We are', 'js_composer' ),
							'brs_font'          => 'montserrat',
							'brs_font_weight'   => 'normal',
							'highlight_massive' => '',

						),
						array(
							'label'             => __( 'cool', 'js_composer' ),
							'brs_font'          => 'montserrat',
							'brs_font_weight'   => 'normal',
							'highlight_massive' => '',

						)
					) ) ),
					'params'     => array(
						array(
							'type'        => 'textfield',
							'heading'     => __( 'Label', 'js_composer' ),
							'param_name'  => 'label',
							'admin_label' => true,
						),

						array(
							"heading"    => __( "Fonts", 'berserk' ),
							"param_name" => "brs_title",
							"type"       => "brs_title",
						),

						array(
							'type'             => 'dropdown',
							'heading'          => __( 'Font', 'berserk' ),
							'value'            => array(
								__( 'Open Sans', 'berserk' )             => 'open-sans',
								__( 'Montserrat', 'berserk' )            => 'montserrat',
								__( 'Montserrat Alternates', 'berserk' ) => 'montserrat-alt',
								__( 'Playfair Display', 'berserk' )      => 'playfair',
								__( 'Poppins', 'berserk' )               => 'poppins',
								__( 'Pacifico', 'berserk' )              => 'pacifico',
								__( 'Roboto', 'berserk' )                => 'roboto',
								__( 'Roboto Slab', 'berserk' )           => 'roboto-slab',
								__( 'Oxygen', 'berserk' )                => 'oxygen',
								__( 'Times New Roman', 'berserk' )       => 'times-new-roman',
							),
							'param_name'       => 'brs_font',
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							"std"              => "montserrat",
						),

						array(
							'type'             => 'dropdown',
							'heading'          => __( 'Font weight', 'berserk' ),
							'value'            => array(
								__( 'Normal', 'berserk' )     => 'normal',
								__( 'Regular', 'berserk' )    => 'regular',
								__( 'Light', 'berserk' )      => 'light',
								__( 'Ultralight', 'berserk' ) => 'ultralight',
								__( 'Bold', 'berserk' )       => 'bold'
							),
							'param_name'       => 'brs_font_weight',
							'edit_field_class' => 'vc_col-sm-6 vc_column',

						),

						array(
							"param_name"       => "highlight_massive",
							"type"             => "checkbox",
							"value"            => array(
								"Highlight Massive" => "y",
							),
							'admin_label'      => true,
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

					)
				);
				$params[] = array(
					'type'       => 'textfield',
					'heading'    => __( 'Description', 'js_composer' ),
					'param_name' => 'description',

				);
				$params[] = array(
					"type"             => "textfield",
					"heading"          => __( "Link Title", 'berserk' ),
					"param_name"       => "link_title",
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					"value"            => "Read More"
				);
				$params[] = array(
					"type"             => "textfield",
					"heading"          => __( "Link URL", 'berserk' ),
					"param_name"       => "link_url",
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					"value"            => "#"
				);
				$params[] = array(
					"type"             => "attach_image",
					"heading"          => __( "Background Image", 'berserk' ),
					"param_name"       => "bg_image",
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					"value"            => ""
				);

				$icons = berserk_shortcodes_icons( '' );

				$params = array_merge( $params, $icons );

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Services", 'berserk' ),
					"base"     => "brs_services",
					"icon"     => "brs_vc_ico_services",
					"class"    => "brs_vc_sc_services",
					"category" => __( 'Berserk', 'berserk' ),
					"params"   => array(
						array(
							'heading'    => __( 'Services Type', 'berserk' ),
							'param_name' => 'services_type',
							'type'       => 'brs_radio',
							'value'      => array(
								"Pedestal"        => "pedestal",
								"Hexagon"         => "hexagon",
								"Honeycomb"       => "honeycomb",
								"Simple Info"     => "simple_info",
								"Architecture"    => "architecture",
								"Architecture BG" => "architecture_bg",
								"Info"            => "info",
							),
							'images'     => array(
								"pedestal"        => 'services/s_pedestal.png',
								"hexagon"         => 'services/s_hexagon.png',
								"honeycomb"       => 'services/s_honeycomb.png',
								"simple_info"     => 'services/simple_info.png',
								"architecture"    => 'services/architecture.png',
								"architecture_bg" => 'services/architecture_bg.png',
								"info"            => 'services/info.png',
							),
							'images_dim' => array(
								'w' => '210',
								'h' => '100'
							)
						),
						array(
							'type'             => 'dropdown',
							'heading'          => __( 'Color scheme', 'berserk' ),
							'value'            => array(
								__( 'Default', 'berserk' ) => 'default',
								__( 'Light', 'berserk' )   => 'light',
							),
							'param_name'       => 'color_scheme',
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__services_type pedestal',
						),
						array(
							'type'       => 'param_group',
							'heading'    => __( 'Values', 'js_composer' ),
							'param_name' => 'values',
							'value'      => urlencode( json_encode( array(
								array(
									'first_title'      => __( 'We are Awesome', 'js_composer' ),
									'second_title'     => __( 'Purposeful<br> & Creative', 'js_composer' ),
									'description'      => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque', 'js_composer' ),
									'link_title'       => 'All Info',
									'link_url'         => '#',
									'icon_fontawesome' => 'fa fa-trophy',

								),
								array(
									'first_title'      => __( 'We are Awesome', 'js_composer' ),
									'second_title'     => __( 'Purposeful Cool<br> & Creative', 'js_composer' ),
									'description'      => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque', 'js_composer' ),
									'link_title'       => 'All Info',
									'link_url'         => '#',
									'icon_fontawesome' => 'fa fa-trophy',

								),
								array(
									'first_title'      => __( 'We are Awesome', 'js_composer' ),
									'second_title'     => __( 'Purposeful<br> & Creative', 'js_composer' ),
									'description'      => __( 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque', 'js_composer' ),
									'link_title'       => 'All Info',
									'link_url'         => '#',
									'icon_fontawesome' => 'fa fa-trophy',

								),

							) ) ),

							'params' => $params

						),
						array(
							'type'             => 'dropdown',
							'heading'          => esc_html__( 'Columns', 'berserk' ),
							'value'            => array(
								'2 Columns' => '2',
								'3 Columns' => '3',
								'4 Columns' => '4',
							),
							'std'              => '3',
							'param_name'       => 'columns',
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__services_type simple_info architecture architecture_bg info',
						),
						array(
							'type'             => 'dropdown',
							'heading'          => esc_html__( 'Text Color', 'berserk' ),
							'value'            => BRS_Shortcodes_VCParams::get_text_colors(),
							//'std'              => '',
							'param_name'       => 'text_color',
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__services_type info',
						),
						array(
							'type'             => 'textfield',
							'heading'          => esc_html__( 'Additional CSS Class', 'berserk' ),
							'group'            => esc_html__( 'Advanced', 'berserk' ),
							'param_name'       => 'css_class',
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__services_type info',
						),

					)
				) );
			}
		}

		public function shortcode( $atts, $content = null ) {

			brs_add_libraries( 'component__services' );

			extract( shortcode_atts( array(
				'services_type' => 'pedestal',
				'values'        => '',
				'columns'       => '3',
				'color_scheme'  => '',
				'text_color'    => 'default',
				'css_class'     => '',
			), $atts ) );

			$output = '';

			$values = vc_param_group_parse_atts( $values );


			switch ( $services_type ) {

				case "pedestal":

					$color_class = ( isset( $color_scheme ) && $color_scheme == 'light' ) ? 'services__wrapper-pedestal_light' : '';

					$output = '<div class="container">
									<div class="services__wrapper-main services__wrapper-pedestal active__effect-main ' . $color_class . '">
						          		<div class="row row-no-gutter align-items-center">
						          ';
					$i      = 1;

					foreach ( $values as $value ) {
						$classes      = array();
						$icon_class_i = 'inline-wrap';
						switch ( $i ) {
							case 1:
								$classes[] = 'right';
								$classes[] = 'text-lg-right';
								break;
							case 2:
								$icon_class_i = '';
								$classes[]    = 'active';
								$classes[]    = 'current';
								$classes[]    = 'center';
								$classes[]    = 'text-center';
								break;
							case 3:
								$classes[] = 'left';
								$classes[] = 'text-lg-left';
								break;

						}
						$classes[] = 'services__wrapper';
						$classes[] = 'active__effect';

						$atts = array(
							'btn_icon_type'    => $value['btn_icon_type'],
							'icon_fontawesome' => $value['icon_fontawesome'],
							'icon_openiconic'  => $value['icon_openiconic'],
							'icon_typicons'    => $value['icon_typicons'],
							'icon_entypo'      => $value['icon_entypo'],
							'icon_linecons'    => $value['icon_linecons'],
							'icon_monosocial'  => $value['icon_monosocial'],
							'brs_btn_icon'     => $value['brs_btn_icon'],
							'option_type'      => 'parsed_shortcode'
						);
						$icon = berserk_shortcodes_icons_process( $atts );

						$class = implode( ' ', $classes );

						$output .= '<div class="col-lg-4">
						              <div class="' . $class . '">
						                <div class="' . $icon_class_i . '">
						                  <button class="icon__btn icon__btn-anim icon__btn-md_1">
						                    <span class="after"></span>
						                    <span class="spike"></span>
						                    <span class="spike"></span>
						                    <span class="spike"></span>
						                    <span class="spike"></span>
						                    <span class="spike"></span>
						                    <span class="spike"></span>
						                    <span class="spike"></span>
						                    <span class="spike"></span>
						                    <span class="spike"></span>
						                    <span class="before"></span>
						                    ' . $icon . '
						                  </button>
						                  <div>
						                    <p class="font__family-open-sans font__weight-bold font__size-16 text-primary">' . $value['first_title'] . '</p>
						                    <h4 class="font__family-montserrat font__weight-ultralight font__size-24 text-uppercase mt-10">' . $value['second_title'] . '</h4>
						                  </div>
						                </div>
						                <p class="font__family-open-sans font__size-14 text-gray mt-20">' . $value['description'] . '</p>
						                <a href="' . $value['link_url'] . '" class="btn btn-md btn-icon border-radius-25 font__family-open-sans font__weight-bold btn-inside-out">
						                  <i class="fa fa-comment icon-inside" aria-hidden="true"></i>
						                  <span class="before">' . $value['link_title'] . '</span>
						                  <span class="text">' . $value['link_title'] . '</span>
						                  <span class="after">' . $value['link_title'] . '</span>
						                </a>
						              </div>
						            </div>
						          ';
						$i ++;
					}

					$output .= '		</div>
						          </div>
						        </div>';
					break;

				case "hexagon":

					brs_add_libraries( 'component__shop_honeycomb' );

					$output = '<div class="brk-sc-honeycomb" data-brk-library="component__shop_honeycomb">';

					$i          = 1;
					$item_class = '';

					foreach ( $values as $value ) {

						switch ( $i ) {
							case 1:
							case 2:
								$item_class = 'brk-sc-honeycomb-one_center';
								break;
							case 3:
								$item_class = 'brk-sc-honeycomb-one_left';
								break;
							case 4:
								$item_class = 'brk-sc-honeycomb-one_right';
								break;

						}

						$title = '';
						if ( isset( $value['values'] ) ) {
							$values_title = vc_param_group_parse_atts( $value['values'] );

							foreach ( $values_title as $item ) {
								$classes = array();

								$classes[] = 'font__family-' . $item['brs_font'];
								if ( $item['brs_font_weight'] != 'normal' ) {
									$classes[] = 'font__weight-' . $item['brs_font_weight'];
								}

								$span_after = '';
								if ( isset( $item['highlight_massive'] ) && $item['highlight_massive'] == 'y' ) {
									$classes[]  = 'highlight-massive';
									$span_after = '<span class="after"></span>';
								}

								$class_t = implode( ' ', $classes );

								$title .= '<span class="' . $class_t . '">' . $item['label'] . $span_after . ' </span>';
							}
						}

						$output .= '<div class="brk-sc-honeycomb-one brk-sc-honeycomb-one_wide-shadow brk-sc-honeycomb-one_hide-btn ' . $item_class . '">
										<div class="brk-sc-honeycomb-one__content">
											<h4 class="font__family-montserrat font__weight-bold font__size-24 brk-sc-honeycomb-one__header" data-brk-library="component__title">'.$title.'</h4>
											<p class="font__family-open-sans font__size-16 mt-20 brk-dark-font-color brk-sc-honeycomb-one__p">' . $value['description'] . '</p>
											<a href="' . $value['link_url'] . '" class="btn btn-prime btn-md border-radius-25 font__weight-bold mt-20 brk-sc-honeycomb-one__hide-btn btn-prime-white-transparent" data-brk-library="component__button"><span class="before"></span><span class="after"></span><span class="border-btn"></span>' . $value['link_title'] . '</a>
										</div>
										<div class="brk-sc-honeycomb-one__layer brk-base-bg-gradient-14"></div>
										<div class="brk-sc-honeycomb-one__hex-1"></div>
										<div class="brk-sc-honeycomb-one__hex-2"></div>
									</div>';
						$i ++;

					}

					$output .= '</div>';

					break;

				case "honeycomb":

					$output = '<div class="container">
						          <div class="services__wrapper-main services__wrapper-honeycomb active__effect-main">
						            <div class="row">
						         ';
					$i      = 1;

					foreach ( $values as $value ) {

						$class_item = '';
						if ( $i == 2 ) {
							$class_item = 'active center current';
						}

						$title = '';

						if ( isset( $value['values'] ) ) {
							$values_title = vc_param_group_parse_atts( $value['values'] );

							foreach ( $values_title as $item ) {
								$classes = array();

								$classes[] = 'font__family-' . $item['brs_font'];
								if ( $item['brs_font_weight'] != 'normal' ) {
									$classes[] = 'font__weight-' . $item['brs_font_weight'];
								}

								$class = implode( ' ', $classes );

								$title .= '<span class="' . $class . '">' . $item['label'] . ' </span>';
							}
						}

						$atts = array(
							'btn_icon_type'    => $value['btn_icon_type'],
							'icon_fontawesome' => $value['icon_fontawesome'],
							'icon_openiconic'  => $value['icon_openiconic'],
							'icon_typicons'    => $value['icon_typicons'],
							'icon_entypo'      => $value['icon_entypo'],
							'icon_linecons'    => $value['icon_linecons'],
							'icon_monosocial'  => $value['icon_monosocial'],
							'brs_btn_icon'     => $value['brs_btn_icon'],
							'option_type'      => 'parsed_shortcode'
						);
						$icon = berserk_shortcodes_icons_process( $atts );

						$output .= ' <div class="col-lg-4">
						                <div class="services__wrapper active__effect ' . $class_item . '">
						                  <div class="icon__cover">
						                    <button class="icon__btn icon__btn-anim icon__btn-sm">
						                      <span class="before"></span>
						                      ' . $icon . '
						                      <span class="after"></span>
						                    </button>
						                  </div>
						                  <p class="font__family-open-sans font__weight-light font__size-14 text-uppercase letter-spacing-60">' . $value['first_title'] . '</p>
						                  <h4 class="font__family-montserrat font__weight-light font__size-24 text-uppercase">' . $title . '</h4>
						                  <span class="divide"></span>
						                  <p class="font__family-open-sans font__size-14 main-text">' . $value['description'] . '</p>
						                  <a href="' . $value['link_url'] . '" class="btn btn-width font__family-open-sans font__weight-bold font__size-16 mt-20"><span>' . $value['link_title'] . '</span></a>
						                </div>
						              </div>';
						$i ++;
					}

					$output .= '
						            </div>
						          </div>
						        </div>';


					break;

				case "simple_info":

					brs_add_libraries( 'component__team_page' );

					$output       = '<div class="row">';
					$column_class = self::get_column_class( $columns );

					foreach ( $values as $value ) {
						$atts = array(
							'btn_icon_type'    => $value['btn_icon_type'],
							'icon_fontawesome' => $value['icon_fontawesome'],
							'icon_openiconic'  => $value['icon_openiconic'],
							'icon_typicons'    => $value['icon_typicons'],
							'icon_entypo'      => $value['icon_entypo'],
							'icon_linecons'    => $value['icon_linecons'],
							'icon_monosocial'  => $value['icon_monosocial'],
							'brs_btn_icon'     => isset( $value['brs_btn_icon'] ) ? $value['brs_btn_icon'] : '',
							'option_type'      => 'parsed_shortcode'
						);

						$icon = berserk_shortcodes_icons_process( $atts );

						$output .= ' <div class="' . $column_class . '">
 										<div class="brk-services mb-45">
	                                        <div class="brk-services__icon">
	                                        ' . $icon . '
	                                        </div>
	                                          <span class="brk-services__title font__family-montserrat font__weight-semibold font__size-18">
	                                            ' . $value['first_title'] . '
	                                          </span>
	                                        <p class="brk-dark-font-color font__family-open-sans font__size-16 line-height-26">
	                                            ' . $value['description'] . '
	                                        </p>
	                                    </div>
                                    </div>';

					}


					$output .= '</div>';
					break;

				case "architecture":

					$column_class = self::get_column_class( $columns );

					$output = '<div class="row">';

					foreach ( $values as $value ) {

						$atts = array(
							'btn_icon_type'    => $value['btn_icon_type'],
							'icon_fontawesome' => $value['icon_fontawesome'],
							'icon_openiconic'  => $value['icon_openiconic'],
							'icon_typicons'    => $value['icon_typicons'],
							'icon_entypo'      => $value['icon_entypo'],
							'icon_linecons'    => $value['icon_linecons'],
							'icon_monosocial'  => $value['icon_monosocial'],
							'brs_btn_icon'     => isset( $value['brs_btn_icon'] ) ? $value['brs_btn_icon'] : '',
							'option_type'      => 'parsed_shortcode'
						);

						$icon = berserk_shortcodes_icons_process( $atts );

						$output .= '<div class="' . $column_class . '">
				                        <div class="services-architecture">
				                            <div class="services-architecture__icon">
				                                ' . $icon . '
				                            </div>
				                            <div class="services-architecture__container">
				                                <h4 class="font__size-21 line__height-24 text-uppercase font__weight-bold pb-10">' . $value['first_title'] . '</h4>
				                                <span class="font__size-14 line__height-24 brk-dark-blur-font-color">' . $value['description'] . '</span>
				                            </div>
				                        </div>
				                    </div>';
					}


					$output .= '</div>';

					break;
				case "architecture_bg":

					$column_class = self::get_column_class( $columns );

					$output = '<div class="row align-items-stretch">';

					foreach ( $values as $value ) {

						$image = wp_get_attachment_image_src( $value['bg_image'], array( 370, 186 ) );

						$atts = array(
							'btn_icon_type'    => $value['btn_icon_type'],
							'icon_fontawesome' => $value['icon_fontawesome'],
							'icon_openiconic'  => $value['icon_openiconic'],
							'icon_typicons'    => $value['icon_typicons'],
							'icon_entypo'      => $value['icon_entypo'],
							'icon_linecons'    => $value['icon_linecons'],
							'icon_monosocial'  => $value['icon_monosocial'],
							'brs_btn_icon'     => isset( $value['brs_btn_icon'] ) ? $value['brs_btn_icon'] : '',
							'option_type'      => 'parsed_shortcode'
						);

						$icon = berserk_shortcodes_icons_process( $atts );

						$output .= '<div class="' . $column_class . '">
				                        <div class="services-architecture-bg" style="background-image: url(' . esc_url( $image[0] ) . ')">
				                            <div class="services-architecture-bg__before brk-bg-primary opacity-90"></div>

				                            <div class="services-architecture-bg__icon">
				                                ' . $icon . '
				                            </div>
				                            <div class="services-architecture-bg__container">
				                                <h4 class="font__size-21 line__height-24 text-uppercase font__weight-bold pb-10 text-white">' . $value['first_title'] . '</h4>
				                                <span class="font__size-14 line__height-24 opacity-80">' . $value['description'] . '</span>
				                            </div>
				                        </div>
				                    </div>';
					}

					$output .= '</div>';

					break;
				case "info":

					$column_class = self::get_column_class( $columns );

					$services_class = array( 'services-info' );
					if( $text_color != 'default' ){
						$services_class[] = $text_color;
					}
					if( $css_class ) {
						$css_class = explode( ' ', $css_class );
						$services_class = array_merge( $services_class, $css_class );
					}
					$services_class = implode( ' ', $services_class );

					$output = '<div class="' . esc_attr( $services_class ) . '"><div class="row no-gutters">';

					foreach ( $values as $value ) {

						$atts = array(
							'btn_icon_type'    => $value['btn_icon_type'],
							'icon_fontawesome' => $value['icon_fontawesome'],
							'icon_openiconic'  => $value['icon_openiconic'],
							'icon_typicons'    => $value['icon_typicons'],
							'icon_entypo'      => $value['icon_entypo'],
							'icon_linecons'    => $value['icon_linecons'],
							'icon_monosocial'  => $value['icon_monosocial'],
							'brs_btn_icon'     => isset( $value['brs_btn_icon'] ) ? $value['brs_btn_icon'] : '',
							'option_type'      => 'parsed_shortcode'
						);

						$icon = berserk_shortcodes_icons_process( $atts );

						$title = explode( ' ', $value['first_title'] );
						$t_p1  = ( isset( $title[0] ) ) ? $title[0] : '';
						$t_p2  = ( isset( $title[1] ) ) ? $title[1] : '';

						$output .= '<div class="' . $column_class . '">
		                                <div class="services-info__content">
		                                    <div class="services-info__icon">
		                                        ' . $icon . '
		                                    </div>
		                                    <div class="services-info__text">
		                                        <div class="font__family-montserrat">
		                                            <span class="font__weight-semibold font__size-38 line__height-50 d-inline-block">' . $t_p1 . '</span>
		                                            <span class="font__weight-ultralight font__size-28 line__height-40 d-inline-block"
		                                                  style="padding-top: 8px;">' . $t_p2 . '</span>
		                                        </div>
		                                        <div class="font__family-montserrat font__size-12 line__height-20 opacity-60 text-uppercase">
		                                            ' . $value['second_title'] . '
		                                        </div>
		                                    </div>
		                                </div>
		                            </div>';
					}

					$output .= '</div></div>';

					break;


			}

			return $output;
		}

		function get_column_class( $col ) {
			$class = '';
			switch ( $col ) {
				case "1":
					$class = 'col-12';
					break;
				case "2":
					$class = 'col-6';
					break;
				case "3":
					$class = 'col-4';
					break;
				case "4":
					$class = 'col-3';
					break;
				case "6":
					$class = 'col-2';
					break;
			}

			return $class;

		}

		protected function get_icon_class( $atts ) {
			$icon_class = '';

			$icon_class = $atts[ 'icon_' . $atts['type'] ];

			if ( empty( $icon_class ) ) {
				$icon_class = 'fa fa-trophy';
			}

			return $icon_class;
		}


	}

	// create shortcode
	BRS_Servises::get_instance();

}
