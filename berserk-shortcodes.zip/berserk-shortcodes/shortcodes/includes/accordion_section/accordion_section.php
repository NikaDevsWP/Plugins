<?php
/**
 * Accordion Section shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


if ( ! class_exists( 'BRS_Accordion_Section', false ) ) {

	class BRS_Accordion_Section extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();
		protected $shortcode_id = 0;
		static $items = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Accordion_Section();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'vc_accordion_tab', array( $this, 'shortcode_accordion_section' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				$params = array();

				$icons = berserk_shortcodes_icons();

				$params[] = array(
					'type'             => 'textfield',
					'heading'          => __( 'Title', 'js_composer' ),
					'param_name'       => 'title',
					'edit_field_class' => 'vc_col-sm-6 vc_column'
				);

				$params[] = array(
					'type'             => 'attach_image',
					'heading'          => __( 'Image', 'js_composer' ),
					'param_name'       => 'image',
					'value'            => '',
					'description'      => '(for Image type)',
					'edit_field_class' => 'vc_col-sm-6 vc_column'
				);

				$params[] = array(
					"param_name"       => "active_section",
					"type"             => "checkbox",
					"value"            => array(
						"Active Section" => "y",
					),
					'edit_field_class' => 'vc_col-sm-6 vc_column',
				);

				$params = array_merge( $params, $icons );


				vc_map( array(
					"weight"                    => - 1,
					"slug"                      => "vc_accordion_tab",
					"name"                      => __( "Accordion Section", 'berserk' ),
					//"base"                      => "brs_accordion_section",
					"base"                      => "vc_accordion_tab",
					"icon"                      => "icon-wpb-ui-tta-section",
					"class"                     => "brs_vc_sc_accordion_section",
					"category"                  => __( 'Berserk', 'berserk' ),
					"is_container"              => true,
					"allowed_container_element" => 'vc_row',
					"as_child"                  => array( 'only' => 'vc_accordion' ),
					"js_view"                   => 'VcAccordionTabView',
					"params"                    => $params


				) );
			}
		}

		public function shortcode_accordion_section( $atts, $content = null ) {

			$this->shortcode_id ++;

			$attributes = shortcode_atts( array(
				'title'          => '',
				'image'          => '',
				'active_section' => 'n'
			), $atts );

			$icon = berserk_shortcodes_icons_process( $atts );

			$image = wp_get_attachment_image_src( $attributes['image'], 'full' );
			$image = $image[0];

			self::$items[ $this->shortcode_id ]['title']          = $attributes['title'];
			self::$items[ $this->shortcode_id ]['content']        = do_shortcode( $content );
			self::$items[ $this->shortcode_id ]['icon']           = $icon;
			self::$items[ $this->shortcode_id ]['image']          = $image;
			self::$items[ $this->shortcode_id ]['active_section'] = $attributes['active_section'];
		}


	}

	// create shortcode
	BRS_Accordion_Section::get_instance();

}