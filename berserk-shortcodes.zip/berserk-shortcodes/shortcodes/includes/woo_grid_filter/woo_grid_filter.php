<?php
/**
 * BRS Woocommerce Grid_Filter shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Woo_Grid_Filter', false ) ) {

	require_once BERSERK_SHORTCODES_PATH . 'shortcodes/includes/shortcodes-ext.php';

	class BRS_Woo_Grid_Filter extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Woo_Grid_Filter();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_woo_grid_filter', array( $this, 'shortcode_grid_filter' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				$params = array();

				$params[] = array(
					"heading"    => __( "Main Settings", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$params[] = array(
					'heading'    => __( 'Woocommerce Grid Filter Type', 'berserk' ),
					'param_name' => 'woo_grid_filter_type',
					'type'       => 'brs_radio',
					'value'      => array(
						"Grid"    => "grid",
						"Cells"   => "cells",
						"Strict"  => "strict",
						"Special" => "special",
					),
					'images'     => array(
						"grid"    => 'woo_grid_filter/001.png',
						"cells"   => 'woo_grid_filter/002.png',
						"strict"  => 'woo_grid_filter/003.png',
						"special" => 'woo_grid_filter/004.png',
					),
					'images_dim' => array(
						'w' => '310',
						'h' => '150'
					)
				);

				$image_sizes = berserk_shortcodes_image_size_options();
				$params      = array_merge( $params, $image_sizes );

				$params[] = array(
					"heading"    => __( "Dynamic Content", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$params = array_merge( $params, berserk_shortcodes_dynamic_filter() );

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Woo: Grid Filter", 'berserk' ),
					"base"     => "brs_woo_grid_filter",
					"icon"     => "brs_vc_ico_grid_filter",
					"class"    => "brs_vc_sc_grid_filter",
					"category" => __( 'Woocommerce Berserk', 'berserk' ),
					"params"   => $params,

				) );
			}
		}

		public function shortcode_grid_filter( $atts, $content = null ) {

			brs_add_libraries( array( 'component__shop_grid_filter' ) );

			$product_categories = BRS_Shortcodes_VCParams::get_terms( 'product_cat' );

			$pairs = array(
				'woo_grid_filter_type' => 'grid',
				'image_size'           => '',
				'image_custom_width'   => '',
				'image_custom_height'  => '',

				'dynamic_content' => 'y',
				'custom_items'    => 'custom_items',
				'filters'         => '',
				'orderby'         => 'date',
				'order_direction' => 'ASC',
			);
			$atts  = shortcode_atts( $pairs, $atts );

			if ( $atts['dynamic_content'] == 'y' ) {
				$args  = array();
				$args  = array_merge( $args, berserk_shortcodes_dynamic_filter_process( $atts['filters'], $atts['orderby'], $atts['order_direction'] ) );
				$posts = get_posts( $args );
				$products = $posts;
			} else {
				$posts        = array();
				$custom_items = explode( ',', $atts['custom_items'] );
				foreach ( $custom_items as $item ) {
					$posts[] = get_post( $item );
					$products = $posts;
				}
			}
			
			$global_query = berserk_shortcodes_dynamic_filter_process( $atts['filters'], $atts['orderby'], $atts['order_direction'] );
			$product_cat_ids = array();
			if (isset($global_query['post_type'])){
				if ($global_query['post_type'] == 'product'){
					$tax_query = $global_query['tax_query'];
					foreach( $tax_query as $tax_query_item ){
						if( is_array($tax_query_item )){
							if( isset($tax_query_item['terms']) ){
								$term_object = get_term_by('slug', $tax_query_item['terms'], 'product_cat');
								$term_id = $term_object->term_id;
								$term_slug = $term_object->slug;
								$product_cat_ids[$term_id] = $term_slug;
							}
						};
					}
				}
			}

			$filters = vc_param_group_parse_atts( $atts['filters'] );

			$categories = array();

			foreach ( $posts as $post ) {
				$post          = wc_get_product( $post->ID );
				$categories_id = $post->get_category_ids();
				foreach ( $categories_id as $cat_id ) {
					$term                      = get_term( $cat_id );
					$categories[ $term->slug ] = $term->name;
				}
			}

			$atts['image_size'] = berserk_shortcodes_image_size_render( $atts );

			$output = '<div class="brk-shop-grid-filter">';
			switch ( $atts['woo_grid_filter_type'] ) {
				case "grid":

					$output .= '<ul class="brk-shop-grid-filter__button brk-shop-grid-filter__button_style-1">
								    <li class="checked" data-filter="*">
								    	<div class="brk-shop-grid-filter__button-text">
									      <i class="fal fa-th"></i>
									      ' . esc_html__( 'All', 'berserk' ) . '
								        </div>
								      <span class="before brk-base-bg-gradient-14"></span>
								    </li>';

					foreach ( $categories as $key => $category ) {
						//$term = get_term_by( 'slug', $category, 'product_cat' );
						$output .= '<li data-filter=".' . $key . '">
										<div class="brk-shop-grid-filter__button-text">
								      ' . $category . '
								        </div>
								      <span class="before brk-base-bg-gradient-14"></span>
								    </li>';
					}

					$output .= '</ul>
								  <div class="brk-shop-grid-filter__items row no-gutters">';

					foreach ( $posts as $post ) {
						$label_terms = get_the_terms( $post->ID, 'brs_product_type' );
						$labels      = array();
						if ( is_array( $label_terms ) && ! empty( $label_terms ) ) {
							foreach ( $label_terms as $term ) {
								$labels[] = $term->name;
							}
						}

						$bg_image           = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), $atts['image_size'] );
						$post               = wc_get_product( $post->ID );
						$currency           = get_woocommerce_currency_symbol();
						$product_attributes = $post->get_attributes();

						//dpm($product_attributes);

						$buy_now = apply_filters( 'woocommerce_loop_add_to_cart_link',
							sprintf( '<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="brk-shop-grid-filter-grid__buy-add brk-white-font-color font__weight-bold font__size-14 line__height-48 text-uppercase add-cart ajax_add_to_cart %s product_type_%s"><i class="fa fa-shopping-cart"></i>' . esc_html__( 'Buy now', 'berserk' ) . '</a>',
								esc_url( $post->add_to_cart_url() ),
								esc_attr( $post->get_id() ),
								esc_attr( $post->get_sku() ),
								$post->is_purchasable() ? 'add_to_cart_button' : '',
								esc_attr( $post->get_type() )
							),
							$post );

						$price = wc_price( $post->get_price() );

						$categories = $post->get_category_ids();
						$terms      = array();
						foreach ( $categories as $cat_id ) {
							$term    = get_term( $cat_id );
							$terms[] = $term->slug;
						}
						$terms = implode( ' ', $terms );

						$output .= '<div class="col-xl-3 col-md-6 brk-shop-grid-filter__item ' . $terms . '">
									      <div class="brk-shop-grid-filter-grid" style="background-image: url(' . esc_url( $bg_image[0] ) . ')">
											  <div class="brk-shop-grid-filter-grid__stick">';
						$i = 1;
						foreach ( $labels as $label ) {
							$label_class = ( $i % 2 ) ? 'brk-base-bg-gradient-14' : 'brk-base-bg-gradient-left-blue';
							$output .= '<span class="brk-white-font-color ' . $label_class . '">' . $label . '</span>';
							$i ++;
						}

						$output .= '</div>
											  <div class="brk-shop-grid-filter-grid__content">
											    <h4 class="font__family-montserrat font__weight-bold font__size-24 line__height-28 brk-white-font-color text-uppercase mb-35">' . esc_html( $post->get_name() ) . '</h4>';

						if ( ! empty( $product_attributes ) ) {
							$output .= '<ul class="brk-white-font-color font__size-14 line__height-21 mb-40">';

							foreach ( $product_attributes as $key => $attribute ) {
								$value = implode( ',', $attribute['options'] );
								$output .= '<li class="d-flex align-items-start"><i class="far fa-check font__size-16"></i>' . esc_html( $value ) . '</li>';
							}

							$output .= '</ul>';
						} else {
							$output .= '<p class="brk-white-font-color font__size-14 line__height-21 mb-40">' . $post->get_description() . '</p>';
						}


						$output .= '<div class="brk-shop-grid-filter-grid__buy brk-bg-grad">
											    ' . $buy_now . '
											      <span class="price font__weight-bold font__size-14 line__height-42 brk-base-font-color bg-white text-center">' . $price . '</span>
											    </div>
											  </div>
											</div>
								    </div>';
					}

					$output .= '</div>';

					break;

				case "cells":

					$output .= '<ul class="brk-shop-grid-filter__button brk-shop-grid-filter__button_style-1">
				                    <li class="checked" data-filter="*">
				                    	<div class="brk-shop-grid-filter__button-text">
					                        <i class="fal fa-th"></i>
					                        ' . esc_html__( 'All', 'berserk' ) . '
				                        </div>
				                        <span class="before brk-base-bg-gradient-14"></span>
				                    </li>';
					foreach ( $categories as $key => $category ) {
						//$term = get_term_by( 'slug', $category, 'product_cat' );
						$output .= '<li data-filter=".' . $key . '">
										<div class="brk-shop-grid-filter__button-text">
								        ' . $category . '
								        </div>
								      <span class="before brk-base-bg-gradient-14"></span>
								    </li>';
					}

					$output .= '</ul>

				                <div class="brk-shop-grid-filter__items row no-gutters">';

					foreach ( $posts as $post ) {
						$label_terms = get_the_terms( $post->ID, 'brs_product_type' );
						$labels      = array();
						if ( is_array( $label_terms ) && ! empty( $label_terms ) ) {
							foreach ( $label_terms as $term ) {
								$labels[] = $term->name;
							}
						}

						$bg_image           = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), $atts['image_size'] );
						$post               = wc_get_product( $post->ID );
						$rate               = $post->get_average_rating() * 20;
						$currency           = get_woocommerce_currency_symbol();
						$product_attributes = $post->get_attributes();
						$price              = wc_price( $post->get_price() );

						$buy_now = apply_filters( 'woocommerce_loop_add_to_cart_link',
							sprintf( '<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="brk-shop-grid-filter-cells__buy font__family-montserrat font__weight-light font__size-16 add-cart ajax_add_to_cart %s product_type_%s">
														<span class="brk-white-font-color">' . $price . '</span>
				                                        <span class="text brk-base-font-color text-center"><i class="fa fa-shopping-cart"></i>' . esc_html__( ' Buy', 'berserk' ) . '</span></a>',
								esc_url( $post->add_to_cart_url() ),
								esc_attr( $post->get_id() ),
								esc_attr( $post->get_sku() ),
								$post->is_purchasable() ? 'add_to_cart_button' : '',
								esc_attr( $post->get_type() )
							),
							$post );


						$categories = $post->get_category_ids();
						$terms      = array();
						foreach ( $categories as $cat_id ) {
							$term    = get_term( $cat_id );
							$terms[] = $term->slug;
						}
						$terms = implode( ' ', $terms );

						$output .= '<div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-12 brk-shop-grid-filter__item ' . $terms . '">
				                        <div class="brk-shop-grid-filter-cells"
				                             style="background-image: url(' . esc_url( $bg_image[0] ) . ')">
				                            <div class="before brk-base-bg-gradient-10deg"></div>
				                            <div class="brk-shop-grid-filter-cells__content d-flex flex-wrap align-content-between">
				                                <div class="w-100">
				                                    <div class="brk-shop-grid-filter-cells__stick font__family-montserrat font__weight-light text-uppercase text-center brk-white-font-color d-flex flex-wrap mb-15">';
						foreach ( $labels as $label ) {
							$output .= '<span class="brk-base-bg-gradient-left-blue font__size-12">' . $label . '</span>';
						}

						$output .= '</div>
				                                    <h4 class="font__family-montserrat font__weight-light font__size-18 line__height-22 brk-white-font-color">' . esc_html( $post->get_name() ) . '</h4>
				                                </div>

				                                <div class="w-100 d-flex flex-wrap justify-content-between align-items-end">
				                                    <div class="brk-shop-grid-filter-cells__rating">
				                                        <div class="font__family-montserrat font__weight-light brk-white-font-color font__size-14">
				                                            ' . esc_html__( 'Rating:', 'berserk' ) . '
				                                        </div>
				                                        <div class="brk-rating">
				                                            <div class="brk-rating__layer">
				                                                <i class="fal fa-star brk-dark-font-color"></i>
				                                                <i class="fal fa-star brk-dark-font-color"></i>
				                                                <i class="fal fa-star brk-dark-font-color"></i>
				                                                <i class="fal fa-star brk-dark-font-color"></i>
				                                                <i class="fal fa-star brk-dark-font-color"></i>
				                                            </div>
				                                            <div class="brk-rating__imposition" style="width: ' . $rate . '%">
				                                                <div class="visible">
				                                                    <i class="fas fa-star brk-base-font-color"></i>
				                                                    <i class="fas fa-star brk-base-font-color"></i>
				                                                    <i class="fas fa-star brk-base-font-color"></i>
				                                                    <i class="fas fa-star brk-base-font-color"></i>
				                                                    <i class="fas fa-star brk-base-font-color"></i>
				                                                </div>
				                                            </div>
				                                        </div>
				                                    </div>
				                                    ' . $buy_now . '
				                                </div>
				                            </div>
				                        </div>
				                    </div>';

					}

					$output .= '</div>';

					break;

				case "strict":

					$output .= '<ul class="brk-shop-grid-filter__button brk-shop-grid-filter__button_style-2 font__family-montserrat brk-base-font-color font__weight-medium">';

					foreach ( $categories as $key => $category ) {
						//$term = get_term_by( 'slug', $category, 'product_cat' );
						$output .= '<li data-filter=".' . $key . '">
								      ' . $category . '
								      <span class="before brk-base-bg-gradient-14"></span>
								    </li>';
					}

					$output .= '<li class="all checked" data-filter="*">
			                            ' . esc_html__( 'All', 'berserk' ) . '
			                            <i class="fas fa-th"></i>
			                            <span class="before brk-base-bg-gradient-14"></span>
			                        </li>
			                    </ul>

			                    <div class="brk-shop-grid-filter__items row">';

					foreach ( $posts as $post ) {
						$label_terms = get_the_terms( $post->ID, 'brs_product_type' );
						$labels      = array();
						if ( is_array( $label_terms ) && ! empty( $label_terms ) ) {
							foreach ( $label_terms as $term ) {
								$labels[] = $term->name;
							}
						}
						$labels = implode( ' ', $labels );

						$bg_image           = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), $atts['image_size'] );
						$post               = wc_get_product( $post->ID );
						$rate               = $post->get_average_rating() * 20;
						$currency           = get_woocommerce_currency_symbol();
						$old_price          = $post->get_sale_price() !== '' ? wc_price( $post->get_regular_price() ) : '';
						$product_attributes = $post->get_attributes();

						$price = wc_price( $post->get_price() );

						$buy_now = apply_filters( 'woocommerce_loop_add_to_cart_link',
							sprintf( '<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="brk-bg-color add-cart ajax_add_to_cart %s product_type_%s">
														<i class="fa fa-shopping-cart brk-white-font-color"></i></a>',
								esc_url( $post->add_to_cart_url() ),
								esc_attr( $post->get_id() ),
								esc_attr( $post->get_sku() ),
								$post->is_purchasable() ? 'add_to_cart_button' : '',
								esc_attr( $post->get_type() )
							),
							$post );


						$wishlist_btn_class = "add_to_wishlist add-wishlist brk-bg-color";
						$wishlist           = get_post_meta( $post->get_id(), 'wishlist' );
						if ( isset( $wishlist[0] ) && $wishlist[0] == 'true' ) {
							$wishlist_btn_class = "remove_from_wishlist add-wishlist brk-bg-color";
						}

						$compare_btn_class = "add_to_compare add-compare brk-bg-color";
						$compare           = get_post_meta( $post->get_id(), 'compare' );
						if ( isset( $compare[0] ) && $compare[0] == 'true' ) {
							$compare_btn_class = "remove_from_compare add-compare brk-bg-color";
						}

						$categories = $post->get_category_ids();
						$terms      = array();
						foreach ( $categories as $cat_id ) {
							$term    = get_term( $cat_id );
							$terms[] = $term->slug;
						}
						$terms = implode( ' ', $terms );

						$output .= '<div class="col-xl-4 col-md-6 brk-shop-grid-filter__item ' . $terms . '">
			                            <div class="brk-shop-grid-filter-strict">
			                                <div class="brk-shop-grid-filter-strict__thumb">
			                                    <img src="' . esc_url( $bg_image[0] ) . '" alt="">
			                                </div>
			                                <div class="brk-shop-grid-filter-strict__inform text-center d-flex flex-column align-content-center justify-content-center">
			                                    <h4 class="font__family-montserrat font__weight-bold font__size-18">' . esc_html( $post->get_name() ) . '</h4>
			                                    <div class="price brk-base-font-color font__family-montserrat font__size-15 line__height-22 font__weight-medium">';

						if ( $old_price !== '' ) {
							$output .= '<span class="old-price brk-dark-font-color">' . $old_price . '</span>';
						}

						$output .= '<span class="font__weight-bold">' . $price . '</span>
			                                    </div>
			                                </div>';
						if ( ! empty( $labels ) ) {
							$output .= '<div class="brk-shop-grid-filter-strict__stick brk-white-font-color font__family-montserrat font__weight-bold">
			                                    ' . esc_html( $labels ) . '
			                                </div>';
						}

						$output .= '<div class="before brk-sc-tiles-split-gradient"></div>

			                                <div class="brk-shop-grid-filter-strict__back">

			                                    <div class="brk-shop-grid-filter-strict__inform text-center d-flex flex-column align-content-center justify-content-center">
			                                        <h4 class="font__family-montserrat font__weight-bold font__size-18">' . esc_html( $post->get_name() ) . '</h4>
			                                        <div class="price brk-base-font-color font__family-montserrat font__size-15 line__height-22 font__weight-medium">';
						if ( $old_price !== '' ) {
							$output .= '<span class="old-price brk-dark-font-color">' . $old_price . '</span>';
						}
						$output .= '<span class="font__weight-bold">' . $price . '</span>
			                                        </div>
			                                    </div>

			                                    <div class="brk-shop-grid-filter-strict__list pt-40 pb-40">';

						if ( ! empty( $product_attributes ) ) {
							$output .= '<ul class="font__size-15 line__height-20 font__weight-light text-left letter-spacing-60">';

							foreach ( $product_attributes as $key => $attribute ) {
								$value = implode( ',', $attribute['options'] );
								$output .= '<li class="d-flex"><i class="far fa-check brk-blue-light-font-color"></i>
                                            <span class="letter-spacing-40">' . esc_html( $value ) . '</span>
                                        </li>';
							}

							$output .= '</ul>';
						} else {
							$output .= '<p class="font__size-15 line__height-20 font__weight-light text-left letter-spacing-60">' . $post->get_description() . '</p>';

						}


						$output .= '</div>
		                                    <div class="text-center pt-35">
		                                        <div class="brk-shop-grid-filter-strict__actions clearfix brk-base-box-shadow-primary">
		                                            ' . $buy_now . '
		                                            <a href="' . esc_url( add_query_arg( 'add_to_wishlist', $post->get_id() ) ) . '" rel="nofollow" data-product-id="' . $post->get_id() . '" class="' . $wishlist_btn_class . '" >
														<i class="fal fa-star brk-white-font-color"></i>
													</a>
													<a href="' . esc_url( add_query_arg( 'add_to_compare', $post->get_id() ) ) . '" rel="nofollow" data-product-id="' . $post->get_id() . '" class="' . $compare_btn_class . '" >
														<i class="fal fa-exchange brk-white-font-color"></i>
													</a>
		                                        </div>
		                                    </div>

		                                </div>
		                            </div>
		                        </div>';
					}

					$output .= '</div>';

					break;

				case "special":

					$output .= '<ul class="brk-shop-grid-filter__button brk-shop-grid-filter__button_style-3 text-uppercase brk-white-font-color d-flex justify-content-center align-items-center flex-wrap font__family-open-sans font__weight-ultralight">';

					$i = 1;

					if ( !empty($product_cat_ids) ){
						foreach ( $product_cat_ids as $id => $slug ) {
							$term         = get_term_by( 'slug', $slug, 'product_cat' );
							
							$thumbnail_id = get_woocommerce_term_meta( $id, 'thumbnail_id', true ); 
							$bg_image     = wp_get_attachment_image_url( $thumbnail_id, 'woo-grid_filter_special_thumb' );
		
							$item_class = ( $i == 2 ) ? 'class="checked"' : '';
	
							$output .= '<li ' . $item_class . ' data-filter=".' . $slug . '" style="background-image: url(' . esc_url( $bg_image ) . ')">
										  <span class="text">' . $term->name . '</span>
										  <span class="before brk-base-bg-gradient-13"></span>
										</li>';
							$i ++;
						}
					} else {
						foreach ( $categories as $key => $category ) {
							$term         = get_term_by( 'slug', $key, 'product_cat' );
							$id           = $term->term_id;
							$thumbnail_id = get_term_meta( $id, 'thumbnail_id', true );
							$bg_image     = wp_get_attachment_image_src( $thumbnail_id, 'woo-grid_filter_special_thumb' );
	
							$item_class = ( $i == 2 ) ? 'class="checked"' : '';
	
							$output .= '<li ' . $item_class . ' data-filter=".' . $key . '" style="background-image: url(' . esc_url( $bg_image[0] ) . ')">
										  <span class="text">' . $term->name . '</span>
										  <span class="before brk-base-bg-gradient-13"></span>
										</li>';
							$i ++;
						}
					}

					$output .= '</ul>
			                    <div class="brk-shop-grid-filter__items row no-gutters">';
					
					
					/*if ( !empty($product_cat_ids) ){
						$posts = get_posts( $args );
					*/

					foreach ( $posts as $post ) {
						$label_terms = get_the_terms( $post->ID, 'brs_product_type' );
						$labels      = array();
						if ( is_array( $label_terms ) && ! empty( $label_terms ) ) {
							foreach ( $label_terms as $term ) {
								$labels[] = $term->name;
							}
						}

						$bg_image           = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), $atts['image_size'] );
						$post               = wc_get_product( $post->ID );
						$rate               = $post->get_average_rating() * 20;
						$currency           = get_woocommerce_currency_symbol();
						$old_price          = $post->get_sale_price() !== '' ? wc_price( $post->get_regular_price() ) : '';
						$product_attributes = $post->get_attributes();

						$price = wc_price( $post->get_price() );

						$buy_now = apply_filters( 'woocommerce_loop_add_to_cart_link',
							sprintf( '<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="brk-shop-grid-filter-special__buy brk-base-bg-gradient-13 brk-base-box-shadow-primary add-cart ajax_add_to_cart %s product_type_%s">
														<span class="text brk-white-font-color text-uppercase font__family-montserrat font__weight-light font__size-14 line__height-44">' . esc_html__( 'Buy it now', 'berserk' ) . '</span>
			                                            <span class="icon brk-base-font-color brk-base-box-shadow-primary"><i class="fa fa-shopping-cart"></i></span></a>',
								esc_url( $post->add_to_cart_url() ),
								esc_attr( $post->get_id() ),
								esc_attr( $post->get_sku() ),
								$post->is_purchasable() ? 'add_to_cart_button' : '',
								esc_attr( $post->get_type() )
							),
							$post );

						$categories = $post->get_category_ids();
						$terms      = array();
						foreach ( $categories as $cat_id ) {
							$term    = get_term( $cat_id );
							$terms[] = $term->slug;
						}
						$terms = implode( ' ', $terms );

						$output .= '<div class="col-xl-3 col-lg-4 col-sm-6 brk-shop-grid-filter__item ' . $terms . '">
			                            <div class="brk-shop-grid-filter-special bg-white">
			                                <img class="brk-shop-grid-filter-special__thumb" src="' . esc_url( $bg_image[0] ) . '" alt="">

			                                <div class="brk-shop-grid-filter-special__stick brk-white-font-color font__family-montserrat font__weight-light text-uppercase">';

						foreach ( $labels as $label ) {
							$output .= '<div class="stick"><span>' . $label . '</span></div>';
						}

						$output .= '</div>
			                                <div class="brk-shop-grid-filter-special__container">
			                                    <div class="brk-shop-grid-filter-special__content text-center">
			                                        <div class="brk-shop-grid-filter-special__title mb-30">
			                                            <h4 class="font__family-montserrat font__weight-light font__size-20 line__height-24 brk-white-font-color text-uppercase">
			                                                ' . esc_html( $post->get_name() ) . '</h4>
			                                        </div>
			                                        <div class="brk-white-font-color font__family-montserrat mb-40">';
						if ( $old_price !== '' ) {
							$output .= '<span class="old-price brk-dark-font-color font__size-13">' . $old_price . '</span>';
						}

						$output .= '<span class="font__size-18">' . $price . '</span>
			                                        </div>
			                                        ' . $buy_now . '
			                                    </div>
			                                </div>
			                            </div>
			                        </div>';

					}

					$output .= '</div>';

					break;
			}


			$output .= '</div>';

			return $output;
		}
	}

	// create shortcode
	BRS_Woo_Grid_Filter::get_instance();

}
