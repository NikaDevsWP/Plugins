<?php
/**
 * App Showcase shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Shortcode progress bars class.
 *
 */
class BRS_App_Showcase extends BRS_Shortcode {

	static protected $instance;
	static protected $atts = array();

	public static function get_instance() {
		if ( ! self::$instance ) {
			self::$instance = new BRS_App_Showcase();
		}

		return self::$instance;
	}

	protected function __construct() {

		add_shortcode( 'brs_app_showcase', array( $this, 'shortcode_app' ) );
		add_action( 'init', array( $this, 'admin_init' ) );
	}

	public function admin_init() {
		if ( function_exists( "vc_map" ) ) {
			vc_map( array(
				"weight"   => - 1,
				"name"     => __( "App Showcase", 'berserk' ),
				"base"     => "brs_app_showcase",
				"icon"     => "brs_app_showcase",
				"class"    => "brs_app_showcase",
				"category" => __( 'Berserk', 'berserk' ),
				"params"   => array(
					array(
						'heading'    => __( 'App Showcase Type', 'berserk' ),
						'param_name' => 'app_showcase_type',
						'type'       => 'brs_radio',
						'value'      => array(
							"iPad"            => "ipad",
							"iPhone Lined"    => "iphone_lined",
							"iPhone Simple"   => "iphone_simple",
							"Notebook"        => "notebook",
							"Single Notebook" => "single_notebook",
						),
						'images'     => array(
							"ipad"            => 'app/ipad.jpg',
							"iphone_lined"    => 'app/iphone_lined.jpg',
							"iphone_simple"   => 'app/iphone_simple.jpg',
							"notebook"        => 'app/notebook.jpg',
							"single_notebook" => 'app/notebook.jpg',
						),
						'images_dim' => array(
							'w' => '210',
							'h' => '100'
						)
					),
					array(
						'type'       => 'param_group',
						'heading'    => __( 'Values', 'js_composer' ),
						'param_name' => 'values',
						'value'      => urlencode( json_encode( array(
							array(
								'f_label'       => __( 'Awesome', 'js_composer' ),
								's_label'       => __( 'Design', 'js_composer' ),
								'description'   => __( 'Aenean vulputate eleifend', 'js_composer' ),
								'number'        => '01',
								'side'          => 'left',
								'arrow_pointer' => 'arrow__pointer-top-left',
							),
							array(
								'f_label'       => __( 'Awesome', 'js_composer' ),
								's_label'       => __( 'Design', 'js_composer' ),
								'description'   => __( 'Aenean vulputate eleifend', 'js_composer' ),
								'number'        => '02',
								'side'          => 'right',
								'arrow_pointer' => 'arrow__pointer-top-right',
							),
							array(
								'f_label'       => __( 'Awesome', 'js_composer' ),
								's_label'       => __( 'Design', 'js_composer' ),
								'description'   => __( 'Aenean vulputate eleifend', 'js_composer' ),
								'number'        => '03',
								'side'          => 'left',
								'arrow_pointer' => 'arrow__pointer-bottom-left',
							),
							array(
								'f_label'       => __( 'Awesome', 'js_composer' ),
								's_label'       => __( 'Design', 'js_composer' ),
								'description'   => __( 'Aenean vulputate eleifend', 'js_composer' ),
								'number'        => '04',
								'side'          => 'right',
								'arrow_pointer' => 'arrow__pointer-bottom-right',
							),

						) ) ),
						'params'     => array(
							array(
								'type'        => 'textfield',
								'heading'     => __( 'First Label', 'js_composer' ),
								'param_name'  => 'f_label',
								'admin_label' => true,
							),
							array(
								'type'        => 'textfield',
								'heading'     => __( 'Second Label', 'js_composer' ),
								'param_name'  => 's_label',
								'admin_label' => true,
							),
							array(
								'type'             => 'textarea',
								'heading'          => __( 'Description', 'js_composer' ),
								'param_name'       => 'description',
								'edit_field_class' => 'vc_col-sm-6 vc_column',
							),
							array(
								'type'             => 'textfield',
								'heading'          => esc_html__( 'Description CSS Class', 'berserk' ),
								'param_name'       => 'description_class',
								'edit_field_class' => 'vc_col-sm-6 vc_column',
							),
							array(
								'type'             => 'textfield',
								'heading'          => __( 'Number', 'js_composer' ),
								'param_name'       => 'number',
								'edit_field_class' => 'vc_col-sm-6 vc_column',
								'admin_label'      => true,
							),
							array(
								'type'             => 'dropdown',
								'heading'          => __( 'Side', 'berserk' ),
								'value'            => array(
									__( 'Left Side', 'berserk' )  => 'left',
									__( 'Right Side', 'berserk' ) => 'right',
								),
								'param_name'       => 'side',
								'edit_field_class' => 'vc_col-sm-6 vc_column',
							),
							array(
								'type'             => 'dropdown',
								'heading'          => __( 'Arrow Pointer Class', 'berserk' ),
								'value'            => array(
									__( 'Top-Left', 'berserk' )     => 'arrow__pointer-top-left',
									__( 'Bottom-Left', 'berserk' )  => 'arrow__pointer-bottom-left',
									__( 'Top-Right', 'berserk' )    => 'arrow__pointer-top-right',
									__( 'Bottom-Right', 'berserk' ) => 'arrow__pointer-bottom-right',
								),
								'param_name'       => 'arrow_pointer',
								'edit_field_class' => 'vc_col-sm-6 vc_column',
							),

							array(
								'type'             => 'dropdown',
								'heading'          => __( 'Icon library', 'berserk' ),
								'value'            => array(
									__( 'Font Awesome', 'berserk' ) => 'fontawesome',
									__( 'Open Iconic', 'berserk' )  => 'openiconic',
									__( 'Typicons', 'berserk' )     => 'typicons',
									__( 'Entypo', 'berserk' )       => 'entypo',
									__( 'Linecons', 'berserk' )     => 'linecons',
									__( 'Mono Social', 'berserk' )  => 'monosocial',
									__( 'Livicon', 'berserk' )      => 'livicon',
								),
								'admin_label'      => true,
								'param_name'       => 'btn_icon_type',
								'edit_field_class' => 'vc_col-sm-6 vc_column icon_option',
							),
							array(
								'type'             => 'iconpicker',
								'heading'          => __( 'Icon', 'berserk' ),
								'param_name'       => 'icon_fontawesome',
								'value'            => 'fa fa-adjust',
								'settings'         => array(
									'emptyIcon'    => false,
									'iconsPerPage' => 4000,
								),
								'dependency'       => array(
									'element' => 'btn_icon_type',
									'value'   => 'fontawesome',
								),
								'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
							),
							array(
								'type'             => 'iconpicker',
								'heading'          => __( 'Icon', 'berserk' ),
								'param_name'       => 'icon_openiconic',
								'value'            => 'vc-oi vc-oi-dial',
								'settings'         => array(
									'emptyIcon'    => false,
									'type'         => 'openiconic',
									'iconsPerPage' => 4000,
								),
								'dependency'       => array(
									'element' => 'btn_icon_type',
									'value'   => 'openiconic',
								),
								'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
							),
							array(
								'type'             => 'iconpicker',
								'heading'          => __( 'Icon', 'berserk' ),
								'param_name'       => 'icon_typicons',
								'value'            => 'typcn typcn-adjust-brightness',
								'settings'         => array(
									'emptyIcon'    => false,
									'type'         => 'typicons',
									'iconsPerPage' => 4000,
								),
								'dependency'       => array(
									'element' => 'btn_icon_type',
									'value'   => 'typicons',
								),
								'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
							),
							array(
								'type'             => 'iconpicker',
								'heading'          => __( 'Icon', 'berserk' ),
								'param_name'       => 'icon_entypo',
								'value'            => 'entypo-icon entypo-icon-note',
								'settings'         => array(
									'emptyIcon'    => false,
									'type'         => 'entypo',
									'iconsPerPage' => 4000,
								),
								'dependency'       => array(
									'element' => 'btn_icon_type',
									'value'   => 'entypo',
								),
								'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
							),
							array(
								'type'             => 'iconpicker',
								'heading'          => __( 'Icon', 'berserk' ),
								'param_name'       => 'icon_linecons',
								'value'            => 'vc_li vc_li-heart',
								'settings'         => array(
									'emptyIcon'    => false,
									'type'         => 'linecons',
									'iconsPerPage' => 4000,
								),
								'dependency'       => array(
									'element' => 'btn_icon_type',
									'value'   => 'linecons',
								),
								'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
							),
							array(
								'type'             => 'iconpicker',
								'heading'          => __( 'Icon', 'berserk' ),
								'param_name'       => 'icon_monosocial',
								'value'            => 'vc-mono vc-mono-fivehundredpx',
								'settings'         => array(
									'emptyIcon'    => false,
									'type'         => 'monosocial',
									'iconsPerPage' => 4000,
								),
								'dependency'       => array(
									'element' => 'btn_icon_type',
									'value'   => 'monosocial',
								),
								'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
							),

							array(
								"heading"          => __( "Add livicon", 'berserk' ),
								"param_name"       => "brs_btn_icon",
								"type"             => "brs_btn_icon",
								'dependency'       => array(
									'element' => 'btn_icon_type',
									'value'   => 'livicon',
								),
								'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
							),
						),
						'edit_field_class' => 'vc_col-xs-12 vc_column brk-dependency__app_showcase_type ipad iphone_lined iphone_simple notebook',
					),
					array(
						'type'       => 'attach_image',
						'heading'    => __( 'Image', 'js_composer' ),
						'param_name' => 'image',
						'value'      => ''
					),
					array(
						'type'             => 'textfield',
						'heading'          => __( 'Caption', 'js_composer' ),
						'param_name'       => 'caption',
						'value'            => 'Our app',
						'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__app_showcase_type ipad iphone_lined iphone_simple notebook',
					),
				)
			) );

		}
	}

	public function shortcode_app( $atts, $content = null ) {

		$libraries = array( 'component__app_showcase', 'wow' );
		brs_add_libraries( $libraries );

		extract( shortcode_atts( array(
			'values'            => '',
			'app_showcase_type' => 'ipad',
			'image'             => '',
			'caption'           => 'Our app',
		), $atts ) );

		$values = vc_param_group_parse_atts( $values );
		$output = '';

		$image = wp_get_attachment_image_src( $image, 'full' );
		$image = $image[0];

		switch ( $app_showcase_type ) {

			case "ipad":
				$output = '<div class="row row-no-gutter align-items-center">
							<div class="col-xl-8 order-xl-1 text-center">
				            <span class="app-img-caption">' . $caption . '</span>
				            <img src="' . esc_url( $image ) . '" alt="">
				          </div>
				          <div class="col-md-6 col-xl-2">';

				$i = 0;
				foreach ( $values as $value ) {
					if ( $value['side'] == 'left' ) {
						vc_icon_element_fonts_enqueue( $value['btn_icon_type'] );
						$icon_class                     = array();
						$icon_class['type']             = $value['btn_icon_type'];
						$icon_class['icon_livicon']     = '';
						$icon_class['icon_fontawesome'] = $value['icon_fontawesome'];
						$icon_class['icon_openiconic']  = $value['icon_openiconic'];
						$icon_class['icon_typicons']    = $value['icon_typicons'];
						$icon_class['icon_entypo']      = $value['icon_entypo'];
						$icon_class['icon_linecons']    = $value['icon_linecons'];
						$icon_class['icon_monosocial']  = $value['icon_monosocial'];
						$icon_class                     = $this->get_icon_class( $icon_class );
						$icon_html                      = ' <i class="icon ' . $icon_class . '"></i>';

						$description_class = ' text-gray';
						if( isset( $value['description_class'] ) ) {
							if( $value['description_class'] ) {
								$description_class = ' ' . $value['description_class'];
							}
						}

						if ( isset( $value['brs_btn_icon'] ) ) {
							$svg_icon  = do_shortcode( $value['brs_btn_icon'] );
							$icon_html = $svg_icon;
						}
						$mt_class = '';
						if ( $i == 0 ) {
							$mt_class = 'mt-xl-70';
						}
						$output .= '<div class="text-xl-right mt-50 mt-xl-70 wow fadeInLeft ' . $mt_class . '">
						              ' . $icon_html . '
						              <h3 class="font__family-montserrat font__weight-light font__size-24 line__height-30 text-uppercase mt-30">' . $value['f_label'] . '</h3>
						              <h3 class="font__family-montserrat font__weight-bold font__size-24 line__height-30 text-uppercase">' . $value['s_label'] . '</h3>
						              <p class="font__family-open-sans font__size-14 mt-10' . esc_attr( $description_class ) . '">' . $value['description'] . '</p>
						            </div>';
					}
					$i ++;
				}

				$output .= '</div>
				          <div class="col-md-6 col-xl-2 order-xl-2">';
				$i = 0;
				foreach ( $values as $value ) {
					if ( $value['side'] == 'right' ) {
						$icon_class                     = array();
						$icon_class['type']             = $value['btn_icon_type'];
						$icon_class['icon_livicon']     = '';
						$icon_class['icon_fontawesome'] = $value['icon_fontawesome'];
						$icon_class['icon_openiconic']  = $value['icon_openiconic'];
						$icon_class['icon_typicons']    = $value['icon_typicons'];
						$icon_class['icon_entypo']      = $value['icon_entypo'];
						$icon_class['icon_linecons']    = $value['icon_linecons'];
						$icon_class['icon_monosocial']  = $value['icon_monosocial'];
						$icon_class                     = $this->get_icon_class( $icon_class );
						$icon_html                      = ' <i class="icon ' . $icon_class . '"></i>';

						$description_class = ' text-gray';
						if( isset( $value['description_class'] ) ) {
							if( $value['description_class'] ) {
								$description_class = ' ' . $value['description_class'];
							}
						}

						if ( isset( $value['brs_btn_icon'] ) ) {
							$svg_icon  = do_shortcode( $value['brs_btn_icon'] );
							$icon_html = $svg_icon;
						}
						$mt_class = '';
						if ( $i == 2 ) {
							$mt_class = 'mt-xl-70';
						}
						$output .= '<div class="text-xl-left mt-50 wow fadeInRight ' . $mt_class . '">
						              ' . $icon_html . '
						              <h3 class="font__family-montserrat font__weight-light font__size-24 line__height-30 text-uppercase mt-30">' . $value['f_label'] . '</h3>
						              <h3 class="font__family-montserrat font__weight-bold font__size-24 line__height-30 text-uppercase">' . $value['s_label'] . '</h3>
						              <p class="font__family-open-sans font__size-14 mt-10' . esc_attr( $description_class ) . '">' . $value['description'] . '</p>
						            </div>';
					}
					$i ++;
				}
				$output .= '</div>
						</div>';

				break;
			case "iphone_lined":
				$output = '<div class="row align-items-center">
				            <div class="col-lg-4 order-lg-1">
				              <div class="mobile-case-1" style="background: url(' . BERSERK_SHORTCODES_URL . '/shortcodes/img/app-case-1.png)">
				                <div class="mobile-bg" style="background: url(' . esc_url( $image ) . ') center center;"></div>
				              </div>
				            </div>
				            <div class="col-md-6 col-lg-4">';
				$i      = 0;
				foreach ( $values as $value ) {
					if ( $value['side'] == 'left' ) {
						vc_icon_element_fonts_enqueue( $value['btn_icon_type'] );
						$icon_class                     = array();
						$icon_class['type']             = $value['btn_icon_type'];
						$icon_class['icon_livicon']     = '';
						$icon_class['icon_fontawesome'] = $value['icon_fontawesome'];
						$icon_class['icon_openiconic']  = $value['icon_openiconic'];
						$icon_class['icon_typicons']    = $value['icon_typicons'];
						$icon_class['icon_entypo']      = $value['icon_entypo'];
						$icon_class['icon_linecons']    = $value['icon_linecons'];
						$icon_class['icon_monosocial']  = $value['icon_monosocial'];
						$icon_class                     = $this->get_icon_class( $icon_class );
						$icon_html                      = ' <i class="icon ' . $icon_class . '" aria-hidden="true"></i>';

						$description_class = ' text-blue-3';
						if( isset( $value['description_class'] ) ) {
							if( $value['description_class'] ) {
								$description_class = ' ' . $value['description_class'];
							}
						}

						if ( isset( $value['brs_btn_icon'] ) ) {
							$svg_icon  = do_shortcode( $value['brs_btn_icon'] );
							$icon_html = $svg_icon;
						}
						$mt_class = '';
						if ( $i == 0 ) {
							$mt_class = 'mt-lg-0';
						}
						$output .= '<div class="text-lg-right z-index-high mt-30 wow fadeInUp ' . $mt_class . '">
					                <img src="' . BERSERK_SHORTCODES_URL . '/shortcodes/img/arrow-pointer.png" class="' . $value['arrow_pointer'] . '" alt="">
					                <div class="inline-wrap inline-wrap-second">
					                  <button class="icon__btn icon__btn-anim icon__btn-center icon__btn-md_1 mr-lg-0 ml-lg-20 order-lg-1">
					                    <span class="after"></span>
					                    <span class="spike"></span>
					                    <span class="spike"></span>
					                    <span class="spike"></span>
					                    <span class="spike"></span>
					                    <span class="spike"></span>
					                    <span class="spike"></span>
					                    <span class="spike"></span>
					                    <span class="spike"></span>
					                    <span class="spike"></span>
					                    <span class="before"></span>
					                    ' . $icon_html . '
					                  </button>
					                  <div><h4 class="font__family-montserrat font__weight-light font__size-24 text-uppercase">' . $value['f_label'] . '</h4></div>
					                </div>
					                <p class="font__family-open-sans font__size-16 line__height-26 mt-10' . esc_attr( $description_class ) . '">' . $value['description'] . '</p>
					              </div>';
					}
					$i ++;
				}

				$output .= '</div>
				            <div class="col-md-6 col-lg-4 order-lg-2">';
				$i = 0;
				foreach ( $values as $value ) {
					if ( $value['side'] == 'right' ) {
						vc_icon_element_fonts_enqueue( $value['btn_icon_type'] );
						$icon_class                     = array();
						$icon_class['type']             = $value['btn_icon_type'];
						$icon_class['icon_livicon']     = '';
						$icon_class['icon_fontawesome'] = $value['icon_fontawesome'];
						$icon_class['icon_openiconic']  = $value['icon_openiconic'];
						$icon_class['icon_typicons']    = $value['icon_typicons'];
						$icon_class['icon_entypo']      = $value['icon_entypo'];
						$icon_class['icon_linecons']    = $value['icon_linecons'];
						$icon_class['icon_monosocial']  = $value['icon_monosocial'];
						$icon_class                     = $this->get_icon_class( $icon_class );
						$icon_html                      = ' <i class="icon ' . $icon_class . '" aria-hidden="true"></i>';

						$description_class = ' text-blue-3';
						if( isset( $value['description_class'] ) ) {
							if( $value['description_class'] ) {
								$description_class = ' ' . $value['description_class'];
							}
						}

						if ( isset( $value['brs_btn_icon'] ) ) {
							$svg_icon  = do_shortcode( $value['brs_btn_icon'] );
							$icon_html = $svg_icon;
						}
						$mt_class = '';
						if ( $i == 1 ) {
							$mt_class = 'mt-lg-0';
						}
						$output .= '<div class="text-lg-left z-index-high mt-30 wow fadeInUp ' . $mt_class . '" data-wow-delay="0.2s">
					                <img src="' . BERSERK_SHORTCODES_URL . '/shortcodes/img/arrow-pointer.png" class="' . $value['arrow_pointer'] . '" alt="">
					                <div class="inline-wrap inline-wrap-second">
					                  <button class="icon__btn icon__btn-anim icon__btn-center icon__btn-center icon__btn-md_1 ml-lg-0 mr-lg-20">
					                    <span class="after"></span>
					                    <span class="spike"></span>
					                    <span class="spike"></span>
					                    <span class="spike"></span>
					                    <span class="spike"></span>
					                    <span class="spike"></span>
					                    <span class="spike"></span>
					                    <span class="spike"></span>
					                    <span class="spike"></span>
					                    <span class="spike"></span>
					                    <span class="before"></span>
					                    ' . $icon_html . '
					                  </button>
					                  <div><h4 class="font__family-montserrat font__weight-light font__size-24 text-uppercase">' . $value['f_label'] . '</h4></div>
					                </div>
					                <p class="font__family-open-sans font__size-16 line__height-26 mt-10' . esc_attr( $description_class ) . '">' . $value['description'] . '</p>
					              </div>';
					}
					$i ++;
				}

				$output .= '</div>
				          </div>';

				break;

			case "iphone_simple":
				$output = '<div class="row">
					          <div class="col-xl-4 order-xl-1">
					            <div class="mobile-case-2">
					              <div class="mobile-bg" style="background: url(' . esc_url( $image ) . ') center center;"></div>
					            </div>
					          </div>
					          <div class="col-md-6 col-xl-4">';
				foreach ( $values as $value ) {
					if ( $value['side'] == 'left' ) {
						$output .= '<div class="text-xl-left mt-50 mt-lg-140 wow fadeInLeft">
						              <div class="app-dot-line left">
						                <span class="dot"><span class="line"></span></span>
						                <h1 class="font__family-montserrat font__size-124 font__weight-light text-blue">' . $value['number'] . '</h1>
						              </div>
						              <div class="mt-10 ml-10">
						                <h4 class="font__family-montserrat font__size-24 font__weight-light line__height-30 text-uppercase">' . $value['f_label'] . '</h4>
						                <h4 class="font__family-montserrat font__size-24 font__weight-bold line__height-30 text-uppercase">' . $value['s_label'] . '</h4>
						              </div>
						            </div>';
					}
				}
				$output .= '</div>
					          <div class="col-md-6 col-xl-4 order-xl-2">';

				foreach ( $values as $value ) {
					if ( $value['side'] == 'right' ) {
						$mt_class = 'mt-lg-140';
						if ( $value['number'] == '02' ) {
							$mt_class = 'mt-xl-0';
						}
						$output .= '<div class="text-xl-right mt-50 wow fadeInRight ' . $mt_class . '">
						              <div class="app-dot-line right">
						                <span class="dot"><span class="line"></span></span>
						                <h1 class="font__family-montserrat font__size-124 font__weight-light text-blue">' . $value['number'] . '</h1>
						              </div>
						              <div class="mt-10 ml-10">
						                <h4 class="font__family-montserrat font__size-24 font__weight-light line__height-30 text-uppercase">' . $value['f_label'] . '</h4>
						                <h4 class="font__family-montserrat font__size-24 font__weight-bold line__height-30 text-uppercase">' . $value['s_label'] . '</h4>
						              </div>
						            </div>';
					}
				}

				$output .= '</div>
					        </div>';


				break;
			case "notebook":

				$output = '<div class="row row-no-gutter align-items-center">
				            <div class="col-xl-6 order-xl-1">
				              <div class="mobile-case-3" style="background-image: url(' . BERSERK_SHORTCODES_URL . '/shortcodes/img/app-case-3.png)">
				                <div class="mobile-bg" style="background: url(' . esc_url( $image ) . ') center center no-repeat; background-size: cover;"></div>
				              </div>
				            </div>
				            <div class="col-md-6 col-xl-3">';
				$i      = 0;
				foreach ( $values as $value ) {
					if ( $value['side'] == 'left' ) {
						$mt_class = '';
						if ( $i == 0 ) {
							$mt_class = 'mt-xl-0';
						}

						$description_class = ' text-blue-3';
						if( isset( $value['description_class'] ) ) {
							if( $value['description_class'] ) {
								$description_class = ' ' . $value['description_class'];
							}
						}

						$output .= '<div class="text-xl-left z-index-high mt-50 wow fadeInLeft ' . $mt_class . '">
					                <div class="inline-wrap inline-wrap-second align-items-start">
					                  <span class="circle-number mb-20 mr-30">' . $value['number'] . '</span>
					                  <div>
					                    <h4 class="font__family-montserrat font__weight-light font__size-24 text-uppercase">' . $value['f_label'] . '</h4>
					                    <p class="font__family-open-sans font__size-16 line__height-26 mt-20' . esc_attr( $description_class ) . '">' . $value['description'] . '</p>
					                  </div>
					                </div>
					              </div>';
					}
					$i ++;
				}

				$output .= '</div>
				            <div class="col-md-6 col-xl-3 order-xl-2">';
				$i = 0;
				foreach ( $values as $value ) {
					if ( $value['side'] == 'right' ) {
						$mt_class = '';
						if ( $i == 1 ) {
							$mt_class = 'mt-xl-0';
						}

						$description_class = ' text-blue-3';
						if( isset( $value['description_class'] ) ) {
							if( $value['description_class'] ) {
								$description_class = ' ' . $value['description_class'];
							}
						}

						$output .= '<div class="text-xl-right z-index-high mt-50 wow fadeInRight ' . $mt_class . '">
						                <div class="inline-wrap inline-wrap-second align-items-start">
						                  <span class="circle-number order-lg-1 mb-20 ml-30">' . $value['number'] . '</span>
						                  <div>
						                    <h4 class="font__family-montserrat font__weight-light font__size-24 text-uppercase">' . $value['f_label'] . '</h4>
						                    <p class="font__family-open-sans font__size-16 line__height-26 mt-20' . esc_attr( $description_class ) . '">' . $value['description'] . '</p>
						                  </div>
						                </div>
						              </div>';
					}
					$i ++;
				}

				$output .= '</div>
				          </div>';

				break;

			case "single_notebook":
				$output ='<div class="mobile-case-4 z-index-high" style="background-image: url('.BERSERK_SHORTCODES_URL . '/shortcodes/img/app-case-3.png)">
								<div class="mobile-bg" style="background: url('.esc_url($image).') center center no-repeat; background-size: cover;"></div>
							</div>';
				break;

		}

		return $output;
	}

	protected function get_icon_class( $atts ) {

		$icon_class = $atts[ 'icon_' . $atts['type'] ];

		if ( empty( $icon_class ) ) {
			$icon_class = 'fa fa-trophy';
		}

		return $icon_class;
	}

}

// create shortcode
BRS_App_Showcase::get_instance();
