<?php
/**
 * Alert shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Alert', false ) ) {

	class BRS_Alert extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Alert();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_alert', array( $this, 'shortcode_alert' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Alert", 'berserk' ),
					"base"     => "brs_alert",
					"icon"     => "brs_vc_ico_alert",
					"class"    => "brs_vc_sc_alert",
					"category" => __( 'Berserk', 'berserk' ),
					"params"   => array(
						array(
							'heading'    => __( 'Alert Style', 'berserk' ),
							'param_name' => 'alert_style',
							'type'       => 'brs_radio',
							'value'      => array(
								"Simple"  => "simple",
								"Clean"   => "clean",
								"Rounded" => "rounded"
							),
							'images'     => array(
								"simple"  => 'alert/simple.png',
								"clean"   => 'alert/clean.png',
								"rounded" => 'alert/rounded.png',
							),
							'images_dim' => array(
								'w' => '320',
								'h' => '100'
							)
						),
						array(
							"type"             => "dropdown",
							"heading"          => __( "Alert Type", 'berserk' ),
							"param_name"       => "alert_type",
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							"value"            => array(
								"Primary"   => "primary",
								"Secondary" => "secondary",
								"Success"   => "success",
								"Danger"    => "danger",
								"Warning"   => "warning",
								"Info"      => "info",
								"Light"     => "light",
								"Dark"      => "dark",
								"Berserk"   => "berserk",
							)
						),
						array(
							'type'             => 'textfield',
							'heading'          => __( 'Label', 'js_composer' ),
							'param_name'       => 'label',
							"value"            => "Heads up!",
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),
						array(
							'type'             => 'textfield',
							'heading'          => __( 'Alert Message', 'js_composer' ),
							'param_name'       => 'message',
							"value"            => "You successfully read this important alert message.",
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

					)
				) );
			}
		}

		public function shortcode_alert( $atts, $content = null ) {

      $libraries = array('component__alert');
      brs_add_libraries($libraries);

			extract( shortcode_atts( array(
				'alert_style' => 'simple',
				'alert_type'  => 'primary',
				'label'       => 'Heads up!',
				'message'     => 'You successfully read this important alert message.',
			), $atts ) );

			// store atts
			$atts_backup = self::$atts;

			$div_class = array();
			$i_class   = '';

			switch ( $alert_style ) {
				case "simple":
					$div_class[] = 'alert-simple';
					$i_class     = 'far fa-life-ring';
					break;
				case "clean":
					$div_class[] = 'alert-clean';
					$i_class     = 'far fa-thumbs-up';
					break;
				case "rounded":
					$div_class[] = 'alert-rounded';
					$i_class     = 'far fa-check-circle';
					break;
			}
			switch ( $alert_type ) {
				case "primary":
					$div_class[] = 'alert-primary';
					$i_class     = 'far fa-thumbs-up';
					break;
				case "secondary":
					$div_class[] = 'alert-secondary';
					$i_class     = 'far fa-life-ring';
					break;
				case "success":
					$div_class[] = 'alert-success';
					$i_class     = 'far fa-check-circle';
					break;
				case "danger":
					$div_class[] = 'alert-danger';
					$i_class     = 'far fa-times-circle';
					break;
				case "warning":
					$div_class[] = 'alert-warning';
					$i_class     = 'far fa-exclamation-triangle';
					break;
				case "info":
					$div_class[] = 'alert-info';
					$i_class     = 'far fa-info-circle';
					break;
				case "light":
					$div_class[] = 'alert-light';
					$i_class     = 'far fa-certificate';
					break;
				case "dark":
					$div_class[] = 'alert-dark';
					$i_class     = 'far fa-certificate';
					break;
				case "berserk":
					$div_class[] = 'alert-brk';
					break;
			}

			$div_class = implode( ' ', $div_class );

			$output = '<div class="alert fade ' . $div_class . ' alert-dismissible text-left font__family-montserrat font__size-16 font__weight-light" role="alert">
			              <button type="button" class="close font__size-18" data-dismiss="alert">
			                <span aria-hidden="true"><i class="fal fa-times"></i></span>
			                <span class="sr-only">Close</span>
			              </button>
			                <i class="start-icon ' . $i_class . '"></i>
			                <strong class="font__weight-semibold">' . esc_html( $label ) . '</strong> ' . esc_html( $message ) . '
			            </div>';


			// restore atts
			self::$atts = $atts_backup;

			return $output;
		}
	}

	// create shortcode
	BRS_Alert::get_instance();

}
