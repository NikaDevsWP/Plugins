<?php
/**
 * Content Slider shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


if ( ! class_exists( 'BRS_Content_Slider', false ) ) {

	require_once BERSERK_SHORTCODES_PATH . 'shortcodes/includes/shortcodes-ext.php';

	class BRS_Content_Slider extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Content_Slider();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_content_slider', array( $this, 'shortcode_content_slider' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				$params = array();

        $params[] = array(
          'heading'    => esc_html__( 'Content Slider Type', 'berserk' ),
          'param_name' => 'brs_slider_type_title',
          'type'       => 'brs_title',
          'edit_field_class' => 'vc_col-sm-12 vc_column'
        );

				$params[] = array(
					//'heading'    => __( 'Content Slider Type', 'berserk' ),
					'param_name' => 'slider_type',
					'type'       => 'brs_radio',
					'value'      => array(
						"Rounded"                 => "rounded",
						"Strict"                  => "strict",
						"Sqaure"                  => "sqaure",
						"Setout"                  => "setout",
						"Shop window"             => "shop_window",
						"Filmstrip"               => "filmstrip",
						"Landscape"               => "landscape",
						"Content slider top skin" => "content_slider_top_skin",
						"Rotation Slider"         => "rotation_slider",
						"Our staff"               => "our_staff",
						"Instagram"               => "instagram",
						"Services"                => "services"
					),
					'images'     => array(
						"rounded"                 => 'content_slider/rounded.jpg',
						"strict"                  => 'content_slider/strict.jpg',
						"sqaure"                  => 'content_slider/sqaure.jpg',
						"setout"                  => 'content_slider/setout.jpg',
						"shop_window"             => 'content_slider/shop_window.jpg',
						"filmstrip"               => 'content_slider/filmstrip.jpg',
						"landscape"               => 'content_slider/landscape.jpg',
						"content_slider_top_skin" => 'content_slider/content_slider_top_skin.jpg',
						"rotation_slider"         => 'content_slider/rotation_slider.jpg',
						"our_staff"               => 'content_slider/our_staff.jpg',
						"instagram"               => 'content_slider/instagram.jpg',
						"services"                => 'content_slider/services.jpg',

					),
					'images_dim' => array(
						'w' => '310',
						'h' => '150'
					)
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Image size', 'berserk' ),
					'value'            => BRS_Shortcodes_VCParams::get_image_sizes_names(),
					'param_name'       => 'image_size',
					'std'              => 'image-frames',
					'edit_field_class' => 'vc_col-sm-6 vc_column'
				);


				// Filmstrip Slider Options
				$params[] = array(
					'heading'    => esc_html__( 'Slider Options', 'berserk' ),
					'param_name' => 'brs_slider_options_title',
					'type'       => 'brs_title',
					'dependency' => array(
						'element' => 'slider_type',
						'value'   => array( 'filmstrip' ),
					),
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => esc_html__( 'Space Between', 'berserk' ),
					'value'            => array(
						'Yes' => 'y',
					),
					'param_name'       => 'spacebetween',
					'value'            => array(
						'no space' => '',
						'5'        => '5',
						'10'       => '10',
						'15'       => '15',
						'20'       => '20',
						'30'       => '30',
					),
					'edit_field_class' => 'vc_col-sm-3 vc_column',
					'dependency'       => array(
						'element' => 'slider_type',
						'value'   => array( 'filmstrip' ),
					),
				);

				$params[] = array(
					'type'             => 'checkbox',
					'heading'          => esc_html__( 'Background Gradient', 'berserk' ),
					'value'            => array(
						'Yes' => 'y',
					),
					'param_name'       => 'gradient',
					'edit_field_class' => 'vc_col-sm-3 vc_column',
					'dependency'       => array(
						'element' => 'slider_type',
						'value'   => array( 'filmstrip' ),
					),
				);

				$params[] = array(
					"heading"    => __( "Dynamic Content", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				// Add dynamic filter and order functionality @see ../shortcodes-ext.php
				$params = array_merge( $params, berserk_shortcodes_dynamic_filter() );

				$params[] = array(
					'type'             => 'checkbox',
					'heading'          => esc_html__( 'Instagram content', 'berserk' ),
					'value'            => array(
						'Yes' => 'y',
					),
					'param_name'       => 'instagram_content',
					'edit_field_class' => 'vc_col-sm-8 vc_column brk-dependency__slider_type instagram',
				);

				$params[] = array(
					'type'             => 'textfield',
					'heading'          => __( 'Images count', 'js_composer' ),
					'param_name'       => 'imagescount',
					"value"            => "8",
					'edit_field_class' => 'vc_col-sm-6 vc_column vc_column brk-dependency__slider_type instagram',
					'dependency'       => array(
						'element' => 'instagram_content',
						'value'   => array( 'y' ),
					),
				);

				$params[] = array(
					'type'             => 'textfield',
					'heading'          => __( 'Instagram User name', 'js_composer' ),
					'param_name'       => 'username',
					"value"            => "",
					'edit_field_class' => 'vc_col-sm-6 vc_column vc_column brk-dependency__slider_type instagram',
					'dependency'       => array(
						'element' => 'instagram_content',
						'value'   => array( 'y' ),
					),
				);

				$params[] = array(
					"heading"    => __( "Content Values", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Get title from', 'berserk' ),
					'param_name'       => 'title_val',
					'value'            => array(
						'Post Title'  => 'post_title',
						'Post Date'   => 'post_date',
						'Post Author' => 'post_author'
					),
					'edit_field_class' => 'vc_col-sm-6 vc_column',
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Get description from', 'berserk' ),
					'param_name'       => 'description_val',
					'value'            => array(
						'Post Title'   => 'post_title',
						'Post Date'    => 'post_date',
						'Post Author'  => 'post_author',
						'Post Content' => 'post_content',
						'Post Excerpt' => 'post_excerpt',
					),
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					'std'              => 'post_content'
				);

				$params[] = array(
					'type'             => 'textfield',
					'heading'          => __( 'Link Text', 'js_composer' ),
					'param_name'       => 'link_text',
					"value"            => "Read More",
					'edit_field_class' => 'vc_col-sm-6 vc_column',
				);

				$params[] = array(
					'type'             => 'textfield',
					'heading'          => __( 'Hover Link Text', 'js_composer' ),
					'param_name'       => 'hover_link_text',
					"value"            => "Click Me",
					'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__slider_type content_slider_top_skin',
				);

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Content Slider", 'berserk' ),
					"base"     => "brs_content_slider",
					"icon"     => "brs_vc_ico_content_slider",
					"class"    => "brs_vc_sc_content_slider",
					"category" => __( 'Berserk', 'berserk' ),
					"params"   => $params
				) );
			}
		}

		public function shortcode_content_slider( $atts, $content = null ) {

			$libraries = array(
				'component__content_slider'
			);

			extract( shortcode_atts( array(
				'slider_type'       => 'rounded',
				'gradient'          => '',
				'spacebetween'      => '',
				'dynamic_content'   => 'no',
				'custom_items'      => 'custom_items',
				'filters'           => '',
				'image_size'        => 'image-frames',
				'full_height'       => 'n',
				//'autoplay_speed'  => '',
				'orderby'           => 'date',
				'order_direction'   => 'ASC',
				'title_val'         => 'post_title',
				'description_val'   => 'post_content',
				'link_text'         => 'Read More',
				'hover_link_text'   => 'Click Me',
				'instagram_content' => '',
				'imagescount'       => '8',
				'username'          => ''

			), $atts ) );


			// store atts
			$atts_backup = self::$atts;

			if ( $dynamic_content == 'y' ) {
				$args  = array();
				$args  = array_merge( $args, berserk_shortcodes_dynamic_filter_process( $filters, $orderby, $order_direction ) );
				$posts = get_posts( $args );
			} else {
				$posts        = array();
				$custom_items = explode( ',', $custom_items );
				foreach ( $custom_items as $item ) {
					$posts[] = get_post( $item );
				}
			}
			$media_array = array();

			if ( $instagram_content == 'y' ) {
				$limit       = $imagescount;
				$target      = '_blank';
				$size        = 'original';
				$media_array = Berserk_Helper::scrape_instagram( $username );

				//dpm($media_array);
			}

			switch ( $slider_type ) {
				case "rounded":

					$libraries['slider__slick']      = 'slider__slick';
					$libraries['component__sliders'] = 'component__sliders';
					$slider_class                    = ( count( $posts ) > 1 ) ? 'default-slider slick-loading' : '';

					$output = '<div class="' . $slider_class . ' dots-rounded-skin" data-slick=\'{"slidesToShow": 3, "slidesToScroll": 1, "dots": true, "responsive": [{"breakpoint": 992, "settings": {"slidesToShow": 2}}, {"breakpoint": 576, "settings": {"slidesToShow": 1}}]}\'>';

					foreach ( $posts as $post ) {

						$bg_image    = get_the_post_thumbnail_url( $post->ID, $image_size );
						$title       = BRS_Shortcodes_VCParams::get_content_title( $title_val, $post );
						$description = BRS_Shortcodes_VCParams::get_content_description( $description_val, $post );

						$output .= '<div class="pr-15 pl-15">
						              <div class="post-rounded brk-base-box-shadow">
						                <div class="post-rounded__thumb" style="background-image: url(' . esc_url( $bg_image ) . ')">
						                    <a href="' . get_permalink( $post->ID ) . '" class="post-rounded__btn btn btn-lg font__family-open-sans font__weight-bold letter-spacing--100">' . esc_html( $link_text ) . '</a>
						                </div>
						                <div class="post-rounded__text">
						                  <h3 class="font__family-montserrat font__weight-bold font__size-19">' . esc_html( $title ) . '</h3>
						                  <p class="font__family-open-sans font__size-16 text-gray line__height-28">' . $description . '</p>
						                </div>
						              </div>
						            </div>';
					}
					$output .= '</div>';

					break;

				case "strict":

					$libraries['slider__slick']   = 'slider__slick';
					$libraries['component__team'] = 'component__team';

					$output = '<div class="default-slider slick-loading arrows-classic-dark" data-slick=\'{"slidesToShow": 4, "slidesToScroll": 1, "arrows": true,
								  "responsive": [
								  {"breakpoint": 992, "settings": {"slidesToShow": 3}},
								  {"breakpoint": 768, "settings": {"slidesToShow": 2}},
								  {"breakpoint": 480, "settings": {"slidesToShow": 1}}
								  ], "autoplay": true, "autoplaySpeed": 3000}\'>';

					foreach ( $posts as $post ) {
						$bg_image  = get_the_post_thumbnail_url( $post->ID, $image_size );
						$title     = BRS_Shortcodes_VCParams::get_content_title( $title_val, $post );
						$post_type = get_post_type( $post->ID );
						$output .= '<div class="pl-15 pr-15">
						              <div class="brk-team-strict" style="background-image: url(' . esc_url( $bg_image ) . ')">
						                <a href="' . get_permalink( $post->ID ) . '"><h3 class="brk-team-strict__name font__family-montserrat font__weight-semibold font__size-21">' . esc_html( $title ) . '</h3></a>';
						if ( $post_type == BRS_Staff::postType() ) {
							$custom_values = get_post_custom( $post->ID );
							$output .= '<div class="brk-team-strict__social">';
							$output .= self::get_social_items( $custom_values );
							$output .= '</div>';
						}

						$output .= '</div>
						 </div>';
					}
					$output .= '</div>';

					break;

				case "sqaure":

					$libraries['slider__slick'] = 'slider__slick';

					$output = '<div class="default-slider slick-loading arrows-classic-dark-square" data-slick=\'{"slidesToShow": 4, "slidesToScroll": 1, "arrows": true, "responsive": [
								  {"breakpoint": 992, "settings": {"slidesToShow": 3}},
								  {"breakpoint": 768, "settings": {"slidesToShow": 2}},
								  {"breakpoint": 480, "settings": {"slidesToShow": 1}}
								  ]}\'>';
					foreach ( $posts as $post ) {
						$bg_image = get_the_post_thumbnail_url( $post->ID, $image_size );
						$title    = BRS_Shortcodes_VCParams::get_content_title( $title_val, $post );

						$output .= '<div class="pr-15 pl-15">
						              <div class="post-sqaure" style="background-image: url(' . esc_url( $bg_image ) . ')">
						                <h3 class="post-sqaure__title font__family-oxygen font__weight-light font__size-21 line__height-26">' . esc_html( $title ) . '</h3>

						                <a href="' . get_permalink( $post->ID ) . '" class="post-sqaure__btn btn btn-md-1 border-radius-0 font__family-montserrat font__weight-light btn-inside-out letter-spacing--100">
						                  <span class="before">' . esc_html( $link_text ) . '</span>
						                  <span class="text">' . esc_html( $link_text ) . '</span>
						                  <span class="after">' . esc_html( $link_text ) . '</span>
						                </a>
						              </div>
						            </div>';

					}

					$output .= '</div>';

					break;

				case "setout":

					$libraries['slider__slick'] = 'slider__slick';

					$output = '<div class="default-slider slick-loading default-slider_mode arrows-classic-dark-circle brk-base-box-shadow" data-slick=\'{"slidesToShow": 4, "slidesToScroll": 1, "arrows": true, "responsive": [
							  {"breakpoint": 992, "settings": {"slidesToShow": 3}},
							  {"breakpoint": 768, "settings": {"slidesToShow": 2}},
							  {"breakpoint": 480, "settings": {"slidesToShow": 1}}
							  ]}\'>';

					foreach ( $posts as $post ) {
						$bg_image  = get_the_post_thumbnail_url( $post->ID, $image_size );
						$title     = BRS_Shortcodes_VCParams::get_content_title( $title_val, $post );
						$post_type = get_post_type( $post->ID );
						if ( $post_type == 'product' ) {
							$product  = wc_get_product( $post->ID );
							$bg_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), $image_size );
							$bg_image = $bg_image[0];
						}

						$output .= '<div class="pl-15 pr-15">
							              <div class="shop-setout text-center">
							                <div class="shop-setout__img" style="background-image: url(' . esc_url( $bg_image ) . ')">';

						if ( $post_type == 'product' ) {

							$wishlist_btn_class = "add_to_wishlist add-wishlist";
							$wishlist           = get_post_meta( $post->ID, 'wishlist' );
							if ( isset( $wishlist[0] ) && $wishlist[0] == 'true' ) {
								$wishlist_btn_class = "remove_from_wishlist add-wishlist";
							}

							$output .= apply_filters( 'woocommerce_loop_add_to_cart_link',
									sprintf( '<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="button add-cart ajax_add_to_cart %s product_type_%s"><i class="fa fa-shopping-basket"></i></a>',
										esc_url( $product->add_to_cart_url() ),
										esc_attr( $product->get_id() ),
										esc_attr( $product->get_sku() ),
										$product->is_purchasable() ? 'add_to_cart_button' : '',
										esc_attr( $product->get_type() )
									),
									$post ) . '
								<a href="' . esc_url( add_query_arg( 'add_to_wishlist', $product->get_id() ) ) . '" rel="nofollow" data-product-id="' . $product->get_id() . '" class="' . $wishlist_btn_class . '" >
									<i class="fas fa-star"></i>
								</a>';
						}

						$output .= '</div>
											<a class="shop-setout__link" href="' . get_permalink( $post->ID ) . '"><h3 class="font__family-montserrat font__weight-semibold font__size-16">' . esc_attr( $title ) . '</h3></a>';
						if ( $post_type == 'product' ) {

							$currency  = get_woocommerce_currency_symbol();
							$old_price = '';
							if ( ( $product->get_sale_price() !== '' ) ) {
								$old_price = $currency . $product->get_regular_price();
							}

							$output .= '<div class="brk-base-font-color font__family-montserrat font__size-15 font__weight-semibold"><span class="old-price font__size-15 font__weight-normal">' . $old_price . '</span>' . $currency . $product->get_price() . '</div>';
						}

						$output .= '</div>
							            </div>';
					}
					$output .= '</div>';

					break;

				case "shop_window":

					$libraries['slider__slick'] = 'slider__slick';

					$output = '<div class="default-slider slick-loading default-slider_big default-slider_no-gutters arrows-classic-ellipse-mini" data-slick=\'{"slidesToShow": 6, "slidesToScroll": 1, "arrows": true, "responsive": [
								  {"breakpoint": 1200, "settings": {"slidesToShow": 5}},
								  {"breakpoint": 992, "settings": {"slidesToShow": 4}},
								  {"breakpoint": 768, "settings": {"slidesToShow": 3}},
								  {"breakpoint": 576, "settings": {"slidesToShow": 2}},
								  {"breakpoint": 375, "settings": {"slidesToShow": 1}}
								  ], "autoplay": true, "autoplaySpeed": 3000}\'>';

					foreach ( $posts as $post ) {
						$bg_image  = get_the_post_thumbnail_url( $post->ID, $image_size );
						$title     = BRS_Shortcodes_VCParams::get_content_title( $title_val, $post );
						$post_type = get_post_type( $post->ID );
						if ( $post_type == 'product' ) {
							$product  = wc_get_product( $post->ID );
							$bg_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), $image_size );
							$bg_image = $bg_image[0];
						}

						$output .= '<div>
						              <div class="shop-window">
						                <a href="' . get_permalink( $post->ID ) . '">
						                  <div class="shop-window__thumb" style="background-image: url(' . esc_url( $bg_image ) . ')"></div>
						                  <h3 class="shop-window__title font__family-montserrat font__weight-bold font__size-16">' . esc_attr( $title ) . '</h3>
						                </a>';
						if ( $post_type == 'product' ) {
							$currency = get_woocommerce_currency_symbol();
							$output .= '<div class="shop-window__price font__family-montserrat font__size-16">' . $currency . $product->get_price() . '</div>';
						}
						$output .= '</div>
						            </div>';

					}
					$output .= '</div>';

					break;
				case "filmstrip":

					$libraries['slider__swiper'] = 'slider__swiper';

					$gradient_class = '';
					if ( $gradient == 'y' ) {
						$gradient_class = ' brk-base-bg-gradient-50deg-a';
					}

					$output = '<div class="filmstrip-slider slider--scroll' . esc_attr( $gradient_class ) . '" data-spacebetween="' . esc_attr( $spacebetween ) . '">
							      <div class="filmstrip-slider-container swiper-container">
							        <div class="swiper-wrapper">';

					foreach ( $posts as $post ) {
						$bg_image    = get_the_post_thumbnail_url( $post->ID, $image_size );
						$full_image  = get_the_post_thumbnail_url( $post->ID, 'full' );
						$title       = BRS_Shortcodes_VCParams::get_content_title( $title_val, $post );
						$description = BRS_Shortcodes_VCParams::get_content_description( $description_val, $post );

						$allowed_html = $allowed_html = array(
							'a' => array(
								'href' => true,
								'title' => true,
							),
							'br' => array(),
							'em' => array(),
							'strong' => array()
						);

						$output .= '<div class="post-filmstrip swiper-slide brk-base-box-shadow" style="background-image: url(' . esc_url( $bg_image ) . ')">
							            <div class="post-filmstrip__content brk-base-bg-gradient-50deg text-center">
							              <h3 class="font__family-montserrat font__weight-semibold font__size-21 line__height-24">' . esc_html( $title ) . '</h3>
							              <div class="post-filmstrip__excerpt font__family-open-sans font__size-16 line__height-26">' . wp_kses_data( $description, $allowed_html  ) . '</div>
							              <div class="links">
							                <a href="' . get_permalink( $post->ID ) . '" class="links__permalink"><i class="fa fa-link"></i></a>
							                <a href="' . esc_url( $full_image ) . '" class="links__view fancybox"><i class="fa fa-search"></i></a>
							              </div>
							            </div>
							          </div>';

					}
					$output .= '</div>
								</div>
								<div class="brk-scrollbar">
									<div class="brk-scrollbar-track"></div>
								</div>
							</div>';
					break;

				case "landscape":

					$libraries['slider__slick'] = 'slider__slick';

					$output = '<div class="landscape-slider slick-loading text-center">
						        <div class="landscape-slider-for" data-slick=\'{"slidesToShow": 1, "slidesToScroll": 1, "fade": true}\'>';

					foreach ( $posts as $post ) {
						$bg_image = get_the_post_thumbnail_url( $post->ID, $image_size );
						$output .= '<div class="brk-slid" style="background-image: url(' . esc_url( $bg_image ) . '); height: 560px"></div>';

					}

					$output .= '</div>
						        <div class="landscape-slider-nav dots-landscape-skin dots-base-color" data-slick=\'{"slidesToShow": 1, "slidesToScroll": 1, "dots": true, "autoplay": true, "autoplaySpeed": 3000}\'>';

					foreach ( $posts as $post ) {
						$title       = BRS_Shortcodes_VCParams::get_content_title( $title_val, $post );
						$description = BRS_Shortcodes_VCParams::get_content_description( $description_val, $post );
						$output .= '<div class="landscape-slider-nav__content">
						              <h3 class="landscape-slider-nav__title font__family-montserrat font__size-21 line__height-28 font__weight-bold">' . esc_html( $title ) . '</h3>
						              <div class="landscape-slider-nav__text font__family-open-sans font__size-16 line__height-26">' . esc_html( $description ) . '</div>
						              <a href="' . get_permalink( $post->ID ) . '" class="landscape-slider-nav__btn btn btn-lg font__family-open-sans font__weight-bold">' . esc_html( $link_text ) . '</a>
						            </div>';
					}

					$output .= '</div>
						      </div>';

					break;

				case "content_slider_top_skin":

					$libraries['slider__slick'] = 'slider__slick';

					$output = '<div class="default-slider dots-base-skin base-skin-top-left dots-base-color slick-loading fa-req" data-slick=\'{"slidesToShow": 1, "slidesToScroll": 1, "dots": true, "autoplay": true, "autoplaySpeed": 4000}\' data-brk-library="slider__slick">';

					foreach ( $posts as $post ) {

						$title       = BRS_Shortcodes_VCParams::get_content_title( $title_val, $post );
						$description = BRS_Shortcodes_VCParams::get_content_description( $description_val, $post );

						$title = explode( ' ', $title );

						$title_first = $title_second = '';
						$i           = 0;
						foreach ( $title as $item ) {
							if ( $i == 0 || $i == 1 ) {
								$title_first .= $item . ' ';
							} else {
								$title_second .= $item . ' ';
							}
							$i ++;
						}
						$output .= '<div class="pl-10 pr-10 pb-30 pt-lg-150 pt-80 mt-lg-20">
										<div class="text-center text-lg-left">
											<h2 class="font__family-montserrat font__weight-bold font__size-56 line__height-60 mt-10" data-brk-library="component__title">' . $title_first . '<br><span class="highlight-massive font__family-playfair font__weight-bold">' . $title_second . '<span class="after wow zoomIn"></span></span></h2>
										</div>
										<p class="brk-dark-font-color font__size-16 line__height-26 mt-45 mb-25 text-center text-lg-left">' . $description . '</p>
										<div class="text-center text-lg-left"><a href="' . get_permalink( $post->ID ) . '" class="btn btn-inside-out btn-lg border-radius-25 btn-shadow ml-0 pl-50 pr-50" data-brk-library="component__button"><span class="before">' . esc_html( $link_text ) . '</span><span class="text">' . esc_html( $hover_link_text ) . '</span><span class="after">' . esc_html( $link_text ) . '</span></a></div>
									</div>';
					}

					$output .= '</div>';


					break;

				case "rotation_slider":

					$libraries['slider__rotate'] = 'slider__rotate';

					$output   = '<div class="rotate-slider">
						        <div class="rotate-container">';
					$i        = 1;
					$bg_class = 'brk-base-bg-gradient-50deg-b';
					foreach ( $posts as $post ) {
						$bg_image    = get_the_post_thumbnail_url( $post->ID, $image_size );
						$title       = BRS_Shortcodes_VCParams::get_content_title( $title_val, $post );
						$description = BRS_Shortcodes_VCParams::get_content_description( $description_val, $post );

						$output .= '<div class="rotate-slid" style="background-image: url(' . esc_url( $bg_image ) . ')">';
						if ( ! ( $i % 2 ) ) {
							$output .= '<div class="rotate-slid__over ' . $bg_class . '">
						              <div class="rotate-slid__content">
						                <h4 class="font__family-montserrat font__weight-bold font__size-28">' . esc_html( $title ) . '</h4>
						                <p class="font__family-open-sans font__size-16 line__height-26">' . esc_html( $description ) . '</p>
						              </div>
						            </div>';
							if ( $bg_class == 'brk-base-bg-gradient-50deg-b' ) {
								$bg_class = 'brk-base-bg-gradient-10deg';
							} else {
								$bg_class = 'brk-base-bg-gradient-50deg-b';
							}
						}

						$output .= '</div>';
						$i ++;
					}

					$output .= '</div>
						      </div>
						      <div class="svg-hidden">
						        <svg>
						          <defs>
						            <clipPath id="slideClip">
						            <path />
						            </clipPath>
						          </defs>
						        </svg>
						      </div>';

					break;

				case "our_staff":

					$libraries['slider__swiper']  = 'slider__swiper';
					$libraries['component__team'] = 'component__team';

					$output = '
					<div class="staff-slider">
						<div class="staff-slider-container swiper-container">
							<div class="swiper-wrapper">';

					foreach ( $posts as $post ) {
						$bg_image    = get_the_post_thumbnail_url( $post->ID, $image_size );
						$title       = BRS_Shortcodes_VCParams::get_content_title( $title_val, $post );
						$description = BRS_Shortcodes_VCParams::get_content_description( $description_val, $post );
						$post_type   = get_post_type( $post->ID );
						if ( $post_type == BRS_Staff::postType() ) {
							$positions = BRS_Shortcodes_VCParams::get_term_names( $post->ID, 'position' );
							$position  = implode( ',', $positions );
						}

						$meta          = BRS_Staff::postMeta();
						$custom_values = get_post_custom( $post->ID );
						$counter       = 0;
						$attributes    = '';
						foreach ( $custom_values as $key => $value ) {
							if ( ! empty( $value[0] ) && isset( $meta[ $key ] ) && $meta[ $key ]['group'] == 'socials' ) {
								$attributes .= '<a href="' . @$meta[ $key ]['prefix'] . $value[0] . '"><i class="fab fa-' . $meta[ $key ]['icon'] . '"></i></a>';
								$counter ++;
							}
							if ( $counter > 5 ) {
								break;
							}
						}

						$output .= '
					              <div class="swiper-slide">
						              <div class="brk-team-staff brk-base-box-shadow">
						              	<div class="brk-team-staff__img lazyload" data-bg="' . esc_attr( $bg_image ) . '"></div>
						                <a href="' . get_permalink( $post->ID ) . '" class="brk-team-staff__link"><i class="far fa-plus"></i><i class="far fa-angle-right"></i></a>
						                <div class="brk-team-staff__description">
						                  <h4>
						                    <a href="' . get_permalink( $post->ID ) . '" class="font__family-montserrat font__weight-normal font__size-18 line__height-26">' . esc_html( $title ) . '</a>
						                    <span class="font__family-montserrat font__weight-ultralight font__size-15 line__height-21">' . $position . '</span>
						                  </h4>
					                    <div class="brk-team-staff__social-links sl-2x">'
						           . $attributes . '
					                                </div>
					                            </div>
					                </div>
					              </div>';
					}

					$output .= '
							          </div>
							        </div>
							        <div class="dots-base-staff-skin">
							          <div class="swiper-arrow button-prev"><i class="far fa-angle-left" aria-hidden="true"></i></div>
							          <ul class="pagination"></ul>
							          <div class="swiper-arrow button-next"><i class="far fa-angle-right" aria-hidden="true"></i></div>
							        </div>
							      </div>';
					break;

				case "services":

					$libraries['slider__slick']       = 'slider__slick';
					$libraries['component__info_box'] = 'component__info_box';

					$output = '<div class="container"><div class="brk-services-slider pb-110 fa-req"><div class="brk-services-slider__items dots-base-skin dots-base-color">';
					foreach ( $posts as $post ) {
						$title       = BRS_Shortcodes_VCParams::get_content_title( $title_val, $post );
						$description = BRS_Shortcodes_VCParams::get_content_description( $description_val, $post );

						$output .= '<div>
							            <div class="info-box-icon-simple d-flex flex-column align-items-center pt-60 pb-50 pl-50 pr-50 position-relative brk-library-rendered" data-brk-library="component__info_box">
											  <span class="brk-abs-overlay  brk-base-bg-gradient-13"></span>
											  <div class="info-box-icon-simple__icon-wrapper d-flex align-items-center justify-content-center mb-45">
											    ' . do_shortcode( $post->post_content ) . '
											  </div>
											  <p class="font__family-montserrat info-box-icon-simple__title font__size-28 font__weight-bold line__height-30 mb-20 text-center">
											    ' . $title . '
											  </p>
											  <p class="brk-dark-font-color font__size-16 info-box-icon-simple__about line__height-26 font__weight-normal mb-35 text-center">
											    ' . $description . '
											  </p>
											<a href="' . get_permalink( $post->ID ) . '" class="btn btn-inside-out btn-lg border-radius-25 btn-shadow ml-0 mr-0 mt-0 mb-0 pl-70 pr-70 brk-library-rendered" data-brk-library="component__button">
											  <span class="before">' . esc_html( $link_text ) . '</span><span class="text">' . esc_html( $link_text ) . '</span><span class="after">' . esc_html( $link_text ) . '</span>
											</a>
										</div>
									</div>';

					}

					$output .= '</div></div></div>';

					break;

				case
				"instagram":

					$libraries['slider__slick']        = 'slider__slick';
					$libraries['component__sliders']   = 'component__sliders';
					$libraries['component__shop_list'] = 'component__shop_list';

					$output = '';
					if ( ! empty( $media_array ) ) {
						$output = '<div class="default-slider default-slider_gutters-15 dots-rounded-skin dots-rounded-skin_top-right"
               data-slick=\'{"slidesToShow": 4, "slidesToScroll": 1, "arrows": false, "dots": true, "autoplay": true, "autoplaySpeed": 2800, "responsive": [
              {"breakpoint": 992, "settings": {"slidesToShow": 3}},
              {"breakpoint": 768, "settings": {"slidesToShow": 2}},
              {"breakpoint": 576, "settings": {"slidesToShow": 1}}
              ]}\'>';
						$i      = 1;
						foreach ( $media_array as $item ) {

							if ( $i > $limit ) {
								break;
							}

							$output .= '<div>';

							$output .= '<div class="brk-sc-card-photo-overlay" data-brk-library="component__shop_cards">
											  <img src="' . esc_attr( BRK_DATA_IMAGE ) . '" data-src="' . esc_url( $item[ $size ] ) . '" alt="alt" class="brk-abs-img lazyload">
											  <span class="brk-abs-overlay brk-base-bg-gradient-right"></span>
											  <div class="brk-sc-card-photo-overlay__actions d-flex justify-content-between brk-white-font-color font__size-16">
											    <a href=""><i class="fa fa-search" aria-hidden="true"></i> ' . __( 'View', 'berserk' ) . '</a>
											    <a href=""><i class="fa fa-heart" aria-hidden="true"></i> <span>' . $item['likes'] . '</span></a>
											    <a href=""><i class="fa fa-comment" aria-hidden="true"></i> <span>' . $item['comments'] . '</span></a>
											  </div>
											</div>';

							$output .= '</div>';
							$i ++;
						}
						$output .= '</div>';
					}

					break;
			}

			brs_add_libraries( $libraries );

			return $output;
		}

		public static function get_social_items( $custom_values ) {

			$output = '';

			$socials = array(
				'email'     => 'email',
				'instagram' => 'instagram',
				'google'    => 'google-plus',
				'youtube'   => 'youtube-play',
				'vimeo'     => 'vimeo',
				'vk'        => 'vk',
				'facebook'  => 'facebook',
				'linkedin'  => 'linkedin',
				'dribble'   => 'dribble',
				'skype'     => 'skype',
			);

			foreach ( $custom_values as $key => $value ) {
				if ( ! empty( $value[0] ) && isset( $socials[ $key ] ) ) {
					$output .= '<a href="' . $value[0] . '"><i class="fab fa-' . $socials[ $key ] . '"></i></a>';
				}
			}

			return $output;

		}

	}

	// create shortcode
	BRS_Content_Slider::get_instance();

}
