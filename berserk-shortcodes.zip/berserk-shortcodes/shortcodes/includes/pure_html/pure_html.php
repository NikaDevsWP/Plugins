<?php
/**
 * HTML shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Html', false ) ) {

	class BRS_Html extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Html();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'vc_pure_html', array( $this, 'shortcode_html' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				vc_map( 
					array(
						'name'        => esc_html__('Pure Html', 'berserk'),
						'base'        => 'vc_pure_html',
						'description' => esc_html__('Add pure html', 'berserk'),
						'category'    => esc_html__('Berserk', 'berserk'),
						'icon'        => 'brs_vc_ico_html fa fa-code',
						'params' => array(
							array(
								'type'        => 'textarea_raw_html',
								'heading'     => esc_html__( 'Pure Html', 'berserk' ),
								'param_name'  => 'content',
								'description' => esc_html__( 'Enter your HTML content.', 'berserk' ),
							)
						)
					)
				);
			}
		}

		public function shortcode_html( $atts, $content = null ) {
			$output = rawurldecode( base64_decode( strip_tags( $content ) ) );
			return  $output;
		}
	}

	// create shortcode
	BRS_Html::get_instance();

}
