<?php
/**
 * Accordion shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Accordion', false ) ) {

	class BRS_Accordion extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Accordion();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'vc_accordion', array( $this, 'shortcode_accordion' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				vc_map( array(
					"weight"                  => - 1,
					"name"                    => __( "Accordion", 'berserk' ),
					"base"                    => "vc_accordion",
					//"base"                    => "brs_accordion",
					"slug"                    => "vc_accordion",
					"icon"                    => "fa fa-plus-circle",
					"class"                   => "brs_vc_sc_accordion",
					"category"                => __( 'Berserk', 'berserk' ),
					"is_container"            => true,
					"show_settings_on_create" => false,
					"js_view"                 => "VcAccordionView",
					"custom_markup"           => '<div class="wpb_accordion_holder wpb_holder clearfix vc_container_for_children">%content%</div><div class="tab_controls"><a class="add_tab" title="Add section"><span class="vc_icon"></span> <span class="tab-label">Add section</span></a></div>',
					"default_content"         => '
			[vc_accordion_tab title="' . sprintf( '%s %d', 'Section', 1 ) . '"][/vc_accordion_tab]
			[vc_accordion_tab title="' . sprintf( '%s %d', 'Section', 2 ) . '"][/vc_accordion_tab]',
					"params"                  => array(
						array(
							'heading'    => __( 'Accordion Type', 'berserk' ),
							'param_name' => 'accordion_type',
							'type'       => 'brs_radio',
							'value'      => array(
								"Slider"   => "slider",
								"Image"    => "image",
								"Layout 1" => "layout_1",
								"Layout 2" => "layout_2",
								"Layout 3" => "layout_3",
								"Layout 4" => "layout_4",
							),
							'images'     => array(
								"slider"   => 'accordion/slider.jpg',
								"image"    => 'accordion/image.jpg',
								"layout_1" => 'accordion/layout_1.jpg',
								"layout_2" => 'accordion/layout_2.jpg',
								"layout_3" => 'accordion/layout_3.jpg',
								"layout_4" => 'accordion/layout_4.jpg',
							),
							'images_dim' => array(
								'w' => '310',
								'h' => '150'
							)
						),
					)
				) );
			}
		}

		public function shortcode_accordion( $atts, $content = null ) {

			wp_enqueue_script( 'brs-shortcodes-accordions', BERSERK_SHORTCODES_URL . 'shortcodes/js/components/accordions.js', 'jQuery', false, true );
			wp_enqueue_style( 'brs-shortcodes-accordions', BERSERK_SHORTCODES_URL . 'shortcodes/css/components/accordions.css' );

			$attributes = shortcode_atts( array(
				'accordion_type' => 'slider',
			), $atts );

			BRS_Accordion_Section::$items = array();
			do_shortcode( $content );
			$output = '';
			$items  = BRS_Accordion_Section::$items;

			//dpm($items);

			switch ( $attributes['accordion_type'] ) {
				case "slider":

					$output = '<div class="accordion accordion-slider" role="tablist" aria-multiselectable="true">';

					$first_item_class = false;
					foreach ( $items as $item ) {
						if( $item['active_section'] == 'y' ) {
							$first_item_class = true;
						}
					}
					$i = 0;
					foreach ( $items as $item ) {
						$id             = random_int(10000, 99999);
						$i++;
						$item_class     = 'card';
						$collapse_class = 'collapse';
						$link_class   = 'font__weight-medium card-title';
						$button_class = 'card-toggle-icon';
						if( $first_item_class == false && $i == 1 ){
							$item_class     .= ' expanded';
							$collapse_class .= ' show';
						} else if( $item['active_section'] == 'y' ) {
							$item_class     .= ' expanded';
							$collapse_class .= ' show';
						} else {
							$link_class   .= ' collapsed';
							$button_class .= ' collapsed';
						}

						$output .= '<div class="' . esc_attr( $item_class ) . '">
										<div class="card-header text-left" role="tab" id="heading_' . esc_attr( $id ) . '">
											<span class="card-dash brk-base-bg-gradient-bottom"></span>
											<h5 class="mb-0 font__family-montserrat font__weight-semibold letter-spacing-20 font__size-16 line__height-16 brk-base-font-color text-uppercase">
												<a class="' . esc_attr( $link_class ) . '" data-toggle="collapse" data-parent=".accordion-slider" href="#collapse_' . esc_attr( $id ) . '" aria-expanded="false"
												   aria-controls="collapse_' . esc_attr( $id ) . '">
													' . $item['icon'] . esc_html( $item['title'] ) . '
												</a>
											</h5>
											<a class="' . esc_attr( $button_class ). '" data-toggle="collapse" data-parent=".accordion-slider" href="#collapse_' . esc_attr( $id ) . '" aria-expanded="false" aria-controls="' . 'collapse_' . esc_attr( $id ) . '">
												<span class="before"></span>
												<span class="after"></span>
											</a>
										</div>

										<div id="collapse_' . esc_attr( $id ) . '" class="' . esc_attr( $collapse_class ) . '" role="tabpanel" aria-labelledby="heading_' . esc_attr( $id ) . '">
											<div class="card-block text-left font__family-open-sans">
												' . $item['content'] . '
											</div>
										</div>
									</div>';

					}
					$output .= '</div>';

					break;

				case "image":

					$output = '<div class="accordion accordion-rounded accordion-image" role="tablist" aria-multiselectable="true">';

					foreach ( $items as $item ) {
						$id             = uniqid();
						$item_class     = ( $item['active_section'] == 'y' ) ? 'card expanded' : 'card';
						$collapse_class = ( $item['active_section'] == 'y' ) ? 'collapse show' : 'collapse';

						$bg_style = 'style="background-image:url(' . esc_url( $item['image'] ) . ')"';
						$output .= '<div class="' . $item_class . '">
										<div class="card-header text-left" role="tab" id="heading_' . $id . '">
											<h5
												class="mb-0 font__family-montserrat font__weight-semibold letter-spacing-20 font__size-16 line__height-16 brk-base-font-color text-uppercase">
												<a class="font__weight-medium card-title" data-toggle="collapse" data-parent=".accordion-image" href="#collapse_' . $id . '" aria-expanded="true"
												   aria-controls="collapse_' . $id . '">
													' . $item['icon'] . esc_html( $item['title'] ) . '
												</a>
											</h5>
											<a class="card-toggle-icon" data-toggle="collapse" data-parent=".accordion-image" href="#collapse_' . $id . '"
											   aria-expanded="true" aria-controls="collapse_' . $id . '">
												<span class="arrow"></span>
											</a>
										</div>

										<div id="collapse_' . $id . '" class="' . $collapse_class . '" role="tabpanel" aria-labelledby="heading_' . $id . '">
											<div class="card-block text-left all-light font__family-open-sans bg-cover " ' . $bg_style . '>
												<span class="full__size-absolute brk-bg-grad opacity-90"></span>
												' . $item['content'] . '
											</div>
										</div>
									</div>';
					}
					$output .= '</div>';

					break;

				case "layout_1":

					$output = '<div class="accordion accordion-simple accordion-simple-image mb-80" role="tablist" aria-multiselectable="true">';

					foreach ( $items as $item ) {
						$id             = uniqid();
						$item_class     = ( $item['active_section'] == 'y' ) ? 'card expanded' : 'card';
						$collapse_class = ( $item['active_section'] == 'y' ) ? 'collapse show' : 'collapse';
						$output .= '<div class="' . $item_class . '">
										<div class="card-header card-header-sm text-left" role="tab" id="heading_' . $id . '">
											<span class="card-dash brk-base-bg-gradient-right"></span>
											<h5
												class="mb-0 font__family-montserrat font__weight-semibold letter-spacing-20 font__size-16 line__height-16">
												<a class="card-title brk-base-font-color" data-toggle="collapse" data-parent=".accordion-simple-image" href="#collapse_' . $id . '" aria-expanded="true"
												   aria-controls="collapse_' . $id . '">
													' . $item['icon'] . esc_html( $item['title'] ) . '
												</a>
											</h5>
											<a class="card-toggle-icon" data-toggle="collapse" data-parent=".accordion-simple-image" href="#collapse_' . $id . '"
											   aria-expanded="true" aria-controls="collapse_' . $id . '">
												<span class="arrow"></span>
											</a>
										</div>

										<div id="collapse_' . $id . '" class="' . $collapse_class . '" role="tabpanel" aria-labelledby="heading_' . $id . '">
											<div class="card-block text-left font__family-open-sans bg-cover">
												' . $item['content'] . '
											</div>
										</div>
									</div>';

					}
					$output .= '</div>';

					break;

				case "layout_2":

					$output = '<div class="accordion accordion-simple accordion-simple-bg mb-80" role="tablist" aria-multiselectable="true">';

					foreach ( $items as $item ) {
						$id             = uniqid();
						$item_class     = ( $item['active_section'] == 'y' ) ? 'card expanded' : 'card';
						$collapse_class = ( $item['active_section'] == 'y' ) ? 'collapse show' : 'collapse';
						$output .= '<div class="' . $item_class . '">
										<div class="card-header card-header-sm text-left" role="tab" id="heading_' . $id . '">
											<span class="card-dash brk-base-bg-gradient-right"></span>
											<h5
												class="mb-0 font__family-montserrat font__weight-semibold letter-spacing-20 font__size-16 line__height-16">
												<a class="card-title brk-base-font-color" data-toggle="collapse" data-parent=".accordion-simple-bg" href="#collapse_' . $id . '" aria-expanded="true"
												   aria-controls="collapse_' . $id . '">
													' . $item['icon'] . esc_html( $item['title'] ) . '
												</a>
											</h5>
											<a class="card-toggle-icon" data-toggle="collapse" data-parent=".accordion-simple-bg" href="#collapse_' . $id . '"
											   aria-expanded="true" aria-controls="collapse_' . $id . '">
												<span class="arrow"></span>
											</a>
										</div>

										<div id="collapse_' . $id . '" class="' . $collapse_class . '" role="tabpanel" aria-labelledby="heading_' . $id . '">
											<div class="card-block text-left font__family-open-sans bg-position_bottom-right bg-norepeat line__height-25"
											     style="background-image: url(' . esc_url( $item['image'] ) . ')">
												' . $item['content'] . '
											</div>
										</div>
									</div>';
					}
					$output .= '</div>';

					break;

				case "layout_3":

					$output = '<div class="accordion accordion-simple accordion-simple-rainbow mb-80" role="tablist" aria-multiselectable="true">';
					$color_scheme = array('brk-color-1', 'brk-color-2', 'brk-color-3', 'brk-color-4');
					$i=0;
					foreach ( $items as $item ) {
						$id             = uniqid();
						$item_class     = ( $item['active_section'] == 'y' ) ? 'card expanded' : 'card';
						$collapse_class = ( $item['active_section'] == 'y' ) ? 'collapse show' : 'collapse';
						$output .= '<div class="' . $item_class . '">
										<div class="card-header card-header-sm text-left '.$color_scheme[$i].'" role="tab" id="heading_' . $id . '">
											<h5
												class="mb-0 font__family-montserrat font__weight-semibold letter-spacing-20 font__size-16 line__height-16">
												<a  class="card-title" data-toggle="collapse" data-parent=".accordion-simple-rainbow" href="#collapse_' . $id . '" aria-expanded="true"
												   aria-controls="collapse_' . $id . '">
													' . $item['icon'] . esc_html( $item['title'] ) . '
												</a>
											</h5>
											<a class="card-toggle-icon" data-toggle="collapse" data-parent=".accordion-simple-rainbow" href="#collapse_' . $id . '"
											   aria-expanded="true" aria-controls="collapse_' . $id . '">
												<span class="arrow"></span>
											</a>
										</div>

										<div id="collapse_' . $id . '" class="' . $collapse_class . '" role="tabpanel" aria-labelledby="heading_' . $id . '">
											<div class="card-block text-left font__family-open-sans bg-cover">
												' . $item['content'] . '
											</div>
										</div>
									</div>';
					$i++;

					}
					$output .= '</div>';

					break;

				case "layout_4":

					$output = '<div class="accordion accordion-simple accordion-simple-scale mb-80" role="tablist" aria-multiselectable="true">';

					foreach ( $items as $item ) {
						$id             = uniqid();
						$item_class     = ( $item['active_section'] == 'y' ) ? 'card expanded' : 'card';
						$collapse_class = ( $item['active_section'] == 'y' ) ? 'collapse show' : 'collapse';
						$output .= '<div class="' . $item_class . '">
									<div class="card-header card-header-sm text-center" role="tab" id="heading_' . $id . '">
										<h5
											class="mb-0 font__family-montserrat font__weight-semibold letter-spacing-20 font__size-16 line__height-16 position-relative">
											<span class="arrow"></span>
											<a data-toggle="collapse" href="#collapse_' . $id . '" aria-expanded="true"
											   aria-controls="collapse_' . $id . '">' . esc_html( $item['title'] ) . '
											</a>
										</h5>
										<a class="card-toggle-icon brk-base-font-color" class="card-toggle-icon" data-toggle="collapse" href="#collapse_' . $id . '"
										   aria-expanded="true" aria-controls="collapse_' . $id . '">
											' . $item['icon'] . '
										</a>
									</div>

									<div id="collapse_' . $id . '" class="' . $collapse_class . '" role="tabpanel" aria-labelledby="heading_' . $id . '">
										<div class="card-block text-center font__family-open-sans bg-position_bottom-right bg-norepeat">
											' . $item['content'] . '
										</div>
									</div>
								</div>';

					}
					$output .= '</div>';

					break;

			}

			return $output;
		}
	}

	// create shortcode
	BRS_Accordion::get_instance();

}
