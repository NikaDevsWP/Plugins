<?php
/**
 * Shape Box shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Info_Box', false ) ) {

	class BRS_Info_Box extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Info_Box();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_info_box', array( $this, 'shortcode_info_box' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				vc_map( array(
					"weight"   => - 1,
					"name"     => esc_html__( "Info Box", 'berserk' ),
					"base"     => "brs_info_box",
					"icon"     => "brs_vc_ico_info_box",
					"class"    => "brs_vc_sc_info_box",
					"category" => esc_html__( 'Berserk', 'berserk' ),
					"params"   => array(
						array(
							'heading'    => esc_html__( 'Info Box Type', 'berserk' ),
							'param_name' => 'info_box_type',
							'type'       => 'brs_radio',
							'value'      => array(
								"Chess"    => "chess",
								"Outline"  => "outline",
								"Gradient" => "gradient",
								"Shuffle"  => "shuffle",
								"Web"      => "web",
								"Strict"   => "strict",
								"Image"    => "image",
								"Icon"     => "icon",
								"Bonus"    => "bonus",
							),
							'images'     => array(
								"chess"    => 'info_box/001.jpg',
								"outline"  => 'info_box/002.jpg',
								"gradient" => 'info_box/005.jpg',
								"shuffle"  => 'info_box/004.jpg',
								"web"      => 'info_box/006.jpg',
								"strict"   => 'info_box/007.jpg',
								"image"    => 'info_box/003.jpg',
								"icon"     => 'info_box/008.jpg',
								"bonus"    => 'info_box/009.jpg'

							),
							'images_dim' => array(
								'w' => '310',
								'h' => '150'
							)
						),
						array(
							'type'             => 'textfield',
							'heading'          => esc_html__( 'First Title', 'js_composer' ),
							'param_name'       => 'first_title',
							"value"            => "Awesome",
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),
						array(
							'type'             => 'textfield',
							'heading'          => esc_html__( 'Title', 'js_composer' ),
							'param_name'       => 'title',
							"value"            => "Design",
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

						// Text Align
						array(
							'heading'    => esc_html__( 'Text Align', 'berserk' ),
							'param_name' => 'text_align',
							'type'       => 'dropdown',
							'value'      => array(
								esc_html__('None','Berserk')   => '',
								esc_html__('Left','Berserk')   => 'text-left',
								esc_html__('Right','Berserk')  => 'text-right',
								esc_html__('Center','Berserk') => 'text-center',
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

						array(
							'type'             => 'param_group',
							'heading'          => esc_html__( 'Title Items', 'js_composer' ),
							'param_name'       => 'title_values',
							'edit_field_class' => 'vc_col-sm-12 vc_column brk-dependency__info_box_type bonus',
							'value'            => urlencode( json_encode( array(
								array(
									'label'             => esc_html__( '$100', 'js_composer' ),
									'brs_font'          => 'montserrat',
									'font_style_italic' => 'n',
									'text_uppercase'    => 'n',
									'font_weight'       => 'normal',
									'item_type'         => 'span'
								),
								array(
									'label'             => esc_html__( 'for', 'js_composer' ),
									'brs_font'          => 'playfair',
									'font_style_italic' => 'y',
									'text_uppercase'    => 'n',
									'font_weight'       => 'normal',
									'item_type'         => 'span'
								),
								array(
									'item_type' => 'br'
								),
								array(
									'label'             => esc_html__( 'the first purchase!', 'js_composer' ),
									'brs_font'          => 'montserrat',
									'font_style_italic' => 'n',
									'text_uppercase'    => 'y',
									'font_weight'       => 'medium',
									'item_type'         => 'span'
								),

							) ) ),
							'params'           => array(

								array(
									'type'             => 'dropdown',
									'heading'          => esc_html__( 'Element Type', 'berserk' ),
									'value'            => array(
										'Span' => 'span',
										'br'   => 'br',
									),
									'admin_label'      => true,
									'param_name'       => 'item_type',
									'edit_field_class' => 'vc_col-sm-6 vc_column',
								),

								array(
									'type'             => 'textfield',
									'heading'          => esc_html__( 'Label', 'js_composer' ),
									'param_name'       => 'label',
									'edit_field_class' => 'vc_col-sm-6 vc_column',
									'admin_label'      => true,
									'dependency'       => array(
										'element' => 'item_type',
										'value'   => 'span',
									),
								),

								array(
									'type'             => 'dropdown',
									'heading'          => esc_html__( 'Font', 'berserk' ),
									'value'            => array(
										esc_html__( 'Open Sans', 'berserk' )             => 'open-sans',
										esc_html__( 'Montserrat', 'berserk' )            => 'montserrat',
										esc_html__( 'Montserrat Alternates', 'berserk' ) => 'montserrat-alt',
										esc_html__( 'Playfair Display', 'berserk' )      => 'playfair',
										esc_html__( 'Poppins', 'berserk' )               => 'poppins',
										esc_html__( 'Pacifico', 'berserk' )              => 'pacifico',
										esc_html__( 'Roboto', 'berserk' )                => 'roboto',
										esc_html__( 'Roboto Slab', 'berserk' )           => 'roboto-slab',
										esc_html__( 'Oxygen', 'berserk' )                => 'oxygen',
										esc_html__( 'Times New Roman', 'berserk' )       => 'times-new-roman',
									),
									'param_name'       => 'brs_font',
									'edit_field_class' => 'vc_col-sm-6 vc_column',
									"std"              => "montserrat",
									'dependency'       => array(
										'element' => 'item_type',
										'value'   => 'span',
									),

								),
								array(
									'type'             => 'dropdown',
									'heading'          => esc_html__( 'Font weight', 'berserk' ),
									'value'            => array(
										__( 'Normal', 'berserk' )     => 'normal',
										__( 'Thin', 'berserk' )       => 'thin',
										__( 'Light', 'berserk' )      => 'light',
										__( 'Ultralight', 'berserk' ) => 'ultralight',
										__( 'Bold', 'berserk' )       => 'bold',
										__( 'Medium', 'berserk' )     => 'medium',
										__( 'Semibold', 'berserk' )   => 'semibold',
										__( 'Extrabold', 'berserk' )  => 'extrabold',
									),
									'param_name'       => 'font_weight',
									'edit_field_class' => 'vc_col-sm-6 vc_column',
									'dependency'       => array(
										'element' => 'item_type',
										'value'   => 'span',
									),

								),
								array(
									"param_name"       => "text_uppercase",
									"type"             => "checkbox",
									"value"            => array(
										"Text Uppercase" => "y",
									),
									'admin_label'      => true,
									'edit_field_class' => 'vc_col-sm-6 vc_column',
									'dependency'       => array(
										'element' => 'item_type',
										'value'   => 'span',
									),

								),
								array(
									"param_name"       => "font_style_italic",
									"type"             => "checkbox",
									"value"            => array(
										"Font style italic" => "y",
									),
									'admin_label'      => true,
									'edit_field_class' => 'vc_col-sm-6 vc_column',
									'dependency'       => array(
										'element' => 'item_type',
										'value'   => 'span',
									),
								),

							),
						),

						array(
							'type'             => 'textarea',
							'heading'          => __( 'Description', 'js_composer' ),
							'param_name'       => 'description',
							"value"            => "Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor consequat",
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__info_box_type chess outline gradient shuffle web strict image icon',
						),

						array(
							'type'             => 'textarea_raw_html',
							'heading'          => __( 'Description', 'js_composer' ),
							'param_name'       => 'description_bonus',
							"value"            => "Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor consequat",
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__info_box_type bonus',
						),

						array(
							"type"             => "textfield",
							"heading"          => __( "Link URL", 'berserk' ),
							"param_name"       => "link_url",
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							"value"            => "#"
						),

						array(
							"type"             => "textfield",
							"heading"          => __( "Link Title", 'berserk' ),
							"param_name"       => "link_title",
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							"value"            => "Read More"
						),

						array(
							'type'        => 'attach_image',
							'heading'     => __( 'Background Image', 'js_composer' ),
							'param_name'  => 'bg_image',
							'value'       => '',
							'description' => __( 'Select image from media library.', 'js_composer' ),
						),

						array(
							'type'             => 'dropdown',
							'heading'          => __( 'FadeIn Effect', 'berserk' ),
							'value'            => array(
								__( 'FadeIn', 'berserk' )      => 'fade_in',
								__( 'FadeInLeft', 'berserk' )  => 'fade_in_left',
								__( 'FadeInRight', 'berserk' ) => 'fade_in_right',
							),
							'param_name'       => 'fade_effect',
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

						array(
							"param_name"       => "bottom",
							"type"             => "checkbox",
							"value"            => array(
								"Bottom Item" => "y",
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

						array(
							"heading"          => __( "Icon", 'berserk' ),
							"param_name"       => "brs_title",
							"type"             => "brs_title",
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
						),

						array(
							'type'             => 'dropdown',
							'heading'          => __( 'Icon library', 'berserk' ),
							'value'            => array(
								__( 'Font Awesome', 'berserk' ) => 'fontawesome',
								__( 'Open Iconic', 'berserk' )  => 'openiconic',
								__( 'Typicons', 'berserk' )     => 'typicons',
								__( 'Entypo', 'berserk' )       => 'entypo',
								__( 'Linecons', 'berserk' )     => 'linecons',
								__( 'Mono Social', 'berserk' )  => 'monosocial',
								__( 'Livicon', 'berserk' )      => 'livicon',
							),
							'admin_label'      => true,
							'param_name'       => 'btn_icon_type',
							'edit_field_class' => 'vc_col-sm-6 vc_column icon_option',
						),
						array(
							'type'             => 'textfield',
							'heading'          => esc_html__( 'Icon Custom CSS Class', 'berserk' ),
							'param_name'       => 'icon_custom_class',
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'fontawesome',
							),
						),
						array(
							'type'             => 'iconpicker',
							'heading'          => __( 'Icon', 'berserk' ),
							'param_name'       => 'icon_fontawesome',
							'value'            => 'fa fa-adjust', // default value to backend editor admin_label
							'settings'         => array(
								'emptyIcon'    => false,
								'iconsPerPage' => 4000,
							),
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'fontawesome',
							),
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
						),
						array(
							'type'             => 'iconpicker',
							'heading'          => __( 'Icon', 'berserk' ),
							'param_name'       => 'icon_openiconic',
							'value'            => 'vc-oi vc-oi-dial', // default value to backend editor admin_label
							'settings'         => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'openiconic',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'openiconic',
							),
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
						),
						array(
							'type'             => 'iconpicker',
							'heading'          => __( 'Icon', 'berserk' ),
							'param_name'       => 'icon_typicons',
							'value'            => 'typcn typcn-adjust-brightness',
							// default value to backend editor admin_label
							'settings'         => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'typicons',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'typicons',
							),
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
						),
						array(
							'type'             => 'iconpicker',
							'heading'          => __( 'Icon', 'berserk' ),
							'param_name'       => 'icon_entypo',
							'value'            => 'entypo-icon entypo-icon-note',
							// default value to backend editor admin_label
							'settings'         => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'entypo',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'entypo',
							),
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
						),
						array(
							'type'             => 'iconpicker',
							'heading'          => __( 'Icon', 'berserk' ),
							'param_name'       => 'icon_linecons',
							'value'            => 'vc_li vc_li-heart', // default value to backend editor admin_label
							'settings'         => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'linecons',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'linecons',
							),
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
						),
						array(
							'type'             => 'iconpicker',
							'heading'          => __( 'Icon', 'berserk' ),
							'param_name'       => 'icon_monosocial',
							'value'            => 'vc-mono vc-mono-fivehundredpx',
							// default value to backend editor admin_label
							'settings'         => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'monosocial',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'monosocial',
							),
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
						),

						array(
							"type"             => "textarea_html",
							"holder"           => "div",
							"class"            => "",
							"param_name"       => "content",
							"value"            => __( "", 'berserk' ),
							"description"      => "",
							'dependency'       => array(
								'element' => 'btn_icon_type',
								'value'   => 'livicon',
							),
							'admin_label'      => false,
							'edit_field_class' => 'icon_option vc_col-xs-12 vc_column',
						),

					)
				) );

			}
		}

		public function shortcode_info_box( $atts, $content = null ) {

			brs_add_libraries( 'component__info_box' );

			extract( shortcode_atts( array(
				'info_box_type'     => 'chess',
				'first_title'       => 'Awesome',
				'title'             => 'Design',
				'description'       => 'Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae',
				'description_bonus' => '',
				'link_url'          => '#',
				'link_title'        => 'Read More',
				'btn_icon_type'     => 'fontawesome',
				'icon_custom_class' => '',
				'icon_fontawesome'  => '',
				'icon_openiconic'   => '',
				'icon_typicons'     => '',
				'icon_entypo'       => '',
				'icon_linecons'     => '',
				'icon_monosocial'   => '',
				'brs_btn_icon'      => '',
				'bg_image'          => '',
				'bg_gradient'       => '',
				'bottom'            => '',
				'text_align'        => '',
				'fade_effect'       => 'fade_in',
				'title_values'      => ''

			), $atts ) );

			static $start_count = 0;

			// store atts
			$atts_backup = self::$atts;

			$icon_class                     = array();
			$icon_class['type']             = $btn_icon_type;
			$icon_class['icon_livicon']     = '';
			$icon_class['icon_fontawesome'] = $icon_fontawesome;
			$icon_class['icon_openiconic']  = $icon_openiconic;
			$icon_class['icon_typicons']    = $icon_typicons;
			$icon_class['icon_entypo']      = $icon_entypo;
			$icon_class['icon_linecons']    = $icon_linecons;
			$icon_class['icon_monosocial']  = $icon_monosocial;
			$icon_class                     = $this->get_icon_class( $icon_class );
			if ( $icon_custom_class ) {
				$icon_class = $icon_class . ' ' . $icon_custom_class;
			}

			$icon_html                      = ' <i class="' . esc_attr( $icon_class ) . '"></i>';

			if ( isset( $content ) && $btn_icon_type == 'livicon' ) {
				$svg_icon  = do_shortcode( $content );
				$icon_html = $svg_icon;
			}

			$bg_image = wp_get_attachment_image_src( $bg_image, 'full' );
			$bg_image = $bg_image[0];

			switch ( $info_box_type ) {
				case "chess":

					// Item class
					$item_class = array(
						'info-box__wrapper-chess',
						'mb-40',
						'mb-md-0',
						'wow',
					);
					if ( isset( $bottom ) && $bottom == 'y' ) {
						$item_class[] = 'bottom';
						$item_class[] = 'fadeInDown';
					} else {
						$item_class[] = 'fadeInUp';
					}
					if ( isset( $text_align ) ) {
						if ( $text_align != '' ) {
							$item_class[] = $text_align;
						}
					}
					$item_class = implode( ' ', $item_class );

					// Overlay Classes
					$overlay_classes = 'overlay_after brk-base-gradient-31 opacity-90';

					$output = '<div class="' . esc_attr( $item_class ) . '">
								<div class="show-cont overlay__gradient">
								  ' . $icon_html . '
								  <h3 class="font__family-montserrat font__weight-medium font__size-28">' . $title . '</h3>
								  <span class="after bg__style" style="background-image: url(' . esc_url( $bg_image ) . ');"></span>
								  <span class="' . esc_attr( $overlay_classes ) . '"></span>
								</div>
								<div class="move-cont">
								  <p class="font__family-open-sans font__size-14">' . $description . '</p>
								  <a href="' . $link_url . '" class="btn btn-lg border-radius-25 font__family-open-sans font__weight-bold btn-inside-out">
									<span class="before">' . $link_title . '</span>
									<span class="text">' . $link_title . '</span>
									<span class="after">' . $link_title . '</span>
								  </a>
								</div>
							  </div>';
					break;

				case "outline":

					$item_class = 'info-box__wrapper-outline';
					if ( isset( $text_align ) ) {
						if ( $text_align != '' ) {
							$item_class .= ' ' . $text_align;
						}
					}

					$output = '<div class="' . esc_attr( $item_class ) . '">
								<div class="move-cont">
								 ' . $icon_html . '
								  <h3 class="font__family-montserrat font__weight-medium font__size-28">' . $title . '</h3>
								  <p class="font__family-open-sans font__size-14">' . $description . '</p>
								</div>
							  </div>';

					break;

				case "gradient":

					$item_class = 'info-box__wrapper-' . $info_box_type;
					if ( isset( $text_align ) ) {
						if ( $text_align != '' ) {
							$item_class .= ' ' . $text_align;
						}
					}

					$output = '<div class="' . esc_attr( $item_class ) . '">
								<div class="move-cont">
								  <div class="svg-wrap">
									' . $icon_html . '
								  </div>
								  <div class="show-cont">
									<h3 class="font__family-montserrat font__weight-semibold font__size-28">' . $title . '</h3>
									<p class="font__family-open-sans font__size-14">' . $description . '</p>
								  </div>
								</div>
							  </div>';

					break;

				case "shuffle":

					$item_class = 'info-box__wrapper-' . $info_box_type;
					if ( isset( $bottom ) && $bottom == 'y' ) {
						$item_class .= ' bottom';
					}
					if ( isset( $text_align ) ) {
						if ( $text_align != '' ) {
							$item_class .= ' ' . $text_align;
						}
					}

					$output = '<div class="' . esc_attr( $item_class ) . '">
								<img src="' . esc_url( $bg_image ) . '" class="img-bottom" alt="">
								<img src="' . esc_url( $bg_image ) . '" class="img-top" alt="">
								<div>
								  <div class="svg-wrap">
									 ' . $icon_html . '
								  </div>
								  <h3 class="font__family-montserrat font__weight-semibold font__size-28">' . $title . '</h3>
								  <p class="font__family-open-sans font__size-14">' . $description . '</p>
								  <a href="' . $link_url . '" class="btn btn-lg border-radius-25 font__family-open-sans font__weight-bold btn-inside-out btn-inside-out-invert">
									<span class="before">' . $link_title . '</span>
									<span class="text">' . $link_title . '</span>
									<span class="after">' . $link_title . '</span>
								  </a>
								  <span class="after-bg"><span class="after"></span></span>
								</div>
							  </div>';

					break;

				case "web":

					$item_class = 'info-box__wrapper-' . $info_box_type;
					if ( isset( $text_align ) ) {
						if ( $text_align != '' ) {
							$item_class .= ' ' . $text_align;
						}
					}

					$output = '<div class="' . esc_attr( $item_class ) . '">
								<div class="shape">
								  <span class="before"></span>
								  <div class="svg-wrap">
									 ' . $icon_html . '
								  </div>
								  <span class="after"></span>
								</div>
								<div class="content">
								  <h3 class="font__family-montserrat font__weight-semibold font__size-28">' . $title . '</h3>
								  <p class="font__family-open-sans font__size-14">' . $description . '</p>
								</div>
							  </div>';

					break;

				case "strict":

					$item_class = 'info-box__wrapper-' . $info_box_type;
					if ( isset( $text_align ) ) {
						if ( $text_align != '' ) {
							$item_class .= ' ' . $text_align;
						}
					}

					$output = '<div class="' . esc_attr( $item_class ) . '">
								<div class="svg-wrap">
								  ' . $icon_html . '
								</div>
								<h3 class="font__family-montserrat font__weight-semibold font__size-24 text-uppercase line__height-30"><span class="font__weight-light">' . $first_title . '</span><br> ' . $title . '</h3>
								<p class="font__family-open-sans font__size-14"> ' . substr( $description, 0, 26 ) . '<span class="show-cont">' . substr( $description, 26 ) . '</span></p>
								<a href="' . $link_url . '" class="btn btn-sliding-left"><span class="text">' . $link_title . '</span><span class="border"><i class="fa fa-angle-right"></i></span></a>
							  </div>';

					break;
				case "image":

					$fade_class = 'fadeIn';

					switch ( $fade_effect ) {
						case "fade_in_left":
							$fade_class = 'fadeInLeft';
							break;
						case "fade_in_right":
							$fade_class = 'fadeInRight';
							break;
					}

					$style = '';
					if ( ! empty( $bg_image ) ) {
						$style = 'background-image: url(' . esc_url( $bg_image ) . ');';
						$fade_class .= ' light bg__style';
					}

					$item_class = 'info-box__wrapper-' . $info_box_type . ' wow';
					$item_class .= ' ' . $fade_class;
					if ( isset( $text_align ) ) {
						if ( $text_align != '' ) {
							$item_class .= ' ' . $text_align;
						}
					}

					$output = '<div class="' . $item_class . '" style="' . $style . '">
								  ' . $icon_html . '
								  <h6 class="font__family-montserrat font__weight-semibold font__size-14 text-uppercase line__height-24 letter-spacing-100">' . $title . '</h6>
								  <p class="font__family-open-sans font__size-14">' . $description . '</p>
								</div>';

					break;
				case "icon":

					$item_class = 'info-box__wrapper-' . $info_box_type;
					if ( isset( $text_align ) ) {
						if ( $text_align != '' ) {
							$item_class .= ' ' . $text_align;
						}
					}
					if ($start_count > 0 ) {
						$wow_delay = $start_count / 10;
					} else {
						$wow_delay = 0;
					}

					$output = '<div class="' . esc_attr( $item_class ) . '">
								<div class="wow fadeInDown" data-wow-duration="0.8s" data-wow-delay="' . esc_attr( $wow_delay ) . 's">
								   ' . $icon_html . '
								</div>
								<div class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="' . esc_attr( $wow_delay ) . 's">
								  <h6 class="font__family-montserrat font__weight-semibold font__size-18 line__height-28">' . $first_title . ' <br>' . $title . '</h6>
								  <p class="font__family-open-sans font__size-14">' . $description . '</p>
								</div>
								<div class="icon-after"></div>
							  </div>';

					$start_count++;

					break;
				case "bonus":

					$title_values = vc_param_group_parse_atts( $title_values );

					$output = '<div class="brk-sc-bonus text-center pl-50 pr-50 pb-40 pt-50 d-flex flex-column">
								<h6 class="brk-sc-bonus__subtitle font__family-montserrat brk-white-font-color font__size-14 font__weight-bold line__height-14 brk-bg-primary">
									' . esc_html( $first_title ) . '
								</h6>

								<h5 class="brk-sc-bonus__title font__family-montserrat font__size-21 font__weight-normal line__height-28 mb-15">';

					foreach ( $title_values as $value ) {

						switch ( $value['item_type'] ) {
							case "span":

								$item_class   = array();
								$item_class[] = 'font__family-' . $value['brs_font'];
								$item_class[] = 'font__weight-' . $value['font_weight'];

								if ( isset( $value['font_style_italic'] ) && $value['font_style_italic'] == 'y' ) {
									$item_class[] = 'font__style-italic';
								}
								if ( isset( $value['text_uppercase'] ) && $value['text_uppercase'] == 'y' ) {
									$item_class[] = 'text-uppercase';
								}
								$item_class = implode( ' ', $item_class );

								$output .= '<span class="' . $item_class . '">' . esc_html( $value['label'] ) . '</span>';

								break;
							case "br":
								$output .= '<br>';
								break;

						}
					}
					$output .= '</h5>
								<p class="font__family-open-sans font__size-16 font__weight-normal line__height-26 brk-dark-font-color">
								   ' . rawurldecode( base64_decode( $description_bonus ) ) . '
								</p>';

					if ( ! empty( $link_url ) && ! empty( $link_title ) ) {
						$output .= '<a href="' . esc_url( $link_url ) . '" class="brk-base-font-color font__family-open-sans font__size-16 font__weight-normal line__height-26  brk-sc-bonus__link">' . esc_html( $link_title ) . '</a>';
					}

					$output .= '</div>';
					break;
			}

			// restore atts
			self::$atts = $atts_backup;

			return $output;
		}

		protected function get_icon_class( $atts ) {
			$icon_class = '';

			$icon_class = $atts[ 'icon_' . $atts['type'] ];

			if ( empty( $icon_class ) ) {
				$icon_class = 'fa fa-trophy';
			}

			return $icon_class;
		}


	}

	// create shortcode
	BRS_Info_Box::get_instance();

}
