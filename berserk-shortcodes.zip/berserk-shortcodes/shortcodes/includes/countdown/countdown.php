<?php
/**
 * CountDown shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Countdown', false ) ) {

	class BRS_Countdown extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Countdown();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_countdown', array( $this, 'shortcode_countdown' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Countdown", 'berserk' ),
					"base"     => "brs_countdown",
					"icon"     => "brs_vc_ico_countdown",
					"class"    => "brs_vc_sc_countdownt",
					"category" => __( 'Berserk', 'berserk' ),
					"params"   => array(
						array(
							'heading'    => __( 'Countdown Type', 'berserk' ),
							'param_name' => 'countdown_type',
							'type'       => 'brs_radio',
							'value'      => array(
								"Circle"  => "circle",
								"Light"   => "light",
								"Massive" => "massive",
								"Dash"    => "dash",
								"Flip"    => "flip",
								"Flip 2"  => "flip_2",
								"Large"   => "large"
							),
							'images'     => array(
								"circle"  => 'countdown/001.jpg',
								"light"   => 'countdown/002.jpg',
								"massive" => 'countdown/003.jpg',
								"dash"    => 'countdown/004.jpg',
								"flip"    => 'countdown/005.jpg',
								"flip_2"  => 'countdown/007.jpg',
								"large"   => 'countdown/006.jpg'
							),
							'images_dim' => array(
								'w' => '320',
								'h' => '100'
							)
						),
						array(
							'type'             => 'textfield',
							'heading'          => __( 'Year', 'js_composer' ),
							'value'            => '2017',
							'param_name'       => 'cd_year',
							"edit_field_class" => "vc_col-sm-2 vc_column",
						),
						array(
							'type'             => 'textfield',
							'heading'          => __( 'Month', 'js_composer' ),
							'value'            => '09',
							'param_name'       => 'cd_month',
							"edit_field_class" => "vc_col-sm-2 vc_column",
						),
						array(
							'type'             => 'textfield',
							'heading'          => __( 'Day', 'js_composer' ),
							'value'            => '01',
							'param_name'       => 'cd_day',
							"edit_field_class" => "vc_col-sm-2 vc_column",
						),
						array(
							'type'             => 'textfield',
							'heading'          => __( 'Hour', 'js_composer' ),
							'value'            => '12',
							'param_name'       => 'cd_hour',
							"edit_field_class" => "vc_col-sm-2 vc_column",
						),
						array(
							'type'             => 'textfield',
							'heading'          => __( 'Minutes', 'js_composer' ),
							'value'            => '00',
							'param_name'       => 'cd_minutes',
							"edit_field_class" => "vc_col-sm-2 vc_column",
						),

						array(
							"param_name"       => "show_days",
							"type"             => "checkbox",
							"value"            => array(
								"Show Days" => "y",
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

						array(
							"type"             => "dropdown",
							"heading"          => __( "Size", 'berserk' ),
							"param_name"       => "size",
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__countdown_type large',
							"value"            => array(
								"Large"           => "large",
								"Large Alternate" => "large_alt",
								"Medium"          => "medium",
							)
						),

						array(
							"param_name"       => "shadow",
							"type"             => "checkbox",
							"value"            => array(
								"Shadow" => "y",
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__countdown_type large',
						),

						array(
							"type"             => "dropdown",
							"heading"          => __( "Padding top/bottom", 'berserk' ),
							"param_name"       => "padding_tb",
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__countdown_type large',
							"value"            => array(
								"10 px" => "10",
								"20 px" => "20",
								"30 px" => "30",
								"40 px" => "40",
								"50 px" => "50",
								"60 px" => "60",
							)
						),

						array(
							'type'             => 'dropdown',
							'heading'          => esc_html__( 'Color', 'berserk' ),
							'param_name'       => 'color',
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__countdown_type light',
							'value'            => array(
								'Default' => 'default',
								'White'   => 'white',
							)
						),

						// Additional CSS Class
						array(
							'type'             => 'textfield',
							'heading'          => esc_html__( 'Additional CSS Class', 'berserk' ),
							'group'            => esc_html__( 'Advanced', 'berserk' ),
							'param_name'       => 'css_class',
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

					)
				) );
			}
		}

		public function shortcode_countdown( $atts, $content = null ) {

			$libraries = array( 'component__countdown' );
			brs_add_libraries( $libraries );

			extract( shortcode_atts( array(
				'countdown_type' => 'circle',
				'cd_year'        => '2017',
				'cd_month'       => '09',
				'cd_day'         => '01',
				'cd_hour'        => '12',
				'cd_minutes'     => '00',
				'show_days'      => '',
				'size'           => 'large',
				'shadow'         => '',
				'padding_tb'     => '',
				'color'          => 'default',
				'css_class'      => '',
			), $atts ) );

			$date = $cd_year . '/' . $cd_month . '/' . $cd_day . ' ' . $cd_hour . ':' . $cd_minutes;

			// store atts
			$atts_backup = self::$atts;

			$class = array( 'countdown__wrapper' );
			if( $css_class ) {
				$css_class = explode( ' ', $css_class );
				$class = array_merge( $class, $css_class );
			}

			switch ( $countdown_type ) {
				case "circle":

					$class[] = 'countdown__circle';
					$class[] = 'pt-70';
					$class[] = 'pb-70';
					$class = implode( ' ', $class );

					$output = '<div class="' . esc_attr( $class ) . '">
					            <div class="countdown"
					              data-format="';

					if ( $show_days && $show_days == 'y' ) {
						$output .= '<div class=\'countdown__section\'>
					                  <div class=\'font__family-montserrat font__size-96 font__weight-light countdown__amount day\'>
					                    %D
					                    <div class=\'svg-wrap\'>
					                      <svg>
					                        <circle stroke=\'url(#stroke_grad_1)\'  cx=\'103\' cy=\'103\' r=\'103\' stroke-dashoffset=\'0\'></circle>
					                        <defs>
					                          <linearGradient id=\'stroke_grad_1\' x1=\'0%\' y1=\'0%\' x2=\'100%\' y2=\'0%\'>
					                            <stop offset=\'0%\'   stop-color=\'#2775ff\'/>
					                            <stop offset=\'100%\' stop-color=\'#7202bb\'/>
					                          </linearGradient>
					                        </defs>
					                      </svg>
					                    </div>
					                  </div>
					                  <span class=\'font__family-montserrat font__size-18 font__weight-bold countdown__period\'>Days</span>
					                </div>';
					}

					$output .= '<div class=\'countdown__section\'>
					                  <div class=\'font__family-montserrat font__size-96 font__weight-light countdown__amount hour\'>
					                    %H
					                    <div class=\'svg-wrap\'>
					                      <svg>
					                        <circle stroke=\'url(#stroke_grad_2)\'  cx=\'103\' cy=\'103\' r=\'103\' stroke-dashoffset=\'0\'></circle>
					                        <defs>
					                          <linearGradient id=\'stroke_grad_2\' x1=\'0%\' y1=\'0%\' x2=\'100%\' y2=\'0%\'>
					                            <stop offset=\'0%\'   stop-color=\'#2775ff\'/>
					                            <stop offset=\'100%\' stop-color=\'#7202bb\'/>
					                          </linearGradient>
					                        </defs>
					                      </svg>
					                    </div>
					                  </div>
					                  <span class=\'font__family-montserrat font__size-18 font__weight-bold countdown__period\'>Hours</span>
					                </div>

					                <div class=\'countdown__section\'>
					                  <div class=\'font__family-montserrat font__size-96 font__weight-light countdown__amount min\'>
					                    %M
					                    <div class=\'svg-wrap\'>
					                      <svg>
					                        <circle stroke=\'url(#stroke_grad_3)\'  cx=\'103\' cy=\'103\' r=\'103\' stroke-dashoffset=\'0\'></circle>
					                        <defs>
					                          <linearGradient id=\'stroke_grad_3\' x1=\'0%\' y1=\'0%\' x2=\'100%\' y2=\'0%\'>
					                            <stop offset=\'0%\'   stop-color=\'#2775ff\'/>
					                            <stop offset=\'100%\' stop-color=\'#7202bb\'/>
					                          </linearGradient>
					                        </defs>
					                      </svg>
					                    </div>
					                  </div>
					                  <span class=\'font__family-montserrat font__size-18 font__weight-bold countdown__period\'>Minutes</span>
					                </div>

					                <div class=\'countdown__section\'>
					                  <div class=\'font__family-montserrat font__size-96 font__weight-light countdown__amount sec\'>
					                    %S
					                    <div class=\'svg-wrap\'>
					                      <svg>
					                        <circle stroke=\'url(#stroke_grad_4)\'  cx=\'103\' cy=\'103\' r=\'103\' stroke-dashoffset=\'0\'></circle>
					                        <defs>
					                          <linearGradient id=\'stroke_grad_4\' x1=\'0%\' y1=\'0%\' x2=\'100%\' y2=\'0%\'>
					                            <stop offset=\'0%\'   stop-color=\'#2775ff\'/>
					                            <stop offset=\'100%\' stop-color=\'#7202bb\'/>
					                          </linearGradient>
					                        </defs>
					                      </svg>
					                    </div>
					                  </div>
					                  <span class=\'font__family-montserrat font__size-18 font__weight-bold countdown__period\'>Seconds</span>
					                </div>
					              "
					              data-type="until"
					              data-time="' . $date . '"></div>
					          </div>';

					break;

				case "light":

					$class[] = 'countdown__light';
					if ( $color == 'white' ) {
						$class[] = 'countdown__light_white';
					}
					$class = implode( ' ', $class );

					$output = '<div class="' . esc_attr( $class ) . '">
					            <div class="countdown"
					              data-format="';
					if ( $show_days && $show_days == 'y' ) {
						$output .= '<div class=\'countdown__section\'>
					                  <div class=\'font__family-montserrat font__size-96 font__weight-ultralight countdown__amount\'>%D</div>
					                  <span class=\'font__family-montserrat font__size-18 font__weight-bold countdown__period\'>Days</span>
					                  <span class=\'symbol\'>:</span>
					                </div>';
					}
					$output .= '<div class=\'countdown__section\'>
					                  <div class=\'font__family-montserrat font__size-96 font__weight-ultralight countdown__amount\'>%H</div>
					                  <span class=\'font__family-montserrat font__size-18 font__weight-bold countdown__period\'>Hours</span>
					                  <span class=\'symbol\'>:</span>
					                </div>
					                <div class=\'countdown__section\'>
					                  <div class=\'font__family-montserrat font__size-96 font__weight-ultralight countdown__amount\'>%M</div>
					                  <span class=\'font__family-montserrat font__size-18 font__weight-bold countdown__period\'>Minutes</span>
					                  <span class=\'symbol\'>:</span>
					                </div>
					                <div class=\'countdown__section\'>
					                  <div class=\'font__family-montserrat font__size-96 font__weight-ultralight countdown__amount\'>%S</div>
					                  <span class=\'font__family-montserrat font__size-18 font__weight-bold countdown__period\'>Seconds</span>
					                  <span class=\'symbol\'>:</span>
					                </div>
					              "
					              data-type="until"
					              data-time="' . $date . '"></div>
					          </div>';

					break;

				case "massive":

					$class[] = 'countdown__massive';
					$class = implode( ' ', $class );

					$output = '<div class="' . esc_attr( $class ) . '">
					            <div class="countdown"
					              data-format="';
					if ( $show_days && $show_days == 'y' ) {
						$output .= '<div class=\'countdown__section\'>
					                  <div class=\'font__family-montserrat font__size-96 font__weight-ultralight countdown__amount\'>%D</div>
					                  <span class=\'font__family-montserrat font__size-14 font__weight-light countdown__period\'>Dys</span>
					                </div>';
					}
					$output .= '<div class=\'countdown__section\'>
					                  <div class=\'font__family-montserrat font__size-96 font__weight-ultralight countdown__amount\'>%H</div>
					                  <span class=\'font__family-montserrat font__size-14 font__weight-light countdown__period\'>Hrs</span>
					                </div>
					                <div class=\'countdown__section\'>
					                  <div class=\'font__family-montserrat font__size-96 font__weight-ultralight countdown__amount\'>%M</div>
					                  <span class=\'font__family-montserrat font__size-14 font__weight-light countdown__period\'>Min</span>
					                </div>
					                <div class=\'countdown__section\'>
					                  <div class=\'font__family-montserrat font__size-96 font__weight-ultralight countdown__amount\'>%S</div>
					                  <span class=\'font__family-montserrat font__size-14 font__weight-light countdown__period\'>Sec</span>
					                </div>
					              "
					              data-type="until"
					              data-time="' . $date . '"></div>
					          </div>';
					break;

				case "dash":

					$class[] = 'countdown__dash';
					$class[] = 'pb-100';
					$class[] = 'pt-100';
					$class = implode( ' ', $class );

					$output = '<div class="' . esc_attr( $class ) . '">
					            <div class="countdown"
					              data-format="';
					if ( $show_days && $show_days == 'y' ) {
						$output .= '<div class=\'countdown__section\'>
					                  <div class=\'font__family-montserrat font__size-96 font__weight-ultralight countdown__amount\'>%D</div>
					                  <span class=\'font__family-montserrat font__size-18 font__weight-bold countdown__period\'>Days</span>
					                  <span class=\'symbol\'>-</span>
					                </div>';
					}
					$output .= '<div class=\'countdown__section\'>
					                  <div class=\'font__family-montserrat font__size-96 font__weight-ultralight countdown__amount\'>%H</div>
					                  <span class=\'font__family-montserrat font__size-18 font__weight-bold countdown__period\'>Hours</span>
					                  <span class=\'symbol\'>-</span>
					                </div>
					                <div class=\'countdown__section\'>
					                  <div class=\'font__family-montserrat font__size-96 font__weight-ultralight countdown__amount\'>%M</div>
					                  <span class=\'font__family-montserrat font__size-18 font__weight-bold countdown__period\'>Minutes</span>
					                  <span class=\'symbol\'>-</span>
					                </div>
					                <div class=\'countdown__section\'>
					                  <div class=\'font__family-montserrat font__size-96 font__weight-ultralight countdown__amount\'>%S</div>
					                  <span class=\'font__family-montserrat font__size-18 font__weight-bold countdown__period\'>Seconds</span>
					                  <span class=\'symbol\'>-</span>
					                </div>
					              "
					              data-type="until"
					              data-time="' . $date . '"></div>
					          </div>';

					break;
				case "flip":

					$class[] = 'countdown__flip';
					$class[] = 'pb-100';
					$class[] = 'pt-100';
					$class = implode( ' ', $class );

					$output = '<div class="' . esc_attr( $class ) . '"
					            data-format="
					              <div class=\'countdown__section\'>
					                <div class=\'time <%= label %>\'>
					                  <span class=\'count curr top\'><%= curr %></span>
					                  <span class=\'count next top\'><%= next %></span>
					                  <span class=\'count next bottom\'><%= next %></span>
					                  <span class=\'count curr bottom\'><%= curr %></span>
					                </div>
					                <span class=\'label\'><%= label %></span>
					              </div>
					            "
					            data-time="' . $date . '"></div>';

					break;
				case "flip_2":

					$class[] = 'countdown__flip-2';
					$class = implode( ' ', $class );

					$output = '<div class="' . esc_attr( $class ) . '"
					            data-format="
					              <div class=\'countdown__section\'>
					                <div class=\'time <%= label %>\'>
					                  <span class=\'count curr top\'><%= curr %></span>
					                  <span class=\'count next top\'><%= next %></span>
					                  <span class=\'count next bottom\'><%= next %></span>
					                  <span class=\'count curr bottom\'><%= curr %></span>
					                </div>
					                <span class=\'label\'><%= label %></span>
					              </div>
					            "
					            data-time="' . $date . '"></div>';

					break;
				case "large":

					$size_class      = 'countdown__large';
					$font_class_div  = 'font__size-56';
					$font_class_span = 'font__size-21';

					switch ( $size ) {
						case "medium":
							$size_class = 'countdown__medium';
							break;
						case "large_alt":
							$font_class_div  = 'font__size-36-i';
							$font_class_span = 'font__size-16';
							break;
					}

					$class[] = $size_class;
					if ( $shadow == 'y' ) {
						$class[] = 'shadow';
					}
					$class = implode( ' ', $class );

					$p_tb = isset( $padding_tb ) ? $padding_tb : '60';

					$output = '<div class="' . esc_attr( $class ) . '">
					            <div class="countdown pb-' . $p_tb . ' pt-' . $p_tb . ' pl-40 pr-40"
					              data-format="';
					if ( $show_days && $show_days == 'y' ) {
						$output .= '<div class=\'countdown__section\'>
					                  <div class=\'font__family-montserrat ' . $font_class_div . ' font__weight-bold countdown__amount\'>%D</div>
					                  <span class=\'font__family-montserrat ' . $font_class_span . ' font__weight-bold countdown__period\'>' . __( 'Days', 'berserk' ) . '</span>
					                </div>';
					}
					$output .= '<div class=\'countdown__section\'>
					                  <div class=\'font__family-montserrat ' . $font_class_div . ' font__weight-bold countdown__amount\'>%H</div>
					                  <span class=\'font__family-montserrat ' . $font_class_span . ' font__weight-bold countdown__period\'>' . __( 'Hours', 'berserk' ) . '</span>
					                </div>
					                <div class=\'countdown__section\'>
					                  <div class=\'font__family-montserrat ' . $font_class_div . ' font__weight-bold countdown__amount\'>%M</div>
					                  <span class=\'font__family-montserrat ' . $font_class_span . ' font__weight-bold countdown__period\'>' . __( 'Mins', 'berserk' ) . '</span>
					                </div>
					                <div class=\'countdown__section\'>
					                  <div class=\'font__family-montserrat ' . $font_class_div . ' font__weight-bold countdown__amount\'>%S</div>
					                  <span class=\'font__family-montserrat ' . $font_class_span . ' font__weight-bold countdown__period\'>' . __( 'Secs', 'berserk' ) . '</span>
					                </div>
					              "
					              data-type="until"
					              data-time="' . $date . '"></div>
					          </div>';

					break;
			}


			// restore atts
			self::$atts = $atts_backup;

			return $output;
		}


	}

	// create shortcode
	BRS_Countdown::get_instance();

}
