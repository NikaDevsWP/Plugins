<?php
/**
 * Contact form shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Contact_Form', false ) ) {

	class BRS_Contact_Form extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Contact_Form();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_contact_form', array( $this, 'shortcode_contact_form' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Contact Form", 'berserk' ),
					"base"     => "brs_contact_form",
					"icon"     => "brs_vc_ico_contact_form",
					"class"    => "brs_vc_sc_contact_form",
					"category" => __( 'Berserk', 'berserk' ),
					"params"   => array(
						array(
							'heading'    => __( 'Contact Form Type', 'berserk' ),
							'param_name' => 'contact_form_type',
							'type'       => 'brs_radio',
							'value'      => array(
								"Type 1" => "type_1",
								"Type 2" => "type_2",
								"Type 3" => "type_3",
								"Type 4" => "type_4",
							),
							'images'     => array(
								"type_1" => 'contact_form/001.jpg',
								"type_2" => 'contact_form/002.jpg',
								"type_3" => 'contact_form/003.jpg',
								"type_4" => 'contact_form/004.jpg',
							),
							'images_dim' => array(
								'w' => '310',
								'h' => '150'
							)
						),
						array(
							'type'        => 'dropdown',
							'param_name'  => 'form_id',
							'heading'     => esc_html__( 'Select contact form', 'berserk' ),
							//'save_always' => true,
							'description' => esc_html__( 'Choose contact form from the drop down list.', 'berserk' ),
							'value'       => BRS_Shortcodes_VCParams::get_wpcf7(),
						),
					)
				) );
			}
		}

		public function shortcode_contact_form( $atts, $content = null ) {

			$libraries = array( 'component__form' );
			brs_add_libraries( $libraries );

			extract( shortcode_atts( array(
				'contact_form_type' => 'type_1',
				'form_id'           => '',

			), $atts ) );

			$output     = '';
			$form_class = '';
			switch ( $contact_form_type ) {
				case "type_1":
					$form_class = 'brk-form-strict';
					break;

				case "type_2":
					$form_class = 'brk-form-round';
					break;

				case "type_3":
					$form_class = 'brk-form-transparent';
					break;
				case "type_4":
					$form_class = 'brk-form-transparent brk-form-transparent_dark brk-form-btn-inside brk-library-rendered';
					break;
			}

			$output .= '<div class="' . $form_class . '">';
			$output .= do_shortcode( sprintf( '[contact-form-7 id="%d"]', intval( $form_id ) ) );
			$output .= '</div>';

			return $output;
		}


	}

	// create shortcode
	BRS_Contact_Form::get_instance();

}
