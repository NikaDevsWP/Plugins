<?php
/**
 * Media shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Media', false ) ) {

	class BRS_Media extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Media();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_media', array( $this, 'shortcode_media' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				vc_map( array(
					"weight"   => - 1,
					"name"     => esc_html__( 'Media', 'berserk' ),
					"base"     => "brs_media",
					"icon"     => "brs_vc_ico_media",
					"class"    => "brs_vc_sc_media",
					"category" => esc_html__( 'Berserk', 'berserk' ),
					"params"   => array(

						array(
							'type'             => 'dropdown',
							'heading'          => esc_html__( 'Video type', 'berserk' ),
							'value'            => array(
								esc_html__( 'Self Hosted', 'berserk' ) => 'self_hosted',
							),
							'param_name'       => 'video_type',
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

						array(
							"type"       => "textarea_html",
							"heading"    => esc_html__( 'Video Upload', 'berserk' ),
							"param_name" => "content",
							"holder"     => "div",
							"class"      => "",
							"value"      => __( "", 'berserk' ),
						),

						array(
							'type'             => 'attach_image',
							'heading'          => esc_html__( 'Video Poster', 'js_composer' ),
							'param_name'       => 'video_poster',
							'value'            => '',
							'edit_field_class' => 'vc_col-sm-6 vc_column'
						),
						array(
							'type'             => 'dropdown',
							'heading'          => esc_html__( 'Image size', 'berserk' ),
							'value'            => BRS_Shortcodes_VCParams::get_image_sizes_names(),
							'param_name'       => 'image_size',
							'std'              => 'video-poster',
							'edit_field_class' => 'vc_col-sm-6 vc_column'
						),

						// Overlay Style
						array(
							'heading'          => esc_html__( 'Video Poster Overlay', 'berserk' ),
							'param_name'       => 'overlay_type',
							'type'             => "dropdown",
							'value'            => array(
								esc_html__( 'None', 'berserk' )                     => 'none',
								esc_html__( 'Overlay Background Color', 'berserk' ) => 'bg_color',
								esc_html__( 'Overlay Background Gradient', 'berserk' )         => 'gradient',
							),
							'edit_field_class' => 'vc_col-sm-3 vc_column',
						),

						array(
							'heading'          => esc_html__( 'Background Gradient', 'berserk' ),
							'param_name'       => 'overlay_gradient',
							'type'             => 'brs_color_scheme',
							'colors'           => BRS_Shortcodes_VCParams::get_gradients(),
							'dependency'       => array(
								'element' => 'overlay_type',
								'value'   => array( 'gradient' ),
							),
							'edit_field_class' => 'vc_col-sm-9 vc_column',
						),

						// Background Color
						array(
							'heading'          => esc_html__( 'Background Color', 'berserk' ),
							'param_name'       => 'overlay_bg_color',
							'type'             => 'brs_color_scheme',
							'colors'           => BRS_Shortcodes_VCParams::get_bg_colors(),
							'dependency'       => array(
								'element' => 'overlay_type',
								'value'   => array( 'bg_color' ),
							),
							'edit_field_class' => 'vc_col-sm-9 vc_column',
						),

						// Opacity
						array(
							'heading'    => esc_html__( 'Opacity', 'berserk' ),
							'param_name' => 'opacity',
							'type'       => 'dropdown',
							'value'      => array(
								'1'   => '100',
								'0.9' => '90',
								'0.8' => '80',
								'0.7' => '70',
								'0.6' => '60',
								'0.5' => '50',
								'0.4' => '40',
								'0.3' => '30',
								'0.2' => '20',
								'0.1' => '10',
							),
							'std'         => '80',
							'edit_field_class' => 'vc_col-sm-3 vc_column',
						),

						array(
							'heading'          => esc_html__( 'Button Size', 'berserk' ),
							'param_name'       => 'btn_size',
							'type'             => 'dropdown',
							'value'            => array(
								'sm' => 'sm',
								'md' => 'md',
								'lg' => 'lg',
								'xl' => 'xl',
							),
							'std'              => 'lg',
							'edit_field_class' => 'vc_col-sm-3 vc_column',
						),

						array(
							'heading'          => esc_html__( 'Circled Button', 'berserk' ),
							'param_name'       => 'btn_circled',
							'type'             => 'checkbox',
							'value'            => array(
								esc_html__( 'Use Circled Button', 'berserk' ) => 'true',
							),
							'std'              => 'false',
							'edit_field_class' => 'vc_col-sm-3 vc_column',
						),

						array(
							"param_name"       => "use_custom_size",
							"type"             => "checkbox",
							"value"            => array(
								"Use custom size" => "y",
							),
							'edit_field_class' => 'vc_col-sm-12 vc_column',
						),

						array(
							'type'             => 'textfield',
							'heading'          => esc_html__( 'Width (in px)', 'js_composer' ),
							'param_name'       => 'width',
							"value"            => '',
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							"dependency"       => array(
								"element" => "use_custom_size",
								"value"   => array( 'y' ),
							),
						),
						array(
							'type'             => 'textfield',
							'heading'          => esc_html__( 'Height (in px)', 'js_composer' ),
							'param_name'       => 'height',
							"value"            => '',
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							"dependency"       => array(
								"element" => "use_custom_size",
								"value"   => array( 'y' ),
							),
						),

						array(
							'type'             => 'textfield',
							'heading'          => esc_html__( 'Additional CSS Class', 'berserk' ),
							'group'            => esc_html__( 'Advanced', 'berserk' ),
							'param_name'       => 'css_class',
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

					)
				) );
			}
		}

		public function shortcode_media( $atts, $content = null ) {

			brs_add_libraries( array( 'component__media_embeds', 'fancybox' ) );

			$attributes = shortcode_atts( array(
				'video_type'       => 'self_hosted',
				'video_poster'     => '',
				'image_size'       => 'video-poster',
				'poster_gradient'  => 'brk-base-bg-gradient-50deg-opacity-28',
				'opacity'          => '80',
				'use_custom_size'  => 'n',
				'width'            => '',
				'height'           => '',
				'css_class'        => '',
				'btn_size'         => 'lg',
				'btn_circled'      => 'true',
				'overlay_type'     => 'gradient',
				'overlay_gradient' => 'brk-bg-grad',
				'overlay_bg_color' => 'brk-bg-primary',
			), $atts );

			$overlay_class   = array();
			$overlay_class[] = 'brk-abs-bg-overlay';
			if ( $attributes['opacity']  != '100' ) {
				$overlay_class[] = 'opacity-' . $attributes['opacity'];
			}
			if ( $attributes['overlay_type'] == 'bg_color' ) {
				$overlay_class[] = $attributes['overlay_bg_color'];
			}
			if ( $attributes['overlay_type'] == 'gradient' ) {
				$overlay_class[] = $attributes['overlay_gradient'];
			}

			$overlay_class = implode( ' ', $overlay_class );

			$src = explode( 'mp4="', $content );
			if ( isset( $src['1'] ) ) {
				$src = $src['1'];
				$src = explode( '"', $src );
				if ( isset( $src['0'] ) ) {
					$src = $src['0'];
				}
			} else {
				$src = false;
			}

			$style = '';
			if ( $attributes['use_custom_size'] == 'y' && !empty($attributes['width'])) {
				$style = 'width:' . $attributes['width'] . 'px;';
				$style .= ' height:' . $attributes['height'] . 'px;';
			}

			// Container Class
			$container_class = array( 'brk-hosted-video' );
			if( $attributes['css_class'] ) {
				$css_class = explode( ' ', $attributes['css_class'] );
				$container_class = array_merge( $container_class, $css_class );
			}
			$container_class = implode( ' ', $container_class );

			// Button Class
			$btn_class = array(
				'icon__btn icon__btn_reverse',
				'brk-hosted-video__btn',
				'fancybox',
			);

			if( $attributes['btn_circled'] ) {
				$btn_class[] = 'icon__btn-circled';
			}
			if( $attributes['btn_size'] ) {
				$btn_class[] = 'icon__btn-' . $attributes['btn_size'];
			}
			$btn_class = implode( ' ', $btn_class );

			// Output
			$output = '<div class="' . esc_attr( $container_class ) . '" style="' . esc_attr__( $style ) . '">';
			if ( $attributes['overlay_type'] != 'none' ) {
				$output .= '<div class="' . esc_attr__( $overlay_class ) . '"></div>';
			}

			if ( $attributes['video_poster'] ) {
				$output .= '<img src="' . esc_attr( BRK_DATA_IMAGE ) . '" data-src="' . esc_url( wp_get_attachment_image_url( $attributes['video_poster'], $attributes['image_size'] ) ) . '" alt="alt" class="brk-hosted-video__img lazyload">';
			}
			$output .= '<div class="brk-hosted-video__body">';
			$output .= '<a href="#" class="' . esc_attr( $btn_class ) . '">';
			$output .= '<span class="before"></span>';
			$output .= '<i class="fa fa-play" aria-hidden="true"></i>';
			$output .= '<span class="after"></span>';
			$output .= '</a>';
			$output .= '</div>';
			$output .= '<video class="brk-hosted-video__video-container" controls id="">';

			if ( $src ) {
				$output .= '<source src="' . esc_url( $src ) . '" type="video/mp4">';
			}
			$output .= '</video>';
			$output .= '</div>';

			return $output;

		}
	}

	// create shortcode
	BRS_Media::get_instance();

}
