<?php
/**
 * Shape Box shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Shape_Box', false ) ) {

	class BRS_Shape_Box extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Shape_Box();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_shape_box', array( $this, 'shortcode_shape_box' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Shape Box", 'berserk' ),
					"base"     => "brs_shape_box",
					"icon"     => "brs_vc_ico_shape_box",
					"class"    => "brs_vc_sc_shape_box",
					"category" => __( 'Berserk', 'berserk' ),
					"params"   => array(
						array(
							'heading'    => __( 'Shape Box Type', 'berserk' ),
							'param_name' => 'shape_box_type',
							'type'       => 'brs_radio',
							'value'      => array(
								"Inline"   => "inline",
								"Wave"     => "wave",
								"Stripe"   => "stripe",
								"Shape"    => "shape",
								"Half"     => "half",
								"Triangle" => "triangle",
							),
							'images'     => array(
								"inline"   => 'shape_box/inline.jpg',
								"wave"     => 'shape_box/wave.jpg',
								"stripe"   => 'shape_box/stripe.jpg',
								"shape"    => 'shape_box/shape.jpg',
								"half"     => 'shape_box/half.jpg',
								"triangle" => 'shape_box/triangle.jpg'
							),
							'images_dim' => array(
								'w' => '150',
								'h' => '150'
							)
						),
						array(
							'type'             => 'textfield',
							'heading'          => __( 'Title', 'js_composer' ),
							'param_name'       => 'title',
							"value"            => "Design",
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),
						array(
							'type'             => 'textfield',
							'heading'          => __( 'Description', 'js_composer' ),
							'param_name'       => 'description',
							"value"            => "Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor consequat",
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),
						array(
							"type"             => "textfield",
							"heading"          => __( "Link URL", 'berserk' ),
							"param_name"       => "link_url",
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							"value"            => "#"
						),

						array(
							"type"             => "textfield",
							"heading"          => esc_html__( 'Link Title', 'berserk' ),
							"param_name"       => "link_title",
							'edit_field_class' => 'vc_col-sm-3 vc_column',
							"value"            => "Read More"
						),
						array(
							"type"             => "textfield",
							"heading"          => esc_html__( 'Link Title On Hover', 'berserk' ),
							"param_name"       => "link_title_hover",
							'edit_field_class' => 'vc_col-sm-3 vc_column',
							"value"            => "Read More"
						),

						array(
							'type'        => 'attach_image',
							'heading'     => __( 'Background Image', 'js_composer' ),
							'param_name'  => 'bg_image',
							'value'       => '',
							'description' => __( 'Select image from media library.', 'js_composer' ),
						),

						array(
							'type'             => 'dropdown',
							'heading'          => esc_html__( 'Overlay', 'berserk' ),
							'param_name'       => 'overlay',
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'value'            => array(
								esc_html__( 'None', 'berserk' ) => '',
								esc_html__( 'Dark', 'berserk' ) => 'dark',
							),
						),

						array(
							"type"             => "textfield",
							"heading"          => __( "Number", 'berserk' ),
							"param_name"       => "number",
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							"value"            => "01"
						),

						array(
							"param_name"       => "shape_invert",
							"type"             => "checkbox",
							"value"            => array(
								"Shape invert" => "y",
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

						array(
							"heading"    => __( "Icon", 'berserk' ),
							"param_name" => "brs_title",
							"type"       => "brs_title",
						),

						array(
							'type'             => 'dropdown',
							'heading'          => __( 'Icon library', 'berserk' ),
							'value'            => array(
								__( 'Font Awesome', 'berserk' ) => 'fontawesome',
								__( 'Open Iconic', 'berserk' )  => 'openiconic',
								__( 'Typicons', 'berserk' )     => 'typicons',
								__( 'Entypo', 'berserk' )       => 'entypo',
								__( 'Linecons', 'berserk' )     => 'linecons',
								__( 'Mono Social', 'berserk' )  => 'monosocial',
								__( 'Livicon', 'berserk' )      => 'livicon',
							),
							'admin_label'      => true,
							'param_name'       => 'btn_icon_type',
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),
						array(
							'type'       => 'iconpicker',
							'heading'    => __( 'Icon', 'berserk' ),
							'param_name' => 'icon_fontawesome',
							'value'      => 'fa fa-adjust', // default value to backend editor admin_label
							'settings'   => array(
								'emptyIcon'    => false,
								'iconsPerPage' => 4000,
							),
							'dependency' => array(
								'element' => 'btn_icon_type',
								'value'   => 'fontawesome',
							),
						),
						array(
							'type'       => 'iconpicker',
							'heading'    => __( 'Icon', 'berserk' ),
							'param_name' => 'icon_openiconic',
							'value'      => 'vc-oi vc-oi-dial', // default value to backend editor admin_label
							'settings'   => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'openiconic',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency' => array(
								'element' => 'btn_icon_type',
								'value'   => 'openiconic',
							),
						),
						array(
							'type'       => 'iconpicker',
							'heading'    => __( 'Icon', 'berserk' ),
							'param_name' => 'icon_typicons',
							'value'      => 'typcn typcn-adjust-brightness', // default value to backend editor admin_label
							'settings'   => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'typicons',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency' => array(
								'element' => 'btn_icon_type',
								'value'   => 'typicons',
							),
						),
						array(
							'type'       => 'iconpicker',
							'heading'    => __( 'Icon', 'berserk' ),
							'param_name' => 'icon_entypo',
							'value'      => 'entypo-icon entypo-icon-note', // default value to backend editor admin_label
							'settings'   => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'entypo',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency' => array(
								'element' => 'btn_icon_type',
								'value'   => 'entypo',
							),
						),
						array(
							'type'       => 'iconpicker',
							'heading'    => __( 'Icon', 'berserk' ),
							'param_name' => 'icon_linecons',
							'value'      => 'vc_li vc_li-heart', // default value to backend editor admin_label
							'settings'   => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'linecons',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency' => array(
								'element' => 'btn_icon_type',
								'value'   => 'linecons',
							),
						),
						array(
							'type'       => 'iconpicker',
							'heading'    => __( 'Icon', 'berserk' ),
							'param_name' => 'icon_monosocial',
							'value'      => 'vc-mono vc-mono-fivehundredpx', // default value to backend editor admin_label
							'settings'   => array(
								'emptyIcon'    => false, // default true, display an "EMPTY" icon?
								'type'         => 'monosocial',
								'iconsPerPage' => 4000, // default 100, how many icons per/page to display
							),
							'dependency' => array(
								'element' => 'btn_icon_type',
								'value'   => 'monosocial',
							),
						),

						array(
							"type"        => "textarea_html",
							"holder"      => "div",
							"class"       => "",
							"param_name"  => "content",
							"value"       => __( "", 'berserk' ),
							"description" => "",
							'dependency'  => array(
								'element' => 'btn_icon_type',
								'value'   => 'livicon',
							),
						),

					)
				) );
			}
		}

		public function shortcode_shape_box( $atts, $content = null ) {

      brs_add_libraries('component__shape_box');

			extract( shortcode_atts( array(
				'shape_box_type'   => 'inline',
				'title'            => 'Design',
				'description'      => 'Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor consequat',
				'link_url'         => '#',
				'link_title'       => 'Read More',
				'link_title_hover' => '',
				'btn_icon_type'    => 'livicon',
				'icon_fontawesome' => '',
				'icon_openiconic'  => '',
				'icon_typicons'    => '',
				'icon_entypo'      => '',
				'icon_linecons'    => '',
				'icon_monosocial'  => '',
				'brs_btn_icon'     => '',
				'bg_image'         => '',
				'number'           => '01',
				'overlay'          => '',
				'shape_invert'     => '',
				//'icon_content'     => '',
			), $atts ) );

			// store atts
			$atts_backup = self::$atts;

			$icon_class                     = array();
			$icon_class['type']             = $btn_icon_type;
			$icon_class['icon_livicon']     = '';
			$icon_class['icon_fontawesome'] = $icon_fontawesome;
			$icon_class['icon_openiconic']  = $icon_openiconic;
			$icon_class['icon_typicons']    = $icon_typicons;
			$icon_class['icon_entypo']      = $icon_entypo;
			$icon_class['icon_linecons']    = $icon_linecons;
			$icon_class['icon_monosocial']  = $icon_monosocial;
			$icon_class                     = $this->get_icon_class( $icon_class );
			$icon_html                      = ' <i class="' . $icon_class . '"></i>';

			if ( isset( $content ) && $btn_icon_type == 'livicon' ) {

				$svg_icon  = do_shortcode( $content );
				$icon_html = $svg_icon;
			}

			$bg_image = wp_get_attachment_image_src( $bg_image, array(270,430) );
			$bg_image = $bg_image[0];

			$overlay_html = '';
			if ( $overlay == 'dark' ) {
				$class = 'bg-black';
				$overlay_html = '<div class="brk-abs-overlay z-index-0 ' . $class . ' opacity-60"></div>';
			}

			if ( empty( $link_title_hover ) ) {
				$link_title_hover = $link_title;
			}

			switch ( $shape_box_type ) {
				case "inline":

					$output = '<figure class="shape-box__wrapper-inline">
					              <img src="' . esc_url( $bg_image ) . '" alt="">
					              ' . $overlay_html . '
					              <figcaption>
					                ' . $icon_html . '
					                <h4 class="font__family-montserrat font__weight-bold font__size-24 text-uppercase main-title  text-center">' . $title . '</h4>
					                <p class="main-description font__family-open-sans font__size-14 text-gray text-center">' . $description . '</p>
					                <a href="' . $link_url . '" class="btn btn-lg border-radius-25 font__family-open-sans font__weight-bold btn-inside-out">
					                  <span class="before">' . $link_title . '</span>
					                  <span class="text">' . $link_title_hover . '</span>
					                  <span class="after">' . $link_title . '</span>
					                </a>
					              </figcaption>
					              <span class="after"></span>
					            </figure>';

					break;

				case "wave":

					$output = '<figure class="shape-box__wrapper-wave text-center">
					              <span class="before"></span>
					              <img src="' . esc_url( $bg_image ) . '" alt="">
					              ' . $overlay_html . '
					              <figcaption>
					                <span class="wave-circle-1"></span>
					                ' . $icon_html . '
					                <h4 class="font__family-montserrat font__weight-bold font__size-24 text-uppercase main-title">' . $title . '</h4>
					                <p class="main-description font__family-open-sans font__size-14 text-gray">' . $description . '</p>
					                <a href="' . $link_url . '" class="btn btn-lg border-radius-25 font__family-open-sans font__weight-bold btn-inside-out">
					                  <span class="before">' . $link_title . '</span>
					                  <span class="text">' . $link_title_hover . '</span>
					                  <span class="after">' . $link_title . '</span>
					                </a>
					                <span class="wave-circle-2"></span>
					                <span class="after">
									      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 270 113">
									        <defs>
									          <style>
									            .cls-1 {
									              isolation: isolate;
									            }

									            .cls-2 {
									              fill: #fff;
									              fill-rule: evenodd;
									            }
									          </style>
									        </defs>
									        <title>Asset 2</title>
									        <g>
									          <g class="cls-1">
									            <g>
									              <path class="cls-2" d="M0,0V113S11.42,90.78,62,90.78,124.54,113,174,113s71.05-27,96-27V0Z"></path>
									            </g>
									          </g>
									        </g>
									      </svg>
									    </span>
					              </figcaption>
					            </figure>';

					break;

				case "stripe":

					$output = '<figure class="shape-box__wrapper-stripe">
					              <img src="' . esc_url( $bg_image ) . '" alt="">
					              ' . $overlay_html . '
					              ' . $icon_html . '
					              <figcaption>
					                <div class="show-cont">
					                  <h4 class="font__family-montserrat font__weight-bold font__size-24 text-uppercase main-title text-center">' . $title . '</h4>
					                </div>
					                <p class="font__family-open-sans font__size-14 text-gray text-center">' . $description . '</p>
					                <a href="' . $link_url . '" class="btn btn-lg border-radius-25 font__family-open-sans font__weight-bold btn-inside-out">
					                  <span class="before">' . $link_title . '</span>
					                  <span class="text">' . $link_title_hover . '</span>
					                  <span class="after">' . $link_title . '</span>
					                </a>
					              </figcaption>
					              <span class="after"></span>
					            </figure>';

					break;

				case "shape":

					$output = '<figure class="shape-box__wrapper-shape">
					              <img src="' . esc_url( $bg_image ) . '" alt="">
					              ' . $overlay_html . '
					              <div class="icon">
					                ' . $icon_html . '
					                <span class="after"></span>
					              </div>
					              <figcaption>
					                <div class="show-cont">
					                  <h4 class="font__family-montserrat font__weight-bold font__size-24 text-uppercase main-title text-center">' . $title . '</h4>
					                </div>
					                <p class="font__family-open-sans font__size-14 text-gray text-center">' . $description . '</p>
					                <a href="' . $link_url . '" class="btn btn-lg border-radius-25 font__family-open-sans font__weight-bold btn-inside-out">
					                  <span class="before">' . $link_title . '</span>
					                  <span class="text">' . $link_title_hover . '</span>
					                  <span class="after">' . $link_title . '</span>
					                </a>
					              </figcaption>
					              <svg class="curve">
					                <path d="M 0 0 Q 0 300 200 300 L 0 300 " />
					              </svg>
					            </figure>';

					break;

				case "half":

					$output = '<figure class="shape-box__wrapper-half">
					              <img src="' . esc_url( $bg_image ) . '" alt="">
					              ' . $overlay_html . '
					              <figcaption>
					                <div class="show-cont">
					                  <h3 class="font__family-montserrat font__size-36 brk-base-font-color">' . $number . '</h3>
					                  <h4 class="font__family-montserrat font__weight-bold font__size-24 text-uppercase main-title">' . $title . '</h4>
					                </div>
					                <p class="font__family-open-sans font__size-14 text-gray">' . $description . '</p>
					                <a href="' . $link_url . '" class="btn btn-lg border-radius-25 font__family-open-sans font__weight-bold btn-inside-out">
					                  <span class="before">' . $link_title . '</span>
					                  <span class="text">' . $link_title_hover . '</span>
					                  <span class="after">' . $link_title . '</span>
					                </a>
					              </figcaption>
					              <span class="after"></span>
					            </figure>';


					break;
				case "triangle":

					$shape_invert_class = '';

					if ( isset( $shape_invert ) && ( $shape_invert == 'y' ) ) {
						$shape_invert_class = 'shape-invert';
					}

					$output = '<figure class="shape-box__wrapper-triangle ' . $shape_invert_class . '">
						              <img src="' . esc_url( $bg_image ) . '" alt="">
						              ' . $overlay_html . '
						              <figcaption>
						                <div>
						                  ' . $icon_html . '
						                  <div class="show-cont">
						                    <h4 class="font__family-montserrat font__size-24 text-uppercase main-title text-center">' . $title . '</h4>
						                    <p class="font__family-open-sans font__size-14 text-gray text-center">' . $description . '</p>
						                    <a href="' . $link_url . '" class="btn btn-lg border-radius-25 font__family-open-sans font__weight-bold btn-inside-out">
						                      <span class="before">' . $link_title . '</span>
						                      <span class="text">' . $link_title_hover . '</span>
						                      <span class="after">' . $link_title . '</span>
						                    </a>
						                  </div>
						                </div>
						              </figcaption>
						              <span class="after"></span>
						            </figure>';


					break;
			}

			// restore atts
			self::$atts = $atts_backup;

			return $output;
		}

		protected function get_icon_class( $atts ) {
			$icon_class = '';

			$icon_class = $atts[ 'icon_' . $atts['type'] ];

			if ( empty( $icon_class ) ) {
				$icon_class = 'fa fa-trophy';
			}

			return $icon_class;
		}


	}

	// create shortcode
	BRS_Shape_Box::get_instance();

}
