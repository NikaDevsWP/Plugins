<?php
/**
 * Tab Section shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


if ( ! class_exists( 'BRS_Tab_Section', false ) ) {

	class BRS_Tab_Section extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();
		protected $shortcode_id = 0;
		static $items = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Tab_Section();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_tab_section', array( $this, 'shortcode_tab_section' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				$params = array();

				$icons = berserk_shortcodes_icons();

				$params[] = array(
					'type'             => 'textfield',
					'heading'          => __( 'Title', 'js_composer' ),
					'param_name'       => 'title',
					'edit_field_class' => 'vc_col-sm-6 vc_column'
				);

				$params[] = array(
					'type'        => 'attach_image',
					'heading'     => __( 'Image', 'js_composer' ),
					'param_name'  => 'image',
					'value'       => '',
					'description' => '(for Parallax type)',
					'edit_field_class' => 'vc_col-sm-6 vc_column'
				);

				$params = array_merge( $params, $icons );

				vc_map( array(
					"weight"                    => - 1,
					"name"                      => __( "Tabs Section", 'berserk' ),
					"base"                      => "brs_tab_section",
					"icon"                      => "brs_vc_ico_tab_section",
					"class"                     => "brs_vc_sc_tab_section",
					"category"                  => __( 'Berserk', 'berserk' ),
					"is_container"              => true,
					"allowed_container_element" => 'vc_row',
					"show_settings_on_create"   => false,
					"scripts"                   => array( 'jquery-lettering' ),
					"as_child"                  => array( 'only' => 'brs_tabs' ),
					"js_view"                   => 'VcBackendTtaSectionView',
					"custom_markup"             => '<div class="vc_tta-panel-heading">
													    <h4 class="vc_tta-panel-title vc_tta-controls-icon-position-left"><a href="javascript:;" data-vc-target="[data-model-id=\'{{ model_id }}\']" data-vc-accordion data-vc-container=".vc_tta-container"><span class="vc_tta-title-text">{{ section_title }}</span><i class="vc_tta-controls-icon vc_tta-controls-icon-plus"></i></a></h4>
													</div>
													<div class="vc_tta-panel-body">
														{{ editor_controls }}
														<div class="{{ container-class }}">
														{{ content }}
														</div>
													</div>',
					"params"                    => $params


				) );
			}
		}

		public function shortcode_tab_section( $atts, $content = null ) {

			$this->shortcode_id ++;

			$attributes = shortcode_atts( array(
				'title' => '',
				'image' => ''
			), $atts );

			$icon = berserk_shortcodes_icons_process( $atts );

			$image = wp_get_attachment_image_src( $attributes['image'], 'full' );
			$image = $image[0];

			self::$items[ $this->shortcode_id ]['title']   = $attributes['title'];
			self::$items[ $this->shortcode_id ]['content'] = do_shortcode( $content );
			self::$items[ $this->shortcode_id ]['icon']    = $icon;
			self::$items[ $this->shortcode_id ]['image']   = $image;
		}


	}

	// create shortcode
	BRS_Tab_Section::get_instance();

}