<?php
/**
 * Servises shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Single_Panel', false ) ) {

	class BRS_Single_Panel extends BRS_Shortcode {

		static protected $instance;

		protected $shortcode_name = 'brs_single_panel_content';
		protected $atts = array();

		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Single_Panel();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( $this->shortcode_name, array( $this, 'shortcode' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				vc_map( array(
					"name"                    => __( "Single panel Content", "berserk" ),
					"base"                    => "brs_single_panel_content",
					"content_element"         => true,
					"is_container"            => true,
					"js_view"                 => 'VcColumnView',
					"as_child"                => array( 'only' => 'brs_panel_content' ),
					"show_settings_on_create" => true,
					"category"                => array( 'Berserk', 'Content' ),
					"params"                  => array(
						array(
							'type'             => 'dropdown',
							'heading'          => __( 'Item type', 'berserk' ),
							'value'            => array(
								__( 'Normal', 'berserk' )           => 'normal',
								__( 'With Line', 'berserk' )        => 'line',
								__( 'With Number', 'berserk' )      => 'number',
								__( 'With Icon', 'berserk' )        => 'icon',
								__( 'With Icon Type 1', 'berserk' ) => 'icon_type_1',
								__( 'With Icon Type 2', 'berserk' ) => 'icon_type_2'
							),
							'param_name'       => 'item_type',
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),
						array(
							'type'             => 'textfield',
							'heading'          => __( 'Number', 'js_composer' ),
							'param_name'       => 'number',
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							"dependency"       => array(
								"element" => "item_type",
								"value"   => array( 'number' ),
							),

						),
						array(
							'type'             => 'dropdown',
							'heading'          => __( 'Icon library', 'berserk' ),
							'value'            => array(
								__( 'Font Awesome', 'berserk' ) => 'fontawesome',
								__( 'Open Iconic', 'berserk' )  => 'openiconic',
								__( 'Typicons', 'berserk' )     => 'typicons',
								__( 'Entypo', 'berserk' )       => 'entypo',
								__( 'Linecons', 'berserk' )     => 'linecons',
								__( 'Mono Social', 'berserk' )  => 'monosocial',
								__( 'Livicon', 'berserk' )      => 'livicon',
							),
							'admin_label'      => true,
							'param_name'       => 'icon_type',
							'dependency'       => array(
								'element' => 'item_type',
								'value'   => array( 'icon', 'icon_type_1', 'icon_type_2' ),
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),
						array(
							'type'       => 'iconpicker',
							'heading'    => __( 'Icon', 'berserk' ),
							'param_name' => 'icon_fontawesome',
							'value'      => 'fa fa-adjust',
							'settings'   => array(
								'emptyIcon'    => false,
								'iconsPerPage' => 4000,
							),
							'dependency' => array(
								'element' => 'icon_type',
								'value'   => 'fontawesome',
							),
						),
						array(
							'type'       => 'iconpicker',
							'heading'    => __( 'Icon', 'berserk' ),
							'param_name' => 'icon_openiconic',
							'value'      => 'vc-oi vc-oi-dial',
							'settings'   => array(
								'emptyIcon'    => false,
								'type'         => 'openiconic',
								'iconsPerPage' => 4000,
							),
							'dependency' => array(
								'element' => 'icon_type',
								'value'   => 'openiconic',
							),
						),
						array(
							'type'       => 'iconpicker',
							'heading'    => __( 'Icon', 'berserk' ),
							'param_name' => 'icon_typicons',
							'value'      => 'typcn typcn-adjust-brightness',
							'settings'   => array(
								'emptyIcon'    => false,
								'type'         => 'typicons',
								'iconsPerPage' => 4000,
							),
							'dependency' => array(
								'element' => 'icon_type',
								'value'   => 'typicons',
							),
						),
						array(
							'type'       => 'iconpicker',
							'heading'    => __( 'Icon', 'berserk' ),
							'param_name' => 'icon_entypo',
							'value'      => 'entypo-icon entypo-icon-note',
							'settings'   => array(
								'emptyIcon'    => false,
								'type'         => 'entypo',
								'iconsPerPage' => 4000,
							),
							'dependency' => array(
								'element' => 'icon_type',
								'value'   => 'entypo',
							),
						),
						array(
							'type'       => 'iconpicker',
							'heading'    => __( 'Icon', 'berserk' ),
							'param_name' => 'icon_linecons',
							'value'      => 'vc_li vc_li-heart',
							'settings'   => array(
								'emptyIcon'    => false,
								'type'         => 'linecons',
								'iconsPerPage' => 4000,
							),
							'dependency' => array(
								'element' => 'icon_type',
								'value'   => 'linecons',
							),
						),
						array(
							'type'       => 'iconpicker',
							'heading'    => __( 'Icon', 'berserk' ),
							'param_name' => 'icon_monosocial',
							'value'      => 'vc-mono vc-mono-fivehundredpx',
							'settings'   => array(
								'emptyIcon'    => false,
								'type'         => 'monosocial',
								'iconsPerPage' => 4000,
							),
							'dependency' => array(
								'element' => 'icon_type',
								'value'   => 'monosocial',
							),
						),

						array(
							"type"        => "textarea_html",
							"holder"      => "div",
							"class"       => "",
							"param_name"  => "content",
							"value"       => __( "", 'berserk' ),
							"description" => "",
							'dependency'  => array(
								'element' => 'icon_type',
								'value'   => 'livicon',
							),
						),
					),
				) );
			}
		}

		public function shortcode( $atts, $content = null ) {

			extract( shortcode_atts( array(
				'item_content'     => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor',
				'item_type'        => 'normal',
				'number'           => '01',
				'icon_type'        => 'fontawesome',
				'icon_fontawesome' => '',
				'icon_openiconic'  => '',
				'icon_typicons'    => '',
				'icon_entypo'      => '',
				'icon_linecons'    => '',
				'icon_monosocial'  => '',
			), $atts ) );
			$before_content = '';
			$before_li      = '';
			$after_li       = '';

			switch ( $item_type ) {
				case "line":
					$before_content = '<span class="line"></span>';
					break;
				case "number":
					$before_content = '<span class="count">' . $number . '</span>';
					break;
				case "icon":
					$icon_class                     = array();
					$icon_class['type']             = $icon_type;
					$icon_class['icon_livicon']     = '';
					$icon_class['icon_fontawesome'] = $icon_fontawesome;
					$icon_class['icon_openiconic']  = $icon_openiconic;
					$icon_class['icon_typicons']    = $icon_typicons;
					$icon_class['icon_entypo']      = $icon_entypo;
					$icon_class['icon_linecons']    = $icon_linecons;
					$icon_class['icon_monosocial']  = $icon_monosocial;
					$icon_class                     = $this->get_icon_class( $icon_class );
					$icon_html                      = ' <i class="left-icon ' . $icon_class . '"></i>';

					if ( isset( $content ) && $icon_type == 'livicon' ) {

						$svg_icon  = do_shortcode( $content );
						$icon_html = $svg_icon;
					}

					$before_li = $icon_html . '<div class="list_wrapper">';
					$after_li = '</div>';
					break;
				case "icon_type_1":

					$icon_class                     = array();
					$icon_class['type']             = $icon_type;
					$icon_class['icon_livicon']     = '';
					$icon_class['icon_fontawesome'] = $icon_fontawesome;
					$icon_class['icon_openiconic']  = $icon_openiconic;
					$icon_class['icon_typicons']    = $icon_typicons;
					$icon_class['icon_entypo']      = $icon_entypo;
					$icon_class['icon_linecons']    = $icon_linecons;
					$icon_class['icon_monosocial']  = $icon_monosocial;
					$icon_class                     = $this->get_icon_class( $icon_class );
					$icon_html                      = ' <i class="icon ' . $icon_class . '"></i>';

					if ( isset( $content ) && $icon_type == 'livicon' ) {

						$svg_icon  = do_shortcode( $content );
						$icon_html = $svg_icon;
					}
					$before_content = '<span class="line"></span>' . $icon_html;
					break;

				case "icon_type_2":

					$icon_class                     = array();
					$icon_class['type']             = $icon_type;
					$icon_class['icon_livicon']     = '';
					$icon_class['icon_fontawesome'] = $icon_fontawesome;
					$icon_class['icon_openiconic']  = $icon_openiconic;
					$icon_class['icon_typicons']    = $icon_typicons;
					$icon_class['icon_entypo']      = $icon_entypo;
					$icon_class['icon_linecons']    = $icon_linecons;
					$icon_class['icon_monosocial']  = $icon_monosocial;
					$icon_class                     = $this->get_icon_class( $icon_class );
					$icon_html                      = ' <i class="icon ' . $icon_class . '"></i>';

					if ( isset( $content ) && $icon_type == 'livicon' ) {

						$svg_icon  = do_shortcode( $content );
						$icon_html = $svg_icon;
					}
					$before_content = '<span class="line"><span class="before"></span></span>' . $icon_html;
					break;

			}

			$output =  '<li>' . $before_li  . $before_content . do_shortcode( $content ) . $after_li . '</li>';

			return $output;

		}

		protected function get_icon_class( $atts ) {
			$icon_class = '';

			$icon_class = $atts[ 'icon_' . $atts['type'] ];

			if ( empty( $icon_class ) ) {
				$icon_class = 'fa fa-trophy';
			}

			return $icon_class;
		}

	}

	// create shortcode
	BRS_Single_Panel::get_instance();

}
