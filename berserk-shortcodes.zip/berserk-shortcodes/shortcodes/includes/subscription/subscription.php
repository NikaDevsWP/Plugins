<?php
/**
 * Subscription shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Subscription', false ) ) {

	class BRS_Subscription extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Subscription();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_subscription', array( $this, 'shortcode_subscription' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Subscription Box", 'berserk' ),
					"base"     => "brs_subscription",
					"icon"     => "brs_vc_ico_subscription",
					"class"    => "brs_vc_sc_subscription",
					"category" => __( 'Berserk', 'berserk' ),
					"params"   => array(
						array(
							'type'             => 'textfield',
							'heading'          => __( 'Caption', 'js_composer' ),
							'param_name'       => 'caption',
							"value"            => "Stay with us!",
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),
						array(
							'type'             => 'textfield',
							'heading'          => __( 'Subscribe text', 'js_composer' ),
							'param_name'       => 'subscribe_text',
							"value"            => "Subscribe Now",
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),
						array(
							'type'             => 'textfield',
							'heading'          => __( 'Placeholder', 'js_composer' ),
							'param_name'       => 'placeholder',
							"value"            => "Your mail",
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),
					)
				) );
			}
		}

		public function shortcode_subscription( $atts, $content = null ) {

			extract( shortcode_atts( array(
				'caption'        => 'Stay with us!',
				'subscribe_text' => 'Subscribe Now',
				'placeholder'    => 'Your mail',
			), $atts ) );

			// store atts
			$atts_backup = self::$atts;


			$output = '<h1 class="font__family-montserrat-alt font__size-34 font__weight-bold line__height-34 text-uppercase">
		                  <span class="badge badge-primary font__size-13 font__weight-bold line__height-28 font__family-open-sans">' . esc_html( $caption ) . '</span>
		                  ' . esc_html( $subscribe_text ) . '
		                </h1>

		                <form class="subscribe mt-20 cfa_subscr__form">
		                  <div class="form-control">
		                    <input type="email" title="email" placeholder="'.esc_attr($placeholder).'">
		                    <button class="btn" type="submit">
		                      <i class="fas fa-paper-plane"></i>
		                    </button>
		                  </div>
		                  <div class="cfa_form_responce" style="display: none;"><ul></ul></div>
		                </form>';


			// restore atts
			self::$atts = $atts_backup;

			return $output;
		}


	}

	// create shortcode
	BRS_Subscription::get_instance();

}
