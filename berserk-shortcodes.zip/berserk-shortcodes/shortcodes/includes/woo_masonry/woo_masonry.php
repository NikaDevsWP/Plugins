<?php
/**
 * BRS Woocommerce Masonry shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Woo_Masonry', false ) ) {

	require_once BERSERK_SHORTCODES_PATH . 'shortcodes/includes/shortcodes-ext.php';

	class BRS_Woo_Masonry extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Woo_Masonry();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_woo_masonry', array( $this, 'shortcode_masonry' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				$params = array();

				$params[] = array(
					"heading"    => __( "Woocommerce Masonry Type", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$params[] = array(
					//'heading'    => __( 'Woocommerce Masonry Type', 'berserk' ),
					'param_name' => 'woo_masonry_type',
					'type'       => 'brs_radio',
					'value'      => array(
						"Type 1"        => "type_1",
						"Type 2"        => "type_2",
						"Type 3 slider" => "type_3_slider",
						"Type 3 single" => "type_3_single",
					),
					'images'     => array(
						"type_1"        => 'woo_masonry/001.png',
						"type_2"        => 'woo_masonry/002.png',
						"type_3_slider" => 'woo_masonry/003.png',
						"type_3_single" => 'woo_masonry/003.png',
					),
					'images_dim' => array(
						'w' => '150',
						'h' => '150'
					)
				);

				$params[] = array(
					"heading"    => __( "Main Settings", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$params[] = array(
					"heading"          => __( "Add Product", 'berserk' ),
					"param_name"       => "product",
					"type"             => "brs_add_product",
					'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__woo_masonry_type type_1 type_2 type_3_single',
				);

				$params[] = array(
					"heading"          => __( "Add Product", 'berserk' ),
					"param_name"       => "products",
					"type"             => "brs_add_product_multiple",
					'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__woo_masonry_type type_3_slider',
				);

				$params[] = array(
					"heading"          => __( "Item type", 'berserk' ),
					'type'             => 'dropdown',
					'param_name'       => 'item_type',
					"value"            => array(
						"Main"  => "main",
						"Small" => "small",
					),
					'edit_field_class' => 'vc_col-sm-6 vc_column',
				);
				$params[] = array(
					"heading"          => __( "Item Layers Type", 'berserk' ),
					'type'             => 'dropdown',
					'param_name'       => 'layers_type',
					"value"            => array(
						"Single Type 1" => "single_type_1",
						"Single Type 2" => "single_type_2",
						"Double"        => "double",
					),
					'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__woo_masonry_type type_2',
				);

				$params[] = array(
					"heading"          => __( "Buttons Skin", 'berserk' ),
					'type'             => 'dropdown',
					'param_name'       => 'buttons_skin',
					"value"            => array(
						"Default" => "default",
						"Colored" => "colored",
					),
					'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__woo_masonry_type type_2',
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Image size', 'berserk' ),
					'value'            => BRS_Shortcodes_VCParams::get_image_sizes_names(),
					'param_name'       => 'image_size',
					'std'              => 'image-frames',
					'edit_field_class' => 'vc_col-sm-6 vc_column'
				);

				$backgrounds                                 = berserk_shortcodes_backgrounds();
				$backgrounds['bg_color']['edit_field_class'] = "vc_col-sm-12 vc_column  brk-dependency__woo_masonry_type type_1 type_2";
				$backgrounds['opacity']['edit_field_class']  = "vc_col-sm-6 vc_column  brk-dependency__woo_masonry_type type_1 type_2";

				$params = array_merge( $params, $backgrounds );

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Woo: Masonry", 'berserk' ),
					"base"     => "brs_woo_masonry",
					"icon"     => "brs_vc_ico_masonry",
					"class"    => "brs_vc_sc_masonry",
					"category" => __( 'Woocommerce Berserk', 'berserk' ),
					"params"   => $params
				) );
			}
		}

		public function shortcode_masonry( $atts, $content = null ) {

			brs_add_libraries( array( 'component__shop_masonry' ) );

			$atts = shortcode_atts( array(
				'woo_masonry_type' => 'type_1',
				'product'          => '',
				'products'         => '',
				'image_size'       => '',
				'gradient'         => 'brk-base-bg-gradient-5',
				'opacity'          => '',
				'item_type'        => 'main',
				'layers_type'      => 'single_type_1',
				'buttons_skin'     => 'default',
				'third_types'      => 'slider'
			), $atts );

			$overlay_class   = array();
			$overlay_class[] = 'brk-backgrounds__before';
			$overlay_class[] = $atts['gradient'];
			$overlay_class[] = $atts['opacity'];
			$overlay_class   = implode( ' ', $overlay_class );

			$currency = get_woocommerce_currency_symbol();


			//dpm($post);

			switch ( $atts['woo_masonry_type'] ) {
				case "type_1":

					$post      = wc_get_product( $atts['product'] );
					$old_price = $post->get_sale_price() !== '' ? $currency . $post->get_regular_price() : '';
					if ( ! $post ) {
						return;
					}
					$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $atts['product'] ), $atts['image_size'] );

					$buy_now = apply_filters( 'woocommerce_loop_add_to_cart_link',
						sprintf( '<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="brk-sc-masonry-one__link brk-bg-light-blue add-cart ajax_add_to_cart %s product_type_%s"><i class="fa fa-shopping-basket brk-white-font-color"></i></a>',
							esc_url( $post->add_to_cart_url() ),
							esc_attr( $post->get_id() ),
							esc_attr( $post->get_sku() ),
							$post->is_purchasable() ? 'add_to_cart_button' : '',
							esc_attr( $post->get_type() )
						),
						$post );

					$item_class = ( $atts['item_type'] == 'main' ) ? 'brk-sc-masonry_main-640' : 'brk-sc-masonry_small-320';

					$output = '<div class="brk-sc-masonry-one ' . $item_class . '" style="background-image: url(' . esc_attr( $image_url[0] ) . ')">
								<div class="brk-sc-masonry-one__layer">
										<div class="brk-sc-masonry-one__layer--before  ' . $overlay_class . '"></div>
									</div>
								<div class="brk-sc-masonry-one__container">
									<div class="brk-sc-masonry-one__content brk-white-font-color">
										<div class="brk-sc-masonry-one__title text-center">
											<h4 class="font__family-montserrat font__weight-bold text-uppercase">' . esc_html( $post->get_name() ) . '</h4>
										</div>
										<div class="brk-sc-masonry-one__price font__family-montserrat text-center">' . $currency . $post->get_price() . '</div>
									</div>' . $buy_now . '</div>
							</div>';

					break;

				case "type_2":

					$post      = wc_get_product( $atts['product'] );
					$old_price = $post->get_sale_price() !== '' ? $currency . $post->get_regular_price() : '';
					if ( ! $post ) {
						return;
					}
					$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $atts['product'] ), $atts['image_size'] );

					$item_class   = array();
					$item_class[] = ( $atts['item_type'] == 'main' ) ? 'brk-sc-masonry_main-590' : 'brk-sc-masonry_small-285';
					$item_class[] = ( $atts['layers_type'] == 'double' ) ? 'brk-sc-masonry_narrow' : '';
					$item_class[] = 'brk-sc-masonry-two';

					$buttons_class = ( $atts['buttons_skin'] == 'colored' ) ? 'brk-sc-masonry-two__links_colored' : '';

					switch ( $atts['layers_type'] ) {
						case "double":

							$buttons_class = ( $atts['buttons_skin'] == 'colored' ) ? 'brk-sc-masonry-two__buy_colored' : '';

							$item_class[] = $atts['gradient'];
							$item_class[] = $atts['opacity'];
							$item_class   = implode( ' ', $item_class );

							$output = '<div class="' . $item_class . '">
										<div class="brk-sc-masonry-two__container">
											<div class="brk-sc-masonry-two__thumbnail">
												<img src="' . esc_attr( $image_url[0] ) . '" alt="">
											</div>
											<div class="brk-sc-masonry-two__layer">
												<div class="brk-sc-masonry-two__title">
													<h4 class="font__family-montserrat font__weight-semibold text-uppercase font__size-16 line__height-27 letter-spacing-60 brk-white-font-color">
														' . esc_html( $post->get_name() ) . '
													</h4>
												</div>
												<div class="brk-sc-masonry-two__description brk-dark-font-color font__family-roboto font__weight-light">
													' . esc_html( $post->get_description() ) . '
												</div>

												<div class="brk-sc-masonry-two__buy ' . $buttons_class . ' d-flex flex-wrap align-items-center">
													<div class="price font__family-montserrat font__weight-bold brk-white-font-color">
														' . $currency . $post->get_price() . '
													</div>';

							$output .= apply_filters( 'woocommerce_loop_add_to_cart_link',
								sprintf( '<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="btn btn-prime btn-md border-radius-5 font__family-montserrat font__weight-bold brk-white-font-color add-cart ajax_add_to_cart %s product_type_%s">
													<i class="fa fa-shopping-bag"></i><span class="before"></span><span class="after"></span><span class="border-btn"></span>' . esc_html__( 'Buy', 'berserk' ) . '</a>',
									esc_url( $post->add_to_cart_url() ),
									esc_attr( $post->get_id() ),
									esc_attr( $post->get_sku() ),
									$post->is_purchasable() ? 'add_to_cart_button' : '',
									esc_attr( $post->get_type() )
								),
								$post );

							$output .= '</div>
											</div>
										</div>
									</div>';

							break;
						case "single_type_1":

							$item_class[] = 'brk-sc-masonry_long';
							$item_class   = implode( ' ', $item_class );

							$output = '<div class="' . $item_class . '">
									<div class="brk-sc-masonry-two__thumbnail">
										<img src="' . esc_attr( $image_url[0] ) . '" alt="">
									</div>
									<div class="brk-sc-masonry-two__container d-flex align-content-between flex-wrap">
										<div class="brk-sc-masonry-two__top-content">
											<a href="' . get_permalink( $post->get_id() ) . '">
												<h4 class="font__family-montserrat font__weight-semibold text-uppercase font__size-25 line__height-27 letter-spacing-40">
													' . esc_html( $post->get_name() ) . '</h4>
											</a>
											<div class="brk-sc-masonry-two__description brk-dark-font-color font__family-roboto font__weight-light">
												' . esc_html( $post->get_description() ) . '
											</div>
										</div>
										<div class="brk-sc-masonry-two__bottom-content">
											<div class="brk-sc-masonry-two__price">';
							if ( $old_price !== '' ) {
								$output .= '<div class="old-price font__family-montserrat font__weight-semibold font__size-16 brk-dark-font-color">
													' . $old_price . '
												</div>';
							}
							$output .= '<div class="price font__family-montserrat font__weight-bold font__size-30">
													' . $currency . $post->get_price() . '
												</div>
											</div>
											<div class="brk-sc-masonry-two__links ' . $buttons_class . '">

												<a href="' . get_permalink( $post->get_id() ) . '" class="btn btn-prime btn-md border-radius-5 font__family-montserrat font__weight-bold">
													<span class="before"></span><span class="after"></span><span class="border-btn"></span>' . esc_html__( 'More', 'berserk' ) . '</a>';

							$output .= apply_filters( 'woocommerce_loop_add_to_cart_link',
								sprintf( '<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="btn btn-inside-out btn-md btn-icon border-radius-5 font__family-montserrat font__weight-bold add-cart ajax_add_to_cart %s product_type_%s">
													<i class="fa fa-shopping-bag icon-inside"></i>
													<span class="before">' . esc_html__( 'Buy', 'berserk' ) . '</span><span class="text">' . esc_html__( 'Now', 'berserk' ) . '</span>
													<span class="after">' . esc_html__( 'Buy', 'berserk' ) . '</span></a>',
									esc_url( $post->add_to_cart_url() ),
									esc_attr( $post->get_id() ),
									esc_attr( $post->get_sku() ),
									$post->is_purchasable() ? 'add_to_cart_button' : '',
									esc_attr( $post->get_type() )
								),
								$post );

							$wishlist_btn_class = "add_to_wishlist wishlist";
							$wishlist           = get_post_meta( $post->get_id(), 'wishlist' );
							if ( isset( $wishlist[0] ) && $wishlist[0] == 'true' ) {
								$wishlist_btn_class = "remove_from_wishlist wishlist";
							}

							$output .= '<a href="' . esc_url( add_query_arg( 'add_to_wishlist', $post->get_id() ) ) . '" data-product-id="' . $post->get_id() . '" class="' . $wishlist_btn_class . '"><i class="fa fa-heart brk-dark-font-color"></i></a>

											</div>
										</div>
									</div>
								</div>';

							break;

						case "single_type_2":
							$item_class[] = 'brk-sc-masonry_long';
							$item_class   = implode( ' ', $item_class );

							$output = '<div class="' . $item_class . '">
											<div class="brk-sc-masonry-two__thumbnail">
												<img src="' . esc_attr( $image_url[0] ) . '" alt="">
											</div>
											<div class="brk-sc-masonry-two__container d-flex align-content-between flex-wrap">
												<div class="brk-sc-masonry-two__top-content">
													<a href="' . get_permalink( $post->get_id() ) . '">
														<h4 class="font__family-montserrat font__weight-semibold text-uppercase font__size-16 line__height-27 letter-spacing-60">
															' . esc_html( $post->get_name() ) . '
														</h4>
													</a>
													<div class="brk-sc-masonry-two__description brk-dark-font-color font__family-roboto font__weight-light">
														' . esc_html( $post->get_description() ) . '
													</div>
												</div>
												<div class="brk-sc-masonry-two__bottom-content">
													<div class="brk-sc-masonry-two__price d-flex flex-wrap align-items-center">
														<div class="price font__family-montserrat font__weight-bold font__size-20">
															' . $currency . $post->get_price() . '
														</div>
														<div class="brk-sc-masonry-two__links ' . $buttons_class . '">';

							$output .= apply_filters( 'woocommerce_loop_add_to_cart_link',
								sprintf( '<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="btn btn-inside-out btn-md btn-icon border-radius-5 font__family-montserrat font__weight-bold add-cart ajax_add_to_cart %s product_type_%s">
													<i class="fa fa-shopping-bag icon-inside"></i>
													<span class="before">' . esc_html__( 'Buy', 'berserk' ) . '</span><span class="text">' . esc_html__( 'Buy', 'berserk' ) . '</span>
													<span class="after">' . esc_html__( 'Buy', 'berserk' ) . '</span></a>',
									esc_url( $post->add_to_cart_url() ),
									esc_attr( $post->get_id() ),
									esc_attr( $post->get_sku() ),
									$post->is_purchasable() ? 'add_to_cart_button' : '',
									esc_attr( $post->get_type() )
								),
								$post );

							$output .= '</div>
													</div>
												</div>
											</div>
										</div>';

							break;

					}

					break;

				case "type_3_slider":

					brs_add_libraries( 'slider__swiper' );

					$output = '<div class="brk-swiper-default brk-sc-masonry-slider" data-delay="0">
								<div class="swiper-container">
									<div class="swiper-wrapper">';

					$products = explode( ',', $atts['products'] );
					if ( ! empty( $products ) ) {
						foreach ( $products as $product ) {
							$post = wc_get_product( $product );
							if ( $post ) {
								$rate       = $post->get_average_rating() * 20;
								$categories = $post->get_category_ids();
								$terms      = array();
								foreach ( $categories as $cat_id ) {
									$term    = get_term( $cat_id );
									$terms[] = $term->name;
								}
								$terms = implode( ', ', $terms );

								$image_url = wp_get_attachment_image_url( get_post_thumbnail_id( $product ), $atts['image_size'] );
								$old_price = $post->get_sale_price() !== '' ? $currency . $post->get_regular_price() : '';

								$output .= '<div class="brk-sc-masonry-three swiper-slide brk-sc-masonry_long brk-sc-masonry_main-570">
										<div class="brk-abs-overlay bg-primary opacity-90"></div>
											<div class="brk-sc-masonry-three__thumbnail">
												<img class="lazyload" src="' . esc_attr( BRK_DATA_IMAGE ) . '" data-src="' . esc_url( $image_url ) . '" alt="">
											</div>
											<div class="brk-sc-masonry-three__container d-flex flex-wrap">
												<div class="brk-sc-masonry-three__top-content">
													<div class="brk-sc-masonry-three__title">
														<h4 class="font__family-montserrat font__weight-bold text-uppercase">
															' . esc_html( $post->get_name() ) . '</h4>
													</div>
													<div class="brk-sc-masonry-three__category brk-white-font-color brk-bg-grad text-uppercase font__weight-semibold ">
														' . $terms . '
													</div>
												</div>
												<div class="brk-sc-masonry-three__bottom-content d-flex flex-wrap align-content-start justify-content-end">';
								$output .= apply_filters( 'woocommerce_loop_add_to_cart_link',
									sprintf( '<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="btn btn-inside-out btn-inside-out-invert btn-lg btn-icon border-radius-5 font__family-open-sans font__weight-bold add-cart ajax_add_to_cart %s product_type_%s">
													<i class="fa fa-shopping-basket icon-inside icon-inline"></i>
														<span class="before"> </span><span class="text"> </span><span class="after"> </span></a>',
										esc_url( $post->add_to_cart_url() ),
										esc_attr( $post->get_id() ),
										esc_attr( $post->get_sku() ),
										$post->is_purchasable() ? 'add_to_cart_button' : '',
										esc_attr( $post->get_type() )
									),
									$post );

								$output .= '<div class="clearfix">
														<div class="brk-sc-masonry-three__price font__family-montserrat d-flex flex-wrap justify-content-end">';

								if ( $old_price !== '' ) {

									$output .= '<div class="old-price font__weight-light brk-dark-font-color">
																' . $old_price . '
												</div>';
								}
								$output .= '<div class="price font__weight-bold brk-base-font-color">
																' . $currency . $post->get_price() . '
															</div>
														</div>

														<div class="brk-rating">
															<div class="brk-rating__layer">
																<i class="fal fa-star brk-dark-font-color"></i>
																<i class="fal fa-star brk-dark-font-color"></i>
																<i class="fal fa-star brk-dark-font-color"></i>
																<i class="fal fa-star brk-dark-font-color"></i>
																<i class="fal fa-star brk-dark-font-color"></i>
															</div>
															<div class="brk-rating__imposition" style="width: ' . $rate . '%">
																<div class="visible">
																	<i class="fas fa-star brk-base-font-color"></i>
																	<i class="fas fa-star brk-base-font-color"></i>
																	<i class="fas fa-star brk-base-font-color"></i>
																	<i class="fas fa-star brk-base-font-color"></i>
																	<i class="fas fa-star brk-base-font-color"></i>
																</div>
															</div>
														</div>
													</div>

												</div>
											</div>
										</div>';
							}
						}
					}


					$output .= '</div>
							</div>
							<div class="brk-swiper-default-pagination"></div>
								<div class="brk-swiper-default-nav brk-swiper-default-nav-prev"><i class="fa fa-angle-left"></i></div>
								<div class="brk-swiper-default-nav brk-swiper-default-nav-next"><i class="fa fa-angle-right"></i></div>
							</div>';

					break;

				case "type_3_single":

					$post = wc_get_product( $atts['product'] );
					if ( ! $post ) {
						return;
					}
					$old_price  = $post->get_sale_price() !== '' ? $currency . $post->get_regular_price() : '';
					$rate       = $post->get_average_rating() * 20;
					$categories = $post->get_category_ids();
					$terms      = array();
					foreach ( $categories as $cat_id ) {
						$term    = get_term( $cat_id );
						$terms[] = $term->name;
					}
					$terms = implode( ', ', $terms );

					$image_url = wp_get_attachment_image_url( get_post_thumbnail_id( $atts['product'] ), $atts['image_size'] );

					$item_class = ( $atts['item_type'] == 'main' ) ? 'brk-sc-masonry_main-570' : 'brk-sc-masonry_small-270';

					$output = '<div class="pt-15 pb-15">
								<div class="brk-sc-masonry-three brk-sc-masonry_narrow ' . $item_class . '">
									<div class="brk-abs-overlay bg-primary opacity-90"></div>
									<div class="brk-sc-masonry-three__thumbnail">
										<img class="lazyload" src="' . esc_attr( BRK_DATA_IMAGE ) . '" data-src="' . esc_url( $image_url ) . '" alt="">
									</div>
									<div class="brk-sc-masonry-three__container d-flex flex-wrap">
										<div class="brk-sc-masonry-three__top-content">
											<div class="brk-sc-masonry-three__title">
												<h4 class="font__family-montserrat font__weight-bold text-uppercase">' . esc_html( $post->get_name() ) . '</h4>
											</div>
											<div class="brk-sc-masonry-three__category brk-white-font-color brk-bg-grad text-uppercase font__weight-semibold ">
												' . $terms . '
											</div>
										</div>
										<div class="brk-sc-masonry-three__bottom-content d-flex flex-wrap align-content-start justify-content-end">';

					$output .= apply_filters( 'woocommerce_loop_add_to_cart_link',
						sprintf( '<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="btn btn-inside-out btn-inside-out-invert btn-lg btn-icon border-radius-5 font__family-open-sans font__weight-bold add-cart ajax_add_to_cart %s product_type_%s">
													 <i class="fa fa-shopping-basket icon-inside icon-inline"></i>
												<span class="before"> </span><span class="text"> </span><span class="after"> </span></a>',
							esc_url( $post->add_to_cart_url() ),
							esc_attr( $post->get_id() ),
							esc_attr( $post->get_sku() ),
							$post->is_purchasable() ? 'add_to_cart_button' : '',
							esc_attr( $post->get_type() )
						),
						$post );

					$output .= '<div class="clearfix">
												<div class="brk-sc-masonry-three__price font__family-montserrat d-flex flex-wrap justify-content-end">
													<div class="price font__weight-bold brk-base-font-color">' . $currency . $post->get_price() . '</div>
												</div>

												<div class="brk-rating">
													<div class="brk-rating__layer">
														<i class="fal fa-star brk-dark-font-color"></i>
														<i class="fal fa-star brk-dark-font-color"></i>
														<i class="fal fa-star brk-dark-font-color"></i>
														<i class="fal fa-star brk-dark-font-color"></i>
														<i class="fal fa-star brk-dark-font-color"></i>
													</div>
													<div class="brk-rating__imposition" style="width: ' . $rate . '%">
														<div class="visible">
															<i class="fas fa-star brk-base-font-color"></i>
															<i class="fas fa-star brk-base-font-color"></i>
															<i class="fas fa-star brk-base-font-color"></i>
															<i class="fas fa-star brk-base-font-color"></i>
															<i class="fas fa-star brk-base-font-color"></i>
														</div>
													</div>
												</div>
											</div>

										</div>
									</div>
								</div>
							</div>';

					break;

			}

			return $output;
		}
	}

	// create shortcode
	BRS_Woo_Masonry::get_instance();

}
