<?php
/**
 * Tiles shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Tiles', false ) ) {

	class BRS_Tiles extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Tiles();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_tiles', array( $this, 'shortcode_tiles' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				$params = array();

				$params[] = array(
					"heading"    => __( "Main Settings", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$params[] = array(
					'heading'    => __( 'Tiles Type', 'berserk' ),
					'param_name' => 'tiles_type',
					'type'       => 'brs_radio',
					'value'      => array(
						"Full"     => "full",
						"Simple"   => "simple",
						"Clean"    => "clean",
						"Assorted" => "assorted",
						"Formats"  => "formats",
					),
					'images'     => array(
						"full"     => 'tiles/001.jpg',
						"simple"   => 'tiles/002.jpg',
						"clean"    => 'tiles/003.jpg',
						"assorted" => 'tiles/004.jpg',
						"formats"  => 'tiles/005.jpg',
					),
					'images_dim' => array(
						'w' => '310',
						'h' => '150'
					)
				);

				$params[] = array(
					'type'             => 'textfield',
					'heading'          => __( 'First Title', 'js_composer' ),
					'param_name'       => 'first_title',
					"value"            => 'Awesome for you',
					'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__tiles_type assorted',
				);

				$params[] = array(
					'type'             => 'textfield',
					'heading'          => __( 'Title', 'js_composer' ),
					'param_name'       => 'title',
					"value"            => 'Keep Calm',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
				);

				$params[] = array(
					'type'             => 'textarea',
					'heading'          => __( 'Description', 'js_composer' ),
					'param_name'       => 'description',
					'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__tiles_type full simple clean formats',
				);

				$params[] = array(
					'type'       => 'vc_link',
					'heading'    => __( 'Link URL', 'js_composer' ),
					'param_name' => 'url',
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Format', 'berserk' ),
					'value'            => array(
						__( 'Photo', 'berserk' ) => 'photo',
						__( 'Quote', 'berserk' ) => 'quote',
						__( 'Image', 'berserk' ) => 'image',
						__( 'Post', 'berserk' )  => 'post',
					),
					'param_name'       => 'format',
					'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__tiles_type formats',
				);

				$params[] = array(
					'type'             => 'textfield',
					'heading'          => __( 'Format text', 'js_composer' ),
					'param_name'       => 'format_text',
					"value"            => 'Photo',
					'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__tiles_type formats',
				);

				$params[] = array(
					"param_name"       => "left_content",
					"type"             => "checkbox",
					"value"            => array(
						"Left Content" => "y",
					),
					'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__tiles_type full simple clean',
				);

				$params[] = array(
					"param_name"       => "bottom_content",
					"type"             => "checkbox",
					"value"            => array(
						"Bottom Content" => "y",
					),
					'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__tiles_type assorted',
				);

				$params[] = array(
					"heading"    => __( "Background", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$params[] = array(
					'type'       => 'attach_image',
					'heading'    => __( 'Background Image', 'js_composer' ),
					'param_name' => 'bg_image',
					'value'      => ''
				);

				// Image sizes
				$image_sizes = berserk_shortcodes_image_size_options();
				$params      = array_merge( $params, $image_sizes );

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Tiles", 'berserk' ),
					"base"     => "brs_tiles",
					"icon"     => "brs_vc_ico_tiles",
					"class"    => "brs_vc_sc_tiles",
					"category" => __( 'Berserk', 'berserk' ),
					"params"   => $params
				) );
			}
		}

		public function shortcode_tiles( $atts, $content = null ) {

			brs_add_libraries( 'component__tiles' );

			$attributes = shortcode_atts( array(
				'tiles_type'          => 'full',
				'title'               => 'Keep Calm',
				'first_title'         => 'Awesome for you',
				'description'         => '',
				'url'                 => '',
				'left_content'        => 'n',
				'bottom_content'      => 'n',
				'format'              => 'photo',
				'format_text'         => 'Photo',
				'bg_image'            => '',
				'image_size'          => 'image-frames',
				'image_custom_width'  => '285',
				'image_custom_height' => '610',
			), $atts );

			$attributes['image_size'] = berserk_shortcodes_image_size_render( $attributes );

			$image = wp_get_attachment_image_src( $attributes['bg_image'], $attributes['image_size'] );
			$image = $image[0];

			$image_full = wp_get_attachment_image_src( $attributes['bg_image'], 'full' );
			$image_full = $image_full[0];

			$url      = ( $attributes['url'] == '||' ) ? '' : $attributes['url'];
			$url      = vc_build_link( $url );
			$link_url = $url['url'];
			$a_title  = ( $url['title'] == '' ) ? '' : $url['title'];
			$a_target = ( $url['target'] == '' ) ? '' : 'target="' . $url['target'] . '"';


			switch ( $attributes['tiles_type'] ) {
				case "full":

					$tiles_class = ( $attributes['left_content'] == 'y' ) ? 'brk-tiles-full brk-tiles-full_left' : 'brk-tiles-full';

					$output = '<article class="' . $tiles_class . '">
					              <div class="brk-tiles-full__thumb" style="background-image: url(' . esc_url( $image ) . ')"></div>
					              <div class="brk-tiles-full__content">
					                <div class="brk-tiles-full__content-layer">
					                  <h4 class="font__family-montserrat font__size-16 line__height-26 font__weight-medium">' . esc_html( $attributes['title'] ) . '</h4>
					                  <p class="font__family-open-sans font__size-15 line__height-24">' . esc_html( $attributes['description'] ) . '</p>
					                  <a class="brk-tiles-full__link" href="' . esc_url( $link_url ) . '" ' . $a_target . '><i class="far fa-angle-right"></i></a>
					                </div>
					              </div>
					            </article>';

					break;

				case "simple":

					$tiles_class = ( $attributes['left_content'] == 'y' ) ? 'brk-tiles-simple' : 'brk-tiles-simple brk-tiles-simple_left';

					$output = '<article class="' . $tiles_class . '" style="background-image: url(' . esc_url( $image ) . ')">
					                <div class="before"></div>
					                <div class="brk-tiles-simple__content">
					                  <h4 class="font__family-montserrat font__weight-semibold font__size-21">' . esc_html( $attributes['title'] ) . '</h4>
					                  <p>' . esc_html( $attributes['description'] ) . '</p>
					                  <a class="brk-tiles-simple__link" href="' . esc_url( $link_url ) . '" ' . $a_target . '>
					                    <span class="before"></span>
					                    <i class="far fa-angle-right"></i>
					                    <span class="after"></span>
					                  </a>
					                </div>
					              </article>';

					break;

				case "clean":

					$tiles_class = ( $attributes['left_content'] == 'y' ) ? 'brk-tiles-clean brk-tiles-clean_left' : 'brk-tiles-clean';

					$output = '<article class="' . $tiles_class . '">
				                <div class="brk-tiles-clean__thumb" style="background-image: url(' . esc_url( $image ) . ')"></div>
				                <div class="brk-tiles-clean__content">
				                  <h4 class="font__family-montserrat font__weight-bold">' . esc_html( $attributes['title'] ) . '</h4>
				                  <p>' . esc_html( $attributes['description'] ) . '</p>
				                  <a class="brk-tiles-clean__link" href="' . esc_url( $link_url ) . '" ' . $a_target . '><i class="far fa-angle-right"></i><span>' . esc_html( $a_title ) . '</span></a>
				                </div>
				              </article>';

					break;
				case "assorted":
					brs_add_libraries( 'fancybox' );

					$tiles_class = ( $attributes['bottom_content'] == 'y' ) ? 'brk-tiles-assorted brk-tiles-assorted_back lazyload' : 'brk-tiles-assorted lazyload';

					$output = '<article class="' . $tiles_class . '" style="background-image: url(' . esc_url( $image ) . ')">
				                <div class="brk-tiles-assorted__title">
				                  <div class="brk-tiles-assorted__title-content text-center">
				                    <h3 class="font__family-roboto font__weight-light">' . esc_html( $attributes['first_title'] ) . '</h3>
				                    <h4 class="font__family-roboto font__weight-bold">' . esc_html( $attributes['title'] ) . '</h4>
				                  </div>
				                  <span class="brk-abs-overlay brk-base-bg-gradient-brown"></span>
				                </div>
				                <div class="before"></div>
				                <div class="brk-tiles-assorted__bg">
				                    <span class="brk-layer brk-base-bg-6 opacity-70"></span>
				                    <span class="brk-abs-overlay  brk-base-bg-gradient-50deg"></span>
		                                <a href="' . esc_url( $link_url ) . '" class="brk-tiles-assorted__link">
		                                    <i class="fas fa-arrow-right"></i>
		                                </a>
		                                <a href="' . esc_url( $image_full ) . '" class="brk-tiles-assorted__search image-popup fancybox">
		                                    <i class="far fa-search"></i>
		                                </a>
				                </div>
				              </article>';

					break;
				case "formats":

					$content      = '';
					$format_class = '';

					switch ( $attributes['format'] ) {

						case "photo":
							$format_class = 'format-image';
							$content      = '<a href="' . esc_url( $link_url ) . '" ' . $a_target . ' class="brk-tiles-formats__read-more">' . $a_title . '</a>';
							break;
						case "quote":
							$format_class = 'format-quote';
							$content      = '<i class="fa fa-quote-right" aria-hidden="true"></i>
						                <h4 class="font__family-montserrat-alt font__weight-bold font__size-26 line__height-32">' . esc_html( $attributes['title'] ) . '</h4>
						                <a href="' . esc_url( $link_url ) . '" ' . $a_target . ' class="brk-tiles-formats__read-more">' . $a_title . '</a>';
							break;
						case "image":
							$format_class = 'format-gallery';
							$content      = '<a href="' . esc_url( $link_url ) . '" ' . $a_target . ' class="brk-tiles-formats__read-more">' . $a_title . '</a>';
							break;
						case "post":
							$format_class = 'format-standard';
							$content      = '<h4 class="font__family-montserrat-alt font__weight-bold font__size-28 line__height-32">' . esc_html( $attributes['title'] ) . '</h4>
						                <p class="font__size-16 line__height-26 mb-30">' . esc_html( $attributes['description'] ) . '</p>
						                <a href="' . esc_url( $link_url ) . '" ' . $a_target . ' class="brk-tiles-formats__read-more">' . $a_title . '</a>';
							break;

					}

					$output = '<article class="brk-tiles-formats ' . $format_class . '" style="background-image: url(' . esc_url( $image ) . ')">
					              <div class="brk-tiles-formats__format-post">' . esc_html( $attributes['format_text'] ) . '</div>
					              <div class="brk-tiles-formats__content">
									' . $content . '
					              </div>
					            </article>';

					break;

			}

			return $output;
		}
	}

	// create shortcode
	BRS_Tiles::get_instance();

}
