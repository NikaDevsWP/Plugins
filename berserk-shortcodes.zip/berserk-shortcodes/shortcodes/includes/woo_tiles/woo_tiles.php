<?php
/**
 * BRS Woocommerce Tiles shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Woo_Tiles', false ) ) {

	require_once BERSERK_SHORTCODES_PATH . 'shortcodes/includes/shortcodes-ext.php';

	class BRS_Woo_Tiles extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Woo_Tiles();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_woo_tiles', array( $this, 'shortcode_tiles' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				$params = array();

				$params[] = array(
					"heading"    => __( "Main Settings", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$params[] = array(
					'heading'    => __( 'Woocommerce Tiles Type', 'berserk' ),
					'param_name' => 'woo_tiles_type',
					'type'       => 'brs_radio',
					'value'      => array(
						"Trend"  => "trend",
						"Images" => "images",
						"Split"  => "split",
						"Angle"  => "angle",
					),
					'images'     => array(
						"trend"  => 'woo_tiles/001.png',
						"images" => 'woo_tiles/002.png',
						"split"  => 'woo_tiles/003.png',
						"angle"  => 'woo_tiles/004.png',
					),
					'images_dim' => array(
						'w' => '310',
						'h' => '150'
					)
				);

				$params[] = array(
					"heading"    => __( "Please add two 'Filter type: Taxonomies' criteria in the Dynamic Filter, and the products will be groupped!", 'berserk' ),
					"param_name" => "brs_notice",
					"type"       => "brs_notice",
					"edit_field_class" => "vc_col-sm-12 vc_column brk-dependency__woo_tiles_type angle",
				);



				$params[] = array(
					"heading"          => __( "Text color scheme", 'berserk' ),
					"param_name"       => "text_color_scheme",
					"type"             => "dropdown",
					"value"            => array(
						"White" => "white",
						"Dark"  => "dark",
					),
					"edit_field_class" => "vc_col-sm-6 vc_column brk-dependency__woo_tiles_type trend",
				);

				$params[] = array(
					"heading"          => __( "Text align", 'berserk' ),
					"param_name"       => "text_align",
					"type"             => "dropdown",
					"value"            => array(
						"Right" => "right",
						"Left"  => "left",
					),
					"edit_field_class" => "vc_col-sm-6 vc_column brk-dependency__woo_tiles_type trend",
				);

				$params[] = array(
					"heading"          => __( "Before the Title", 'berserk' ),
					'type'             => 'textfield',
					'param_name'       => 'before_title',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
				);

				$params[] = array(
					"heading"          => __( "After the Title", 'berserk' ),
					'type'             => 'textfield',
					'param_name'       => 'after_title',
					'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__woo_tiles_type images',
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Image size', 'berserk' ),
					'value'            => BRS_Shortcodes_VCParams::get_image_sizes_names(),
					'param_name'       => 'image_size',
					'std'              => 'image-frames',
					'edit_field_class' => 'vc_col-sm-6 vc_column'
				);

				$params[] = array(
					"heading"          => __( "Button type", 'berserk' ),
					'type'             => 'dropdown',
					'param_name'       => 'button_type',
					"value"            => array(
						"Gradient" => "gradient",
						"Prime"    => "prime",
					),
					'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__woo_tiles_type images',
				);
				/*
				$params[] = array(
					'type'             => 'attach_image',
					'heading'          => __( 'Background Image', 'js_composer' ),
					'param_name'       => 'single_bg_image',
					'edit_field_class' => 'vc_col-xs-12 vc_column brk-dependency__woo_tiles_type split angle',
					'value'            => '',
				);*/

				$options  = array( 'edit_field_class' => 'brk-dependency__woo_tiles_type trend split angle' );
				$patterns = berserk_shortcodes_patterns( $options );
				$params   = array_merge( $params, $patterns );

				$backgrounds                                 = berserk_shortcodes_backgrounds();
				$backgrounds['bg_color']['edit_field_class'] = "vc_col-sm-12 vc_column  brk-dependency__woo_tiles_type trend";
				$backgrounds['opacity']['edit_field_class']  = "vc_col-sm-6 vc_column  brk-dependency__woo_tiles_type trend";

				$params = array_merge( $params, $backgrounds );

				$params[] = array(
					"heading"    => __( "Dynamic Content", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$params = array_merge( $params, berserk_shortcodes_dynamic_filter() );



				$params[] = array(
					"heading"    => __( "Content Values", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Get title from', 'js_composer' ),
					'param_name'       => 'title_val',
					'value'            => array(
						'Post Title'  => 'post_title',
						'Post Date'   => 'post_date',
						'Post Author' => 'post_author'
					),
					'edit_field_class' => 'vc_col-sm-6 vc_column',
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Get description from', 'js_composer' ),
					'param_name'       => 'description_val',
					'value'            => array(
						'Post Title'   => 'post_title',
						'Post Date'    => 'post_date',
						'Post Author'  => 'post_author',
						'Post Content' => 'post_content',
						'Post Excerpt' => 'post_excerpt',
					),
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					'std'              => 'post_content'
				);

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Woo: Tiles", 'berserk' ),
					"base"     => "brs_woo_tiles",
					"icon"     => "brs_vc_ico_tiles",
					"class"    => "brs_vc_sc_tiles",
					"category" => __( 'Woocommerce Berserk', 'berserk' ),
					"params"   => $params
				) );
			}
		}

		public function shortcode_tiles( $atts, $content = null ) {

			brs_add_libraries( array( 'component__shop_tiles' ) );

			$atts = shortcode_atts( array(
				'woo_tiles_type'        => 'trend',
				'product'               => '',
				'dynamic_content'       => 'no',
				'custom_items'          => 'custom_items',
				'filters'               => '',
				'orderby'               => 'date',
				'order_direction'       => 'ASC',
				'before_title'          => '',
				'after_title'           => '',
				'bg_image'              => '',
				'pattern_type'          => '',
				'background_size'       => 'bg-cover',
				'background_repeat'     => '',
				'background_position'   => '',
				'use_custom_background' => 'no',
				'image_size'            => '',
				'title_val'             => 'post_title',
				'description_val'       => 'post_content',
				'gradient'              => 'brk-base-bg-gradient-5',
				'opacity'               => '',
				'text_color_scheme'     => 'white',
				'text_align'            => 'right',
				'button_type'           => 'gradient',
				//'single_bg_image'        => ''
			), $atts );


			if ( $atts['dynamic_content'] == 'y' ) {
				$args  = array();
				$args  = array_merge( $args, berserk_shortcodes_dynamic_filter_process( $atts['filters'], $atts['orderby'], $atts['order_direction'] ) );
				$posts = get_posts( $args );
			} else {
				$posts        = array();
				$custom_items = explode( ',', $atts['custom_items'] );
				foreach ( $custom_items as $item ) {
					$posts[] = get_post( $item );
				}
			}

			$pattern_style = '';
			$pattern_class = '';
			if ( $atts['use_custom_background'] == 'yes' ) {
				$image         = wp_get_attachment_image_src( $atts['bg_image'], 'full' );
				$image         = $image[0];
				$pattern_style = 'background-image: url(' . esc_url( $image ) . ');';
			} else {
				$pattern_class = $atts['pattern_type'];
			}

			if(isset( $atts['background_size']) && ( $atts['background_size'] !='none')){
				$pattern_class = $atts['background_size'];
			}
			if(isset( $atts['background_repeat']) && ( $atts['background_repeat'] !='none')){
				$pattern_class = $atts['background_repeat'];
			}
			if(isset( $atts['background_position']) && ( $atts['background_position'] !='none')){
				$pattern_class = $atts['background_position'];
			}

			$overlay_class   = array();
			$overlay_class[] = 'brk-backgrounds__before';
			$overlay_class[] = $atts['gradient'];
			$overlay_class[] = $atts['opacity'];
			$overlay_class   = implode( ' ', $overlay_class );

			switch ( $atts['woo_tiles_type'] ) {
				case "trend":

					$post        = $posts[0];
					$bg_image    = get_the_post_thumbnail_url( $post->ID, $atts['image_size'] );
					$title       = BRS_Shortcodes_VCParams::get_content_title( $atts['title_val'], $post );
					$description = BRS_Shortcodes_VCParams::get_content_description( $atts['description_val'], $post );

					$post_type = get_post_type( $post->ID );
					if ( $post_type == 'product' ) {
						$product  = wc_get_product( $post->ID );
						$bg_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), $atts['image_size'] );
						$bg_image = $bg_image[0];
					}

					$output = '<div class="brk-sc-tiles-trend brk-sc-tiles-trend_' . $atts['text_color_scheme'] . '-text ' . $atts['gradient'] . ' brk-sc-tiles-trend_' . $atts['text_align'] . '-text  ' . $pattern_class . '" style="' . $pattern_style . '">
									<div class="' . $overlay_class . '"></div>
								  <div class="brk-sc-tiles-trend__content">
								    <div class="brk-sc-tiles-trend__thumbnail"><img src="' . esc_url( $bg_image ) . '" alt=""></div>
								    <div class="brk-sc-tiles-trend__description">
								      <h4 class="brk-sc-tiles-trend__title font__family-montserrat text-uppercase">
								        ' . esc_html( $atts['before_title'] ) . ' <strong>' . esc_html( $title ) . '</strong>
								      </h4>

								      <div class="brk-sc-tiles-trend__text">
								        ' . $description . '
								      </div>

								      <div class="brk-sc-tiles-trend__price-buy">';

					if ( $post_type == 'product' ) {
						$currency = get_woocommerce_currency_symbol();

						$output .= '<div class="brk-sc-tiles-trend__price-buy--price font__family-montserrat font__weight-ultralight">' . $product->get_price() . $currency . '</div>';

						$output .= apply_filters( 'woocommerce_loop_add_to_cart_link',
							sprintf( '<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="btn btn-inside-out btn-inside-out-invert btn-lg btn-icon border-radius-25 font__family-open-sans font__weight-bold add-cart ajax_add_to_cart %s product_type_%s"><i class="fa fa-shopping-basket icon-inside icon-inline"></i>
											<span class="before">' . esc_html__( 'Add to cart', 'berserk' ) . '</span><span class="text">' . esc_html__( 'Add to cart', 'berserk' ) . '</span><span class="after">' . esc_html__( 'Add to cart', 'berserk' ) . '</span></a>',
								esc_url( $product->add_to_cart_url() ),
								esc_attr( $product->get_id() ),
								esc_attr( $product->get_sku() ),
								$product->is_purchasable() ? 'add_to_cart_button' : '',
								esc_attr( $product->get_type() )
							),
							$post );
					}

					$output .= '</div>
								    </div>
								  </div>
								</div>';

					break;

				case "images":

					$output = '';

					if ( isset( $args['tax_query']['0'] ) ) {

						$taxonomy     = $args['tax_query']['0']['taxonomy'];
						$term_p       = $args['tax_query']['0']['terms'];
						$term         = get_term_by( 'slug', $term_p, $taxonomy );
						$id           = $term->term_id;
						$thumbnail_id = get_term_meta( $id, 'thumbnail_id', true );
						$bg_image     = wp_get_attachment_image_src( $thumbnail_id, $atts['image_size'] );
						$bg_image     = $bg_image[0];

						$output = '<div class="brk-sc-tiles-images brk-sc-tiles-images_style-1" style="background-image: url(' . esc_url( $bg_image ) . ')">
								  <div class="brk-sc-tiles-images__content">
								    <h4 class="brk-sc-tiles-images__title font__family-montserrat text-uppercase">
								      ' . esc_html( $atts['before_title'] ) . ' <strong>' . esc_html( $term->name ) . '</strong>
								    </h4>
								    <span class="brk-sc-tiles-images__year font__family-montserrat font__weight-bold">
								      ' . esc_html( $atts['after_title'] ) . '
								    </span>

								    <div class="brk-sc-tiles-images__text font__family-oxygen font__weight-light">
								      ' . esc_html( $term->description ) . '
								    </div>';

						switch ( $atts['button_type'] ) {
							case "gradient":
								$output .= '<a href="' . get_term_link( $id ) . '"	class="btn btn-gradient btn-lg brk-sc-tiles-images__btn border-radius-25 font__family-open-sans font__weight-bold">
									<span class="after"></span>' . esc_html__( 'Read more', 'berserk' ) . '</a>';

								break;
							case "prime":
								$output .= '<a href="' . get_term_link( $id ) . '"	class="btn btn-prime btn-lg brk-sc-tiles-images__btn border-radius-25 font__family-open-sans font__weight-bold">
												<span class="before"></span><span class="after"></span><span class="border-btn"></span>' . esc_html__( 'Read more', 'berserk' ) . '</a>';
								break;
						}

						$output .= '</div>
								</div>';

					}

					break;

				case "split":

					$taxonomy = $args['tax_query']['0']['taxonomy'];
					$term_p   = $args['tax_query']['0']['terms'];
					$term     = get_term_by( 'slug', $term_p, $taxonomy );

					$output = '<div class="brk-sc-tiles-split">';
					$i      = 1;
					foreach ( $posts as $post ) {
						$bg_image  = get_the_post_thumbnail_url( $post->ID, $atts['image_size'] );
						$title     = BRS_Shortcodes_VCParams::get_content_title( $atts['title_val'], $post );
						$post_type = get_post_type( $post->ID );
						if ( $post_type == 'product' ) {
							$product  = wc_get_product( $post->ID );
							$bg_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), $atts['image_size'] );
							$bg_image = $bg_image[0];
						}

						$output .= '<div class="brk-sc-tiles-split__product brk-sc-tiles-split_style-' . $i . '">';

						//$image = wp_get_attachment_image_src( $atts['single_bg_image'], 'full' );
						//$image = $image[0];

						if ( $i == 2 ) {
							$output .= '<div class="brk-sc-tiles-split__bg-thumb brk-sc-tiles-split-gradient '.$pattern_class.'" style="'.$pattern_style.'">
									      <div class="brk-sc-tiles-split__bg-thumb--img" style="background-image: url(' . esc_url( $bg_image ) . ')"></div>
									    </div>';
						} else {
							$output .= '<div class="brk-sc-tiles-split__bg-thumb">
									      <div class="brk-sc-tiles-split__bg-thumb--img" style="background-image: url(' . esc_url( $bg_image ) . ')"></div>
									    </div>';
						}


						$output .= '<div class="brk-sc-tiles-split__thumb">
									      <img src="' . esc_url( $bg_image ) . '" alt="">
									    </div>

									    <div class="brk-sc-tiles-split__content">';
						if ( $post_type == 'product' ) {
							$grad_color = ( $i == 2 ) ? 'brk-base-bg-gradient-left-blue' : 'brk-base-bg-gradient-14';

							$output .= '<div class="brk-sc-tiles-split__cat font__family-montserrat brk-white-font-color"><span class="' . $grad_color . '">' . $term->name . '</span></div>';
						}

						$font_color = ( $i == 2 ) ? 'brk-white-font-color' : 'brk-black-font-color';

						$output .= '<a class="brk-sc-tiles-split__link ' . $font_color . '" href="' . get_permalink( $post->ID ) . '"><h4 class="font__family-montserrat text-uppercase font__weight-bold">' . esc_attr( $title ) . '</h4></a>';

						if ( $post_type == 'product' ) {
							$currency  = get_woocommerce_currency_symbol();
							$old_price = '';
							if ( ( $product->get_sale_price() !== '' ) ) {
								$old_price = $currency . $product->get_regular_price();
							}
							$output .= '<div class="brk-sc-tiles-split__price font__family-montserrat">
									        <span class="brk-sc-tiles-split__price--old brk-dark-font-color">' . $old_price . '</span>
									        <span class="brk-sc-tiles-split__price--price brk-base-font-color">' . $currency . $product->get_price() . '</span>
									      </div>';

							$output .= '';

							$output .= apply_filters( 'woocommerce_loop_add_to_cart_link',
								sprintf( '<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="btn btn-gradient btn-md brk-sc-tiles-split__btn font__family-open-sans font__weight-bold add-cart ajax_add_to_cart %s product_type_%s">
											<span class="after"></span>' . esc_html__( 'Buy now', 'berserk' ) . '</a>',
									esc_url( $product->add_to_cart_url() ),
									esc_attr( $product->get_id() ),
									esc_attr( $product->get_sku() ),
									$product->is_purchasable() ? 'add_to_cart_button' : '',
									esc_attr( $product->get_type() )
								),
								$post );
						}


						$output .= '</div>
									  </div>';
						$i ++;
					}

					$output .= '</div>';

					break;
				case "angle":

					$first_term  = get_term_by( 'slug', $args['tax_query']['0']['terms'], $args['tax_query']['0']['taxonomy'] );
					$second_term = get_term_by( 'slug', $args['tax_query']['1']['terms'], $args['tax_query']['1']['taxonomy'] );

					$first_tax  = $args['tax_query']['0'];
					$second_tax = $args['tax_query']['1'];

					$args_first              = $args;
					$args_first['tax_query'] = array( $first_tax );

					$args_second              = $args;
					$args_second['tax_query'] = array( $second_tax );

					$posts_first  = get_posts( $args_first );
					$posts_second = get_posts( $args_second );

					//$image = wp_get_attachment_image_src( $atts['single_bg_image'], 'full' );
					//$image = $image[0];
					$output = '';

					if (is_object($first_term) && is_object($second_term)) {

						$output = '<div class="brk-sc-tiles-angle '.$pattern_class.'" style="'.$pattern_style.'">
								  <div class="brk-sc-tiles-angle__loading"><span class="before"></span>
								    <i class="fa fa-refresh"></i>
								  </div>

								   <div class="brk-sc-tiles-angle__top brk-base-bg-gradient-50deg-a">
									    <div class="brk-sc-tiles-angle__container">
									      <div class="brk-sc-tiles-angle__slider">
									        <div class="post-angle-slider arrows-classic-ellipse slick-loading fa-req"
									     data-slick=\'{
									     "slidesToShow": 3,
									     "slidesToScroll": 1,
									     "arrows": true,
									     "autoplaySpeed": 2800,
									     "centerMode": true,
									     "centerPadding": 0,
									     "responsive": [
									     {
									        "breakpoint": 1200,
									        "settings": {"slidesToShow": 2}
									     },
									     {
									        "breakpoint": 992,
									        "settings": {"slidesToShow": 3}
									     },
									     {
									        "breakpoint": 768,
									        "settings": {"slidesToShow": 2}
									     },
									     {
									        "breakpoint": 576,
									        "settings": {"slidesToShow": 1}
									     }
									     ]}\'>';

						foreach ( $posts_first as $post ) {
							$bg_image  = get_the_post_thumbnail_url( $post->ID, $atts['image_size'] );
							$title     = BRS_Shortcodes_VCParams::get_content_title( $atts['title_val'], $post );
							$post_type = get_post_type( $post->ID );
							if ( $post_type == 'product' ) {
								$product  = wc_get_product( $post->ID );
								$bg_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), $atts['image_size'] );
								$bg_image = $bg_image[0];
							}

							$output .= '<div class="brk-sc-angle-post">
										  <div class="brk-sc-angle-post__container" style="background-image: url(' . esc_url( $bg_image ) . ')">
										    <div class="brk-sc-angle-post__container-before brk-base-bg-gradient-10deg"></div>
										    <a href="' . get_permalink( $post->ID ) . '"><h4 class="brk-sc-angle-post__title brk-white-font-color">' . esc_html( $title ) . '</h4></a>';

							if ( $post_type == 'product' ) {
								$currency = get_woocommerce_currency_symbol();
								$price    = $product->get_price();
								$price    = explode( '.', $price );

								if ( isset( $price[1] ) ) {
									$sum   = $price[0];
									$cents = $price[1];
								} else {
									$sum   = $price[0];
									$cents = '00';
								}

								$output .= '<div class="brk-sc-angle-post__price brk-white-font-color brk-bg-primary font__family-montserrat">' . $currency . $sum . ' <span>' . $cents . '</span></div>';

								$output .= apply_filters( 'woocommerce_loop_add_to_cart_link',
									sprintf( '<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="brk-sc-angle-post__buy brk-white-font-color brk-bg-primary font__family-montserrat font__weight-bold add-cart ajax_add_to_cart %s product_type_%s">
											<i class="fa fa-shopping-basket" aria-hidden="true"></i>' . esc_html__( 'Buy now', 'berserk' ) . '</a>',
										esc_url( $product->add_to_cart_url() ),
										esc_attr( $product->get_id() ),
										esc_attr( $product->get_sku() ),
										$product->is_purchasable() ? 'add_to_cart_button' : '',
										esc_attr( $product->get_type() )
									),
									$post );

							}
							$output .= '</div>
										</div>';

						}

						$output .= '</div>
									      </div>
									      <div class="brk-sc-tiles-angle__content">
									        <h4 class="font__family-montserrat brk-white-font-color">
									          <span class="font__weight-light">' . esc_html( $atts['before_title'] ) . '</span>
									          <span class="font__weight-bold">' . esc_html( $first_term->name ) . '</span>
									        </h4>

									        <p class="font__family-oxygen font__weight-light brk-white-font-color">' . esc_html( $first_term->description ) . '</p>
									      </div>
									    </div>
									  </div>

									  <div class="brk-sc-tiles-angle__bottom brk-base-bg-gradient-bottom-blue">
										    <div class="brk-sc-tiles-angle__container">
										      <div class="brk-sc-tiles-angle__slider">
										        <div class="post-angle-slider arrows-classic-ellipse slick-loading fa-req"
										     data-slick=\'{
										     "slidesToShow": 3,
										     "slidesToScroll": 1,
										     "arrows": true,
										     "autoplaySpeed": 2800,
										     "centerMode": true,
										     "centerPadding": 0,
										     "responsive": [
										     {
										        "breakpoint": 1200,
										        "settings": {"slidesToShow": 2}
										     },
										     {
										        "breakpoint": 992,
										        "settings": {"slidesToShow": 3}
										     },
										     {
										        "breakpoint": 768,
										        "settings": {"slidesToShow": 2}
										     },
										     {
										        "breakpoint": 576,
										        "settings": {"slidesToShow": 1}
										     }
										     ]}\'>';


						foreach ( $posts_second as $post ) {
							$bg_image  = get_the_post_thumbnail_url( $post->ID, $atts['image_size'] );
							$title     = BRS_Shortcodes_VCParams::get_content_title( $atts['title_val'], $post );
							$post_type = get_post_type( $post->ID );
							if ( $post_type == 'product' ) {
								$product  = wc_get_product( $post->ID );
								$bg_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), $atts['image_size'] );
								$bg_image = $bg_image[0];
							}
							$output .= '<div class="brk-sc-angle-post">
											  <div class="brk-sc-angle-post__container" style="background-image: url(' . esc_url( $bg_image ) . ')">
											    <div class="brk-sc-angle-post__container-before brk-base-bg-gradient-10deg"></div>
											    <h4 class="brk-sc-angle-post__title brk-white-font-color">' . esc_html( $title ) . '</h4>';

							if ( $post_type == 'product' ) {
								$currency = get_woocommerce_currency_symbol();
								$price    = $product->get_price();
								$price    = explode( '.', $price );

								if ( isset( $price[1] ) ) {
									$sum   = $price[0];
									$cents = $price[1];
								} else {
									$sum   = $price[0];
									$cents = '00';
								}

								$output .= '<div class="brk-sc-angle-post__price brk-white-font-color brk-bg-primary font__family-montserrat">' . $currency . $sum . ' <span>' . $cents . '</span></div>';


								$output .= apply_filters( 'woocommerce_loop_add_to_cart_link',
									sprintf( '<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="brk-sc-angle-post__buy brk-white-font-color brk-bg-primary font__family-montserrat font__weight-bold add-cart ajax_add_to_cart %s product_type_%s">
											<i class="fa fa-shopping-basket" aria-hidden="true"></i>' . esc_html__( 'Buy now', 'berserk' ) . '</a>',
										esc_url( $product->add_to_cart_url() ),
										esc_attr( $product->get_id() ),
										esc_attr( $product->get_sku() ),
										$product->is_purchasable() ? 'add_to_cart_button' : '',
										esc_attr( $product->get_type() )
									),
									$post );

							}

							$output .= '</div>
											</div>';

						}
						$output .= '</div>
										      </div>
										      <div class="brk-sc-tiles-angle__content">
										        <h4 class="font__family-montserrat brk-white-font-color">
										          <span class="font__weight-light">' . esc_html( $atts['before_title'] ) . '</span>
										          <span class="font__weight-bold">' . esc_html( $second_term->name ) . '</span>
										        </h4>

										        <p class="font__family-oxygen font__weight-light brk-white-font-color">
										         ' . esc_html( $first_term->description ) . '</p>
										      </div>
										    </div>
										  </div>


							  </div>';
					}

					break;

			}

			return $output;
		}
	}

	// create shortcode
	BRS_Woo_Tiles::get_instance();

}
