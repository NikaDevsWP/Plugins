<?php
// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**************************************************************************************/
// Radio field
/**************************************************************************************/

if ( ! class_exists( 'BRS_Radio_Field' ) ) {
	class BRS_Radio_Field {
		/**
		 * Get field HTML
		 *
		 * @param string $html
		 * @param mixed $meta
		 * @param array $field
		 *
		 * @return string
		 */
		static function html( $html, $meta, $field ) {

			$tpl = '<label %s><div href="#" atr-title="%s">%s<input type="radio" class="brs-radio" name="%s" value="%s" %s /></div></label>';

			$admin_images_uri = BERSERK_SHORTCODES_URL . 'shortcodes/images/';

			foreach ( $field['options'] as $value => $label ) {

				$class         = '';
				$image         = '';
				$checked       = '';
				$current_class = '';

				if ( $label == $meta ) {
					$checked = 'checked';
					$current_class = 'current-item';
				}

				$bg_img = ($field['images'][ $label ]) ? esc_url( $admin_images_uri . $field['images'][ $label ] ) : esc_url($admin_images_uri.'blank.gif');

				$image = sprintf(
					'<div class="wrap_radio_image '.$current_class.'" style="width:' . $field['images_dim']['w'] . 'px; height:' . $field['images_dim']['h'] . 'px;"><img src="%s" class="hide-if-no-js"  style="%s" width="%d" height="%d" data-val="%s" /></div>',
					esc_url( $admin_images_uri . 'blank.gif' ),
					"background-image:url('" . $bg_img . "');",
					absint( $field['images_dim']['w'] - 6 ),
					absint( $field['images_dim']['h'] - 6 ),
					$label
				);

				//$label = current( $label );

				$html .= sprintf(
					$tpl,
					$class,
					$value,
					$image,
					$field['param_name'],
					$label,
					$checked
				);
			}

			return $html;
		}

		/**
		 * Filter before html.
		 */
		static function dt_filter_begin_html( $begin, $field, $meta ) {

			if ( ! empty( $field['hide_fields'] ) ) {
				$begin = str_replace( 'class="rwmb-input', 'class="rwmb-input rwmb-radio-hide-fields', $begin );
			}

			return $begin;
		}
	}

	add_filter( 'brs_radio_begin_html', array( 'BRS_Radio_Field', 'brs_filter_begin_html' ), 10, 3 );
}
