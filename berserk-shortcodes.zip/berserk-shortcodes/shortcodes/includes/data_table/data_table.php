<?php
/**
 * BRS_Data_Table shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Data_Table', false ) ) {

	require_once BERSERK_SHORTCODES_PATH . 'shortcodes/includes/shortcodes-ext.php';

	class BRS_Data_Table extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Data_Table();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_data_table', array( $this, 'shortcode_data_table' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				$params = array();

				$params[] = array(
					"heading"    => __( "Main Settings", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);
				$params[] = array(
					'heading'    => __( 'Table Type', 'berserk' ),
					'param_name' => 'table_type',
					'type'       => 'brs_radio',
					'value'      => array(
						"Trend"    => "trend",
						"Lines"    => "lines",
						"Strict"   => "strict",
						"Pedestal" => "pedestal",
					),
					'images'     => array(
						"trend"    => 'gallery_sliders/trend.png',
						"lines"    => 'data_table/lines.png',
						"strict"   => 'data_table/strict.png',
						"pedestal" => 'data_table/pedestal.png',
					),
					'images_dim' => array(
						'w' => '320',
						'h' => '100'
					)
				);
				$params[] = array(
					'type'        => 'dropdown',
					'class'       => '',
					'heading'     => __( 'wpDataTable', 'wpdatatables' ),
					'admin_label' => true,
					'param_name'  => 'id',
					'value'       => wdtGetAllTablesVC(),
					'description' => __( 'Choose the wpDataTable from a dropdown', 'wpdatatables' )
				);

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Berserk Data Table", 'berserk' ),
					"base"     => "brs_data_table",
					"icon"     => "brs_vc_ico_data_table",
					"class"    => "brs_vc_sc_data_table",
					"category" => __( 'Berserk', 'berserk' ),
					"params"   => $params
				) );

			}
		}

		public function shortcode_data_table( $atts, $content = null ) {
			brs_add_libraries( array( 'component__tables' ) );

			$atts = shortcode_atts( array(
				'table_type' => 'trend',
				'id'         => ''
			), $atts );

			$table_wrapper_class = array();
			$table_wrapper_class[] = 'brk-tables';
			$table_wrapper_class[] = 'font__family-montserrat';

			switch ( $atts['table_type'] ) {
				case 'trend':
					$table_wrapper_class[] = 'brk-tables-trend';
					break;
				case 'lines':
					$table_wrapper_class[] = 'brk-tables-lines';
					$table_wrapper_class[] = 'brk-tables-lines__table';
					break;
				case 'strict':
					$table_wrapper_class[] = 'brk-tables-strict';
					break;
				case 'pedestal':
					$table_wrapper_class[] = 'brk-tables-pedestal';
					break;
			}
			$table_wrapper_class = implode(' ', $table_wrapper_class);

			$id = $atts['id'];

			if ( ! $id ) {
				return false;
			}

			$tableData = WDTConfigController::loadTableFromDB( $id );
			if ( empty( $tableData->content ) ) {
				return __( 'wpDataTable with provided ID not found!', 'wpdatatables' );
			}

			do_action( 'wpdatatables_before_render_table', $id );


			/** @var WPDataTable $wpDataTable */
			$wpDataTable = new WPDataTable();


			$wpDataTable->setWpId( $id );

			$columnDataPrepared = $wpDataTable->prepareColumnData( $tableData );

			try {
				$wpDataTable->fillFromData( $tableData, $columnDataPrepared );
				$wpDataTable = apply_filters( 'wpdatatables_filter_initial_table_construct', $wpDataTable );

				$output = '';
				$output .= '<div class="'.$table_wrapper_class.'">';
				$output .= $wpDataTable->generateTable();
				$output .= '</div>';

			} catch ( Exception $e ) {
				$output = WDTTools::wdtShowError( $e->getMessage() );
			}
			$output = apply_filters( 'wpdatatables_filter_rendered_table', $output, $id );

			return $output;
		}


	}

	// create shortcode
	BRS_Data_Table::get_instance();

}
