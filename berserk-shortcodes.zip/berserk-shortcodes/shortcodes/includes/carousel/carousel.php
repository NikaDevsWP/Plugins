<?php
/**
 * Carousel shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Carousel', false ) ) {

	class BRS_Carousel extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Carousel();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_carousel', array( $this, 'shortcode_carousel' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Carousel", 'berserk' ),
					"base"     => "brs_carousel",
					"icon"     => "brs_vc_ico_carousel",
					"class"    => "brs_vc_sc_carousel",
					"category" => __( 'Berserk', 'berserk' ),
					"params"   => array(
						array(
							'heading'          => esc_html__('Carousel Type','berserk'),
							'param_name'       => 'carousel_type_title',
							'type'             => 'brs_title',
							'edit_field_class' => 'brs_vc_row-param vc_col-xs-12 vc_column',
						),
						array(
							//'heading'    => __( 'Carousel Type', 'berserk' ),
							'param_name' => 'carousel_type',
							'type'       => 'brs_radio',
							'value'      => array(
								esc_html__( 'Rotation Type 1', 'berserk' )    => "rotation_type_1",
								esc_html__( 'Rotation Type 2', 'berserk' )    => "rotation_type_2",
								esc_html__( 'Dark', 'berserk' )               => "dark",
								esc_html__( 'Thumbnailed', 'berserk' )        => "thumbnailed",
								esc_html__( 'Tiled', 'berserk' )              => "tiled",
								esc_html__( 'Thumbnailed Slider', 'berserk' ) => "thumbnailed_slider",
								esc_html__( 'Brand Carousel', 'berserk' )     => 'brand',
								esc_html__( 'Team Slider', 'berserk' )        => 'slider_team',
								esc_html__( 'Triple Slider', 'berserk' )      => 'triple_slider',
							),
							'images'     => array(
								"rotation_type_1"    => 'carousel/rotation_type_1.jpg',
								"rotation_type_2"    => 'carousel/rotation_type_2.jpg',
								"dark"               => 'carousel/dark.jpg',
								"thumbnailed"        => 'carousel/thumbnailed.jpg',
								"tiled"              => 'carousel/tiled.jpg',
								"thumbnailed_slider" => 'carousel/thumbnailed_slider.jpg',
								'brand'              => 'carousel/brand.jpg',
								'slider_team'        => 'carousel/slider_team.jpg',
								'triple_slider'      => 'carousel/triple_slider.jpg'
							),
							'images_dim' => array(
								'w' => '310',
								'h' => '150'
							)
						),
						array(
							'type'             => 'attach_images',
							'heading'          => __( 'Images', 'js_composer' ),
							'value'            => '2017',
							'param_name'       => 'images',
							"edit_field_class" => "vc_col-xs-12 vc_column",
						),
						array(
							'type'             => 'dropdown',
							'heading'          => __( 'Image size', 'berserk' ),
							'value'            => BRS_Shortcodes_VCParams::get_image_sizes_names(),
							'param_name'       => 'image_size',
							'std'              => 'image-frames',
							'edit_field_class' => 'vc_col-sm-6 vc_column'
						),
						array(
							'type'             => 'dropdown',
							'heading'          => esc_html__( 'Image Grayscale Filter', 'berserk' ),
							'value'            => BRS_Shortcodes_VCParams::get_grayscale_values(),
							'param_name'       => 'image_grayscale',
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__carousel_type rotation_type_1'
						),
						array(
							'heading'          => __( 'Full height', 'berserk' ),
							'param_name'       => 'full_height',
							'type'             => 'brs_switch',
							'value'            => 'n',
							'options'          => array(
								'Yes' => 'y',
								'No'  => 'n',
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column'
						),
						array(
							'heading'          => esc_html__('Carousel Options','berserk'),
							'param_name'       => 'carousel_options',
							'type'             => 'brs_title',
							'edit_field_class' => 'brs_vc_row-param vc_col-xs-12 vc_column',
						),
						array(
							'heading'          => esc_html__('With dots pagination','berserk'),
							'param_name'       => 'dots',
							'type'             => 'checkbox',
							'value'            => array(
								esc_html__('Yes','berserk') => 'y',
							),
							'edit_field_class' => 'vc_col-sm-3 vc_column brk-dependency__carousel_type rotation_type_1',
						),
						array(
							'heading'          => esc_html__('Arrows','berserk'),
							'param_name'       => 'arrows',
							'type'             => 'checkbox',
							'value'            => array(
								esc_html__('Yes','berserk') => 'y',
							),
							'edit_field_class' => 'vc_col-sm-3 vc_column brk-dependency__carousel_type rotation_type_1',
						),
						array(
							'type'             => 'textfield',
							'heading'          => __( 'centerPadding', 'js_composer' ),
							'param_name'       => 'center_padding',
							"value"            => "110px",
							'edit_field_class' => 'vc_col-sm-3 vc_column brk-dependency__carousel_type rotation_type_1',
						),
						array(
							'type'             => 'textfield',
							'heading'          => __( 'Autoplay Speed', 'js_composer' ),
							'param_name'       => 'autoplay_speed',
							"value"            => "",
							'edit_field_class' => 'vc_col-sm-3 vc_column',
						),

					)
				) );
			}
		}

		public function shortcode_carousel( $atts, $content = null ) {

			brs_add_libraries( array( 'slider__slick_with_component_sliders', 'component__image_caption' ) );

			extract( shortcode_atts( array(
				'carousel_type'     => 'rotation_type_1',
				'images'            => '',
				'image_size'        => 'image-frames',
				'image_grayscale'   => 'none',
				'full_height'       => 'n',
				'autoplay_speed'    => '',
				'autoplay_settings' => '',
				'dots'              => 'n',
				'arrows'            => '',
				'center_padding'    => '110px'

			), $atts ) );

			$images = explode( ',', $images );

			$image_class = '';
			if( $image_grayscale != 'none' ) {
				$image_class = 'grayscale-' . $image_grayscale;
			}

			$data_slick = array();
			$slider_class = array();

			if( $dots == 'y' ) {
				$data_slick['dots'] = true;
				$slider_class[] = 'dots-base-skin';
				$slider_class[] = 'dots-base-color';
			}
			if( $arrows ) {
				$data_slick['arrows'] = true;
				$slider_class[] = 'arrows-classic';
			} else {
				$data_slick['arrows'] = false;
			}
			if( $center_padding ) {
				$data_slick['centerPadding'] = esc_attr( $center_padding );
			}

			if ( $autoplay_speed !== '' ) {
				$autoplay_settings = ', "autoplay": true, "autoplaySpeed": ' . esc_attr( $autoplay_speed );
				$data_slick['autoplay'] = true;
				$data_slick['autoplaySpeed'] = esc_attr( $autoplay_speed );
			}


			switch ( $carousel_type ) {
				case "rotation_type_1":

					$data_slick['slidesToShow'] = 1;
					$data_slick['slidesToScroll'] = 1;
					$data_slick['draggable'] = false;

					array_unshift( $slider_class, 'rotation-slider', 'slick-loading');
					$slider_class = implode(' ', $slider_class );

					$output       = '<div class="' . esc_html__($slider_class) . '" data-slick=\'' . wp_json_encode( $data_slick ) . '\'>';

					foreach ( $images as $image ) {
						$output .= '<div>
										<div class="brk-slid">
											<a href="' . esc_url( wp_get_attachment_image_url( $image, 'full' ) ) . '" class="frame-image image-popup img-square shadow fancybox">
												<img src="' . wp_get_attachment_image_url( $image, $image_size ) . '" class="' . esc_attr( $image_class ) . '">
											</a>
										</div>
									</div>';
					}

					$output .= '</div>';

					break;

				case "rotation_type_2":

					$output = '<div class="rotation-slider-min dots-base-skin dots-base-color" data-slick=\'{"slidesToShow": 1, "slidesToScroll": 1, "dots": true' . $autoplay_settings . '}\'>';

					foreach ( $images as $image ) {
						$img_html   = wp_get_attachment_image( $image, $image_size );
						$image_src  = wp_get_attachment_image_src( $image, 'full' );
						$image_href = $image_src[0];
						$output .= '<div>' . $img_html . '</div>';
					}

					$output .= '</div>';

					break;

				case "dark":

					$output = '<div class="slider-dark arrows-dark" data-slick=\'{"slidesToShow": 1, "slidesToScroll": 1, "arrows": true' . $autoplay_settings . '}\'>';

					foreach ( $images as $image ) {
						$img_html   = wp_get_attachment_image( $image, $image_size );
						$image_src  = wp_get_attachment_image_src( $image, 'full' );
						$image_href = $image_src[0];
						$output .= '<div>' . $img_html . '</div>';
					}
					$output .= '</div>';

					break;

				case "thumbnailed":

					$output = '<div class="slider-thumbnailed">
					              <div class="slider-thumbnailed-for arrows-modern" data-slick=\'{"slidesToShow": 1, "slidesToScroll": 1, "fade": true, "arrows": true' . $autoplay_settings . '}\'>';

					foreach ( $images as $image ) {
						$img_html   = wp_get_attachment_image( $image, $image_size );
						$image_src  = wp_get_attachment_image_src( $image, 'full' );
						$image_href = $image_src[0];
						$output .= '<div>' . $img_html . '</div>';
					}

					$output .= '</div>
					              <div class="slider-thumbnailed-nav" data-slick=\'{"slidesToShow": 4, "slidesToScroll": 1}\'>';

					foreach ( $images as $image ) {
						$img_html   = wp_get_attachment_image( $image, 'carousel-thumbnailed-nav' );
						$image_src  = wp_get_attachment_image_src( $image, 'full' );
						$image_href = $image_src[0];
						$output .= '<div class="brk-slid">' . $img_html . '</div>';
					}

					$output .= '</div>
					            </div>';


					break;
				case "tiled":

					$output = '<div class="tiled-slider arrows-classic-ellipse" data-slick=\'{"slidesToShow": 5, "slidesToScroll": 1, "arrows": true' . $autoplay_settings . ', "centerMode": true, "centerPadding": "0"}\'>';

					foreach ( $images as $image ) {
						$img_html   = wp_get_attachment_image( $image, $image_size );
						$image_src  = wp_get_attachment_image_src( $image, 'full' );
						$image_href = $image_src[0];
						$output .= '<div class="brk-slid">
					                <a href="' . $image_href . '" class="image-popup-gradient img-square fancybox">
					                  ' . $img_html . '
					                </a>
					              </div>';
					}

					$output .= '</div>';

					break;

				case "thumbnailed_slider":

					$height_class = "";

					if ( $full_height == 'y' ) {
						$height_class = "height-100vh";
					}

					$output = '<div class="slider-thumbnailed-full ' . $height_class . '">
						          <div class="slider-thumbnailed-full-for arrows-full" data-slick=\'{"slidesToShow": 1, "slidesToScroll": 1, "fade": true, "arrows": true}\'>';

					foreach ( $images as $image ) {
						$img_html   = wp_get_attachment_image( $image, 'full' );
						$image_src  = wp_get_attachment_image_src( $image, $image_size );
						$image_href = $image_src[0];
						$output .= '<div>
						              <div class="brk-slid" style="background-image: url(' . esc_url( $image_href ) . ')"></div>
						            </div>';
					}

					$output .= '</div>
						          <div class="slider-thumbnailed-full-nav" data-slick=\'{"slidesToShow": 6, "slidesToScroll": 1' . $autoplay_settings . '}\'>';

					foreach ( $images as $image ) {
						$img_html   = wp_get_attachment_image( $image, 'carousel-thumbnailed_slider-nav' );
						$image_src  = wp_get_attachment_image_src( $image, 'full' );
						$image_href = $image_src[0];
						$output .= '<div class="brk-slid">' . $img_html . '</div>';
					}

					$output .= '</div>
						        </div>';

					break;

				case "brand":

					$output = '<div class="brk-brand-slider slick-loading fa-req">';

					foreach ( $images as $image ) {
						$image_url = wp_get_attachment_image_url( $image, $image_size );
						$output .= '<div>
										<img class="lazyload" src="' . esc_attr( BRK_DATA_IMAGE ) . '" data-src="' . esc_url( $image_url ) . '" alt="">
									</div>';
					}

					$output .= '</div>';

					break;
				case "slider_team":

					$output = '<div class="brk-slider-team" data-brk-library="slider__slick">';

					foreach ( $images as $image ) {
						$image_url = wp_get_attachment_image_url( $image, $image_size );

						$output .= '<div>
					                    <div class="brk-img-zoom">
					                        <a href="">
					                            <img src="' . esc_attr( BRK_DATA_IMAGE ) . '" data-src="' . esc_url( $image_url ) . '" alt="alt" class="brk-img-zoom__img lazyload">
					                        </a>
					                    </div>
					                </div>';
					}


					$output .= '</div>';


					break;

				case "triple_slider":
					$output = '<div class="triple-slider slick-loading arrows-classic" data-brk-library="slider__slick,component__image_caption">';
					foreach ( $images as $image ) {
						$image_url  = wp_get_attachment_image_url( $image, $image_size );
						$attachment = get_post( $image );

						$output .= '<div>
				                        <div class="brk-ic-left-slide brk-ic-left-slide__pointer "
				                             data-brk-library="component__image_caption_css">
				                            <a href="javascript:void(0)" class="brk-ic-left-slide__link"></a>
				                            <img src="' . esc_url( $image_url ) . '"
				                                 data-src="' . esc_url( $image_url ) . '"
				                                 alt="alt" class="brk-ic-left-slide__img lazyload "/>
				                            <div class="brk-ic-left-slide__overlay brk-base-bg-gradient-6-black"></div>
				                            <div class="brk-ic-left-slide__wrapper brk-ic-left-slide__wrapper_gradient brk-base-bg-gradient-50deg-a">
				                                <h3 class="brk-ic-left-slide__title font__size-21 line__height-28">
				                                    <span class="font__family-montserrat font__weight-light">' . esc_html( $attachment->post_title ) . '</span>
				                                    <br>
				                                    <span class="font__family-montserrat font__weight-bold letter-spacing--20">' . esc_html( $attachment->post_excerpt ) . '</span>
				                                </h3>
				                            </div>
				                        </div>
				                    </div>';

					}
					$output .= '</div>';
					break;
			}

			return $output;
		}


	}

	// create shortcode
	BRS_Carousel::get_instance();

}
