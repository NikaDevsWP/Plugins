<?php
/**
 * Logo shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Logo', false ) ) {

	class BRS_Logo extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Logo();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_logo', array( $this, 'shortcode_logo' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Logos", 'berserk' ),
					"base"     => "brs_logo",
					"icon"     => "brs_vc_ico_logo",
					"class"    => "brs_vc_sc_logo",
					"category" => __( 'Berserk', 'berserk' ),
					"params"   => array(

						array(
							'heading'    => esc_html__( 'Main Settings', 'berserk' ),
							'param_name' => 'brs_title',
							'type'       => 'brs_title',
						),
						array(
							'heading'    => esc_html__( 'Logos Type', 'berserk' ),
							'param_name' => 'type',
							'type'       => 'brs_radio',
							'value'      => array(
								'Type 1'  => 'type_1',
								'Type 2'  => 'type_2',
							),
							'images'     => array(
								'type_1'  => 'logos/001.png',
								'type_2'  => 'logos/002.png',
							),
							'images_dim' => array(
								'w' => '310',
								'h' => '150'
							)
						),

						array(
							'type'       => 'param_group',
							'heading'    => __( 'Values', 'js_composer' ),
							'param_name' => 'values',
							'value'      => urlencode( json_encode( array(
								array(
									'image'      => '',
									'image_size' => 'logo-shortcode',
									'link'       => '',
								),
								array(
									'image'      => '',
									'image_size' => 'logo-shortcode',
									'link'       => '',
								),
								array(
									'image'      => '',
									'image_size' => 'logo-shortcode',
									'link'       => '',
								),
								array(
									'image'      => '',
									'image_size' => 'logo-shortcode',
									'link'       => '',
								),

							) ) ),
							'params'     => array(

								array(
									'type'             => 'attach_image',
									'heading'          => __( 'Upload Image', 'berserk' ),
									'param_name'       => 'image',
									'admin_label'      => true,
									'value'            => '',
									'description'      => __( 'Select image from media library.', 'berserk' ),
									'edit_field_class' => 'vc_col-sm-6 vc_column'
								),
								array(
									'type'             => 'dropdown',
									'heading'          => __( 'Image size', 'berserk' ),
									'value'            => BRS_Shortcodes_VCParams::get_image_sizes_names(),
									'param_name'       => 'image_size',
									//'std'              => 'logo-shortcode',
									'edit_field_class' => 'vc_col-sm-6 vc_column'
								),
								array(
									'type'             => 'vc_link',
									'heading'          => __( 'Link URL', 'berserk' ),
									'param_name'       => 'link',
									'edit_field_class' => 'vc_col-sm-6 vc_column'
								)

							),
						),

						array(
							'type'             => 'dropdown',
							'heading'          => __( 'Columns', 'berserk' ),
							'value'            => array(
								'1 Columns' => '1',
								'2 Columns' => '2',
								'3 Columns' => '3',
								'4 Columns' => '4',
								'6 Columns' => '6',
							),
							'std'              => '2',
							'param_name'       => 'logo_columns',
							'edit_field_class' => 'vc_col-sm-6 vc_column brk-dependency__portfolio_type grid category',
						),
					)
				) );
			}
		}

		public function shortcode_logo( $atts, $content = null ) {

			//brs_add_libraries( $libraries );
			brs_add_libraries( array( 'component__portfolio_page' ) );

			$output = '';
			$items  = array();

			$attributes = shortcode_atts( array(
				'type'         => 'type_1',
				'logo_columns' => '2',
				'values'       => '',
			), $atts );

			// Extract
			/*extract( shortcode_atts( array(
				'type'         => 'type_1',
				'logo_columns' => '2',
				'values'       => '',
			), $atts ) );*/

			$values = vc_param_group_parse_atts( $attributes['values'] );

			if ( ! empty( $values ) ) {
				foreach ( $values as $key => $value ) {
					$image                  = ( isset( $value['image'] ) ) ? wp_get_attachment_image_src( $value['image'], $value['image_size'] ) : array( '' );
					$items[ $key ]['image'] = $image[0];
					$items[ $key ]['url']   = '';
					if ( isset( $value['link'] ) ) {
						$url                  = vc_build_link( $value['link'] );
						$items[ $key ]['url'] = $url;
					}
				}
			}

			// Type 1
			if ( $attributes['type'] == 'type_1' ) {

				$output = '<div class="brk-logos pl-15 pr-15">
					<div class="row">';
					foreach ( $items as $item ) {
						$output .= self::get_logo_item( $item['image'], $item['url'], $attributes['logo_columns'] );
					}

				$output .= '</div>
				</div>';

			// Type 2
			} elseif ( $attributes['type'] == 'type_2' ) {

				brs_add_libraries( array( 'component__widgets' ) );
				
				$item_class = self::get_column_class( $attributes['logo_columns'] );

				$output = '<div class="row">';
					foreach ( $items as $item ) {
						$output .= '<div class="' . esc_attr( $item_class ) . '">'; //logo_columns col-lg-3 col-sm-6
						$output .= '<a href="' . esc_url( $item['url'] ) . '" class="logo-set">';
						$output .= '<img class="logo-set__img lazyload" src="' . esc_attr( BRK_DATA_IMAGE ) . '" data-src="' . esc_url( $item['image'] ) . '" alt="alt">';
						$output .= '</a>';
						$output .= '</div>';
					}

				$output .= '</div>';

			}

			return $output;
		}

		function get_logo_item( $image, $url, $col ) {

			$column       = self::get_column_class( $col );
			$item_class   = array();
			$item_class[] = $column;
			$item_class[] = 'brk-logos__item';
			$item_class[] = 'justify-content-center';
			$item_class[] = 'align-items-center';
			$item_class[] = 'd-flex';
			$item_class[] = 'p-4';
			$item_class   = implode( ' ', $item_class );

			$target = ( ! isset( $url['target'] ) || $url['target'] == '' ) ? '' : 'target="' . $url['target'] . '"';
			$url    = ( isset( $url['url'] ) ) ? $url['url'] : '';
			$output = '<a href="' . esc_url( $url ) . '" ' . $target . ' class="' . $item_class . '">
                            <span class="brk-logos__item-l-t-angle"></span>
                            <span class="brk-logos__item-r-t-angle"></span>
                            <span class="brk-logos__item-r-b-angle"></span>
                            <span class="brk-logos__item-l-b-angle"></span>
                            <img src="' . esc_url( $image ) . '" class="brk-logos__img" alt="">
                        </a>';

			return $output;
		}

		function get_column_class( $col ) {
			$class = '';
			switch ( $col ) {
				case "1":
					$class = 'col-12';
					break;
				case "2":
					$class = 'col-6';
					break;
				case "3":
					$class = 'col-4';
					break;
				case "4":
					$class = 'col-3';
					break;
				case "6":
					$class = 'col-2';
					break;
			}

			return $class;

		}

	}

	// create shortcode
	BRS_Logo::get_instance();

}
