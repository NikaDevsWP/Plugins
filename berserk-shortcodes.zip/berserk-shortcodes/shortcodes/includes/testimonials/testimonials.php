<?php
/**
 * BRS_Testimonials shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Testimonials', false ) ) {

	require_once BERSERK_SHORTCODES_PATH . 'shortcodes/includes/shortcodes-ext.php';

	class BRS_Testimonials extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Testimonials();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_testimonials', array( $this, 'shortcode_testimonials' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				$params = array();

				$params[] = array(
					"heading"    => __( "Main Settings", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);
				$params[] = array(
					'heading'    => __( 'Testimonials Type', 'berserk' ),
					'param_name' => 'testimonials_type',
					'type'       => 'brs_radio',
					'value'      => array(
						"Dash"               => "dash",
						"Type 1"             => "type_1",
						"Type 2"             => "type_2",
						"Type 3"             => "type_3",
						"Type 4"             => "type_4",
						"Type 5"             => "type_5",
						"Double"             => "double",
						"Layered Horizontal" => "layered_horizontal",
						"Layered Vertical"   => "layered_vertical",
						"Circle"             => "circle",
					),
					'images'     => array(
						"dash"               => 'testimonials/01.png',
						"type_1"             => 'testimonials/02.png',
						"type_2"             => 'testimonials/03.png',
						"type_3"             => 'testimonials/04.png',
						"type_4"             => 'testimonials/05.png',
						"type_5"             => 'testimonials/06.png',
						"double"             => 'testimonials/07.png',
						"layered_horizontal" => 'testimonials/08.png',
						"layered_vertical"   => 'testimonials/09.png',
						"circle"             => 'testimonials/10.png',
					),
					'images_dim' => array(
						'w' => '320',
						'h' => '100'
					)
				);

				$params[] = array(
					'type'             => 'textfield',
					'heading'          => __( 'Our reviews title', 'berserk' ),
					'param_name'       => 'reviews_title',
					'value'            => 'Our reviews',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
				);

				$params[] = array(
					'type'             => 'textfield',
					'heading'          => esc_html__( 'Our reviews subtitle', 'berserk' ),
					'param_name'       => 'reviews_subtitle',
					'value'            => '',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Image size', 'berserk' ),
					'value'            => BRS_Shortcodes_VCParams::get_image_sizes_names(),
					'param_name'       => 'image_size',
					'std'              => 'testimonials-avatar',
					'edit_field_class' => 'vc_col-sm-6 vc_column'
				);
				
				$params[] = array(
					'type'             => 'checkbox',
					'heading'          => esc_html__( 'Single Slide Per View', 'berserk' ),
					'value'            => array(
						esc_attr__('Use Single Slide', 'berserk' ) => 'y',
					),
					'param_name'       => 'single_slide',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					/*'dependency' => array(
						'element' => 'testimonials_type',
						'value'   => 'type_2',
					),*/
				);
				

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => esc_html__( 'Image Grayscale', 'berserk' ),
					'value'            => array(
						esc_html__( 'None', 'berserk' ) => '',
						esc_html__( '50%', 'berserk' )  => '50',
						esc_html__( '100%', 'berserk' ) => '100',
					),
					'param_name'       => 'image_grayscale',
					'std'              => '',
					'edit_field_class' => 'vc_col-sm-6 vc_column'
				);

				$params[] = array(
					'type'             => 'textfield',
					'heading'          => __( 'Link Text', 'js_composer' ),
					'param_name'       => 'link_text',
					"value"            => "All Reviews",
					'edit_field_class' => 'vc_col-sm-6 vc_column',
				);

				$params[] = array(
					'type'             => 'textfield',
					'heading'          => __( 'Video Review Link Text', 'js_composer' ),
					'param_name'       => 'video_review_link_text',
					"value"            => "Watch video review",
					'edit_field_class' => 'vc_col-sm-6 vc_column',
				);

				$params[] = array(
					"heading"    => __( "Dynamic Content", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$params = array_merge( $params, berserk_shortcodes_dynamic_filter() );

				$params[] = array(
					"heading"    => __( "Content Values", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Get title from', 'js_composer' ),
					'param_name'       => 'title_val',
					'value'            => array(
						'Post Title'  => 'post_title',
						'Post Date'   => 'post_date',
						'Post Author' => 'post_author'
					),
					'edit_field_class' => 'vc_col-sm-6 vc_column',
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Get description from', 'js_composer' ),
					'param_name'       => 'description_val',
					'value'            => array(
						'Post Title'   => 'post_title',
						'Post Date'    => 'post_date',
						'Post Author'  => 'post_author',
						'Post Content' => 'post_content',
						'Post Excerpt' => 'post_excerpt',
					),
					'edit_field_class' => 'vc_col-sm-6 vc_column',
					'std'              => 'post_content'
				);
				
				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => esc_html__( 'Description Font Weight', 'berserk' ),
					'value'            => BRS_Shortcodes_VCParams::get_font_weight(),
					'param_name'       => 'font_weight',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
				);
				
				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => esc_html__( 'Description Font Size', 'berserk' ),
					'value'            => BRS_Shortcodes_VCParams::get_font_size(),
					'param_name'       => 'font_size',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
				);

				$params[] = array(
					"heading"    => __( "Background", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$params[] = array(
					'type'             => 'attach_image',
					'heading'          => __( 'Background Image', 'js_composer' ),
					'param_name'       => 'bg_image',
					'value'            => '',
					'description'      => __( 'Select image from media library.', 'js_composer' ),
					'edit_field_class' => 'vc_col-sm-6 vc_column',
				);

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Background type', 'js_composer' ),
					'param_name'       => 'bg_type',
					'value'            => array(
						'White'   => 'white',
						'Colored' => 'colored',
					),
					'edit_field_class' => 'vc_col-sm-6 vc_column',

				);

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Testimonials", 'berserk' ),
					"base"     => "brs_testimonials",
					"icon"     => "brs_vc_ico_testimonials",
					"class"    => "brs_vc_sc_testimonials",
					"category" => __( 'Berserk', 'berserk' ),
					"params"   => $params
				) );

			}
		}

		public function shortcode_testimonials( $atts, $content = null ) {

			brs_add_libraries( array( 'component__testimonials', 'slider__swiper', 'fancybox' ) );

			extract( shortcode_atts( array(
				'testimonials_type'      => 'dash',
				'bg_image'               => '',
				'image_size'             => 'testimonials-avatar',
				'dynamic_content'        => 'no',
				'custom_items'           => '',
				'orderby'                => 'date',
				'order_direction'        => 'ASC',
				'filters'                => '',
				'title_val'              => 'post_title',
				'description_val'        => 'post_content',
				'link_text'              => 'All Reviews',
				'video_review_link_text' => 'Watch video review',
				'reviews_title'          => 'Our reviews',
				'reviews_subtitle'       => '',
				'bg_type'                => 'white',
				'image_grayscale'        => 'image_grayscale',
				'single_slide'           => '',
				'font_weight'            => 'initial',
				'font_size'              => '',
			), $atts ) );


			$bg_image        = wp_get_attachment_image_src( $bg_image, 'full' );
			$slider_bg_image = $bg_image[0];

			if ( $dynamic_content == 'y' ) {
				$args  = array();
				$args  = array_merge( $args, berserk_shortcodes_dynamic_filter_process( $filters, $orderby, $order_direction ) );
				$posts = get_posts( $args );
			} else {
				$posts        = array();
				$custom_items = explode( ',', $custom_items );
				foreach ( $custom_items as $item ) {
					$posts[] = get_post( $item );
				}
			}

			$taxonomy = '';
			$filters  = vc_param_group_parse_atts( $filters );
			if ( is_array( $filters ) ) {
				foreach ( $filters as $filter ) {
					if ( $filter['filter_type'] == 'taxonomies' ) {
						$taxonomy = $filter['taxonomy_values'];
						$term     = get_term_by( 'slug', $taxonomy, $filter['taxonomies'] );
						$taxonomy = $term->name;
					}
				}
			}

			//dpm($filters);

			switch ( $testimonials_type ) {
				case "dash":

					$output = '<div class="dash-one-slider swiper-container">
								<div class="swiper-wrapper">';

					foreach ( $posts as $post ) {
						$bg_image    = get_the_post_thumbnail_url( $post->ID, $image_size );
						$title       = BRS_Shortcodes_VCParams::get_content_title( $title_val, $post );
						$description = BRS_Shortcodes_VCParams::get_content_description( $description_val, $post );
						$post_type   = get_post_type( $post->ID );

						$output .= '<div class="swiper-slide">
									<div class="brk-testimonials-dash-one">
									  <div class="brk-testimonials-dash-one__info">
										<div class="brk-testimonials-dash-one__img"><img src="' . esc_url( $bg_image ) . '" alt=""></div>' . self::get_rating( $post->ID ) .
								   '<h4 class="font__family-montserrat font__weight-bold">' . esc_html( $title ) . '</h4>';
						if ( $post_type == Berserk_Testimonials::postType() ) {
							$positions = BRS_Shortcodes_VCParams::get_term_names( $post->ID, 'testimonial_position' );
							$position  = implode( ',', $positions );
							$output .= '<span class="brk-testimonials-dash-one__position font__family-open-sans">' . esc_html( $position ) . '</span>';
						}
						$output .= '
									  </div>
									  <div class="brk-testimonials-dash-one__description font__family-open-sans text-center text-lg-left">' . esc_html( $description ) . '</div>
									</div>
								  </div>';

					}

					$output .= '</div>

								<div class="swiper-modern-arrow">
								  <div class="button-prev"><i class="fa fa-angle-left"></i></div>
								  <div class="button-next"><i class="fa fa-angle-right"></i></div>
								</div>

								<a href="' . esc_url( get_post_type_archive_link( $post_type ) ) . '" class="brk-testimonials-dash-one__btn btn btn-lg border-radius-25 font__family-open-sans font__weight-bold btn-inside-out">
								  <span class="before">' . esc_html( $link_text ) . '</span>
								  <span class="text">' . esc_html( $link_text ) . '</span>
								  <span class="after">' . esc_html( $link_text ) . '</span>
								</a>
							  </div>';

					break;

				case "type_1":

					$output = '<div class="brk-testimonials-dash-two">
								<div class="dash-two-pagination"></div>

								<div class="swiper-container dash-two-slider">
								  <div class="swiper-wrapper">';

					foreach ( $posts as $post ) {
						$bg_image    = get_the_post_thumbnail_url( $post->ID, $image_size );
						$title       = BRS_Shortcodes_VCParams::get_content_title( $title_val, $post );
						$description = BRS_Shortcodes_VCParams::get_content_description( $description_val, $post );
						$post_type   = get_post_type( $post->ID );

						$output .= '<div class="swiper-slide">
									  <div class="brk-testimonials-dash-two__text-reviews brk-base-box-shadow" data-img="' . $bg_image . '">
										<span class="brk-testimonials-dash-two__name font__family-open-sans font__weight-bold">' . esc_html( $title ) . '</span>
										<span>,</span>';
						if ( $post_type == Berserk_Testimonials::postType() ) {
							$positions = BRS_Shortcodes_VCParams::get_term_names( $post->ID, 'testimonial_position' );
							$position  = implode( ',', $positions );
							$output .= '<span class="brk-testimonials-dash-two__service font__family-open-sans">' . $position . '</span>';

						}

						$output .= '<div class="brk-testimonials-dash-two__description font__family-open-sans">' . esc_html( $description ) . '</div>';

						if ( $post_type == Berserk_Testimonials::postType() ) {
							$video_url = get_post_meta( $post->ID, 'video-review-link', true );
							$link_text = $video_review_link_text;
							$output .= '<a href="' . esc_url( $video_url ) . '" class="brk-testimonials-dash-two__link-video font__family-open-sans fancybox-media">
										  <span><i class="fas fa-caret-right"></i></span>
										 ' . esc_html( $link_text ) . '
										</a>';
						}

						$output .= '</div>
									</div>';

					}

					$output .= '</div>
								</div>
							  </div>';


					break;

				case "type_2":

					$container_class = 'dash-three-slider swiper-container';
					if ( $single_slide ) {
						$container_class .= ' dash-three-slider_single';
					}
					
					$desc_class = array (
						'brk-testimonials-dash-three__desc',
						'font__family-open-sans',
						'line__height-28',
					);
					if( $font_weight ) {
						$desc_class[] = 'font__weight-' . $font_weight;
					}
					if( $font_size ) {
						$desc_class[] = 'font__size-' . $font_size;
					}
					$desc_class = implode( ' ', $desc_class );
					
					$output = '<div class="' . esc_attr( $container_class ) . '">
								  <div class="swiper-wrapper">';
					foreach ( $posts as $post ) {
						$bg_image    = get_the_post_thumbnail_url( $post->ID, $image_size );
						$title       = BRS_Shortcodes_VCParams::get_content_title( $title_val, $post );
						$description = BRS_Shortcodes_VCParams::get_content_description( $description_val, $post );
						$post_type   = get_post_type( $post->ID );

						$output .= '<div class="swiper-slide">
									  <div class="brk-testimonials-dash-three__item">
										<div class="brk-testimonials-dash-three__img"><img src="' . esc_url( $bg_image ) . '" alt=""></div>
										<div class="brk-testimonials-dash-three__caption">
										  <div class="brk-testimonials-dash-three__name font__family-montserrat font__weight-medium letter-spacing-100">' . esc_html( $title ) . '</div>';
						if ( $post_type == Berserk_Testimonials::postType() ) {
							$positions = BRS_Shortcodes_VCParams::get_term_names( $post->ID, 'testimonial_position' );
							$position  = implode( ',', $positions );
							$output .= '<div class="brk-testimonials-dash-three__classes font__family-playfair font__style-italic">' . esc_html( $position ) . '</div>';

						}
						$output .= '</div>
										<div class="' . esc_attr( $desc_class ) . '">' . esc_html( $description ) . '</div>
									  </div>
									</div>';
					}

					$output .= '</div>
								  <div class="swiper-pagination-base"></div>
								</div>';


					break;

				case "type_3":

					$output = '<div class="brk-testimonials-dash-four">
								<div class="dash-four-slider swiper-container">
								  <div class="swiper-wrapper">';

					foreach ( $posts as $post ) {
						$bg_image    = get_the_post_thumbnail_url( $post->ID, $image_size );
						$title       = BRS_Shortcodes_VCParams::get_content_title( $title_val, $post );
						$description = BRS_Shortcodes_VCParams::get_content_description( $description_val, $post );
						$post_type   = get_post_type( $post->ID );

						$output .= '<div class="swiper-slide">
									  <div class="brk-testimonials-dash-four__item text-center" data-img="' . $bg_image . '">
										<i class="fa fa-quote-right font__size-64"></i>
										<h4 class="brk-testimonials-dash-four__title font__family-open-sans font__weight-bold">' . esc_html( $title ) . '</h4>
										<div class="brk-testimonials-dash-four__text font__family-open-sans">' . esc_html( $description ) . '</div>
									  </div>
									</div>';

					}
					$admin_images_uri = BERSERK_SHORTCODES_URL . '/shortcodes/images/';

					$output .= '</div>
								</div>
								<div class="dash-four-pagination"></div>
								<div class="brk-testimonials-dash-four__layout" style="background-image: url(' . $admin_images_uri . 'testim.jpg)">
								  <span class="before"></span>
								</div>
							  </div>';


					break;

				case "type_4":

					$output = '<div class="brk-testimonials-dash-five">
									<div class="dash-five-slider swiper-container">
										<div class="swiper-wrapper">';

					foreach ( $posts as $post ) {
						$bg_image    = get_the_post_thumbnail_url( $post->ID, $image_size );
						$title       = BRS_Shortcodes_VCParams::get_content_title( $title_val, $post );
						$description = BRS_Shortcodes_VCParams::get_content_description( $description_val, $post );
						$post_type   = get_post_type( $post->ID );

						$output .= '<div class="swiper-slide">
									  <div class="brk-testimonials-dash-five__item text-center">
									  <span class="brk-testimonials-dash-five__icon">
											<i class="far fa-quote-right font__size-32"></i>
									  </span>
										<div class="brk-testimonials-dash-five__img"><img class="lazyload" src="' . esc_url( $bg_image ) . '" alt=""></div>
										<div class="brk-testimonials-dash-five__name font__family-open-sans">
										  <span class="font__weight-bold">' . esc_html( $title ) . ', </span>';
						if ( $post_type == Berserk_Testimonials::postType() ) {
							$positions = BRS_Shortcodes_VCParams::get_term_names( $post->ID, 'testimonial_position' );
							$position  = implode( ',', $positions );
							$output .= $position;

						}
						$output .= '</div>
										<div class="brk-testimonials-dash-five__desc font__family-open-sans">' . $description . '</div>
									  </div>
									</div>';
					}

					$output .= '</div>
								</div>
								<div class="dots-dash-five-skin">
								  <div class="swiper-arrow button-prev"><i class="fas fa-caret-left" aria-hidden="true"></i></div>
								  <ul class="pagination"></ul>
								  <div class="swiper-arrow button-next"><i class="fas fa-caret-right" aria-hidden="true"></i></div>
								</div>
							  </div>';


					break;

				case "type_5":

					$output = '<div class="brk-testimonials-dash-six">';

					if ( $reviews_subtitle != '' ) {
						$output .= '<div class="text-left mb-100">
										<div class="heading-style-left">
											<h2 class="font__family-roboto font__weight-thin  font__size-56 line__height-64 heading-style-left-h">' . esc_html( $reviews_title ) . '</h2>
											<span class="title__heading-05 pl-1  title__heading-sub wow fadeInLeft heading-style-left-span font__family-roboto font__size-16 font__weight-bold" style="visibility: visible; animation-name: fadeInRight;">' . esc_html( $reviews_subtitle ) . '</span>
										</div>
									</div>';
					} else {
						$output .= '<div class="brk-testimonials-dash-six__title-slider font__family-oxygen font__weight-light">' . esc_html( $reviews_title ) . '</div>';
					}

					$output .= '<div class="dash-six-slider swiper-container">
										<div class="swiper-wrapper">';

					foreach ( $posts as $post ) {
						$bg_image    = get_the_post_thumbnail_url( $post->ID, $image_size );
						$title       = BRS_Shortcodes_VCParams::get_content_title( $title_val, $post );
						$description = BRS_Shortcodes_VCParams::get_content_description( $description_val, $post );
						$post_type   = get_post_type( $post->ID );

						if ( $image_grayscale != '' ) {
							$grayscale_class = ' grayscale-' . $image_grayscale;
						} else {
							$grayscale_class = '';
						}

						$output .= '<div class="swiper-slide">
									  <div class="brk-testimonials-dash-six__item font__family-oxygen">
										<div class="brk-testimonials-dash-six__comment font__weight-light">' . esc_html( $description ) . '</div>
										<div class="brk-testimonials-dash-six__photo' . $grayscale_class . '" style="background-image: url(' . esc_url( $bg_image ) . ')"></div>
										<div class="brk-testimonials-dash-six__name font__weight-bold">' . esc_html( $title ) . ',</div>';
						if ( $post_type == Berserk_Testimonials::postType() ) {
							$positions = BRS_Shortcodes_VCParams::get_term_names( $post->ID, 'testimonial_position' );
							$position  = implode( ',', $positions );
							$output .= '<div class="brk-testimonials-dash-six__job"><i class="fal fa-minus"></i> ' . esc_html( $position ) . '</div>';

						}
						$output .= '</div>
									</div>';

					}

					$output .= '</div>
								</div>
								<div class="dash-six-arrow">
								  <div class="dash-six-arrow-prev"><i class="fa fa-angle-left"></i></div>
								  <div class="dash-six-arrow-next"><i class="fa fa-angle-right"></i></div>
								</div>
							  </div>';

					break;

				case "double":

					$bg_class = 'double-white';
					switch ( $bg_type ) {
						case "white":
							$bg_class = 'double-white';
							break;
						case "colored":
							$bg_class = 'double-dark';
							break;
					}

					$output = '<div class="brk-testimonials-double__slider ' . $bg_class . '" style="background-image: url(' . esc_url( $slider_bg_image ) . ')">
								<div class="brk-testimonials-double__type-reviews font__family-montserrat font__weight-bold">' . esc_html( $taxonomy ) . '</div>
									<div class="double-pagination"></div>
								  <div class="double-slider swiper-container">
									<div class="swiper-wrapper">';

					foreach ( $posts as $post ) {
						$bg_image    = get_the_post_thumbnail_url( $post->ID, $image_size );
						$title       = BRS_Shortcodes_VCParams::get_content_title( $title_val, $post );
						$description = BRS_Shortcodes_VCParams::get_content_description( $description_val, $post );
						$post_type   = get_post_type( $post->ID );

						$output .= '<div class="swiper-slide">
										<div class="brk-testimonials-double__item">
										  <div class="brk-testimonials-double__title font__family-montserrat letter-spacing-20">' . esc_html( $description ) . '</div>
										  <div class="brk-testimonials-double__contant">
											<div class="brk-testimonials-double__photo" style="background-image: url(' . esc_html( $bg_image ) . ')"></div>
											<div class="brk-testimonials-double__name">
											  ' . self::get_rating( $post->ID ) . '
											  <strong class="font__family-montserrat font__weight-bold">' . esc_html( $title ) . '</strong>';

						if ( $post_type == Berserk_Testimonials::postType() ) {
							$positions = BRS_Shortcodes_VCParams::get_term_names( $post->ID, 'testimonial_position' );
							$position  = implode( ',', $positions );
							$output .= '<span>' . $position . '</span>';

						}
						$output .= '</div>
										  </div>
										</div>
									  </div>';
					}

					$output .= '</div>
								  </div>
								</div>';


					break;

				case "layered_horizontal":

					$output = '<div class="brk-testimonials-layered-horizontal__container">
										<div class="overlay-horizontal"></div>
										<div class="layered-horizontal-slider swiper-container">
											<div class="swiper-wrapper">';
					foreach ( $posts as $post ) {
						$bg_image    = get_the_post_thumbnail_url( $post->ID, $image_size );
						$title       = BRS_Shortcodes_VCParams::get_content_title( $title_val, $post );
						$description = BRS_Shortcodes_VCParams::get_content_description( $description_val, $post );
						$post_type   = get_post_type( $post->ID );

						$output .= '<div class="swiper-slide">
										<div class="brk-testimonials-layered-horizontal__item text-center">
											<div class="brk-testimonials-layered-horizontal__photo lazyload" data-bg="' . esc_attr( $bg_image ) . '"></div>
											<div class="brk-testimonials-layered-horizontal__name font__family-montserrat font__weight-bold">' . esc_html( $title ) . '</div>';
						if ( $post_type == Berserk_Testimonials::postType() ) {
							$positions = BRS_Shortcodes_VCParams::get_term_names( $post->ID, 'testimonial_position' );
							$position  = implode( ',', $positions );
							$output .= '<div class="brk-testimonials-layered-horizontal__job font__family-open-sans letter-spacing-20">' . esc_html( $position ) . '</div>';

						}

						$output .= '<div class="brk-testimonials-layered-horizontal__comment font__family-open-sans">' . esc_html( $description ) . '</div>
										</div>
									  </div>';
					}

					$output .= '</div>
								</div>

									<div class="swiper-base-arrow-md button-prev"><i class="fa fa-long-arrow-left"></i></div>
									<div class="swiper-base-arrow-md button-next"><i class="fa fa-long-arrow-right"></i></div>
								</div>';

					break;

				case "layered_vertical":

					$output = '<div class="brk-testimonials-layered-vertical">
								<div class="brk-testimonials-layered-vertical__container">
								  <div class="overlay-vertical"></div>
								  <div class="layered-vertical-slider swiper-container">
									<div class="swiper-wrapper">';

					foreach ( $posts as $post ) {
						$bg_image    = get_the_post_thumbnail_url( $post->ID, $image_size );
						$title       = BRS_Shortcodes_VCParams::get_content_title( $title_val, $post );
						$description = BRS_Shortcodes_VCParams::get_content_description( $description_val, $post );
						$post_type   = get_post_type( $post->ID );

						$output .= '<div class="swiper-slide">
										<div class="brk-testimonials-layered-vertical__item layered-vertical-item">
										  <div class="brk-testimonials-layered-vertical__person">
											<div class="brk-testimonials-layered-vertical__person-info">
											  <div class="brk-testimonials-layered-vertical__photo" style="background-image: url(' . esc_url( $bg_image ) . ')"></div>
											  <div class="brk-testimonials-layered-vertical__name font__family-montserrat font__weight-bold">' . esc_html( $title ) . '</div>';
						if ( $post_type == Berserk_Testimonials::postType() ) {
							$positions = BRS_Shortcodes_VCParams::get_term_names( $post->ID, 'testimonial_position' );
							$position  = implode( ',', $positions );
							$output .= '<div class="brk-testimonials-layered-vertical__job font__family-open-sans letter-spacing-20">' . esc_html( $position ) . '</div>';
						}
						$output .= '</div>' .
								   self::get_rating( $post->ID ) . '
										  </div>
										  <div class="brk-testimonials-layered-vertical__comment font__family-open-sans">' . esc_html( $description ) . '</div>
										</div>
									  </div>';
					}

					$output .= '</div>
								  </div>
								  <div class="swiper-base-arrow-vertical button-prev"><i class="fas fa-arrow-down brk-white-font-color"></i></div>
								  <div class="swiper-base-arrow-vertical button-next"><i class="fas fa-arrow-up brk-white-font-color"></i></div>
								</div>

							  </div>';

					break;

				case "circle":

					$output = '<div class="brk-testimonials-circle">
								<div class="circle-slider swiper-container">
								  <div class="brk-testimonials-circle__parallax-bg" data-swiper-parallax="-5%"></div>
								  <div class="swiper-wrapper">';

					foreach ( $posts as $post ) {
						$bg_image    = get_the_post_thumbnail_url( $post->ID, $image_size );
						$title       = BRS_Shortcodes_VCParams::get_content_title( $title_val, $post );
						$description = BRS_Shortcodes_VCParams::get_content_description( $description_val, $post );
						$post_type   = get_post_type( $post->ID );

						$output .= '<div class="swiper-slide">
									  <div class="brk-testimonials-circle__item" data-img="' . $bg_image . '">
										<i class="fa fa-quote-right" data-swiper-parallax="-20%"></i>
										<div class="brk-testimonials-circle__comment font__family-open-sans font__weight-light font__style-italic" data-swiper-parallax="-60%">" ' . esc_html( $description ) . ' "</div>
										<div class="brk-testimonials-circle__name" data-swiper-parallax="-100%"><span class="font__family-montserrat font__weight-medium">' . esc_html( $title ) . ',</span>';
						if ( $post_type == Berserk_Testimonials::postType() ) {
							$positions = BRS_Shortcodes_VCParams::get_term_names( $post->ID, 'testimonial_position' );
							$position  = implode( ',', $positions );
							$output .= ' <em class="font__family-playfair font__style-italic">' . esc_html( $position ) . '</em>';

						}
						$output .= '</div>
									  </div>
									</div>';
					}

					$output .= '</div>
								</div>

								<div class="circle-pagination"></div>
							  </div>';

					break;
			}

			return $output;
		}

		public static function get_rating( $post_id ) {
			$value  = get_post_meta( $post_id, 'testimonials-rating', true );
			$output = '<div class="brk-rating">
						  <div class="brk-rating__layer">
								<i class="fal fa-star brk-dark-font-color"></i>
								<i class="fal fa-star brk-dark-font-color"></i>
								<i class="fal fa-star brk-dark-font-color"></i>
								<i class="fal fa-star brk-dark-font-color"></i>
								<i class="fal fa-star brk-dark-font-color"></i>
						  </div>
						  <div class="brk-rating__imposition" style="width: ' . ( $value * 20 ) . '%">
							<div class="visible">
								<i class="fas fa-star brk-base-font-color"></i>
								<i class="fas fa-star brk-base-font-color"></i>
								<i class="fas fa-star brk-base-font-color"></i>
								<i class="fas fa-star brk-base-font-color"></i>
								<i class="fas fa-star brk-base-font-color"></i>
							</div>
						  </div>
						</div>';

			return $output;
		}

	}

	// create shortcode
	BRS_Testimonials::get_instance();

}
