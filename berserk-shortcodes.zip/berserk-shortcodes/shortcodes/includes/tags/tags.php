<?php
/**
 * Header shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


if ( ! class_exists( 'BRS_Tags_Shortcode', false ) ) {

//  require_once BERSERK_SHORTCODES_PATH . 'shortcodes/includes/shortcodes-ext.php';

	class BRS_Tags_Shortcode extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();

		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Tags_Shortcode();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_tags', array( $this, 'shortcode_tags' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {

			if ( function_exists( "vc_map" ) ) {

				$params = array();

				$params[] = array(
					"heading"    => __( "Tags Type", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$params[] = array(
					'param_name' => 'type',
					'type'       => 'brs_radio',
					'value'      => array(
						'solid'       => 'solid',
						'light'       => 'light',
						'transparent' => 'transparent',
						'gradient'    => 'gradient',
						'bubble'      => 'bubble',
						'round'       => 'round',
						'image'       => 'image',
						'rectangle'   => 'rectangle',
						'angle'       => 'angle',
					),
					'images'     => array(
						'solid'       => 'tags/001.png',
						'light'       => 'tags/002.png',
						'transparent' => 'tags/002.png',
						'gradient'    => 'tags/003.png',
						'bubble'      => 'tags/004.png',
						'round'       => 'tags/005.png',
						'image'       => 'tags/006.png',
						'rectangle'   => 'tags/007.png',
						'angle'       => 'tags/008.png',
					),
					'images_dim' => array(
						'w' => '310',
						'h' => '150'
					)
				);

				$params[] = array(
					"heading"    => __( "Main Settings", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$tag_taxonomies = array('');
				$taxonomies     = get_taxonomies();
				if ( is_array( $taxonomies ) && ! empty( $taxonomies ) ) {
					foreach ( $taxonomies as $taxonomy ) {
						$tax = get_taxonomy( $taxonomy );
						if ( ( is_object( $tax ) && ( ! $tax->show_tagcloud || empty( $tax->labels->name ) ) ) || ! is_object( $tax ) ) {
							continue;
						}
						$tag_taxonomies[ $tax->labels->name ] = esc_attr( $taxonomy );
					}
				}

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Category', 'js_composer' ),
					'param_name'       => 'taxonomy',
					'value'            => $tag_taxonomies,
					'edit_field_class' => 'vc_col-sm-4 vc_column',
				);

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Tags", 'berserk' ),
					"base"     => "brs_tags",
					"icon"     => "brs_vc_ico_menu",
					"class"    => "brs_vc_sc_menu",
					"category" => __( 'Berserk', 'berserk' ),
					"params"   => $params
				) );
			}
		}

		public function shortcode_tags( $atts, $content = null ) {

			$components = array();

			$atts = shortcode_atts( array(
				'type'     => 'solid',
				'taxonomy' => '',
			), $atts );

			$output = theme_brk__tags( $atts );

			return $output;
		}


	}

	// create shortcode
	BRS_Tags_Shortcode::get_instance();

	function theme_brk__tags( $vars ) {

		$components = array( 'component__tags' );
		if ( $vars['type'] == 'bubble' ) {
			$components[] = 'component__tags_js';
		}
		brs_add_libraries( $components );

		$type = $vars['type'];

		$ul_class = array(
			'solid'       => 'brk-tags_solid font__family-montserrat',
			'light'       => 'brk-tags_light font__family-open-sans',
			'transparent' => 'brk-tags_transparent font__family-open-sans',
			'gradient'    => 'brk-tags_gradient',
			'bubble'      => 'brk-tags_bubble grid font__family-montserrat',
			'round'       => 'brk-tags_round',
			'image'       => 'brk-tags_image',
			'rectangle'   => 'brk-tags_rectangle font__family-montserrat',
			'angle'       => 'brk-tags_angle font__family-montserrat',
		);

		$output = '';

		$args = array(
			'taxonomy' => array( $vars['taxonomy'] ),
			'echo'     => false,
			'format'   => 'array'
		);
		//$tags = wp_tag_cloud( $args );


		$args = array('taxonomy' => $vars['taxonomy']);
		$tags = get_terms($args);

		$output = '<ul class = "brk-tags text-center ' . $ul_class[ $type ] . '">';

		foreach ( $tags as $tag ) {
			$tag_link = get_tag_link($tag->term_id);
			$output .= '<li><a href="'.$tag_link.'" title="'.$tag->name .'Tag" class="'. $tag->slug.'">' . $tag->name . '</a></li>';
		}

		$output .= '</ul>';

		return $output;
	}

}
