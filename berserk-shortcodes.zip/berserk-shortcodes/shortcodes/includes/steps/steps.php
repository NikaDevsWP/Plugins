<?php
/**
 * Sequence shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'BRS_Steps', false ) ) {

	class BRS_Steps extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();


		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_Steps();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_steps', array( $this, 'shortcode_steps' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Steps", 'berserk' ),
					"base"     => "brs_steps",
					"icon"     => "brs_vc_ico_steps",
					"class"    => "brs_vc_sc_steps",
					"category" => __( 'Berserk', 'berserk' ),
					"params"   => array(
						array(
							'heading'    => __( 'Steps Type', 'berserk' ),
							'param_name' => 'steps_type',
							'type'       => 'brs_radio',
							'value'      => array(
								"Gradient" => "gradient",
								"History"  => "history",
								"Checkers" => "checkers",
								"Squared"  => "squared",
								"Light"    => "light",
							),
							'images'     => array(
								"gradient" => 'steps_gradient.png',
								"history"  => 'history.png',
								"checkers" => 'checkers.png',
								"arrow"    => 'arrow.png',
								"squared"  => 'squared.png',
								"light"    => 'light.png'

							),
							'images_dim' => array(
								'w' => '185',
								'h' => '160'
							)
						),

						array(
							"param_name"       => "white_text_color",
							"type"             => "checkbox",
							"value"            => array(
								"White text color" => "y",
							),
							'edit_field_class' => 'vc_col-sm-6 vc_column',
						),

						array(
							'type'       => 'param_group',
							'heading'    => __( 'Values', 'js_composer' ),
							'param_name' => 'values',
							'value'      => urlencode( json_encode( array(
								array(
									'label'       => '',
									'active'      => 'n',
									'icon_bg'     => '',
									'title'       => '',
									'description' => '',
								),

							) ) ),
							'params'     => array(

								array(
									'type'             => 'textfield',
									'heading'          => __( 'Label', 'js_composer' ),
									'param_name'       => 'label',
									'edit_field_class' => 'vc_col-sm-6 vc_column',
									'admin_label'      => true,
								),
								array(
									'type'             => 'textfield',
									'heading'          => __( 'Title', 'js_composer' ),
									'param_name'       => 'title',
									'edit_field_class' => 'vc_col-sm-6 vc_column',
								),
								array(
									'type'             => 'textfield',
									'heading'          => __( 'Description', 'js_composer' ),
									'param_name'       => 'description',
									'edit_field_class' => 'vc_col-sm-6 vc_column',
								),
								array(
									"param_name"       => "active",
									"type"             => "checkbox",
									"value"            => array(
										"Active" => "y",
									),
									'edit_field_class' => 'vc_col-sm-6 vc_column',
								),

								array(
									'type'             => 'dropdown',
									'heading'          => __( 'Icon library', 'berserk' ),
									'value'            => array(
										__( 'Font Awesome', 'berserk' ) => 'fontawesome',
										__( 'Open Iconic', 'berserk' )  => 'openiconic',
										__( 'Typicons', 'berserk' )     => 'typicons',
										__( 'Entypo', 'berserk' )       => 'entypo',
										__( 'Linecons', 'berserk' )     => 'linecons',
										__( 'Mono Social', 'berserk' )  => 'monosocial',
										__( 'Livicon', 'berserk' )      => 'livicon',
									),
									'admin_label'      => true,
									'param_name'       => 'btn_icon_type',
									'edit_field_class' => 'vc_col-sm-6 vc_column',
								),
								array(
									'type'       => 'iconpicker',
									'heading'    => __( 'Icon', 'berserk' ),
									'param_name' => 'icon_fontawesome',
									'value'      => 'fa fa-adjust', // default value to backend editor admin_label
									'settings'   => array(
										'emptyIcon'    => false,
										'iconsPerPage' => 4000,
									),
									'dependency' => array(
										'element' => 'btn_icon_type',
										'value'   => 'fontawesome',
									),
								),
								array(
									'type'       => 'iconpicker',
									'heading'    => __( 'Icon', 'berserk' ),
									'param_name' => 'icon_openiconic',
									'value'      => 'vc-oi vc-oi-dial', // default value to backend editor admin_label
									'settings'   => array(
										'emptyIcon'    => false, // default true, display an "EMPTY" icon?
										'type'         => 'openiconic',
										'iconsPerPage' => 4000, // default 100, how many icons per/page to display
									),
									'dependency' => array(
										'element' => 'btn_icon_type',
										'value'   => 'openiconic',
									),
								),
								array(
									'type'       => 'iconpicker',
									'heading'    => __( 'Icon', 'berserk' ),
									'param_name' => 'icon_typicons',
									'value'      => 'typcn typcn-adjust-brightness', // default value to backend editor admin_label
									'settings'   => array(
										'emptyIcon'    => false, // default true, display an "EMPTY" icon?
										'type'         => 'typicons',
										'iconsPerPage' => 4000, // default 100, how many icons per/page to display
									),
									'dependency' => array(
										'element' => 'btn_icon_type',
										'value'   => 'typicons',
									),
								),
								array(
									'type'       => 'iconpicker',
									'heading'    => __( 'Icon', 'berserk' ),
									'param_name' => 'icon_entypo',
									'value'      => 'entypo-icon entypo-icon-note', // default value to backend editor admin_label
									'settings'   => array(
										'emptyIcon'    => false, // default true, display an "EMPTY" icon?
										'type'         => 'entypo',
										'iconsPerPage' => 4000, // default 100, how many icons per/page to display
									),
									'dependency' => array(
										'element' => 'btn_icon_type',
										'value'   => 'entypo',
									),
								),
								array(
									'type'       => 'iconpicker',
									'heading'    => __( 'Icon', 'berserk' ),
									'param_name' => 'icon_linecons',
									'value'      => 'vc_li vc_li-heart', // default value to backend editor admin_label
									'settings'   => array(
										'emptyIcon'    => false, // default true, display an "EMPTY" icon?
										'type'         => 'linecons',
										'iconsPerPage' => 4000, // default 100, how many icons per/page to display
									),
									'dependency' => array(
										'element' => 'btn_icon_type',
										'value'   => 'linecons',
									),
								),
								array(
									'type'       => 'iconpicker',
									'heading'    => __( 'Icon', 'berserk' ),
									'param_name' => 'icon_monosocial',
									'value'      => 'vc-mono vc-mono-fivehundredpx', // default value to backend editor admin_label
									'settings'   => array(
										'emptyIcon'    => false, // default true, display an "EMPTY" icon?
										'type'         => 'monosocial',
										'iconsPerPage' => 4000, // default 100, how many icons per/page to display
									),
									'dependency' => array(
										'element' => 'btn_icon_type',
										'value'   => 'monosocial',
									),
								),


								array(
									"heading"    => __( "Add livicon", 'berserk' ),
									"param_name" => "brs_btn_icon",
									"type"       => "brs_btn_icon",
									'dependency' => array(
										'element' => 'btn_icon_type',
										'value'   => 'livicon',
									),
								),

								array(
									"heading"          => __( "Icon Background Color", 'berserk' ),
									'type'             => 'colorpicker',
									'param_name'       => 'icon_bg',
									'value'            => '#1059E0',
									'edit_field_class' => 'vc_col-sm-6 vc_column',
								),

							),
						),

						// Label Position
						array(
							'type'             => 'dropdown',
							'heading'          => esc_html__( 'Labels Position', 'berserk' ),
							'param_name'       => 'labels_position',
							'edit_field_class' => 'vc_col-sm-6 vc_column',
							'value'            => array(
								esc_html__( 'Top', 'berserk' )    => 'top',
								esc_html__( 'Bottom', 'berserk' ) => 'bottom',
							),
						),

					)
				) );

			}
		}

		public function shortcode_steps( $atts, $content = null ) {

      brs_add_libraries('component__steps');

			extract( shortcode_atts( array(
				'steps_type'       => 'gradient',
				'values'           => '',
				'white_text_color' => '',
				'labels_position'   => 'top',
			), $atts ) );

			// store atts
			$atts_backup = self::$atts;

			$values = vc_param_group_parse_atts( $values );

			switch ( $steps_type ) {
				case "gradient":

					$unique_id = uniqid();

					$label_class = ' font__weight-bold';
					if( $white_text_color ){
						$label_class = ' font__weight-ultralight';
					}

					$before_output = '<div class="tabs-wrapper maxw-970">';

					$output_nav = '<div class="steps__wrapper-main steps__wrapper-gradient">
											<div class="steps__progress"></div>
											<ul class="steps__wrapper tabs" data-tabgroup="tab-group-' . $unique_id . '">';
					$i         = 1;

					$complete = 'class="complete"';
					foreach ( $values as $value ) {

						$active = '';
						if ( isset( $value['active'] ) && $value['active'] == 'y' ) {
							$active = 'class="active"';
						}
						$output_nav .= '<li ' . $complete . '>
										<a href="#tab-' . $unique_id . '_' . $i . '" ' . $active . '>
											<p class="font__family-montserrat font__size-15 letter-spacing-20 steps__title' . esc_attr( $label_class ) . '">' . $value['label'] . '</p>
											<span class="steps__dot"><span class="before"></span><span class="after"></span></span>
										</a>
							</li>';
						$i ++;
						if ( isset( $value['active'] ) && $value['active'] == 'y' ) {
							$complete = '';
						}
					}

					$tab_group_class = 'tabgroup text-lg-left text-center';
					if ( $labels_position == 'top' ) {
						$tab_group_class .= ' mt-60';
					} else {
						$tab_group_class .= ' mt-30 mb-100';
					}

					$output_nav .= '</ul>';
					$output_nav .= '</div>';
					
					$output_content = '<div id="tab-group-' . $unique_id . '" class="' . esc_attr__( $tab_group_class ) .'">';
					$j = 1;
					foreach ( $values as $value ) {
						$output_content .= '<div id="tab-' . $unique_id . '_' . $j . '">
											<h4 class="font__family-montserrat font__size-21 letter-spacing-40' . esc_attr( $label_class ) . '">' . $value['title'] . '</h4>
												<p class="font__family-open-sans text-gray-light font__size-15 mt-20">' . $value['description'] . '</p>
											</div>';
						$j ++;
					}

					$output_content .= '</div>';

					$after_output = '</div>';

					if ( $labels_position == 'top' ) {
						$output = $before_output . $output_nav . $output_content . $after_output;
					} else {
						$output = $before_output . $output_content . $output_nav . $after_output;
					}

					break;

				case "history":

					$unique_id = uniqid();

					$output = '<div class="tabs-wrapper maxw-970">
						          <div class="steps__wrapper-main steps__wrapper-history">
						            <div class="steps__progress"></div>
						            <ul class="steps__wrapper tabs" data-tabgroup="tab-group-' . $unique_id . '">';
					$i      = 1;

					$complete = 'class="complete"';
					foreach ( $values as $value ) {

						$active = '';
						if ( isset( $value['active'] ) && $value['active'] == 'y' ) {
							$active = 'class="active"';
						}
						$output .= '<li ' . $complete . '>
										<a href="#tab-' . $unique_id . '_' . $i . '" ' . $active . '>
						                  <p class="font__family-open-sans font__weight-bold font__size-14 steps__title">' . $value['label'] . ' <span class="after"></span></p>
                                            <span class="steps__dot"></span>
						              	</a>
					                </li>';
						$i ++;
						if ( isset( $value['active'] ) && $value['active'] == 'y' ) {
							$complete = '';
						}
					}

					$output .= '</ul>
						          </div>
						          <div id="tab-group-' . $unique_id . '" class="tabgroup text-left mt-60">';
					$j = 1;
					foreach ( $values as $value ) {
						$output .= '<div id="tab-' . $unique_id . '_' . $j . '">
										<h4 class="font__family-montserrat font__weight-bold font__size-21">' . $value['title'] . '</h4>
						                <p class="font__family-open-sans text-gray-light font__size-15 mt-20">' . $value['description'] . '</p>
						            </div>';
						$j ++;
					}

					$output .= '</div>
						        </div>';
					break;

				case "checkers":

					$unique_id = uniqid();

					$output = '<div class="tabs-wrapper maxw-970">
						          <div class="steps__wrapper-main steps__wrapper-checkers">
						            <div class="steps__progress"></div>
						            <ul class="steps__wrapper tabs" data-tabgroup="tab-group-' . $unique_id . '">';
					$i      = 1;

					$complete = 'class="complete"';
					foreach ( $values as $value ) {

						$active = '';
						if ( isset( $value['active'] ) && $value['active'] == 'y' ) {
							$active = 'class="active"';
						}
						$output .= '<li ' . $complete . '>
										<a href="#tab-' . $unique_id . '_' . $i . '" ' . $active . '>
                                           <span class="font__family-montserrat font__weight-bold font__size-15 steps__dot" style="background: #2775FF;"><span class="before"></span><span class="after"></span>' . $i . '</span>
                                            <p class="font__family-montserrat font__size-15 steps__title">' . $value['label'] . '</p>
						              	</a>
					                </li>';
						$i ++;
						if ( isset( $value['active'] ) && $value['active'] == 'y' ) {
							$complete = '';
						}
					}

					$output .= '</ul>
						          </div>
						          <div id="tab-group-' . $unique_id . '" class="tabgroup text-left">';
					$j = 1;
					foreach ( $values as $value ) {
						$output .= ' <div id="tab-' . $unique_id . '_' . $j . '"></div>';
						$j ++;
					}

					$output .= '</div>
						        </div>';
					break;

				case
				"squared":

					$unique_id = uniqid();

					$output = '<div class="tabs-wrapper maxw-970 pt-160">
						          <div class="steps__wrapper-main steps__wrapper-squared">
						            <div class="steps__progress"></div>
						            <ul class="steps__wrapper tabs" data-tabgroup="tab-group-' . $unique_id . '">';
					$i      = 1;

					$complete = 'class="complete"';
					foreach ( $values as $value ) {

						$active = '';
						if ( isset( $value['active'] ) && $value['active'] == 'y' ) {
							$active = 'class="active"';
						}

						$icon_style = '';

						if ( isset( $value['icon_bg'] ) ) {
							$icon_style = 'background: ' . $value['icon_bg'] . '; border-color: ' . $value['icon_bg'] . ';';
						}

						$icon_class                     = array();
						$icon_class['type']             = $value['btn_icon_type'];
						$icon_class['icon_livicon']     = '';
						$icon_class['icon_fontawesome'] = $value['icon_fontawesome'];
						$icon_class['icon_openiconic']  = $value['icon_openiconic'];
						$icon_class['icon_typicons']    = $value['icon_typicons'];
						$icon_class['icon_entypo']      = $value['icon_entypo'];
						$icon_class['icon_linecons']    = $value['icon_linecons'];
						$icon_class['icon_monosocial']  = $value['icon_monosocial'];
						$icon_class                     = $this->get_icon_class( $icon_class );
						$icon_html                      = ' <span style="' . $icon_style . '" class="steps__icon ' . $icon_class . '"><span class="after" style="border-color: ' . $value['icon_bg'] . ' transparent transparent transparent;"></span></span>';

						if ( isset( $value['brs_btn_icon'] ) ) {
							$svg_icon  = do_shortcode( $value['brs_btn_icon'] );
							$icon_html = $svg_icon;
						}

						$output .= '<li ' . $complete . '>
										<a href="#tab-' . $unique_id . '_' . $i . '" ' . $active . '>
											' . $icon_html . '
											</span>
                      <span class="steps__dot"><span class="after"></span></span>
                      <p class="font__family-montserrat font__weight-light font__size-15 letter-spacing-20 steps__title">' . $value['label'] . '</p>
		              	</a>
	                </li>';
						$i ++;
						if ( isset( $value['active'] ) && $value['active'] == 'y' ) {
							$complete = '';
						}
					}

					$output .= '</ul>
						          </div>
						          <div id="tab-group-' . $unique_id . '" class="tabgroup text-left mt-100">';
					$j = 1;
					foreach ( $values as $value ) {
						$output .= '<div id="tab-' . $unique_id . '_' . $j . '">
						                <h4 class="font__family-montserrat font__weight-light font__size-21 letter-spacing-40 text-uppercase">' . $value['title'] . '</h4>
                                        <p class="font__family-open-sans text-gray font__size-15 mt-20">' . $value['description'] . '</p>
						            </div>';
						$j ++;
					}

					$output .= '</div>
						        </div>';
					break;

				case "light":

					$unique_id = uniqid();

					$output = '<div class="tabs-wrapper maxw-970">
						          <div class="steps__wrapper-main steps__wrapper-light">
						            <div class="steps__progress"></div>
						            <ul class="steps__wrapper tabs" data-tabgroup="tab-group-' . $unique_id . '">';
					$i      = 1;

					$complete = 'class="complete"';
					foreach ( $values as $value ) {

						$icon_class                     = array();
						$icon_class['type']             = $value['btn_icon_type'];
						$icon_class['icon_livicon']     = '';
						$icon_class['icon_fontawesome'] = $value['icon_fontawesome'];
						$icon_class['icon_openiconic']  = $value['icon_openiconic'];
						$icon_class['icon_typicons']    = $value['icon_typicons'];
						$icon_class['icon_entypo']      = $value['icon_entypo'];
						$icon_class['icon_linecons']    = $value['icon_linecons'];
						$icon_class['icon_monosocial']  = $value['icon_monosocial'];
						$icon_class                     = $this->get_icon_class( $icon_class );
						$icon_html                      = ' <span class="icon ' . $icon_class . '"></span> ';

						if ( isset( $value['brs_btn_icon'] ) ) {
							$svg_icon  = do_shortcode( $value['brs_btn_icon'] );
							$icon_html = $svg_icon;
						}

						$active = '';
						if ( isset( $value['active'] ) && $value['active'] == 'y' ) {
							$active = 'class="active"';
						}
						$output .= '<li ' . $complete . '>
										<a href="#tab-' . $unique_id . '_' . $i . '" ' . $active . '>
											 <p class="font__family-montserrat font__size-15 steps__title brk-base-font-color-i">
											     ' . $icon_html . $value['label'] . ' <span class="after"></span>
											 </p>
						              	</a>
					                </li>';
						$i ++;
						if ( isset( $value['active'] ) && $value['active'] == 'y' ) {
							$complete = '';
						}
					}

					$output .= '</ul>
						          </div>
						          <div id="tab-group-' . $unique_id . '" class="tabgroup text-left mt-50">';
					$j = 1;

					$text_color = (isset($white_text_color) && $white_text_color=='y') ? 'brk-white-font-color' : '';

					foreach ( $values as $value ) {
						$output .= '<div id="tab-' . $unique_id . '_' . $j . '">
                                        <h4 class="font__family-montserrat font__weight-bold font__size-21 '.$text_color.'">' . $value['title'] . '</h4>
                                        <p class="font__family-open-sans text-gray font__size-15 mt-20 '.$text_color.'">' . $value['description'] . '</p>
						            </div>';
						$j ++;
					}

					$output .= '</div>
						        </div>';

					break;
			}

			// restore atts
			self::$atts = $atts_backup;

			return $output;
		}

		protected function get_icon_class( $atts ) {
			$icon_class = '';

			$icon_class = $atts[ 'icon_' . $atts['type'] ];

			if ( empty( $icon_class ) ) {
				$icon_class = 'fa fa-trophy';
			}

			return $icon_class;
		}


	}

	// create shortcode
	BRS_Steps::get_instance();

}
