<?php
/**
 * Team shortcode.
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


if ( ! class_exists( 'BRS_PricingTable', false ) ) {

	require_once BERSERK_SHORTCODES_PATH . 'shortcodes/includes/shortcodes-ext.php';

	class BRS_PricingTable extends BRS_Shortcode {

		static protected $instance;
		static protected $atts = array();

		public static function get_instance() {
			if ( ! self::$instance ) {
				self::$instance = new BRS_PricingTable();
			}

			return self::$instance;
		}

		protected function __construct() {
			add_shortcode( 'brs_pricing_table', array( $this, 'shortcode_pricing_table' ) );
			add_action( 'init', array( $this, 'admin_init' ) );
		}

		public function admin_init() {
			if ( function_exists( "vc_map" ) ) {

				$params = array();

				$params[] = array(
					"heading"    => __( "Pricing Table Type", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$params[] = array(
					//'heading'    => __( 'Pricing Table', 'berserk' ),
					'param_name' => 'type',
					'type'       => 'brs_radio',
					'value'      => array(
						"Colored"    => "colored",
						"Doubled"    => "doubled",
						"Horizontal" => "horizonal",
						"Rounded"    => "rounded",
						"Strict"     => "strict",
						"Shop"       => "shop",
						"Plan"       => "plan",
						"Light"      => "light",
					),
					'images'     => array(
						"colored"   => 'pricing_tables/001.jpg',
						"doubled"   => 'pricing_tables/002.jpg',
						"horizonal" => 'pricing_tables/003.jpg',
						"rounded"   => 'pricing_tables/004.jpg',
						"strict"    => 'pricing_tables/005.jpg',
						"shop"      => 'pricing_tables/006.jpg',
						"plan"      => 'pricing_tables/007.jpg',
						"light"     => 'pricing_tables/008.jpg',
					),
					'images_dim' => array(
						'w' => '310',
						'h' => '150'
					)
				);

				$params[] = array(
					"heading"    => __( "Main Settings", 'berserk' ),
					"param_name" => "brs_title",
					"type"       => "brs_title",
				);

				$params[] = array(
					"heading"    => __( "Add Product", 'berserk' ),
					"param_name" => "product",
					"type"       => "brs_add_product",
					'dependency' => array(
						'element' => 'type',
						'value'   => array( 'doubled', 'horizonal', 'rounded', 'strict', 'shop', 'plan', 'light' )
					),
				);

				$params[] = array(
					"heading"    => __( "Add Products", 'berserk' ),
					"param_name" => "products",
					"type"       => "brs_add_product_multiple",
					'dependency' => array(
						'element' => 'type',
						'value'   => 'colored',
					),
				);

				$icons                  = berserk_shortcodes_icons();
				$icons[0]['dependency'] = array(
					'element' => 'type',
					'value'   => array( 'doubled', 'rounded', 'shop' ),
				);

				$params = array_merge( $params, $icons );

				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Image size', 'berserk' ),
					'value'            => BRS_Shortcodes_VCParams::get_image_sizes_names(),
					'param_name'       => 'image_size',
					'std'              => 'image-frames',
					'edit_field_class' => 'vc_col-sm-6 vc_column'
				);

				$params[] = array(
					'type'             => 'textfield',
					'heading'          => esc_html__( 'Price Description', 'js_composer' ),
					'param_name'       => 'price_info',
					"value"            => '',
					'edit_field_class' => 'vc_col-sm-6 vc_column',
				);
				
				$params[] = array(
					'type'             => 'dropdown',
					'heading'          => __( 'Price Description Color', 'berserk' ),
					'value'            => BRS_Shortcodes_VCParams::get_text_colors(),
					'param_name'       => 'desc_text_color',
					'edit_field_class' => 'vc_col-sm-6 vc_column'
				);

				$params[] = array(
					'type'             => 'textfield',
					'heading'          => __( 'Buy now text', 'js_composer' ),
					'param_name'       => 'buy_now_text',
					"value"            => "Buy now",
					'edit_field_class' => 'vc_col-sm-6 vc_column',
				);

				vc_map( array(
					"weight"   => - 1,
					"name"     => __( "Pricing Table", 'berserk' ),
					"base"     => "brs_pricing_table",
					"icon"     => "brs_vc_ico_team",
					"class"    => "brs_vc_sc_team",
					"category" => __( 'Berserk', 'berserk' ),
					"params"   => $params
				) );
			}
		}

		public function shortcode_pricing_table( $atts, $content = null ) {

			$libraries = array( 'component__pricing_table' );

			extract( shortcode_atts( array(
				'type'            => 'colored',
				'image_size'      => 'image-frames',
				'products'        => '',
				'title_val'       => 'post_title',
				'position_val'    => 'post_position',
				'description_val' => 'post_content',
				'buy_now_text'    => 'buy now',
				'price_info'      => 'month',
				'product'         => '',
				'desc_text_color' => 'default',
			), $atts ) );

			// store atts
			$atts_backup = self::$atts;

			$output = '';

			$products = explode( ',', $products );
			
			$desc_class = '';
			if ( $desc_text_color != 'default' ) {
				$desc_class = ' ' .$desc_text_color;
			}

			switch ( $type ) {
				case 'colored':

					$libraries['slider__swiper'] = 'slider__swiper';

					$output = '<div class="colored-slider swiper-container">
					              <div class="swiper-wrapper">';

					foreach ( $products as $product ) {
						$post = wc_get_product( $product );

						if ( is_object( $post ) ) {
							$currency           = get_woocommerce_currency_symbol();
							$product_attributes = $post->get_attributes();
							$image_url          = wp_get_attachment_image_url( get_post_thumbnail_id( $product ), $image_size );

							$buy_now = apply_filters( 'woocommerce_loop_add_to_cart_link',
								sprintf( '<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="brk-pricing-colored__btn btn font__family-open-sans font__weight-bold add-cart ajax_add_to_cart %s product_type_%s"><i class="fa fa-shopping-basket"></i>%s</a>',
									esc_url( $post->add_to_cart_url() ),
									esc_attr( $post->get_id() ),
									esc_attr( $post->get_sku() ),
									$post->is_purchasable() ? 'add_to_cart_button' : '',
									esc_attr( $post->get_type() ),
									$buy_now_text
								),
								$post );

							$attributes = '';
							foreach ( $product_attributes as $key => $attribute ) {
								$value = implode( ',', $attribute['options'] );
								$attributes .= '<li>' . $value . '</li>';
							}

							$output .= '
					                <div class="swiper-slide">
					                  <div class="brk-pricing-colored">
					                    <div class="brk-pricing-colored__layer lazyload" data-bg="' . esc_attr( $image_url ) . '">
					                      <div class="brk-pricing-colored__overlay brk-base-bg-gradient-50deg-a"></div>
					                      <div class="brk-pricing-colored__content text-center">
					                        <div class="brk-pricing-colored__title font__family-open-sans font__weight-bold">' . $post->get_name() . '</div>
					                        <div class="brk-pricing-colored__price">
					                          <span class="font__family-montserrat font__weight-ultralight">' . $currency . $post->get_price() . '</span>
					                          <div class="period font__family-open-sans font__weight-bold' . esc_attr( $desc_class ) . '">' . esc_html( $price_info ) . '</div>
					                        </div>
					                        <div class="brk-pricing-colored__description font__family-open-sans">
					                          <ul>
					                            ' . $attributes . '
					                          </ul>
					                        </div>
					                        ' . $buy_now . '
					                      </div>
					                    </div>
					                  </div>
					                </div>';
						}

					}
					$output .= '
					                </div>
					              <div class="swiper-base-arrow button-prev"><i class="fa fa-long-arrow-left"></i></div>
					              <div class="swiper-base-arrow button-next"><i class="fa fa-long-arrow-right"></i></div>

					            </div>';

					break;
				case 'doubled':

					$post = wc_get_product( $product );
					if ( ! $post ) {
						return;
					}
					$currency           = get_woocommerce_currency_symbol();
					$old_price          = $post->get_sale_price() !== '' ? $currency . $post->get_regular_price() : '';
					$product_attributes = $post->get_attributes();
					$image_url          = wp_get_attachment_image_src( get_post_thumbnail_id( $product ), $image_size );
					$icon               = berserk_shortcodes_icons_process( $atts );

					$buy_now = apply_filters( 'woocommerce_loop_add_to_cart_link',
						sprintf( '<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="brk-pricing-doubled__link font__family-open-sans font__size-16 line__height-24 add-cart ajax_add_to_cart %s product_type_%s">%s<i class="far fa-angle-right"></i></a>',
							esc_url( $post->add_to_cart_url() ),
							esc_attr( $post->get_id() ),
							esc_attr( $post->get_sku() ),
							$post->is_purchasable() ? 'add_to_cart_button' : '',
							esc_attr( $post->get_type() ),
							$buy_now_text
						),
						$post );

					$attributes = '';
					foreach ( $product_attributes as $key => $attribute ) {
						$value = implode( ',', $attribute['options'] );
						$attributes .= '<li><i class="far fa-check"></i>' . $value . '</li>';
					}

					$output .= '<article class="brk-pricing-doubled">
					              <div class="brk-pricing-doubled__front text-center">
					                ' . $icon . '
					                <p class="pd-title font__family-montserrat font__weight-ultralight font__size-32 line__height-34 letter-spacing-20">' . $post->get_name() . '</p>
					                <div class="pd-price brk-base-box-shadow brk-base-bg-gradient-left-blue">
					                  <span class="font__family-playfair font__style-italic font__size-18' . esc_attr( $desc_class ) . '">' . esc_html( $price_info ) . '</span>
					                  <strong class="font__family-montserrat font__size-36">' . $currency . $post->get_price() . '</strong>
					                </div>
					                <div class="pb-list font__family-open-sans">
					                  <ul>
					                    ' . $attributes . '
					                  </ul>
					                </div>
					              </div>
					              <div class="brk-pricing-doubled__back text-center" style="background-image: url(' . $image_url[0] . ')">
					                <div class="pd-overlay brk-base-bg-gradient-50deg-a"></div>
					                <div class="pb-content">
					                  ' . $icon . '
					                  <p class="pd-title font__family-montserrat font__weight-ultralight font__size-32 line__height-34 letter-spacing-20">' . $post->get_name() . '</p>
					                  <div class="pd-price">
					                    <span class="font__family-playfair font__style-italic font__size-18' . esc_attr( $desc_class ) . '">' . esc_html( $price_info ) . '</span>
					                    <strong class="font__family-montserrat font__size-36">' . $currency . $post->get_price() . '</strong>
					                  </div>
					                </div>
					                ' . $buy_now . '
					              </div>
					            </article>';
					break;

				case 'horizonal':

					$post = wc_get_product( $product );
					if ( ! $post ) {
						return;
					}
					$currency           = get_woocommerce_currency_symbol();
					$product_attributes = $post->get_attributes();
					$image_url          = wp_get_attachment_image_src( get_post_thumbnail_id( $product ), $image_size );

					$buy_now = apply_filters( 'woocommerce_loop_add_to_cart_link',
						sprintf( '<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="h-button btn border-radius-5 font__family-montserrat font__weight-bold add-cart ajax_add_to_cart %s product_type_%s"><span class="before brk-bg-grad border-radius-5"></span><strong>%s</strong><i class="fas fa-angle-right"></i></a>',
							esc_url( $post->add_to_cart_url() ),
							esc_attr( $post->get_id() ),
							esc_attr( $post->get_sku() ),
							$post->is_purchasable() ? 'add_to_cart_button' : '',
							esc_attr( $post->get_type() ),
							$buy_now_text
						),
						$post );

					$attributes = '';
					foreach ( $product_attributes as $key => $attribute ) {
						$value = implode( ',', $attribute['options'] );
						$attributes .= $attribute['visible'] ? '<span class="options-active"><i class="fal fa-check">' : '<span class="options-deactive"><i class="fal fa-minus">';
						$attributes .= '</i>' . $value . '</span>';
					}

					$output .= '<article class="brk-pricing-horizontal brk-base-box-shadow">
					              <div class="brk-pricing-horizontal__container">
					              	<h2 class="sr-only">' . __( 'Pricing package', 'berserk' ) . '</h2>
					                <div class="brk-pricing-horizontal__viewed">
					                    <h3 class="font__family-montserrat font__weight-bold font__size-12">' . $post->get_name() . '</h3>
				                    </div>
					                <div class="brk-pricing-horizontal__info">
					                  <div class="brk-pricing-horizontal__img-icon"><img class="img-icon lazyload" src="' . $image_url[0] . '" alt=""></div>
					                  <div class="brk-pricing-horizontal__price">
					                    <span class="sign">' . $currency . '</span>
					                    <span class="font__family-montserrat font__weight-bold font__size-40 line__height-50">' . $post->get_price() . '</span>
					                  </div>
					                  <div class="brk-pricing-horizontal__list-options font__family-roboto font__weight-light font__size-15 line__height-28">
					                    ' . $attributes . '
					                  </div>
					                </div>
					                ' . $buy_now . '
					              </div>
					            </article>';

					break;
				case 'rounded':

					$post = wc_get_product( $product );
					if ( ! $post ) {
						return;
					}
					$currency           = get_woocommerce_currency_symbol();
					$old_price          = $post->get_sale_price() !== '' ? $currency . $post->get_regular_price() : '';
					$product_attributes = $post->get_attributes();
					$icon               = berserk_shortcodes_icons_process( $atts );

					$buy_now = apply_filters( 'woocommerce_loop_add_to_cart_link',
						sprintf( '
            <a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="btn btn-md-2 btn-icon border-radius-25 font__family-open-sans font__weight-bold btn-inside-out add-cart ajax_add_to_cart %s product_type_%s">
              <i class="fa fa-shopping-cart icon-inside" aria-hidden="true"></i>
              <span class="before">%s</span>
              <span class="text">%s</span>
              <span class="after">%s</span>
            </a>',
							esc_url( $post->add_to_cart_url() ),
							esc_attr( $post->get_id() ),
							esc_attr( $post->get_sku() ),
							$post->is_purchasable() ? 'add_to_cart_button' : '',
							esc_attr( $post->get_type() ),
							$buy_now_text,
							$buy_now_text,
							$buy_now_text
						),
						$post );

					$attributes = '';
					foreach ( $product_attributes as $key => $attribute ) {
						$value = implode( ',', $attribute['options'] );
						$attributes .= '<li>' . $value . '</li>';
					}

					$output = '<article class="brk-pricing-rounded text-center">
					              <div class="brk-pricing-rounded__icon">
					                <span class="before"></span>
					                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 121.1 121.1"><path d="M121.1,60.55,117.72,64l2.94,3.84-3.77,3L119.35,75l-4.11,2.55L117.18,82l-4.39,2,1.38,4.63-4.6,1.49.81,4.76-4.74.92.23,4.83-4.82.35-.35,4.82-4.83-.23-.92,4.74-4.76-.81-1.49,4.6-4.63-1.38-2,4.38-4.43-1.93L75,119.35l-4.16-2.45-3,3.76L64,117.72l-3.46,3.38-3.46-3.37-3.84,2.94-3-3.76-4.16,2.45-2.55-4.11-4.43,1.93-2-4.38-4.63,1.38-1.49-4.6-4.77.81-.92-4.74-4.83.23L20,101l-4.82-.35.23-4.83-4.74-.92.81-4.76-4.6-1.49,1.38-4.63L3.92,82l1.93-4.43L1.75,75,4.2,70.88l-3.77-3L3.38,64,0,60.55l3.38-3.46L.44,53.25l3.77-3L1.75,46.06,5.85,43.5,3.92,39.07l4.39-2L6.93,32.4l4.6-1.49-.81-4.76,4.74-.93-.23-4.83L20,20l.35-4.82,4.83.23.92-4.74,4.76.81,1.49-4.6L37,8.3l2-4.38L43.5,5.85l2.55-4.11L50.22,4.2l3-3.77,3.84,2.94L60.55,0,64,3.38,67.85.44l3,3.77L75,1.74,77.6,5.85,82,3.92l2,4.39L88.7,6.93l1.49,4.6L95,10.71l.92,4.74,4.83-.23.35,4.82,4.82.35-.23,4.83,4.74.92-.81,4.77,4.6,1.49L112.8,37l4.38,2-1.93,4.43,4.1,2.55-2.46,4.16,3.77,3-2.94,3.84Z" style="fill:#2775ff"/></svg>
					                <div class = "brk-pricing-rounded__icon-wrap">' . $icon . '</div>
					                <span class="after"></span>
					              </div>

					              <div class="brk-pricing-rounded__content brk-base-box-shadow">
					                <span class="rd-circl-overlay"></span>
					                <div class="rd-view">
					                  <div class="rd-view__title font__family-open-sans font__weight-bold font__size-16 line__height-24">' . $post->get_name() . '</div>
					                  <div class="rd-view__price">
					                    <span class="font__family-montserrat font__weight-ultralight font__size-56 line__height-56">' . $currency . $post->get_price() . '</span>
					                    <span class="old-price font__family-montserrat font__size-18">' . $old_price . '</span>
					                  </div>
					                </div>

					                <div class="rd-description">
					                  <ul class="rd-description__list font__family-open-sans font__size-14 line__height-48">
					                  ' . $attributes . '
					                  </ul>
					                  ' . $buy_now . '
					                </div>
					              </div>
					            </article>';

					break;
				case 'strict':

					$post = wc_get_product( $product );
					if ( ! $post ) {
						return;
					}
					$currency           = get_woocommerce_currency_symbol();
					$old_price          = $post->get_sale_price() !== '' ? $currency . $post->get_regular_price() : '';
					$product_attributes = $post->get_attributes();

					$buy_now = apply_filters( 'woocommerce_loop_add_to_cart_link',
						sprintf( '
            <a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="brk-pricing-strict__btn btn btn-md-2 btn-icon border-radius-25 font__family-open-sans font__weight-bold btn-inside-out add-cart ajax_add_to_cart %s product_type_%s">
              <i class="fa fa-shopping-cart icon-inside" aria-hidden="true"></i>
              <span class="before">%s</span>
              <span class="text">%s</span>
              <span class="after">%s</span>
            </a>',
							esc_url( $post->add_to_cart_url() ),
							esc_attr( $post->get_id() ),
							esc_attr( $post->get_sku() ),
							$post->is_purchasable() ? 'add_to_cart_button' : '',
							esc_attr( $post->get_type() ),
							$buy_now_text,
							$buy_now_text,
							$buy_now_text
						),
						$post );

					$attributes = '';
					foreach ( $product_attributes as $key => $attribute ) {
						$value = implode( ',', $attribute['options'] );
						$attributes .= '<li>' . $value . '</li>';
					}

					$output = '<div class="brk-pricing-strict text-center">
					              <div class="brk-pricing-strict__content brk-base-box-shadow">
					                <div class="brk-pricing-strict__title font__family-open-sans font__weight-bold">
					                  <span class="before brk-bg-grad"></span>
					                  <span>' . $post->get_name() . '</span>
					                </div>
					                <div class="brk-pricing-strict__price font__family-montserrat">
					                  <span class="st-sign">' . $currency . '</span>
					                  <span class="st-price font__weight-ultralight">' . $post->get_price() . '</span>
					                  <span class="st-sign' . esc_attr( $desc_class ) . '">' . esc_html( $price_info ) . '</span>
					                </div>
					                <div class="brk-pricing-strict__description">
					                  <ul class="font__family-open-sans font__size-14 line__height-48">
					                    ' . $attributes . '
					                  </ul>
					                </div>
					                ' . $buy_now . '
					              </div>
					            </div>';

					//$output = '';


					break;
				case 'shop':
					$post = wc_get_product( $product );
					if ( ! $post ) {
						return;
					}
					$currency           = get_woocommerce_currency_symbol();
					$old_price          = $post->get_sale_price() !== '' ? $currency . $post->get_regular_price() : '';
					$product_attributes = $post->get_attributes();
					$icon               = berserk_shortcodes_icons_process( $atts );
					$rate               = $post->get_average_rating() * 20;

					$buy_now = apply_filters( 'woocommerce_loop_add_to_cart_link',
						sprintf( '
            <a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="brk-pricing-shop__btn btn font__family-open-sans font__weight-bold add-cart ajax_add_to_cart %s product_type_%s">
              <i class="fa fa-shopping-basket"></i>
              %s
            </a>',
							esc_url( $post->add_to_cart_url() ),
							esc_attr( $post->get_id() ),
							esc_attr( $post->get_sku() ),
							$post->is_purchasable() ? 'add_to_cart_button' : '',
							esc_attr( $post->get_type() ),
							$buy_now_text
						),
						$post );

					$attributes = '';
					foreach ( $product_attributes as $key => $attribute ) {
						$value = implode( ',', $attribute['options'] );
						$attributes .= '<li>' . $value . '</li>';
					}

					$output = '<div class="brk-pricing-shop brk-base-box-shadow">
					              <div class="brk-pricing-shop__view">
					                <div class="brk-pricing-shop__title font__family-open-sans font__weight-bold font__size-24 line__height-24">' . $post->get_name() . '</div>
					                <div class="brk-pricing-shop__price">
					                  <div class="price-item font__family-montserrat">
					                    <span class="price font__weight-ultralight">' . $currency . $post->get_price() . '</span>
					                    <span class="period font__weight-light' . esc_attr( $desc_class ) . '">' . $price_info . '</span>
					                  </div>
					                  <div class="price-icon">
					                    <span class="before"></span>
					                    ' . $icon . '
					                    <p style="text-align: left"></p><span class="after"></span>
					                  </div>
					                </div>
					              </div>
					              <div class="brk-pricing-shop__description font__family-open-sans">
					                <ul>
					                  ' . $attributes . '
					                </ul>
					              </div>
					              <div class="brk-pricing-shop__block-info">
					                <div class="brk-rating">
					                  <div class="brk-rating__layer">
					                    <i class="fal fa-star brk-dark-font-color"></i>
					                    <i class="fal fa-star brk-dark-font-color"></i>
					                    <i class="fal fa-star brk-dark-font-color"></i>
					                    <i class="fal fa-star brk-dark-font-color"></i>
					                    <i class="fal fa-star brk-dark-font-color"></i>
					                  </div>
					                  <div class="brk-rating__imposition" style="width: ' . $rate . '%">
					                    <div class="visible">
					                      <i class="fas fa-star brk-base-font-color"></i>
					                      <i class="fas fa-star brk-base-font-color"></i>
					                      <i class="fas fa-star brk-base-font-color"></i>
					                      <i class="fas fa-star brk-base-font-color"></i>
					                      <i class="fas fa-star brk-base-font-color"></i>
					                    </div>
					                  </div>
					                </div>
					                <a href="' . get_permalink( $product ) . '" class="info-link font__family-montserrat font__weight-bold">' . __( 'info', 'berserk' ) . '<i class="fal fa-long-arrow-right"></i></a>
					              </div>
					              ' . $buy_now . '
					            </div>';

					break;
				case 'plan':
					$post = wc_get_product( $product );
					if ( ! $post ) {
						return;
					}
					$currency           = get_woocommerce_currency_symbol();
					$old_price          = $post->get_sale_price() !== '' ? $currency . $post->get_regular_price() : '';
					$product_attributes = $post->get_attributes();
					$description        = apply_filters( 'the_content', $post->get_short_description() );

					$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $product ), $image_size );

					$buy_now = apply_filters( 'woocommerce_loop_add_to_cart_link',
						sprintf( '
            <a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="brk-pricing-plan__btn btn font__family-montserrat letter-spacing-100 add-cart ajax_add_to_cart %s product_type_%s">
              <span class="after">%s</span>
            </a>',
							esc_url( $post->add_to_cart_url() ),
							esc_attr( $post->get_id() ),
							esc_attr( $post->get_sku() ),
							$post->is_purchasable() ? 'add_to_cart_button' : '',
							esc_attr( $post->get_type() ),
							$buy_now_text
						),
						$post );

					$attributes = '';
					foreach ( $product_attributes as $key => $attribute ) {
						$value = implode( ',', $attribute['options'] );
						$attributes .= '<li><i class="fal fa-check"></i>' . $value . '</li>';
					}

					$output = '<div class="brk-pricing-plan">
									<div class="brk-pricing-plan__bg lazyload" data-bg="' . $image_url[0] . '">
				                        <div class="brk-layer brk-bg-primary position-absolute opacity-90"></div>
				                      </div>
						              <div class="brk-pricing-plan__content text-center">
						                <div class="brk-pricing-plan__title font__family-montserrat font__weight-semibold letter-spacing-200">' . $post->get_name() . '</div>
						                <div class="brk-pricing-plan__price font__family-montserrat font__weight-semibold">
						                  <span class="sign">' . $currency . '</span>
						                  <span class="price">' . $post->get_price() . '</span>
						                  <span class="period' . esc_attr( $desc_class ) . '">' . $price_info . '</span>
						                </div>
						                <div class="brk-pricing-plan__description font__family-playfair font__style-italic letter-spacing-20">' . $description . '</div>
						                <div class="brk-pricing-plan__included">
						                  <ul>
						                    ' . $attributes . '
						                  </ul>
						                </div>
						                ' . $buy_now . '
						              </div>
					            </div>';

					break;

				case "light":

					$post = wc_get_product( $product );
					if ( ! $post ) {
						return;
					}
					$currency           = get_woocommerce_currency_symbol();
					$old_price          = $post->get_sale_price() !== '' ? $post->get_regular_price() . $currency : '';
					$product_attributes = $post->get_attributes();
					$description        = apply_filters( 'the_content', $post->get_short_description() );

					$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $product ), $image_size );

					$buy_now = apply_filters( 'woocommerce_loop_add_to_cart_link',
						sprintf( '
				            <a href="%1$s" rel="nofollow" data-product_id="%2$s" data-product_sku="%3$s" class="btn btn-inside-out btn-lg border-radius-25 brk-white-font-color font__family-open-sans font__weight-bold pl-70 pr-70 brk-library-rendered add-cart ajax_add_to_cart %4$s product_type_%5$s">
				              	<span class="before">%6$s</span>
								<span class="text">%6$s</span>
								<span class="after">%6$s</span>
				            </a>',
							esc_url( $post->add_to_cart_url() ),
							esc_attr( $post->get_id() ),
							esc_attr( $post->get_sku() ),
							$post->is_purchasable() ? 'add_to_cart_button' : '',
							esc_attr( $post->get_type() ),
							$buy_now_text
						),
						$post );

					$attributes = '';
					$i          = 1;
					foreach ( $product_attributes as $key => $attribute ) {
						$value = implode( ',', $attribute['options'] );
						$class = ( $i <= 3 ) ? 'active' : '';
						$attributes .= '<li class="brk-pricing-light__list-item ' . $class . ' mb-10"><div class="brk-pricing-light__list-indicator"><i class="fas fa-check-circle"></i> <i class="fas fa-minus-circle"></i></div><p>' . $value . '</p></li>';
						$i ++;
					}

					$output = '<div class="brk-pricing-light__item mb-40 brk-library-rendered" data-brk-library="component__pricing_table,component__button">
									<div class="brk-pricing-light__header">';

					if ( ! empty( $old_price ) ) {
						$output .= '<h2 class="mb-1 brk-pricing-light__old-price font__family-montserrat font__size-16 font__weight-bold line__height-16"><s>' . $old_price . '</s></h2>';
					}

					$title = ( ! empty( $old_price ) ) ? $post->get_price() . $currency : $post->get_name();

					$output .= '<h2 class="brk-pricing-light__price font__family-montserrat font__size-48 font__weight-bold line__height-50">' . $title . '</h2>
										<h3 class="brk-pricing-light__period font__family-playfair font__size-16 line__height-16 font__weight-bold opacity-40' . esc_attr( $desc_class ) . '">' . esc_html( $price_info ) . '</h3>

										' . $buy_now . '
									</div>
									<div class="brk-pricing-light__body pl-40 pr-20 pt-70 pb-50">
										<ul class="brk-pricing-light__list w-100 font__size-16 line__height-18">
											' . $attributes . '
										</ul>
									</div>
								</div>';

					break;
			}

			brs_add_libraries( $libraries );

			return $output;
		}


	}

	// create shortcode
	BRS_PricingTable::get_instance();

}
