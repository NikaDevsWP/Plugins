<?php

/**
 * The Helper
 * Contains all the helping functions
 */
class Shortcodes_Helper {

	// for Ajax pagination
	public static function posts_get_more() {
		$html              = '';
		$post_type         = $_REQUEST['post_type'];
		$posts_per_load    = $_REQUEST['posts_per_load'];
		$posts_per_page    = $_REQUEST['posts_per_page'];
		$layout_type       = $_REQUEST['layout_type'];
		$offset            = $_REQUEST['offset'];
		$key               = $_REQUEST['key'];
		$categories        = $_REQUEST['categories'];
		$columns           = $_REQUEST['columns'];
		$folio_type_layout = $_REQUEST['folio_type_layout'];

		$response = array();

		$args = array(
			'posts_per_page' => $posts_per_load,
			'post_type'      => $post_type,
			'offset'         => $offset
		);

		$args['tax_query'] = array();

		if ( $categories ) {
			$args['tax_query'][] = array(
				'taxonomy' => 'folio-category',
				'field'    => 'slug',
				'terms'    => array( $categories ),
			);
		}


		$args['tax_query']['relation'] = 'AND';


		$posts = self::get_posts( $args );

		$display_next = ( count( $posts ) < $posts_per_load ) ? false : true;

		foreach ( $posts as $post ) {
			switch ( $post_type ) {
				case "brs_portfolio":
					ob_start();
					Berserk_Portfolio::get_folio_article( $post->ID, $layout_type, '', $columns, $folio_type_layout );
					$html .= ob_get_clean();

					break;
			}
		}

		$new_offset = $posts_per_page + ( $posts_per_load * $key );

		$args  = array(
			'posts_per_page' => $posts_per_load,
			'post_type'      => $post_type,
			'offset'         => $new_offset
		);
		$posts = self::get_posts( $args );

		$display_next             = ( count( $posts ) == 0 ) ? false : $display_next;
		$response['html']         = $html;
		$response['offset']       = $new_offset;
		$response['display_next'] = $display_next;

		wp_die( json_encode( $response ) );
	}

	public static function check_if_posts_exist() {

		$post_type      = $_REQUEST['post_type'];
		$posts_per_load = $_REQUEST['posts_per_load'];
		$offset         = $_REQUEST['offset'];
		$categories     = $_REQUEST['categories'];
		$response       = array();

		$args = array(
			'posts_per_page' => $posts_per_load,
			'post_type'      => $post_type,
			'offset'         => $offset
		);

		$args['tax_query'] = array();

		if ( $categories ) {
			$args['tax_query'][] = array(
				'taxonomy' => 'folio-category',
				'field'    => 'slug',
				'terms'    => array( $categories ),
			);
		}

		$args['tax_query']['relation'] = 'AND';

		$posts = self::get_posts( $args );
		//dpm($posts);

		$response['show_load_more'] = ( count( $posts ) == 0 ) ? false : true;
		wp_die( json_encode( $response ) );

	}

	public static function add_post_image_like() {
		$id          = $_REQUEST['id'];
		$count_likes = 'post_image_likes';

		$count = get_comment_meta( $id, $count_likes, true );
		if ( $count == '' ) {
			$count = 0;
			$count ++;
			delete_comment_meta( $id, $count_likes );
			add_comment_meta( $id, $count_likes, $count );
		} else {
			$count ++;
			update_comment_meta( $id, $count_likes, $count );
		}
		die();
	}

	public static function get_posts( $args ) {
		$loop = new WP_Query( $args );
		//dpm($loop);
		$posts = $loop->posts;

		return $posts;
	}

	public static function get_found_posts( $args ) {
		$loop = new WP_Query( $args );
		//dpm($loop);
		$found_posts = $loop->found_posts;

		return $found_posts;
	}

	public static function get_all_posts_terms( $posts ) {

		$terms_array      = array();
		$taxonomies_array = array();

		foreach ( $posts as $post ) {
			$post             = get_post( $post->ID );
			$tax              = ( get_object_taxonomies( $post ) );
			$taxonomies_array = $taxonomies_array + $tax;
		}

		//dpm( $taxonomies_array );

		foreach ( $posts as $post ) {
			foreach ( $taxonomies_array as $taxonomy ) {
				$terms = get_the_terms( $post->ID, $taxonomy );
				if ( ! empty( $terms ) ) {
					foreach ( $terms as $term ) {
						$terms_array[ $term->slug ] = $term->name;
					}
				}
			}
		}

		return $terms_array;
	}

	public static function get_paged() {
		if ( get_query_var( 'paged' ) ) {
			return get_query_var( 'paged' );
		}

		if ( get_query_var( 'page' ) ) {
			return get_query_var( 'page' );
		}

		return 1;
	}

	public static function get_portfolio_filter( $filter_type ) {
		$terms   = get_terms( array(
			'taxonomy'   => 'folio-category',
			'hide_empty' => true,
		) );
		$sort_by = array(
			'original-order' => esc_html__( 'None', 'berserk' ),
			'category_name'  => esc_html__( 'Category Name', 'berserk' ),
			'name'           => esc_html__( 'Name', 'berserk' ),
		);
		$filter  = '';

		switch ( $filter_type ) {
			case "layout_1":
				$filter = '<div class="container">
				            <div class="row">
				                <div class="col-12">
				                    <div class="brk-grid-config d-flex mt-50 mb-60">
				                        <ul class="brk-filters  brk-filters_style-1 font__family-montserrat font__size-15 font__weight-bold line__height-44 text-uppercase">
				                            <li class="brk-filters__item active" data-filter="*">
				                                <span class="brk-dark-font-color-2">' . esc_html__( 'All', 'berserk' ) . '</span>
				                                <span class="font__weight-normal brk-dark-font-color brk-filters__count"></span>
				                            </li>';
				foreach ( $terms as $term ) {
					$filter .= '<li class="brk-filters__item" data-filter=".' . $term->slug . '">
	                                <span class="brk-dark-font-color-2">' . $term->name . '</span>
	                                <span class="font__weight-normal brk-dark-font-color brk-filters__count">' . $term->count . '</span>
	                            </li>';
				}
				$filter .= '</ul>

				                        <select id="brk-select__sizer">
											<option id="brk-select__sizer-option" class="font__family-montserrat font__size-15 font__weight-bold text-uppercase letter-spacing-20 pr-20"></option>
										</select>
				                        <div class="line__height-44 font__family-montserrat font__size-15 font__weight-bold text-uppercase letter-spacing-20 pr-20">
				                            <span>' . esc_html__( 'Sort by', 'berserk' ) . '</span>
				                            <div class="brk-select">
				                                <select name="select" id="brk-grid-sort" class="font__weight-normal brk-dark-font-color text-uppercase">';
				foreach ( $sort_by as $key => $value ) {
					$filter .= '<option value="' . $key . '">' . $value . '</option>';
				}

				$filter .= '</select>
				                                <i class="fal fa-angle-down brk-select__icon"></i>
				                            </div>
				                        </div>
				                    </div>
				                </div>
				            </div>
				        </div>';
				break;

			case "layout_2":

				$filter = '<div class="row">
					<ul class="brk-filters brk-filters_style-2 font__size-14 font__weight-bold line__height-16 text-uppercase mx-auto d-inline-flex brk-base-font-color pl-35 pr-35 mt-70 mt-lg-0 mb-40 mb-lg-70">
							<li class="brk-filters__item active" data-filter="*">
								<span>' . esc_html__( 'All', 'berserk' ) . '</span>
							  </li>';

				foreach ( $terms as $term ) {

					$filter .= '<li class="brk-filters__item" data-filter=".' . $term->slug . '">
									<span>' . $term->name . '</span>
								</li>';
				}

				$filter .= '</ul>
				</div>';

				break;
		}

		return $filter;
	}

}