var BRS_VC_ADMIN_CUSTOM_POST = function () {
	var self = {
		hide_delay: 333,
		change_form: false,
		new_tax: '',
		show_static_info_popup: function (text) {

			jQuery(".info_popup").html(text);
			jQuery(".info_popup").fadeTo(400, 0.9);
		},
		hide_static_info_popup: function () {
			window.setTimeout(function () {
				jQuery(".info_popup").fadeOut(400);
			}, self.hide_delay);
		},
		get_ajax_terms: function (new_tax) {

			var data = {
				action: "get_post_terms",
				tax: new_tax
			};
			jQuery.post(ajaxurl, data, function (response) {
				if (response) {
					jQuery('.vc_active [name="filters_taxonomy_values"]').each(function () {
						jQuery(this).find('option')
							.remove()
							.end()
							.append(response);

						var data_option = jQuery(this).attr('data-option');

						if (jQuery(this).find('option[value="' + data_option + '"]').length) {
							jQuery(this).find('option[value="' + data_option + '"]').attr('selected', 'selected');
						} else {
							jQuery(this).find('option:first').attr('selected', 'selected');
						}
						var val = jQuery(this).find('option:first').attr('value');
					});
				} else {
					jQuery('.vc_active [name="filters_taxonomy_values"]').each(function () {
						var empty_option = jQuery('<option class="" value="">None</option>');
						jQuery(this).find('option')
							.remove()
							.end()
							.append(empty_option);
					});
				}
				if ($('.vc_inline-shortcode-edit-form').length) {
					$('.vc_inline-shortcode-edit-form .vc_active [data-vc-ui-element="button-save"]').trigger("click");
				}

			});
		},
		init: function () {

			(function ($) {

				jQuery.fn.life = function (types, data, fn) {
					"use strict";
					jQuery(this.context).on(types, this.selector, data, fn);
					return this;
				};

				$('.vc_active [name="filters_post_type"]').on('change', function () {

					var $this = $(this),
						post_type = $this.val();

					$('.vc_active [name="filters_post_type"]').each(function () {
						var $this = $(this);
						$(this).find('option[value="' + post_type + '"]').attr('selected', 'selected');
						$(this).val(post_type).attr('data-option', post_type);
					});

					var loading = $('<div id="fountainTextG"><div id="fountainTextG_1" class="fountainTextG">L</div><div id="fountainTextG_2" class="fountainTextG">o</div><div id="fountainTextG_3" class="fountainTextG">a</div><div id="fountainTextG_4" class="fountainTextG">d</div><div id="fountainTextG_5" class="fountainTextG">i</div><div id="fountainTextG_6" class="fountainTextG">n</div><div id="fountainTextG_7" class="fountainTextG">g</div><div id="fountainTextG_8" class="fountainTextG">.</div><div id="fountainTextG_9" class="fountainTextG">.</div><div id="fountainTextG_10" class="fountainTextG">.</div></div>');
					self.show_static_info_popup(loading);

					var data = {
						action: "get_post_taxonomies",
						post_type: post_type
					};
					jQuery.post(ajaxurl, data, function (response) {

						if (response) {
							$('.vc_active [name="filters_taxonomies"]').each(function () {
								$(this).find('option')
									.remove()
									.end()
									.append(response);

								var data_option = $(this).attr('data-option');

								if ($(this).find('option[value="' + data_option + '"]').length) {
									$(this).find('option[value="' + data_option + '"]').attr('selected', 'selected');
									if ($(this).parent().parent().attr('class').indexOf('vc_dependent-hidden') == -1) {
										self.new_tax = data_option;
									}
									//console.log('self_new_tax1='+self.new_tax);
									$('.vc_active .vc_param_group-list').attr('data-taxonomy', self.new_tax);

								} else {
									$(this).find('option:first').attr('selected', 'selected');
									self.new_tax = $(this).find('option:first').attr('value');

									//console.log('self_new_tax2='+self.new_tax);
								}
							});

							self.get_ajax_terms(self.new_tax);

						} else {
							$('.vc_active [name="filters_taxonomies"]').each(function () {
								var empty_option = $('<option class="" value="">None</option>');
								$(this).find('option')
									.remove()
									.end()
									.append(empty_option);
							});
							$('.vc_active [name="filters_taxonomy_values"]').each(function () {
								var empty_option = $('<option class="" value="">None</option>');
								$(this).find('option')
									.remove()
									.end()
									.append(empty_option);
							});
						}
						self.hide_static_info_popup();
					});

				});

				$('.vc_active [name="filters_taxonomies"]').life('change', function () {

					var $this = $(this),
						tax = $this.val();

					if ($('.vc_active .vc_param_group-list').attr('data-taxonomy')) {
						tax = $('.vc_active .vc_param_group-list').attr('data-taxonomy');
					}

					self.get_ajax_terms(tax);

				});

				$('.vc_active [name="filters_taxonomies"]').life('click', function () {
					var $this = $(this),
						tax = $this.val();

					self.get_ajax_terms(tax);
				});

			}(jQuery));
		},
		add_custom_post_type: function (container_id, unique_id) {
			var params = {
				content: jQuery('#' + container_id).html(),
				title: "Add Content from Custom Post Type",
				popup_class: 'fenix-popup-add-slide',
				open: function () {
					var cur_popup_class = '.fenix-popup-add-slide',
						cur_popup = jQuery(cur_popup_class);

					jQuery('.fenix_grid_load_posts').on('click', function () {
						var loading = jQuery('<div id="fountainTextG"><div id="fountainTextG_1" class="fountainTextG">L</div><div id="fountainTextG_2" class="fountainTextG">o</div><div id="fountainTextG_3" class="fountainTextG">a</div><div id="fountainTextG_4" class="fountainTextG">d</div><div id="fountainTextG_5" class="fountainTextG">i</div><div id="fountainTextG_6" class="fountainTextG">n</div><div id="fountainTextG_7" class="fountainTextG">g</div><div id="fountainTextG_8" class="fountainTextG">.</div><div id="fountainTextG_9" class="fountainTextG">.</div><div id="fountainTextG_10" class="fountainTextG">.</div></div>');
						self.show_static_info_popup(loading);
						var type = jQuery('.fenix-popup-add-slide .select_item_post_type').val();

						var data = {
							action: "get_posts_to_add",
							post_type: type
						};

						jQuery.post(ajaxurl, data, function (response) {
							jQuery('.slider_item_list_popup').append(response);
							self.hide_static_info_popup();
						});
						return false;
					});

					cur_popup.find('.slider_item').life('click', function () {
						var $this = jQuery(this),
							icon = jQuery('<div class="media-modal-icon"></div>');
						if ($this.attr('class').indexOf('selected') == -1) {
							$this.addClass('selected');
							$this.append(icon);
						} else {
							$this.removeClass('selected');
							$this.find('.media-modal-icon').remove();

						}

					});

					jQuery('.fenix_grid_remove_posts').on('click', function () {
						jQuery('.slider_item_list_popup').empty();
						return false;
					});

				},
				close: function () {


				},
				save: function () {

					var cur_popup_content = jQuery('.fenix-popup-add-slide .fenix-popup-content'),
						slected_items = cur_popup_content.find('.slider_item.selected'),
						ids = [];

					slected_items.each(function (i) {
						var $this = jQuery(this);
						ids[i] = $this.attr('data-id');
					});

					jQuery('.vc_active').find('[name="custom_items"]').val(ids);
					self.change_form = true;

				}
			};
			jQuery.fenix_popup(params);
		},

	};
	return self;
};

var brs_vc_admin_custom_post = null;
brs_vc_admin_custom_post = new BRS_VC_ADMIN_CUSTOM_POST();
brs_vc_admin_custom_post.init();
