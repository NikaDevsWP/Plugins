(function ($) {

	if (typeof window.vc.EditElementUIPanel == 'undefined') {
		return;
	}

	// Switch row type
	var rowParamsSwitch = function () {

		var onChangeEvent = 'change.dt_vc_ext.vc_row.type',
			selector = '.dropdown.type',
			type_row = jQuery('div[data-vc-shortcode-param-name="type"]'),
			berserk_options = jQuery('.vc_shortcode-param.brs_vc_row-param'),
			vc_options = jQuery('.vc_shortcode-param').not('.brs_vc_row-param'),
			designOptionsTab = jQuery('.vc_edit-form-tab-control[data-tab-index="1"]');
			designOptionsTabSpacing = jQuery('.vc_edit-form-tab-control[data-tab-index="2"]');

		checkRowType(this.$(selector).val());

		this.$el
			.off(onChangeEvent, selector)
			.on(onChangeEvent, selector, function () {
				var val = $(this).val();
				checkRowType(val);
			});

		function checkRowType(val) {

			switch (val) {
				case "berserk":
					designOptionsTab.hide(300);
					designOptionsTabSpacing.show(300);
					vc_options.each(function () {
						$(this).hide(300);
					});
					berserk_options.each(function () {
						$(this).show(300);
					});
					break;
				case "vc_default":
					designOptionsTab.show(300);
					designOptionsTabSpacing.hide(300);
					berserk_options.each(function () {
						$(this).hide(300);
					});
					vc_options.each(function () {
						$(this).show(300);
					});
					break;
			}
			type_row.show(300);
		}

	};

	var EditElementUIPanel__buildParamsContent = window.vc.EditElementUIPanel.prototype.buildParamsContent;

	window.vc.EditElementUIPanel.prototype.buildParamsContent = function (data) {
		EditElementUIPanel__buildParamsContent.call(this, data);

		if ('vc_row' === this.model.attributes.shortcode) {
			rowParamsSwitch.call(this, data);
		}
	};

	// OVerride VcBackendTtaViewInterface
	if ('VcBackendTtaViewInterface' in window) {

		window.VcBackendTtaViewInterface.prototype.clickAppendSection = function (e) {
			e.preventDefault();
			this.addSection(undefined, $(e.currentTarget).data('element_type'));
		};

		window.VcBackendTtaViewInterface.prototype.clickPrependSection = function (e) {
			e.preventDefault();
			this.addSection(!0, $(e.currentTarget).data('element_type'));
		};

		window.VcBackendTtaViewInterface.prototype.addSection = function (prepend, element) {
			var newTabTitle, params, shortcode;

			element = element || "vc_tta_section";

			return newTabTitle = this.defaultSectionTitle,
				params = {
					shortcode: element,
					params: {
						title: newTabTitle
					},
					parent_id: this.model.get("id"),
					order: _.isBoolean(prepend) && prepend ? vc.add_element_block_view.getFirstPositionIndex() : vc.shortcodes.getNextOrder(),
					prepend: prepend
				},
				shortcode = vc.shortcodes.create(params);
		};
	};

	$.fn.vcAccordion.Constructor.prototype.collapseTemplate = function(showCallback) {
		var $allTriggers, $activeTriggers, $this, $triggers;
		$this = this.$element;
		var i;
		if (i = 0, $allTriggers = this.getContainer().find("[data-vc-preview-handler]").each(function() {
				var accordion, $this;
				$this = $(this), accordion = $this.data("vc.accordion"), void 0 === accordion && ($this.vcAccordion(), accordion = $this.data("vc.accordion")), accordion && accordion.setIndex && accordion.setIndex(i++)
			}), $activeTriggers = $allTriggers.filter(function() {
				var $this, accordion;
				return $this = $(this), accordion = $this.data("vc.accordion"), accordion.getTarget().hasClass(accordion.activeClass)
			}), $triggers = $activeTriggers.filter(function() {
				return $this[0] !== this
			}), $triggers.length && $.fn.vcAccordion.call($triggers, "hide"), this.isActive()) $.fn.vcAccordion.call($this, "hide");
		else {
			$.fn.vcAccordion.call($this, "show");
			var $triggerPanel = $this.closest(".vc_ui-list-bar-item"),
				$wrapper = $this.closest("[data-template_id]"),
				$panel = $wrapper.closest("[data-vc-ui-element=panel-content]").parent();
			setTimeout(function() {
				if (Math.round($wrapper.offset().top - $panel.offset().top) < 0) {
					var posit = Math.round($wrapper.offset().top - $panel.offset().top + $panel.scrollTop() - $triggerPanel.height());
					$panel.animate({
						scrollTop: posit
					}, 400)
				}
				"function" == typeof showCallback && showCallback($wrapper, $panel)
			}, 400)
		}
	};

})(window.jQuery);