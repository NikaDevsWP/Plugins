var BRS_VC_ADMIN_SCRIPT = function () {
	var self = {
		hide_delay: 333,
		change_form: false,
		show_static_info_popup: function (text) {

			jQuery(".info_popup").html(text);
			jQuery(".info_popup").fadeTo(400, 0.9);
		},
		hide_static_info_popup: function () {
			window.setTimeout(function () {
				jQuery(".info_popup").fadeOut(400);
			}, self.hide_delay);
		},
		if_hidden_change: function (selector, callback) {
			var input = jQuery(selector);
			var oldvalue = input.val();
			setInterval(function () {
				if (input.val() != oldvalue) {
					oldvalue = input.val();
					callback();
				}
			}, 100);
		},
		set_def_window_size: function () {
			var $window = jQuery('.vc_ui-panel-window.vc_active');
			var left = jQuery(window).width() - 405;
			$window.css({
				'height': 'auto',
				'max-height': '75vh',
				'width': '1136px',
				'left': '246px',
				'top': '37px'
			});
		},
		init: function () {

			(function ($) {

				jQuery.fn.life = function (types, data, fn) {
					"use strict";
					jQuery(this.context).on(types, this.selector, data, fn);
					return this;
				};

				//Radio Image option
				if (jQuery(".brs-radio-wrapper").length) {

					jQuery(".brs-radio-wrapper").on("click", "img", function (e) {
						var self = jQuery(this), hidden, data_val;
						hidden = jQuery(this).parent().parent().parent().parent().find(".brs_radio_field");
						data_val = self.attr('data-val');
						hidden.val(data_val);
						$('.wrap_radio_image').removeClass("current-item");
						self.parent().addClass("current-item");

						// Show and hide fields which depended on the Radio Image value
						var name = hidden.attr('name');
						$('.brk-dependency__' + name + ':not(.' + data_val + ')').addClass('hidden').hide();
						$('.brk-dependency__' + name + '.' + data_val).removeClass('hidden').show();

					});

				}

				// Initite the click on the active item, so required scripts will be triggered
				jQuery(".wrap_radio_image.current-item img").click();

				// Livicon implementation
				jQuery(".brs_lievo_add#lievo-add-button").on('click', function () {
					var $this = $(this);
					var len = $('.lievo-icon-wrapper').length;

					var btn_icon_input = $('input[name="values_brs_btn_icon"]');
					btn_icon_input.each(function () {
						var $this = $(this);
						$this.removeClass('active');
					});
					$this.next().next().next('input[name="values_brs_btn_icon"]').addClass('active');

				});

				$('.lievo-icon-wrapper').on('click', function () {
					var len = $('#lievo-paste-shortcode').length;
					$('#lievo-paste-shortcode').addClass('brs_paste_shortcode');

				});

				$('#lievo-paste-shortcode').on('click', function () {

					$('#lievo-get-shortcode').trigger('click');
					$('#lievo-modal').hide();

					var result_code = $('#lievo-code').html();

					if ($('input[name="values_brs_btn_icon"].active').length) {
						$('input[name="values_brs_btn_icon"].active').val(result_code);
					}

					if ($('.vc_active input[name="brs_btn_icon"]').length) {

						var data = {
							action: "add_json_encode",
							result_code: result_code
						};
						jQuery.post(ajaxurl, data, function (response) {

							if (response) {
								$('.vc_active input[name="brs_btn_icon"]').val('');
								$('.vc_active input[name="brs_btn_icon"]').val(response);
							}
						});

					}

					$('#lievo-dialog-close-btn').trigger('click');
				});

				// Video uploader

				$('.brs_button_upload').on('click', function () {
					var input_object = $(this).prev('input, textarea'),
						type = $(this).data('type'),
						title = wp.media.view.l10n.chooseImage;

					if (!type) {
						type = 'image';
					} else if (type === 'audio') {
						title = wp.media.view.l10n.audioAddSourceTitle;
					} else if (type === 'video') {
						title = wp.media.view.l10n.videoAddSourceTitle;
					}

					var frame = wp.media({
						title: title,
						multiple: false,
						library: {type: type}
					});

					frame.on('select', function () {
						var selection = frame.state().get('selection');
						selection.each(function (attachment) {
							var url = attachment.attributes.url;
							input_object.val(url).trigger('change');
						});
					});

					frame.open();

					return false;
				});

				//ADD Product

				$('#brs-add-product').on('click', function () {

					var params = {
						//content: jQuery('#' + container_id).html(),
						title: "Please choose the product",
						popup_class: 'fenix-popup-add-slide-options',
						open: function () {
							var cur_popup_class = '.fenix-popup-add-slide-options',
								cur_popup = jQuery(cur_popup_class);

							var loading = $('<div id="fountainTextG"><div id="fountainTextG_1" class="fountainTextG">L</div><div id="fountainTextG_2" class="fountainTextG">o</div><div id="fountainTextG_3" class="fountainTextG">a</div><div id="fountainTextG_4" class="fountainTextG">d</div><div id="fountainTextG_5" class="fountainTextG">i</div><div id="fountainTextG_6" class="fountainTextG">n</div><div id="fountainTextG_7" class="fountainTextG">g</div><div id="fountainTextG_8" class="fountainTextG">.</div><div id="fountainTextG_9" class="fountainTextG">.</div><div id="fountainTextG_10" class="fountainTextG">.</div></div>');
							self.show_static_info_popup(loading);

							var data = {
								action: "get_all_products"
							};
							jQuery.post(ajaxurl, data, function (response) {

								if (response) {
									$('.fenix-popup-content').html(response);
									self.hide_static_info_popup();
								}
							});

							cur_popup.find('.slider_item').life('click', function () {
								var $this = jQuery(this),
									icon = jQuery('<div class="media-modal-icon"></div>');
								if ($this.attr('class').indexOf('selected') == -1) {
									$('.slider_item').each(function () {
										var $this = $(this);
										$this.removeClass('selected');
										$this.find('.media-modal-icon').remove();
									});
									setTimeout(function () {
										$this.addClass('selected');
										$this.append(icon);
									}, 300);

								} else {
									$this.removeClass('selected');
									$this.find('.media-modal-icon').remove();
								}
							});
						},
						close: function () {
						},
						save: function () {
							var cur_popup_content = jQuery('.fenix-popup-add-slide-options .fenix-popup-content'),
								id = cur_popup_content.find('.slider_item.selected').attr('data-id');

							$('.vc_active').find('[name="product"]').val(id);
							self.change_form = true;
						}
					};
					jQuery.fenix_popup(params);

				});

				$('#brs-add-product-multiple').on('click', function () {

					var params = {
						//content: jQuery('#' + container_id).html(),
						title: "Please choose products",
						popup_class: 'fenix-popup-add-slide-options',
						open: function () {
							var cur_popup_class = '.fenix-popup-add-slide-options',
								cur_popup = jQuery(cur_popup_class);

							var loading = $('<div id="fountainTextG"><div id="fountainTextG_1" class="fountainTextG">L</div><div id="fountainTextG_2" class="fountainTextG">o</div><div id="fountainTextG_3" class="fountainTextG">a</div><div id="fountainTextG_4" class="fountainTextG">d</div><div id="fountainTextG_5" class="fountainTextG">i</div><div id="fountainTextG_6" class="fountainTextG">n</div><div id="fountainTextG_7" class="fountainTextG">g</div><div id="fountainTextG_8" class="fountainTextG">.</div><div id="fountainTextG_9" class="fountainTextG">.</div><div id="fountainTextG_10" class="fountainTextG">.</div></div>');
							self.show_static_info_popup(loading);

							var data = {
								action: "get_all_products"
							};
							jQuery.post(ajaxurl, data, function (response) {
								if (response) {
									$('.fenix-popup-content').html(response);
									self.hide_static_info_popup();
								}
							});

							cur_popup.find('.slider_item').life('click', function () {
								var $this = jQuery(this),
									icon = jQuery('<div class="media-modal-icon"></div>');
								if ($this.attr('class').indexOf('selected') == -1) {
									$this.addClass('selected');
									$this.append(icon);
								} else {
									$this.removeClass('selected');
									$this.find('.media-modal-icon').remove();

								}
							});

						},
						close: function () {
						},
						save: function () {

							var cur_popup_content = jQuery('.fenix-popup-add-slide-options .fenix-popup-content'),
								slected_items = cur_popup_content.find('.slider_item.selected'),
								ids = [];

							slected_items.each(function (i) {
								var $this = jQuery(this);
								ids[i] = $this.attr('data-id');
							});

							jQuery('.vc_active').find('[name="products"]').val(ids);
							self.change_form = true;
						}
					};
					jQuery.fenix_popup(params);

				});


				// Switch param
				jQuery('.wpb_el_type_brs_switch .wpb_vc_param_value').on('change', function () {
					var $this = $(this);
					var values = json_decode($this.attr('data-values'));
					var value = values[1];
					if ($this.is(':checked')) {
						value = values[0];
					}

					$this.val(value);
				});

				// Switch button brs_type
				if (jQuery('input[name="brs_type"]').length) {
					var brs_type_val = $('input[name="brs_type"]').val(),
						dropdown_items = $('div[data-vc-shortcode-param-name="dropdown_values"]'),
						dropdown_opened = $('div[data-vc-shortcode-param-name="dropdown_opened"]'),
						drop_color_scheme = $('div[data-vc-shortcode-param-name="drop_color_scheme"]'),
						size = $('div[data-vc-shortcode-param-name="size"]'),
						enable_delimiter = $('div[data-vc-shortcode-param-name="enable_delimiter"]'),
						style = $('div[data-vc-shortcode-param-name="style"]'),
						custom_background = $('div[data-vc-shortcode-param-name="custom_background"]'),
						split_title = $('div[data-vc-shortcode-param-name="split_title"]'),
						brs_title = $('div[data-vc-shortcode-param-name="brs_title"]'),
						round_circled = $('div[data-vc-shortcode-param-name="round_circled"]');


					checkBrsType(brs_type_val);

					jQuery('input[name="brs_type"]').on('change', function () {
						var $this = $(this),
							val = $this.val();
						checkBrsType(val);
					});

					function checkBrsType(val) {
						switch (val) {
							case "dropdown":
								dropdown_items.show(300);
								dropdown_opened.show(300);
								drop_color_scheme.show(300);
								size.hide(300);
								enable_delimiter.hide(300);
								style.hide(300);
								custom_background.hide(300);
								split_title.hide(300);
								brs_title.hide(300);
								round_circled.hide(300);

								break;
							case "round":
								dropdown_items.hide(300);
								dropdown_opened.hide(300);
								drop_color_scheme.hide(300);
								size.show(300);
								enable_delimiter.show(300);
								style.show(300);
								custom_background.show(300);
								split_title.show(300);
								brs_title.show(300);
								round_circled.show(300);

								break;

							default:
								dropdown_items.hide(300);
								dropdown_opened.hide(300);
								drop_color_scheme.hide(300);
								size.show(300);
								enable_delimiter.show(300);
								style.show(300);
								custom_background.show(300);
								split_title.show(300);
								brs_title.show(300);
								round_circled.hide(300);

								break;
						}

					}

				}

				//Switch button delimiter
				if (jQuery('input[name="delimiter"]').length) {
					var delimiter_val = jQuery('input[name="delimiter"]').val(),
						delimiter_color = $('div[data-vc-shortcode-param-name="delimiter_color"]'),
						delimiter_color_first = $('div[data-vc-shortcode-param-name="delimiter_color_first"]'),
						delimiter_color_second = $('div[data-vc-shortcode-param-name="delimiter_color_second"]');

					checkDelimiter(delimiter_val);

					jQuery('input[name="delimiter"]').on('change', function () {
						var $this = $(this),
							val = $this.val();
						checkDelimiter(val);
					});

					function checkDelimiter(val) {

						switch (val) {
							case "solid":
							case "double":
							case "solid_slope":
							case "solid_shade":
							case "doted":
								delimiter_color.show(300);
								delimiter_color_first.hide(300);
								delimiter_color_second.hide(300);
								break;
							case "solid_gradient":
							case"double_colors":
								delimiter_color.hide(300);
								delimiter_color_first.show(300);
								delimiter_color_second.show(300);
								break;
						}

					}

				}

				// Switch button style
				if (jQuery('input[name="style"]').length) {

					var style_val = jQuery('input[name="style"]').val(),
						bg_color = $('div[data-vc-shortcode-param-name="custom_background"]'),
						bg_color_g_1 = $('div[data-vc-shortcode-param-name="bg_color_g_1"]'),
						bg_color_g_2 = $('div[data-vc-shortcode-param-name="bg_color_g_2"]'),
						bg_color_g_3 = $('div[data-vc-shortcode-param-name="bg_color_g_3"]'),
						bg_color_g_4 = $('div[data-vc-shortcode-param-name="bg_color_g_4"]'),
						caption_on_hover = $('div[data-vc-shortcode-param-name="caption_on_hover"]'),
						hover_caption = $('div[data-vc-shortcode-param-name="hover_caption"]');

					checkStyle(style_val);

					jQuery('input[name="style"]').on('change', function () {
						var $this = $(this),
							val = $this.val();
						checkStyle(val);
					});

					function checkStyle(val) {

						switch (val) {
							case "solid":
								bg_color.show(300);
								bg_color_g_1.hide(300);
								bg_color_g_2.hide(300);
								bg_color_g_3.hide(300);
								bg_color_g_4.hide(300);
								caption_on_hover.show(300);
								hover_caption.show(300);
								break;

							case "border":
							case "double":
							case "border_progress":
							case "solid_dark":
								bg_color.show(300);
								bg_color_g_1.hide(300);
								bg_color_g_2.hide(300);
								bg_color_g_3.hide(300);
								bg_color_g_4.hide(300);
								caption_on_hover.hide(300);
								hover_caption.hide(300);
								break;

							case "border_gradient":
								bg_color.show(300);
								bg_color_g_1.hide(300);
								bg_color_g_2.hide(300);
								bg_color_g_3.show(300);
								bg_color_g_4.show(300);
								caption_on_hover.hide(300);
								hover_caption.hide(300);
								break;

							case "gradient":
								bg_color_g_3.show(300);
								bg_color_g_4.show(300);
								bg_color_g_1.show(300);
								bg_color_g_2.show(300);
								bg_color.hide(300);
								caption_on_hover.hide(300);
								hover_caption.hide(300);
								break;

							case "gradient_wave":
								bg_color_g_3.show(300);
								bg_color_g_4.show(300);
								bg_color_g_1.hide(300);
								bg_color_g_2.hide(300);
								bg_color.hide(300);
								caption_on_hover.hide(300);
								hover_caption.hide(300);
								break;

							case "double_background":
								bg_color_g_1.show(300);
								bg_color_g_2.show(300);
								bg_color_g_3.show(300);
								bg_color_g_4.show(300);
								bg_color.hide(300);
								caption_on_hover.hide(300);
								hover_caption.hide(300);
								break;
							case "light_border_shadow":
								bg_color.hide(300);
								bg_color_g_1.hide(300);
								bg_color_g_2.hide(300);
								bg_color_g_3.hide(300);
								bg_color_g_4.hide(300);
								caption_on_hover.show(300);
								hover_caption.show(300);
								break;

							default:
								bg_color.hide(300);
								bg_color_g_1.hide(300);
								bg_color_g_2.hide(300);
								bg_color_g_3.hide(300);
								bg_color_g_4.hide(300);
								caption_on_hover.hide(300);
								hover_caption.hide(300);
								break;
						}
					}
				}

				//Split title
				jQuery('#brs_switch-split_title').on('change', function () {
					var $this = $(this);
					var splited_input = $('.vc_ui-panel-content-container .splited_title');
					var tile_val = $('.vc_ui-panel-content-container .content').val();
					var tile = $('.vc_ui-panel-content-container .content');
					splited_input.val(tile_val);

					if ($this.is(':checked')) {
						tile.prop('readonly', true);
					}
					else {
						tile.prop('readonly', false);
					}

				});
				//Switch List Font

				if (jQuery('input[name="enable_font"]').length) {
					var enable_font = jQuery('input[name="enable_font"]').val(),
						brs_font = $('div[data-vc-shortcode-param-name="brs_font"]'),
						brs_font_weight = $('div[data-vc-shortcode-param-name="brs_font_weight"]');

					checkListFont(enable_font);

					jQuery('input[name="enable_font"]').on('change', function () {
						var $this = $(this),
							val = $this.val();
						checkListFont(val);
					});

					function checkListFont(val) {

						switch (val) {
							case "y":
								brs_font.hide(300);
								brs_font_weight.hide(300);
								break;
							case "n":
								brs_font.show(300);
								brs_font_weight.show(300);
								break;

						}

					}

				}

				//Switch List type
				if (jQuery('input[name="list_type"]').length) {
					var list_type = jQuery('input[name="list_type"]').val(),
						color_1 = $('div[data-vc-shortcode-param-name="values_color_1"]'),
						color_2 = $('div[data-vc-shortcode-param-name="values_color_2"]');

					checkListType(list_type);

					jQuery('input[name="list_type"]').on('change', function () {
						var $this = $(this),
							val = $this.val();
						checkListType(val);
					});

					function checkListType(val) {

						switch (val) {
							case "type_1":
							case "type_2":
							case "type_3":
							case "type_6":
								color_1.show(300);
								color_2.hide(300);
								break;
							case "type_4":
							case "type_5":
								color_1.show(300);
								color_2.show(300);
								break;
						}

					}

				}

				//Carousel type
				if (jQuery('input[name="carousel_type"]').length) {
					var carousel_type = jQuery('input[name="carousel_type"]').val(),
						full_height = $('div[data-vc-shortcode-param-name="full_height"]');

					checkCarouselType(carousel_type);

					jQuery('input[name="carousel_type"]').on('change', function () {
						var $this = $(this),
							val = $this.val();
						checkCarouselType(val);
					});

					function checkCarouselType(val) {

						switch (val) {
							case "thumbnailed_slider":
								full_height.show(300);
								break;
							default:
								full_height.hide(300);
								break;
						}

					}

				}

				// Color scheme option
				if ($('.brs-colors-wrapper').length) {
					jQuery(".brs-colors-wrapper").on("click", ".color", function (e) {
						var self = jQuery(this), hidden, data_val;
						hidden = jQuery(this).parent().find(".brs-color-scheme");
						data_val = self.attr('data-color');
						hidden.val(data_val);

						self.siblings().removeClass("current-item");
						self.addClass("current-item");
					});
				}

				if (jQuery('input[name="use_custom_color"]').length) {
					var brs_type_val = $('input[name="use_custom_color"]').val(),
						color_scheme = $('div[data-vc-shortcode-param-name="color_scheme"]');

					checkCustomColor(brs_type_val);

					jQuery('input[name="use_custom_color"]').on('change', function () {
						var $this = $(this),
							val = $this.val();
						checkCustomColor(val);
					});

					function checkCustomColor(val) {
						switch (val) {
							case "y":
								color_scheme.hide(300);
								break;
							case "n":
								color_scheme.show(300);
								break;
						}
					}
				}

				if (jQuery('[name="portfolio_type"]')) {
					var portfolio_type = $('input[name="portfolio_type"]').val(),
						option_slider = $('.pagination_type').find('.slider');

					checkPortfolioType(portfolio_type);

					jQuery('input[name="portfolio_type"]').on('change', function () {
						var $this = $(this),
							val = $this.val();
						checkPortfolioType(val);
					});

					function checkPortfolioType(val) {
						if (val == 'category') {
							option_slider.show(300);
						} else {
							option_slider.hide(300);
						}
					}

				}

				if (jQuery('input[name="use_custom_background"]').length) {
					var brs_type_val = $('input[name="use_custom_background"]').val(),
						pattern_type = $('.pattern_type'),
						image_uploader = $('.image_uploader');

					//setTimeout(function(){
					checkCustomPattern(brs_type_val);
					//},300);

					jQuery('input[name="use_custom_background"]').on('change', function () {
						var $this = $(this),
							val = $this.val();
						checkCustomPattern(val);
					});

					function checkCustomPattern(val) {
						switch (val) {
							case "yes":
								pattern_type.addClass('hidden').hide(300);
								image_uploader.removeClass('hidden').show(300);
								break;
							case "no":
								pattern_type.removeClass('hidden').show(300);
								image_uploader.addClass('hidden').hide(300);
								break;
						}
					}
				}

				// Switch dynamic content
				if (jQuery('input[name="dynamic_content"]').length) {
					var dynamic_content = jQuery('input[name="dynamic_content"]').val(),
						custom_items = $('div[data-vc-shortcode-param-name="custom_items"]');

					switchDC(dynamic_content);
					jQuery('input[name="dynamic_content"]').on('change', function () {
						var $this = $(this),
							val = $this.val();
						switchDC(val);
					});

					function switchDC(val) {
						switch (val) {
							case "no":
								custom_items.show(300);
								break;
							case "y":
								custom_items.hide(300);
								break;
						}

					}

				}

				//Shape box type
				if (jQuery('input[name="shape_box_type"]').length) {
					var shape_box_type = jQuery('input[name="shape_box_type"]').val(),
						number = $('div[data-vc-shortcode-param-name="number"]'),
						shape_invert = $('div[data-vc-shortcode-param-name="shape_invert"]'),
						btn_icon_type = $('div[data-vc-shortcode-param-name="btn_icon_type"]'),
						content = $('div[data-vc-shortcode-param-name="content"]'),
						brs_title = $('div[data-vc-shortcode-param-name="brs_title"]'),
						icon_fontawesome = $('div[data-vc-shortcode-param-name="icon_fontawesome"]'),
						icon_openiconic = $('div[data-vc-shortcode-param-name="icon_openiconic"]'),
						icon_typicons = $('div[data-vc-shortcode-param-name="icon_typicons"]'),
						icon_entypo = $('div[data-vc-shortcode-param-name="icon_entypo"]'),
						icon_linecons = $('div[data-vc-shortcode-param-name="icon_linecons"]'),
						icon_monosocial = $('div[data-vc-shortcode-param-name="icon_monosocial"]');

					ShapeBoxType(shape_box_type);

					jQuery('input[name="shape_box_type"]').on('change', function () {
						var $this = $(this),
							val = $this.val();
						ShapeBoxType(val);
					});

					function ShapeBoxType(val) {

						switch (val) {
							case "inline":
							case "wave":
							case "stripe":
							case "shape":
								number.hide(300);
								shape_invert.hide(300);
								btn_icon_type.show(300);
								content.show(300);
								brs_title.show(300);
								icon_fontawesome.show(300);
								icon_openiconic.show(300);
								icon_typicons.show(300);
								icon_entypo.show(300);
								icon_linecons.show(300);
								icon_monosocial.show(300);
								break;
							case "half":
								number.show(300);
								shape_invert.hide(300);
								btn_icon_type.hide(300);
								content.hide(300);
								brs_title.hide(300);
								icon_fontawesome.hide(300);
								icon_openiconic.hide(300);
								icon_typicons.hide(300);
								icon_entypo.hide(300);
								icon_linecons.hide(300);
								icon_monosocial.hide(300);
								break;
							case "triangle":
								number.hide(300);
								shape_invert.show(300);
								btn_icon_type.show(300);
								content.show(300);
								brs_title.show(300);
								icon_fontawesome.show(300);
								icon_openiconic.show(300);
								icon_typicons.show(300);
								icon_entypo.show(300);
								icon_linecons.show(300);
								icon_monosocial.show(300);
								break;

						}

					}

				}

				//Info box type
				if (jQuery('input[name="info_box_type"]').length) {
					var info_box_type = jQuery('input[name="info_box_type"]').val(),

						first_title = $('div[data-vc-shortcode-param-name="first_title"]'),
						title = $('div[data-vc-shortcode-param-name="title"]'),
						link_url = $('div[data-vc-shortcode-param-name="link_url"]'),
						link_title = $('div[data-vc-shortcode-param-name="link_title"]'),
						bg_image = $('div[data-vc-shortcode-param-name="bg_image"]'),
						fade_effect = $('div[data-vc-shortcode-param-name="fade_effect"]'),
						bottom = $('div[data-vc-shortcode-param-name="bottom"]'),

						btn_icon_type = $('div[data-vc-shortcode-param-name="btn_icon_type"]'),
						content = $('div[data-vc-shortcode-param-name="content"]'),
						brs_title = $('div[data-vc-shortcode-param-name="brs_title"]'),
						icon_fontawesome = $('div[data-vc-shortcode-param-name="icon_fontawesome"]'),
						icon_openiconic = $('div[data-vc-shortcode-param-name="icon_openiconic"]'),
						icon_typicons = $('div[data-vc-shortcode-param-name="icon_typicons"]'),
						icon_entypo = $('div[data-vc-shortcode-param-name="icon_entypo"]'),
						icon_linecons = $('div[data-vc-shortcode-param-name="icon_linecons"]'),
						icon_monosocial = $('div[data-vc-shortcode-param-name="icon_monosocial"]'),
						icon_option = $('.icon_option');

					InfoBoxType(info_box_type);

					jQuery('input[name="info_box_type"]').on('change', function () {
						var $this = $(this),
							val = $this.val();
						InfoBoxType(val);
					});

					function InfoBoxType(val) {

						switch (val) {
							case "chess":
								title.show(300);
								first_title.hide(300);
								link_url.show(300);
								link_title.show(300);
								bg_image.show(300);
								fade_effect.hide(300);
								bottom.show(300);
								icon_option.show(300);

								break;

							case "outline":
							case "gradient":
							case "web":
								title.show(300);
								first_title.hide(300);
								link_url.hide(300);
								link_title.hide(300);
								bg_image.hide(300);
								fade_effect.hide(300);
								bottom.hide(300);
								icon_option.show(300);

								break;

							case "shuffle":
								title.show(300);
								first_title.hide(300);
								link_url.show(300);
								link_title.show(300);
								bg_image.show(300);
								fade_effect.hide(300);
								bottom.show(300);
								icon_option.show(300);

								break;

							case "strict":
								title.show(300);
								first_title.show(300);
								link_url.show(300);
								link_title.show(300);
								bg_image.hide(300);
								fade_effect.hide(300);
								bottom.hide(300);
								icon_option.show(300);

								break;

							case "image":
								title.show(300);
								first_title.hide(300);
								link_url.hide(300);
								link_title.hide(300);
								bg_image.show(300);
								fade_effect.show(300);
								bottom.hide(300);
								icon_option.show(300);

								break;

							case "icon":
								title.show(300);
								first_title.show(300);
								link_url.hide(300);
								link_title.hide(300);
								bg_image.show(300);
								fade_effect.hide(300);
								bottom.hide(300);
								icon_option.show(300);
								break;

							case "bonus":
								title.hide(300);
								first_title.show(300);
								link_url.show(300);
								link_title.show(300);
								bg_image.hide(300);
								fade_effect.hide(300);
								bottom.hide(300);
								icon_option.hide(300);
								break;

						}

					}

				}

				//Switch Services type

				if (jQuery('input[name="services_type"]').length) {
					var services_type = jQuery('input[name="services_type"]').val(),
						values_first_title = $('div[data-vc-shortcode-param-name="values_first_title"]'),
						values_second_title = $('div[data-vc-shortcode-param-name="values_second_title"]'),
						values_description = $('div[data-vc-shortcode-param-name="values_description"]'),
						values_bg_image = $('div[data-vc-shortcode-param-name="values_bg_image"]'),
						values_values = $('div[data-vc-shortcode-param-name="values_values"]'),
						values_type = $('div[data-vc-shortcode-param-name="values_type"]'),
						values_link_title = $('div[data-vc-shortcode-param-name="values_link_title"]'),
						values_link_url = $('div[data-vc-shortcode-param-name="values_link_url"]'),
						icon_option = $('.icon_option');

					checkServicesType(services_type);

					jQuery('input[name="services_type"]').on('change', function () {
						var $this = $(this),
							val = $this.val();
						checkServicesType(val);
					});

					function checkServicesType(val) {

						switch (val) {
							case "pedestal":
								values_first_title.show(300);
								values_second_title.show(300);
								values_values.hide(300);
								values_type.show(300);
								values_link_title.show(300);
								values_link_url.show(300);
								icon_option.show(300);
								values_description.show(300);
								values_bg_image.hide(300);

								break;
							case "hexagon":
								values_first_title.hide(300);
								values_second_title.hide(300);
								values_values.show(300);
								values_type.hide(300);
								values_link_title.show(300);
								values_link_url.show(300);
								icon_option.hide(300);
								values_description.show(300);
								values_bg_image.hide(300);

								break;

							case "honeycomb":
								values_first_title.show(300);
								values_second_title.hide(300);
								values_values.show(300);
								values_type.show(300);
								values_link_title.show(300);
								values_link_url.show(300);
								icon_option.show(300);
								values_description.show(300);
								values_bg_image.hide(300);

								break;

							case "simple_info":
							case "architecture":
								values_first_title.show(300);
								values_second_title.hide(300);
								values_values.hide(300);
								values_type.hide(300);
								values_link_title.hide(300);
								values_link_url.hide(300);
								icon_option.show(300);
								values_description.show(300);
								values_bg_image.hide(300);
								break;

							case "architecture_bg":
								values_first_title.show(300);
								values_second_title.hide(300);
								values_values.hide(300);
								values_type.hide(300);
								values_link_title.hide(300);
								values_link_url.hide(300);
								icon_option.show(300);
								values_description.show(300);
								values_bg_image.show(300);
								break;

							case "info":
								values_description.hide(300);
								values_first_title.show(300);
								values_second_title.show(300);
								values_values.hide(300);
								values_type.hide(300);
								values_link_title.hide(300);
								values_link_url.hide(300);
								icon_option.show(300);
								values_bg_image.hide(300);

								break;
						}

					}

				}

				//Title Section type

				if (jQuery('input[name="titles_section_type"]').length) {
					var titles_section_type = jQuery('input[name="titles_section_type"]').val(),
						st_description = $('div[data-vc-shortcode-param-name="st_description"]'),
						st_bg_heading = $('div[data-vc-shortcode-param-name="st_bg_heading"]'),
						itens_values = $('div[data-vc-shortcode-param-name="itens_values"]');

					checkTSType(titles_section_type);

					jQuery('input[name="titles_section_type"]').on('change', function () {
						var $this = $(this),
							val = $this.val();
						checkTSType(val);
					});

					function checkTSType(val) {

						switch (val) {
							case "extra_heading_1":
								st_description.hide(300);
								st_bg_heading.hide(300);
								itens_values.hide(300);
								break;
							case "extra_heading_2":
								st_description.show(300);
								st_bg_heading.show(300);
								itens_values.show(300);
								break;

							case "extra_heading_3":
								st_description.show(300);
								st_bg_heading.show(300);
								itens_values.hide(300);
								break;
						}

					}

				}

				//App Showcase type

				if (jQuery('input[name="app_showcase_type"]').length) {
					var app_showcase_type = jQuery('input[name="app_showcase_type"]').val(),
						values_s_label = $('div[data-vc-shortcode-param-name="values_s_label"]'),
						values_description = $('div[data-vc-shortcode-param-name="values_description"]'),
						values_number = $('div[data-vc-shortcode-param-name="values_number"]'),
						values_arrow_pointer = $('div[data-vc-shortcode-param-name="values_arrow_pointer"]'),
						caption = $('div[data-vc-shortcode-param-name="caption"]'),
						icon_option = $('.icon_option');

					checkAppType(app_showcase_type);

					jQuery('input[name="app_showcase_type"]').on('change', function () {
						var $this = $(this),
							val = $this.val();
						checkAppType(val);
					});

					function checkAppType(val) {

						switch (val) {
							case "ipad":
								values_s_label.show(300);
								values_description.show(300);
								values_number.hide(300);
								values_arrow_pointer.hide(300);
								icon_option.show(300);
								caption.show(300);
								break;
							case "iphone_lined":
								values_s_label.hide(300);
								values_description.show(300);
								values_number.hide(300);
								values_arrow_pointer.show(300);
								icon_option.show(300);
								caption.hide(300);
								break;
							case "iphone_simple":
								values_s_label.show(300);
								values_description.hide(300);
								values_number.show(300);
								values_arrow_pointer.hide(300);
								icon_option.hide(300);
								caption.hide(300);
								break;
							case "notebook":
								values_s_label.hide(300);
								values_description.show(300);
								values_number.show(300);
								values_arrow_pointer.hide(300);
								icon_option.hide(300);
								caption.hide(300);
								break;

						}

					}

				}

				//Progress circle type

				if (jQuery('input[name="progress_circle_type"]').length) {
					var progress_circle_type = jQuery('input[name="progress_circle_type"]').val(),
						icon_option = $('.icon_option');

					checkPCType(progress_circle_type);

					jQuery('input[name="progress_circle_type"]').on('change', function () {
						var $this = $(this),
							val = $this.val();
						checkPCType(val);
					});

					function checkPCType(val) {

						switch (val) {
							case "minimal":
							case "light":
							case "triangled":
							case "vertical":
								icon_option.hide(300);
								break;
							case "two_circles":
							case "icon":
								icon_option.show(300);
								break;
						}

					}

				}

				//Testimonials type

				if (jQuery('input[name="testimonials_type"]').length) {
					var testimonials_type = jQuery('input[name="testimonials_type"]').val(),
						reviews_title = $('div[data-vc-shortcode-param-name="reviews_title"]'),
						link_text = $('div[data-vc-shortcode-param-name="link_text"]'),
						video_review_link_text = $('div[data-vc-shortcode-param-name="video_review_link_text"]'),
						bg_image = $('div[data-vc-shortcode-param-name="bg_image"]'),
						bg_head = bg_image.prev(),
						bg_type = $('div[data-vc-shortcode-param-name="bg_type"]');

					setTimeout(function () {
						checkTestimonialsType(testimonials_type);
					}, 700);

					checkTestimonialsType(testimonials_type);

					jQuery('input[name="testimonials_type"]').on('change', function () {
						var $this = $(this),
							val = $this.val();
						checkTestimonialsType(val);
					});

					function checkTestimonialsType(val) {

						switch (val) {
							case "dash":
								link_text.show(300);
								reviews_title.hide(300);
								bg_image.hide(300);
								bg_type.hide(300);
								bg_head.hide(300);
								video_review_link_text.hide(300);
								break;

							case "type_1":
								reviews_title.hide(300);
								link_text.hide(300);
								bg_image.hide(300);
								bg_type.hide(300);
								bg_head.hide(300);
								video_review_link_text.show(300);
								break;

							case "type_2":
							case "type_3":
							case "type_4":
								reviews_title.hide(300);
								link_text.hide(300);
								bg_image.hide(300);
								bg_type.hide(300);
								bg_head.hide(300);
								video_review_link_text.hide(300);
								break;

							case "type_5":
								reviews_title.show(300);
								link_text.hide(300);
								bg_image.hide(300);
								bg_type.hide(300);
								bg_head.hide(300);
								video_review_link_text.hide(300);
								break;

							case "double":
								reviews_title.hide(300);
								link_text.hide(300);
								bg_image.show(300);
								bg_type.show(300);
								bg_head.show(300);
								video_review_link_text.hide(300);
								break;

							case "layered_horizontal":
							case "layered_vertical":
							case "circle":
								reviews_title.hide(300);
								link_text.hide(300);
								bg_image.hide(300);
								bg_type.hide(300);
								bg_head.hide(300);
								video_review_link_text.hide(300);
								break;
						}

					}

				}

				//Counter type

				if (jQuery('input[name="counter_type"]').length) {
					var counter_type = jQuery('input[name="counter_type"]').val(),
						icon_option = $('.icon_option'),
						max_count = $('div[data-vc-shortcode-param-name="max_count"]');

					checkCounterType(counter_type);

					jQuery('input[name="counter_type"]').on('change', function () {
						var $this = $(this),
							val = $this.val();
						checkCounterType(val);
					});

					function checkCounterType(val) {

						switch (val) {
							case "filled":
								icon_option.hide(300);
								max_count.show(300);
								break;
							case "invertible":
							case "clean":
							case "roller":
							case "airport":
							case "gradient":
								icon_option.hide(300);
								max_count.hide(300);
								break;
							case "icon":
								icon_option.show(300);
								max_count.hide(300);
								break;
						}

					}

				}

				//Panel content type

				if (jQuery('input[name="panels_type"]').length) {
					var panels_type = jQuery('input[name="panels_type"]').val(),
						bg_image = $('div[data-vc-shortcode-param-name="bg_image"]'),
						p_description = $('div[data-vc-shortcode-param-name="p_description"]');

					checkPanelsType(panels_type);

					jQuery('input[name="panels_type"]').on('change', function () {
						var $this = $(this),
							val = $this.val();
						checkPanelsType(val);
					});

					function checkPanelsType(val) {

						switch (val) {
							case "image":
								bg_image.show(300);
								p_description.show(300);
								break;
							case "info_block":
								bg_image.hide(300);
								p_description.hide(300);
								break;
							default:
								bg_image.hide(300);
								p_description.show(300);
								break;
						}

					}

				}

				//Social block type

				if (jQuery('input[name="social_block_type"]').length) {
					var social_block_type = jQuery('input[name="social_block_type"]').val(),
						follow_text = $('div[data-vc-shortcode-param-name="follow_text"]');

					checkSBType(social_block_type);

					jQuery('input[name="social_block_type"]').on('change', function () {
						var $this = $(this),
							val = $this.val();
						checkSBType(val);
					});

					function checkSBType(val) {

						switch (val) {
							case "circle":
							case "round":
							case "honeycomb":
							case "double":
								follow_text.show(300);
								break;

							case "gradient":
							case "square":
								follow_text.hide(300);
								break;
						}
					}

				}

				//Switch Steps

				if (jQuery('input[name="steps_type"]').length) {
					var steps_type = jQuery('input[name="steps_type"]').val(),
						values_title = $('div[data-vc-shortcode-param-name="values_title"]'),
						values_description = $('div[data-vc-shortcode-param-name="values_description"]'),
						values_icon_bg = $('div[data-vc-shortcode-param-name="values_icon_bg"]'),
						values_btn_icon_type = $('div[data-vc-shortcode-param-name="values_btn_icon_type"]'),
						values_icon_fontawesome = $('div[data-vc-shortcode-param-name="values_icon_fontawesome"]'),
						values_icon_openiconic = $('div[data-vc-shortcode-param-name="values_icon_openiconic"]'),
						values_icon_typicons = $('div[data-vc-shortcode-param-name="values_icon_typicons"]'),
						values_icon_entypo = $('div[data-vc-shortcode-param-name="values_icon_entypo"]'),
						values_icon_linecons = $('div[data-vc-shortcode-param-name="values_icon_linecons"]'),
						values_icon_monosocial = $('div[data-vc-shortcode-param-name="values_icon_monosocial"]'),
						values_brs_btn_icon = $('div[data-vc-shortcode-param-name="values_brs_btn_icon"]');

					checkStepsType(steps_type);

					jQuery('input[name="steps_type"]').on('change', function () {
						var $this = $(this),
							val = $this.val();
						checkStepsType(val);
					});

					function checkStepsType(val) {

						switch (val) {
							case "gradient":
							case "history":
								values_title.show(300);
								values_description.show(300);

								values_btn_icon_type.hide(300);
								values_icon_fontawesome.hide(300);
								values_icon_openiconic.hide(300);
								values_icon_typicons.hide(300);
								values_icon_entypo.hide(300);
								values_icon_linecons.hide(300);
								values_icon_monosocial.hide(300);
								values_brs_btn_icon.hide(300);
								values_icon_bg.hide(300);

								break;

							case "checkers":

								values_title.hide(300);
								values_description.hide(300);

								values_btn_icon_type.hide(300);
								values_icon_fontawesome.hide(300);
								values_icon_openiconic.hide(300);
								values_icon_typicons.hide(300);
								values_icon_entypo.hide(300);
								values_icon_linecons.hide(300);
								values_icon_monosocial.hide(300);
								values_brs_btn_icon.hide(300);
								values_icon_bg.hide(300);

								break;

							case "squared":

								values_title.show(300);
								values_description.show(300);
								values_icon_bg.show(300);

								values_btn_icon_type.show(300);
								values_icon_fontawesome.show(300);
								values_icon_openiconic.show(300);
								values_icon_typicons.show(300);
								values_icon_entypo.show(300);
								values_icon_linecons.show(300);
								values_icon_monosocial.show(300);
								values_brs_btn_icon.show(300);
								break;

							case "light":

								values_title.show(300);
								values_description.show(300);
								values_icon_bg.hide(300);

								values_btn_icon_type.show(300);
								values_icon_fontawesome.show(300);
								values_icon_openiconic.show(300);
								values_icon_typicons.show(300);
								values_icon_entypo.show(300);
								values_icon_linecons.show(300);
								values_icon_monosocial.show(300);
								values_brs_btn_icon.show(300);
								break;

						}

					}

				}


				//Switch Progress-bar type
				if (jQuery('input[name="progress_bar_type"]').length) {
					var progress_bar_type = jQuery('input[name="progress_bar_type"]').val(),
						color_1 = $('div[data-vc-shortcode-param-name="pb_color_1"]'),
						color_2 = $('div[data-vc-shortcode-param-name="pb_color_2"]');

					checkPBType(progress_bar_type);

					jQuery('input[name="progress_bar_type"]').on('change', function () {
						var $this = $(this),
							val = $this.val();
						checkPBType(val);
					});

					function checkPBType(val) {

						switch (val) {
							case "gradient":
							case "triangle":
							case "round":
								color_1.show(300);
								color_2.show(300);
								break;
							case "wide":
							case "doted":
							case "stripe":
							case "count":
							case "squared":
							case "transparent":
							case "inline":
							case "classic":
							case "minimal":
							case "light":
							case "thin":
							case "curve":
								color_1.show(300);
								color_2.hide(300);
								break;
							default:
								color_1.show(300);
								color_2.show(300);
								break;
						}

					}

				}

				//Switch Countdown Type
				if (jQuery('input[name="countdown_type"]').length) {
					var countdown_type = jQuery('input[name="countdown_type"]').val(),
						size = $('div[data-vc-shortcode-param-name="size"]');

					checkCDType(countdown_type);

					jQuery('input[name="countdown_type"]').on('change', function () {
						var $this = $(this),
							val = $this.val();
						checkCDType(val);
					});

					function checkCDType(val) {

						switch (val) {
							case "large":
								size.show(300);
								break;
							default:
								size.hide(300);
								break;
						}
					}
				}

				//Switch Sequence type
				if (jQuery('input[name="sequence_type"]').length) {
					var sequence_type = jQuery('input[name="sequence_type"]').val(),
						values_btn_icon_type = $('div[data-vc-shortcode-param-name="values_btn_icon_type"]'),
						values_icon_fontawesome = $('div[data-vc-shortcode-param-name="values_icon_fontawesome"]'),
						values_icon_openiconic = $('div[data-vc-shortcode-param-name="values_icon_openiconic"]'),
						values_icon_typicons = $('div[data-vc-shortcode-param-name="values_icon_typicons"]'),
						values_icon_entypo = $('div[data-vc-shortcode-param-name="values_icon_entypo"]'),
						values_icon_linecons = $('div[data-vc-shortcode-param-name="values_icon_linecons"]'),
						values_icon_monosocial = $('div[data-vc-shortcode-param-name="values_icon_monosocial"]'),
						values_brs_btn_icon = $('div[data-vc-shortcode-param-name="values_brs_btn_icon"]'),
						values_number = $('div[data-vc-shortcode-param-name="values_number"]'),
						values_second_title = $('div[data-vc-shortcode-param-name="values_second_title"]'),
						values_link_title = $('div[data-vc-shortcode-param-name="values_link_title"]'),
						values_link_url = $('div[data-vc-shortcode-param-name="values_link_url"]'),
						values_bg_image = $('div[data-vc-shortcode-param-name="values_bg_image"]');

					checkSequenceType(sequence_type);

					jQuery('input[name="sequence_type"]').on('change', function () {
						var $this = $(this),
							val = $this.val();
						checkSequenceType(val);
					});

					function checkSequenceType(val) {

						switch (val) {
							case "gradient":
								values_btn_icon_type.show(300);
								values_icon_fontawesome.show(300);
								values_icon_openiconic.show(300);
								values_icon_typicons.show(300);
								values_icon_entypo.show(300);
								values_icon_linecons.show(300);
								values_icon_monosocial.show(300);
								values_brs_btn_icon.show(300);
								values_number.hide(300);
								values_second_title.hide(300);
								values_link_title.hide(300);
								values_link_url.hide(300);
								values_bg_image.show(300);

								break;
							case "linear":
							case "arrow":
								values_btn_icon_type.show(300);
								values_icon_fontawesome.show(300);
								values_icon_openiconic.show(300);
								values_icon_typicons.show(300);
								values_icon_entypo.show(300);
								values_icon_linecons.show(300);
								values_icon_monosocial.show(300);
								values_brs_btn_icon.show(300);
								values_number.hide(300);
								values_second_title.hide(300);
								values_link_title.hide(300);
								values_link_url.hide(300);
								values_bg_image.hide(300);
								break;
							case "overlay":
								values_btn_icon_type.show(300);
								values_icon_fontawesome.show(300);
								values_icon_openiconic.show(300);
								values_icon_typicons.show(300);
								values_icon_entypo.show(300);
								values_icon_linecons.show(300);
								values_icon_monosocial.show(300);
								values_brs_btn_icon.show(300);
								values_number.hide(300);
								values_second_title.hide(300);
								values_link_title.show(300);
								values_link_url.show(300);
								values_bg_image.hide(300);
								break;
							case "triangle":
								values_btn_icon_type.show(300);
								values_icon_fontawesome.show(300);
								values_icon_openiconic.show(300);
								values_icon_typicons.show(300);
								values_icon_entypo.show(300);
								values_icon_linecons.show(300);
								values_icon_monosocial.show(300);
								values_brs_btn_icon.show(300);
								values_number.hide(300);
								values_second_title.hide(300);
								values_link_title.show(300);
								values_link_url.show(300);
								values_bg_image.show(300);
								break;
							case "strict":
								values_btn_icon_type.hide(300);
								values_icon_fontawesome.hide(300);
								values_icon_openiconic.hide(300);
								values_icon_typicons.hide(300);
								values_icon_entypo.hide(300);
								values_icon_linecons.hide(300);
								values_icon_monosocial.hide(300);
								values_brs_btn_icon.hide(300);
								values_number.show(300);
								values_second_title.show(300);
								values_link_title.show(300);
								values_link_url.show(300);
								values_bg_image.show(300);

								break;
						}

					}

				}

				//Switch CTA type
				if (jQuery('input[name="call_to_action_type"]').length) {
					var call_to_action_type = jQuery('input[name="call_to_action_type"]').val(),
						multiple_title = $('div[data-vc-shortcode-param-name="multiple_title"]'),
						cta_hot = $('div[data-vc-shortcode-param-name="cta_hot"]'),
						values = $('div[data-vc-shortcode-param-name="values"]'),
						cta_description = $('div[data-vc-shortcode-param-name="cta_description"]'),
						cta_description_hading = cta_description.prev(),
						cta_link_url = $('div[data-vc-shortcode-param-name="cta_link_url"]'),
						cta_link_title = $('div[data-vc-shortcode-param-name="cta_link_title"]'),
						hide_button = $('div[data-vc-shortcode-param-name="hide_button"]'),
						without_border_radius = $('div[data-vc-shortcode-param-name="without_border_radius"]'),
						with_fixed_bg = $('div[data-vc-shortcode-param-name="with_fixed_bg"]'),
						cta_bg_image = $('div[data-vc-shortcode-param-name="cta_bg_image"]'),
						cta_bg_image_heading = cta_bg_image.prev(),
						cta_video = $('div[data-vc-shortcode-param-name="cta_video"]'),
						cta_video_heading = cta_video.prev(),
						type = $('div[data-vc-shortcode-param-name="type"]'),
						icon_type_heading = type.prev(),
						icon_fontawesome = $('div[data-vc-shortcode-param-name="icon_fontawesome"]'),
						icon_openiconic = $('div[data-vc-shortcode-param-name="icon_openiconic"]'),
						icon_typicons = $('div[data-vc-shortcode-param-name="icon_typicons"]'),
						icon_entypo = $('div[data-vc-shortcode-param-name="icon_entypo"]'),
						icon_linecons = $('div[data-vc-shortcode-param-name="icon_linecons"]'),
						icon_monosocial = $('div[data-vc-shortcode-param-name="icon_monosocial"]');

					checkCTAType(call_to_action_type);

					jQuery('input[name="call_to_action_type"]').on('change', function () {
						var $this = $(this),
							val = $this.val();
						checkCTAType(val);
					});

					function checkCTAType(val) {

						switch (val) {
							case "container":
							case "minimal":
								multiple_title.hide(300);
								cta_hot.hide(300);
								values.hide(300);
								cta_description.show(300);
								cta_description_hading.show(300);
								cta_link_url.show(300);
								cta_link_title.show(300);
								cta_bg_image.show(300);
								cta_bg_image_heading.show(300);
								cta_video.hide(300);
								cta_video_heading.hide(300);
								icon_type_heading.hide(300);
								type.hide(300);
								icon_fontawesome.hide(300);
								icon_openiconic.hide(300);
								icon_typicons.hide(300);
								icon_entypo.hide(300);
								icon_linecons.hide(300);
								icon_monosocial.hide(300);
								hide_button.show(300);
								without_border_radius.show(300);
								with_fixed_bg.hide(300);
								break;
							case "hot":
								multiple_title.show(300);
								cta_hot.show(300);
								values.show(300);
								cta_description.hide(300);
								cta_description_hading.hide(300);
								cta_link_url.show(300);
								cta_link_title.show(300);
								cta_bg_image.show(300);
								cta_bg_image_heading.show(300);
								cta_video.hide(300);
								cta_video_heading.hide(300);
								icon_type_heading.hide(300);
								type.hide(300);
								icon_fontawesome.hide(300);
								icon_openiconic.hide(300);
								icon_typicons.hide(300);
								icon_entypo.hide(300);
								icon_linecons.hide(300);
								icon_monosocial.hide(300);
								hide_button.show(300);
								without_border_radius.hide(300);
								with_fixed_bg.show(300);

								break;
							case "outer":
								multiple_title.hide(300);
								cta_hot.hide(300);
								values.hide(300);
								cta_description.show(300);
								cta_description_hading.show(300);
								cta_link_url.show(300);
								cta_link_title.show(300);
								cta_bg_image.show(300);
								cta_bg_image_heading.show(300);
								cta_video.hide(300);
								cta_video_heading.hide(300);
								type.hide(300);
								icon_type_heading.hide(300);
								icon_fontawesome.hide(300);
								icon_openiconic.hide(300);
								icon_typicons.hide(300);
								icon_entypo.hide(300);
								icon_linecons.hide(300);
								icon_monosocial.hide(300);
								hide_button.hide(300);
								without_border_radius.hide(300);
								with_fixed_bg.hide(300);
								break;
							case "email":
								multiple_title.hide(300);
								cta_hot.hide(300);
								values.hide(300);
								cta_description.show(300);
								cta_description_hading.show(300);
								cta_link_url.hide(300);
								cta_link_title.hide(300);
								cta_bg_image.hide(300);
								cta_bg_image_heading.hide(300);
								cta_video.hide(300);
								cta_video_heading.hide(300);
								icon_type_heading.hide(300);
								type.hide(300);
								icon_fontawesome.hide(300);
								icon_openiconic.hide(300);
								icon_typicons.hide(300);
								icon_entypo.hide(300);
								icon_linecons.hide(300);
								icon_monosocial.hide(300);
								hide_button.hide(300);
								without_border_radius.hide(300);
								with_fixed_bg.hide(300);
								break;
							case "trend":
								multiple_title.show(300);
								cta_hot.hide(300);
								values.show(300);
								cta_description.show(300);
								cta_description_hading.show(300);
								cta_link_url.show(300);
								cta_link_title.hide(300);
								cta_bg_image.show(300);
								cta_bg_image_heading.show(300);
								cta_video.hide(300);
								cta_video_heading.hide(300);
								icon_type_heading.hide(300);
								type.hide(300);
								icon_fontawesome.hide(300);
								icon_openiconic.hide(300);
								icon_typicons.hide(300);
								icon_entypo.hide(300);
								icon_linecons.hide(300);
								icon_monosocial.hide(300);
								hide_button.hide(300);
								without_border_radius.hide(300);
								with_fixed_bg.hide(300);
								break;
							case "video":
								multiple_title.hide(300);
								cta_hot.hide(300);
								values.hide(300);
								cta_description.hide(300);
								cta_description_hading.hide(300);
								cta_link_url.show(300);
								cta_link_title.show(300);
								cta_bg_image.show(300);
								cta_bg_image_heading.show(300);
								cta_video.show(300);
								cta_video_heading.show(300);
								type.hide(300);
								icon_type_heading.hide(300);
								icon_fontawesome.hide(300);
								icon_openiconic.hide(300);
								icon_typicons.hide(300);
								icon_entypo.hide(300);
								icon_linecons.hide(300);
								icon_monosocial.hide(300);
								hide_button.hide(300);
								without_border_radius.hide(300);
								with_fixed_bg.hide(300);
								break;
							case "image":
								multiple_title.show(300);
								cta_hot.hide(300);
								values.show(300);
								cta_description.hide(300);
								cta_description_hading.hide(300);
								cta_link_url.show(300);
								cta_link_title.show(300);
								cta_bg_image.show(300);
								cta_bg_image_heading.show(300);
								cta_video.hide(300);
								cta_video_heading.hide(300);
								type.hide(300);
								icon_type_heading.hide(300);
								icon_fontawesome.hide(300);
								icon_openiconic.hide(300);
								icon_typicons.hide(300);
								icon_entypo.hide(300);
								icon_linecons.hide(300);
								icon_monosocial.hide(300);
								hide_button.hide(300);
								without_border_radius.hide(300);
								with_fixed_bg.hide(300);
								break;
							case "icon":
								multiple_title.hide(300);
								cta_hot.hide(300);
								values.hide(300);
								cta_description.show(300);
								cta_description_hading.show(300);
								cta_link_url.show(300);
								cta_link_title.show(300);
								cta_bg_image.hide(300);
								cta_bg_image_heading.hide(300);
								cta_video.hide(300);
								cta_video_heading.hide(300);
								type.show(300);
								icon_type_heading.show(300);
								icon_fontawesome.show(300);
								icon_openiconic.show(300);
								icon_typicons.show(300);
								icon_entypo.show(300);
								icon_linecons.show(300);
								icon_monosocial.show(300);
								hide_button.hide(300);
								without_border_radius.hide(300);
								with_fixed_bg.hide(300);
								break;
						}

					}

				}

				// Switch row type
				if (jQuery('input[name="row_type"]').length) {

					var row_type = $('input[name="row_type"]').val(),
						row_color_f = $('div[data-vc-shortcode-param-name="row_color_f"]'),
						row_color_s = $('div[data-vc-shortcode-param-name="row_color_s"]');

					checkRowType(row_type);

					jQuery('input[name="row_type"]').on('change', function () {
						var $this = $(this),
							val = $this.val();

						checkRowType(val);
					});

					function checkRowType(val) {
						switch (val) {
							case "gradient_corner":
							case "gradient_circle":
							case "gradient_triangle":
							case "gradient_round":
							case "gradient_wing":
							case "double_triangle":
							case "gradient_double_triangle":
								row_color_f.show(300);
								row_color_s.show(300);

								break;

							default:
								row_color_f.hide(300);
								row_color_s.hide(300);

								break;
						}

					}

				}

				// Tooltips
				jQuery.fn.tooltips = function (el) {

					var $tooltip,
						$body = $('body'),
						$el;

					return this.each(function (i, el) {
						$el = $(el).attr("data-tooltip", i);

						var $tooltip = $('<div class="tooltip" data-tooltip="' + i + '">' + $el.attr('atr-title') + '</div>').appendTo($el);
						var linkPosition = $el.position();
						$tooltip.css({
							//top: linkPosition.top - $tooltip.outerHeight() - 15,
							//left: linkPosition.left - ($tooltip.width()/2)
						});

						$el.removeAttr("atr-title")
							.hover(function () {
								$el = $(this);
								$tooltip = $('div[data-tooltip=' + $el.data('tooltip') + ']');
								var linkPosition = $el.position();
								$tooltip.css({
									//top: linkPosition.top - ($tooltip.outerHeight()) / 2 - 5,
									top: linkPosition.top - 40,
									//left: linkPosition.left - ($tooltip.width()/2) + 25
									left: linkPosition.left
								});
								$tooltip.addClass("active");

							}, function () {

								$el = $(this);
								$tooltip = $('div[data-tooltip=' + $el.data('tooltip') + ']').addClass("out");
								setTimeout(function () {
									$tooltip.removeClass("active").removeClass("out");
								}, 300);
							});
					});

				}

				jQuery(".brs-radio-wrapper div[atr-title]").tooltips();


				// Live updates
				if ($('.vc_navgar-frontend').length) {

					addExpander();
					addBtnLive();
					var trigger_save = false;
					if ((brs_live_mode !== undefined) && (brs_live_mode == true || brs_live_mode == 'true')) {
						setWindowSize();
						//addExpander();
						trigger_save = true;
						$('.vc_ui-panel-header-heading').hide(300);
					}

					var $live_btn = $('.vc_active').find('.brs-live-mode-checkbox');
					$live_btn.on('change', function () {
						var $this = $(this);

						if ($this.is(':checked')) {
							setWindowSize();
							trigger_save = true;
							$('.vc_ui-panel-header-heading').hide(300);
						} else {
							trigger_save = false;
							$('.vc_ui-panel-header-heading').show(300);
							//removeExpander();
						}
					});

					$('.vc_active .vc_edit-form-tab-control').on('click', function () {
						if (trigger_save == true) {
							setTimeout(function () {
								setWindowSize();
							}, 500);
						}
					});


					$(".vc_ui-panel-window-inner .wpb_vc_param_value:not('.iconpicker_field')").on('keyup change', function () {
						self.change_form = true;
					});
					jQuery(".vc_ui-panel-window-inner .brs-radio-wrapper").on("click", "img", function (e) {
						self.change_form = true;
					});

					if (jQuery('input[name="testimonials_type"]').length) {
						setTimeout(function () {
							self.change_form = true;
						}, 4000);

					}
					$('.iconpicker_field').each(function () {
						var $this = $(this);
						self.if_hidden_change($this, function () {
							self.change_form = true;
						});

					});

					jQuery(".brs-colors-wrapper").on("click", ".color", function (e) {
						self.change_form = true;
					});

					var t = setInterval(saveForm, 1000);

					function saveForm() {
						if (self.change_form == true && trigger_save == true) {
							$('.vc_active [data-vc-ui-element="button-save"]').trigger("click");
							self.change_form = false;
						}
					}

					function setWindowSize() {
						var $window = $('.vc_ui-panel-window.vc_active');
						var left = $(window).width() - 405;

						if ($('.post-type-brs_header').length) {
							var top = $(window).height() - 400;
							$window.css({
								'height': '400px',
								'width': '100%',
								'bottom': '0px',
								'left': '0px',
								'top': top + 'px'
							});
						} else {
							$window.css({
								'height': '100%',
								'max-height': '100%',
								'width': '400px',
								'top': '0px',
								'left': left + 'px'
							});
						}
					}

					function addExpander() {
						var option = $('.vc_active .vc_shortcode-param');
						option.each(function (i) {
							var $this = $(this);
							if ($this.attr('class').indexOf('wpb_el_type_brs_title') != -1) {
								$this.addClass('brs_heading');
							}
						});

						var heading = $('.vc_active .brs_heading');

						heading.each(function () {
							var $this = $(this),
								content = $this.nextUntil('.brs_heading'),
								expander = '<span class="accordion-expander"><i class="fa fa-plus"></i><i class="fa fa-minus"></i></span>';

							$this.find('.wpb_element_label').append(expander);

							setTimeout(function () {
								content.slideUp(300);
							}, 200);

						});

						heading.on('click', function () {
							var $this = $(this),
								content = $this.nextUntil('.brs_heading');

							if ($this.attr('class').indexOf('active') != -1) {
								$this.removeClass('active');
								content.slideUp(300);
							} else {
								var $current_active = $('.brs_heading.active');
								$('.brs_heading.active').removeClass('active');
								$current_active.nextUntil('.brs_heading').slideUp(300);

								$this.addClass('active');
								content.slideDown(300);
							}
						});

						if (!$('.vc_active .dt_vc_row-params_switch').length) {
							setTimeout(function () {
								$('.vc_active .brs_heading:first').trigger('click');
							}, 300);
						}

					}

					function removeExpander() {
						var option = $('.vc_shortcode-param');
						option.each(function () {
							var $this = $(this);

							if ($this.attr('class').indexOf('brs_heading') != -1) {
								$this.removeClass('brs_heading');
							}
						});
					}

					function addBtnLive() {

						if ((brs_live_mode !== undefined) && (brs_live_mode == true || brs_live_mode == 'true')) {
							var $checked = 'checked="checked"';
						} else {
							var $checked = '';
						}

						var $brs_panel = $('#vc_ui-panel-edit-element'),
							$live_mode_checkbox = $('<label class="brs-live-mode-switch"><input type="checkbox" class="brs-live-mode-checkbox" ' + $checked + ' value="true">LIVE<span><i class="fa fa-power-off"> </i></span></label>'),
							$live_mode;

						$brs_panel.find('.brs-live-mode-switch').remove();
						$brs_panel.find('.vc_ui-panel-header-controls').prepend($live_mode_checkbox);
						$live_mode = $live_mode_checkbox.find('.brs-live-mode-checkbox');

						$live_mode.on('change', function () {
							var $this = $(this);
							if ($this.is(':checked')) {
								brs_live_mode = 'true';
								$checked = 'checked="checked"';
							} else {
								brs_live_mode = 'false';
								//removeExpander();
							}
							var data = {
								action: "add_live_mode",
								value: brs_live_mode
							};

							$.post(ajaxurl, data, function (response) {
							});
						});
					}
				} else {
					self.set_def_window_size();
				}


			}(jQuery));
		}

	};
	return self;
};

var brs_vc_admin_script = null;
brs_vc_admin_script = new BRS_VC_ADMIN_SCRIPT();
brs_vc_admin_script.init();
