(function ($) {

	window.InlineShortcodeView_vc_column_text = window.InlineShortcodeView.extend({
		initialize: function (options) {
			window.InlineShortcodeView_vc_column_text.__super__.initialize.call(this, options);
			_.bindAll(this, 'setupEditor', 'updateContent');
		},
		setupEditor: function (ed) {
			ed.on('keyup', this.updateContent)
		},
		updateContent: function () {
			var params = this.model.get('params');
			params.content = tinyMCE.activeEditor.getContent();
			this.model.save({params: params}, {silent: true});
		},
		render: function () {
			window.InlineShortcodeView_vc_column_text.__super__.render.call(this);

			vc.frame_window.vc_iframe.addActivity(function () {
				// this.createSocIcons();
			});

			return this;
		},
		parentChanged: function () {
			// vc.frame_window.createSocIcons();
		}
	});

  var shortcodes = ['content_slider', 'counter', 'carousel', 'our_team', 'pricing_table', 'flip_box', 'testimonials', 'tabs', 'contact_form', 'map', 'portfolio', 'gallery_sliders', 'data_table', 'woo_tiles', 'woo_product_row'];
  for (var key in shortcodes) {

    var name = 'InlineShortcodeView_brs_' + shortcodes[key];
    window[name] = window.InlineShortcodeView.extend({
      render: function () {
        window[name].__super__.render.call(this);
        var data_model_id = this.model.attributes.id;
        vc.frame_window.vc_iframe.addActivity(function () {
          $('#vc_inline-frame')[0].contentWindow.jQuery('[data-model-id="' + data_model_id + '"]').addClass('trigger-behaviors').trigger('trigger-behaviors');
        });
        return this;
      }
    });

  }


})(window.jQuery);