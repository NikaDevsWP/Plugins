
(function ($) {

  /*
   * Mail CFA
   */

  $(function () {

    $('.cfa_subscr__form').on('submit', function() {
      SubmitCFA(this);
      return false;
    });

    $(document).on('click', '.add_to_wishlist', function(){
      var $this = $(this),
        id  = $this.attr('data-product-id');
      var data = {
        action: "add_to_wishlist",
        id:id
      };
      jQuery.post(brs_l10n.ajaxurl, data, function(response) {
        if(response){
          $this.removeClass('add_to_wishlist');
          $this.addClass('remove_from_wishlist');
        }
      });

      return false;
    });

    $(document).on('click', '.remove_from_wishlist', function(){

      var $this = $(this),
        id  = $this.attr('data-product-id');
      var data = {
        action: "remove_from_wishlist",
        id:id
      };
      jQuery.post(brs_l10n.ajaxurl, data, function(response) {
        if(response){
          $this.removeClass('remove_from_wishlist');
          $this.addClass('add_to_wishlist');
        }
      });

      return false;
    });


    $(document).on('click', '.add_to_compare', function(){
      var $this = $(this),
        id  = $this.attr('data-product-id');
      var data = {
        action: "add_to_compare",
        id:id
      };
      jQuery.post(brs_l10n.ajaxurl, data, function(response) {
        if(response){
          $this.removeClass('add_to_compare');
          $this.addClass('remove_from_compare');
        }
      });

      return false;
    });

    $(document).on('click', '.remove_from_compare', function(){

      var $this = $(this),
        id  = $this.attr('data-product-id');
      var data = {
        action: "remove_from_compare",
        id:id
      };
      jQuery.post(brs_l10n.ajaxurl, data, function(response) {
        if(response){
          $this.removeClass('remove_from_compare');
          $this.addClass('add_to_compare');
        }
      });

      return false;
    });

  });

  function SubmitCFA($this){

    $response = $($this).find(jQuery(".cfa_form_responce"));
    $response.find("ul").html("");
    $response.find("ul").removeClass();

    var data = {
      action: "cfa_submit",
      values: $($this).serialize()
    };
    jQuery.post(brs_l10n.ajaxurl, data, function(response) {
      response = jQuery.parseJSON(response);
      if (response.is_errors) {
        $($this).find(".cfa_form_responce ul").addClass("error").append('<li>' + response.is_errors + '</li>');
        $response.show(450);
      } else {
        $($this).find(".cfa_form_responce ul").addClass("success").append('<li>' + response.info + '</li>');
        $response.show(450).delay(1800).hide(400);
      }

    });

  }


}(jQuery));
