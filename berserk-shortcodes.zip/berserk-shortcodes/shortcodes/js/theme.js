(function ($) {

	// Portfolio Isotope
	Berserk.behaviors.portfolio_isotope_cols_init = {
		attach: function (context, settings) {

			if ($('.brk-grid_portfolio_isotope').length) {

				var col_algoritm_arr = ['col', 'col_w2_h2', 'col', 'col', 'col_w2', 'col_h2', 'col_w2', 'col', 'col'];
				$('.brk-grid__item').each(function (i, el) {
					if (i > col_algoritm_arr.length) {
						var j = Math.floor(i / col_algoritm_arr.length);
						i = (i - (col_algoritm_arr.length * j));
					}
					var col = col_algoritm_arr[i];
					var $this = $(this);

					switch (col) {
						case "col_w2_h2":
							$this.addClass('brk-grid__item_width-2');
							$this.addClass('brk-grid__item_height-2');

							break;
						case "col_w2":
							$this.addClass('brk-grid__item_width-2');
							break;
						case "col_h2":
							$this.addClass('brk-grid__item_height-2');
							break;
					}
					if (col == 'col2') {
						$this.addClass('brk-grid-fitrows__item_width-2');
					}
				});
			}
		}
	}
	Berserk.behaviors.portfolio_isotope_cols_init.attach();

// Portfolio Isotope Alternate
	Berserk.behaviors.portfolio_isotope_alternate_cols_init = {
		attach: function (context, settings) {

			if ($('.brk-grid_portfolio_isotope_2').length) {

				var col_algoritm_arr = ['col', 'col_w2_h2', 'col_h2', 'col_w2'];
				$('.brk-grid__item').each(function (i, el) {
					if (i > col_algoritm_arr.length) {
						var j = Math.floor(i / col_algoritm_arr.length);
						i = (i - (col_algoritm_arr.length * j));
					}
					var col = col_algoritm_arr[i];
					var $this = $(this);

					switch (col) {
						case "col_w2_h2":
							$this.addClass('brk-grid__item_width-2');
							$this.addClass('brk-grid__item_height-2');
							break;
						case "col_w2":
							$this.addClass('brk-grid__item_width-2');
							break;
						case "col_h2":
							$this.addClass('brk-grid__item_height-2');
							break;
					}
				});
			}
		}
	}
	Berserk.behaviors.portfolio_isotope_alternate_cols_init.attach();

	// Portfolio portfolio_swipe_card_cols_init

	Berserk.behaviors.portfolio_swipe_card_cols_init = {
		attach: function (context, settings) {

			if ($('.brk-grid_portfolio_swipe_card_masonry').length) {

				var col_algoritm_arr = ['col', 'col_h2', 'col', 'col', 'col_h2', 'col_w2'];
				$('.brk-grid__item').each(function (i, el) {
					if (i > col_algoritm_arr.length) {
						var j = Math.floor(i / col_algoritm_arr.length);
						i = (i - (col_algoritm_arr.length * j));
					}
					var col = col_algoritm_arr[i];
					var $this = $(this);

					switch (col) {
						case "col_w2_h2":
							$this.addClass('brk-grid__item_width-2');
							$this.addClass('brk-grid__item_height-2');
							break;
						case "col_w2":
							$this.addClass('brk-grid__item_width-2');
							break;
						case "col_h2":
							$this.addClass('brk-grid__item_height-2');
							break;
					}
				});
			}
		}
	}
	Berserk.behaviors.portfolio_swipe_card_cols_init.attach();

	//Portfolio ROW

	Berserk.behaviors.portfolio_row_cols_init = {
		attach: function (context, settings) {
			if ($('.brk-grid-fitrows').length) {

				var col_algoritm_arr = ['col1', 'col2', 'col2', 'col1', 'col1', 'col2', 'col1'];
				$('.brk-grid-fitrows__item').each(function (i, el) {
					if (i > col_algoritm_arr.length) {
						var j = Math.floor(i / col_algoritm_arr.length);
						i = (i - (col_algoritm_arr.length * j));
					}
					var col = col_algoritm_arr[i];
					var $this = $(this);
					if (col == 'col2') {
						$this.addClass('brk-grid-fitrows__item_width-2');
					}
				});
			}
		}
	}
	Berserk.behaviors.portfolio_row_cols_init.attach();

	/*
	 * Mail CFA
	 */

	$(function () {

		$('.brk-atts').each(function () {
			if (!$(this).data('more-posts')) {
				$(this).closest('.brk-js-parent').find('.brk-shortcode-pagination-ajax').hide();
			}
		});

		$('.brk-shortcode-pagination-ajax').click(function () {
			var $this = $(this);
			var atts = $this.next('.brk-atts').html();
			var data = {
				'action': 'brk_pagination',
				'shortcode': $this.data('shortcode'),
				'offset': $this.closest('.brk-js-parent').find('.brk-js-append > *').length,
				'numberposts': $this.data('numberposts'),
				'atts': JSON.parse(atts)
			};

			$.post(brs_l10n.ajaxurl, data, function (response) {
				var more_posts = $(response).find('.brk-atts').data('more-posts');
				if (!more_posts) {
					$this.hide();
				}

				response = $(response).find('.brk-js-append').html();

				$('.brk-grid').removeClass('rendered');

				$this.closest('.brk-js-parent').find('.brk-js-append').append(response);
				Berserk.attachBehaviors($this.closest('.brk-js-parent').parent());
				//Berserk.behaviors.portfolio_isotope_init.attach();

			});

			return false;
		});

		//Ajax


		// add/remove to Cart

		// Ajax delete product in the cart
		$(document).on('click', '.brk-mini-cart a.remove', function (e) {
			e.preventDefault();

			var product_id = $(this).attr("data-product_id"),
				cart_item_key = $(this).attr("data-cart_item_key"),
				product_container = $(this).parents('.brk-mini-cart__product');

			// Add loader
			product_container.block({
				message: null,
				overlayCSS: {
					cursor: 'none'
				}
			});

			$.ajax({
				type: 'POST',
				dataType: 'json',
				url: wc_add_to_cart_params.ajax_url,
				data: {
					action: "product_remove",
					product_id: product_id,
					cart_item_key: cart_item_key
				},
				success: function (response) {
					if (!response || response.error)
						return;

					var fragments = response.fragments;
					var cart_contents_count = response.cart_contents_count;

					// Replace fragments
					if (fragments) {
						$.each(fragments, function (key, value) {
							$(key).replaceWith(value);
						});
					}

					if (cart_contents_count) {
						$('.brk-mini-cart').find('span.brk-mini-cart__count').text(cart_contents_count);
					}
				}
			});
		});

		(function quantityProducts() {
			$(document).on('click', '.brk-quantity .brk-quantity__arrows', function (e) {
				var calc = $(this).parent().find(".brk-quantity__value");
				var id = calc.attr('data-product-id');
				var calcText = calc.val();
				var quantity;
				if ($(this).hasClass("minus") && calcText > 1) {
					calc.val(+calcText - 1);
					quantity = +calcText - 1;
				} else if ($(this).hasClass("plus")) {
					calc.val(+calcText + 1);
					quantity = +calcText + 1;
				}

				$.ajax({
					type: 'POST',
					dataType: 'json',
					url: wc_add_to_cart_params.ajax_url,
					data: {
						action: "cart_add_product_quantity",
						product_id: id,
						quantity: quantity
					},
					success: function (response) {

						if (!response || response.error)
							return;

						var cart_contents_count = response.cart_contents_count;

						if (cart_contents_count) {
							$('.brk-mini-cart').find('span.brk-mini-cart__count').text(cart_contents_count);
						}

					}
				});
			});
		})();

		Berserk.behaviors.brk_mini_cart_update = {
			attach: function (context, settings) {
				if ($('.brk-mini-cart.brk-header__item').length) {
					var $this = $('.brk-mini-cart.brk-header__item'),
						count_class = $this.attr('data-count_class');
					setTimeout(function () {
						$this.find('.brk-mini-cart__count').addClass(count_class);
					}, 1500);

				}
			}
		}
		Berserk.behaviors.brk_mini_cart_update.attach();

		$(document.body).on('added_to_cart', function () {
			Berserk.behaviors.brk_mini_cart_update.attach();
		});


		// Ajax delete product in the cart
		$(document).on('click', '.brk-mini-cart a.remove', function (e) {
			setTimeout(function(){
			Berserk.behaviors.brk_mini_cart_update.attach();
			},1500);
		});


		// Product listing filters

		if ($('.brk-product-filters').length) {

			// Price filter
			$('.brk-sc-price-slider__container').on('slidestop', function (event, ui) {
				var min, max;
				min = ui.values[0];
				max = ui.values[1];

				var data = {
					min_price: min,
					max_price: max,
				}
				ajaxDataFilter(data);

			});

			//Sort filter
			$('.brk-sc-sorting__sort-select select').on('change', function () {
				var val = $(this).val();
				var data = {
					filter_orderby: val
				}
				ajaxDataFilter(data);
			});

			//Count filter
			$('.brk-sc-sorting__show-count select').on('change', function () {
				var val = $(this).val();
				var data = {
					filter_items_per_page: val
				}
				ajaxDataFilter(data);
			});

			//Categories filter
			$('.brk-categories__list a').on('click', function () {
				var $this = $(this);
				var val = $this.attr('data-category');
				var data = {
					filter_category: val
				}
				ajaxDataFilter(data);

				$('.brk-categories__list a').each(function () {
					var $this = $(this);
					$this.removeClass('active');
				});

				$this.addClass('active');
				return false;
			});

			//Color filter
			$('.brk-color-filter__container a').on('click', function () {
				var $this = $(this);
				var val = $this.attr('data-color');

				var data = {
					filter_color: val
				}
				ajaxDataFilter(data);

				$('.brk-color-filter__container a').each(function () {
					var $this = $(this);
					$this.removeClass('active');
				});

				$this.addClass('active');
				return false;
			});

			//Brand filter
			$('.brk-brand-filter__container a').on('click', function () {
				var $this = $(this);
				var val = $this.attr('data-brand');

				var data = {
					filter_brand: val
				}
				ajaxDataFilter(data);

				$('.brk-brand-filter__container a').each(function () {
					var $this = $(this);
					$this.removeClass('active');
				});

				$this.addClass('active');
				return false;
			});


			function ajaxDataFilter(data) {

				var atts = $('.brk-atts').html();
				data.action = 'product_filter';
				data.atts = JSON.parse(atts);

				var products_holder = $('.brs_listing_products');
				products_holder.empty();
				var products_loader = '<div class="brs_product_loader"></div>';
				products_holder.append(products_loader);


				jQuery.post(brs_l10n.ajaxurl, data, function (response) {

					if (response) {

						response = $.parseJSON(response);
						var html = response.posts_html;
						var brk_atts = response.brk_atts;
						products_holder.empty().append(html);
						var atts = $(brk_atts).html();
						var more_posts = $(brk_atts).data('more-posts');
						var pagination_btn = $('.brk-shortcode-pagination-ajax');

						if (!more_posts) {
							pagination_btn.hide(300);
						} else {
							pagination_btn.show(300);
						}

						$('.brk-atts').empty().append(atts);
					}

				});

			}

		}

		//Product single page
		if ($('.brs_comment_form_rating').length) {

			$('.brs_comment_form_rating').find('.jq-selectbox__dropdown').hide();
			$('.brs_comment_form_rating').find('.jq-selectbox__select').hide();
			setTimeout(function () {
				$('.brs_comment_form_rating').find('p.stars').hide();
			}, 100);

			onClickRate($('.brk-rating__layer i'));
			onClickRate($('.brk-rating__imposition i'));

			function onClickRate(item) {
				item.on('click', function () {
					var $this = $(this);
					var value = $(this).attr('data-value');
					var imposition = $('.brk-rating__imposition');
					imposition.css({'width': '0%'});
					var index = item.index($this);
					var width = (index - 4) * 20;
					imposition.css({'width': width + '%'});
					var s_rating = $('#rating');
					s_rating.val(value);
				});
			}
		}

		if ($('.brk_choose_variable').length) {
			$('.brk_choose_variable a').on('click', function () {
				var $this = $(this);
				var size = $('.brk-size-chooser__items').find('a.active').attr('data-size');
				var color = $('.brk-color-filter__container').find('a.active').attr('data-color');
				var product_id = $('.brk_single_product').attr('data-id');

				$this.siblings().removeClass('active');
				$this.addClass('active');

				if ($this.attr('class').indexOf('brk-size-chooser__item') != -1) {
					size = $this.attr('data-size');
				}
				if ($this.attr('class').indexOf('brk-color-filter__item') != -1) {
					color = $this.attr('data-color');
				}

				var data = {
					action: 'brs_woo_get_variable_id',
					size: size,
					color: color,
					product_id: product_id

				}
				jQuery.post(brs_l10n.ajaxurl, data, function (response) {
					if (response) {
						$('.add_to_cart_button').attr('data-product_id', response);
					}
				});

				return false;
			});

		}

		// Portfolio single with sidebar
		if ($('.brk_sidebar_single_product').length) {
			var last_div = $('.brk_sidebar_single_product>div').last();
			last_div.insertBefore($('.brk-tabs_shop'));
		}


		//Portfolio filter

		if ($('.filter__container').length) {

			$("input.sliderValue").change(function () {
				var $this = $(this);
				$("#slider").slider("values", $this.data("index"), $this.val());
			});

			$('button#filter-trigger').click(function () {
				this.classList.toggle('closed');
				this.nextElementSibling.classList.toggle('closed');
			});

			$('button#categories-list-trigger').click(function () {
				var filtersContainer = this.parentNode.parentNode;
				filtersContainer.querySelector('#filter-trigger').classList.add('closed');
				filtersContainer.querySelector('.filter').classList.add('closed');
			});

			$("#slider").on("slidestop", function (event, ui) {
				var min, max;

				min = ui.values[0];
				max = ui.values[1];

				var folio_type = $('.posts_content').attr('data-folio-type');

				var data = {
					action: "portfolio_year_filter",
					min_year: min,
					max_year: max,
					folio_type: folio_type
				}
				jQuery.post(brs_l10n.ajaxurl, data, function (response) {

					if (response) {
						response = $.parseJSON(response);
						var html = response.html;

						$('.posts_content').empty().append(html);

						if ($('.brk-pagination').length) {
							$('.brk-pagination').hide();
						}

						if ($('.load-more').length) {
							$('.load-more').hide();
						}

						Berserk.attachBehaviors(document, Berserk.settings);

						var fancybox = $(".fancybox");
						if (fancybox.length) {
							fancybox.fancybox({
								openEffect: 'elastic',
								closeEffect: 'elastic'
							});
						}
						var fancybox_media = $('.fancybox-media');
						if (fancybox_media.length) {
							fancybox_media.fancybox({
								openEffect: 'fade',
								closeEffect: 'fade',
								helpers: {
									media: {}
								}
							});
						}

					}

				});

			});
		}


		//Portfolio load more
		var load_more_key = 1;

		$(document).on('click', '.load-more', function () {

			var $this = $(this),
				posts_per_page = $this.attr('data-posts_per_page'),
				posts_per_load = $this.attr('data-posts_per_load'),
				post_type = $this.attr('data-post_type'),
				offset = $this.attr('data-offset'),
				layout_type = $this.attr('data-layout_type');

			var data = {
				action: "posts_get_more",
				posts_per_page: posts_per_page,
				posts_per_load: posts_per_load,
				post_type: post_type,
				offset: offset,
				layout_type: layout_type,
				key: load_more_key
			};

			if ($this.attr('data-categories')) {
				data.categories = $this.attr('data-categories');
			}

			if ($this.attr('data-columns')) {
				data.columns = $this.attr('data-columns');
			}

			if ($this.attr('data-folio_type_layout')) {
				data.folio_type_layout = $this.attr('data-folio_type_layout');
			}

			jQuery.post(brs_l10n.ajaxurl, data, function (response) {
				if (response) {
					response = $.parseJSON(response);
					var html = response.html;
					var offset = response.offset;
					var display_next = response.display_next;

					$this.attr('data-offset', offset);
					$this.parent().prev('.posts_content').append(html);

					if ($('.brk-grid-fitrows').length) {
						Berserk.behaviors.portfolio_rows_init.attach();
						var $content = $(html);
						$('.brk-grid-fitrows').append($content).isotope('appended', $content);
						Berserk.behaviors.portfolio_row_cols_init.attach();
					}

					if ($('.brk-grid_portfolio_isotope').length) {
						Berserk.behaviors.portfolio_isotope_init.attach();
						var $content = $(html);
						$('.brk-grid_portfolio_isotope').append($content).isotope('appended', $content);
						Berserk.behaviors.portfolio_isotope_cols_init.attach();
					}

					if ($('.brk-grid_portfolio_isotope_2')) {
						$('.brk-grid').removeClass('rendered');
						Berserk.behaviors.portfolio_isotope_alternate_cols_init.attach();
						Berserk.behaviors.portfolio_masonry_init.attach();
					}

					if ($('.brk-grid_portfolio_swipe_card_masonry')) {
						$('.brk-grid').removeClass('rendered');
						Berserk.behaviors.portfolio_swipe_card_cols_init.attach();
						Berserk.behaviors.portfolio_isotope_init.attach();

					}

					var fancybox = $(".fancybox");
					if (fancybox.length) {
						fancybox.fancybox({
							openEffect: 'elastic',
							closeEffect: 'elastic'
						});
					}
					var fancybox_media = $('.fancybox-media');
					if (fancybox_media.length) {
						fancybox_media.fancybox({
							openEffect: 'fade',
							closeEffect: 'fade',
							helpers: {
								media: {}
							}
						});
					}

					if (display_next == false) {
						$this.hide(300);
					}
				}
			});
			load_more_key++;

			return false;
		});

		//Portfolio Isotope

		if ($('.brk-filters').length) {
			$(".brk-filters").on("click", "li", function () {
				var filterValue = $(this).attr("data-filter");
				var loadMore = $('.load-more');
				var elemCount = $(".brk-grid").find(filterValue).length;
				filterValue = filterValue.split('.');
				filterValue = filterValue[1];
				loadMore.attr('data-categories', filterValue);
				loadMore.attr('data-offset', elemCount);

				var post_type = loadMore.attr('data-post_type');
				var posts_per_load = loadMore.attr('data-posts_per_load');

				var data = {
					action: "check_if_posts_exist",
					posts_per_load: posts_per_load,
					post_type: post_type,
					offset: elemCount,
				};

				if (loadMore.attr('data-categories')) {
					data.categories = loadMore.attr('data-categories');
				}

				jQuery.post(brs_l10n.ajaxurl, data, function (response) {
					if (response) {
						response = $.parseJSON(response);
						var show_load_more = response.show_load_more;

						if (show_load_more == true) {
							loadMore.show(300);
						} else {
							loadMore.hide(300);
						}
					}

				});

			});
		}

		// Forum pages
		if ($('.brk_single_topic_header').length) {

			var favorite_btn = $('.brk_single_topic_header').find('.favorite-toggle');
			var subscription_btn = $('.brk_single_topic_header').find('.subscription-toggle');
			var forum_subscription_btn = $('.brk_bbpress_forums').find('.subscription-toggle');

			favorite_btn.addClass('btn btn-inside-out btn-sm font__family-open-sans font__size-14 font__weight-normal ml-auto border-radius-25 text-capitalize btn-shadow');
			subscription_btn.addClass('btn btn-inside-out btn-sm font__family-open-sans font__size-14 font__weight-normal mr-0 border-radius-25 text-capitalize btn-shadow');
			forum_subscription_btn.addClass('btn btn-inside-out btn-sm font__family-open-sans font__size-14 font__weight-normal mr-0 border-radius-25 text-capitalize btn-shadow');

		}

		// Tables Page
		setTimeout(function () {
			if ($('.brk-tables').length) {
				$('.brk-tables').each(function () {
					var $this = $(this);
					$this.find('table').attr('class', '');
				});


				function tableAddAct(el) {
					if ($(el).length) {
						$(el + ' table').find('th:eq( 1 )').addClass('active');
						$(el + ' table tbody tr').each(function () {
							var $this = $(this);
							$this.find('td:eq( 1 )').addClass('active');
						});
					}
				}

				tableAddAct('.brk-tables-trend');
				tableAddAct('.brk-tables-strict');


			}
		}, 100);

		// Team page
		if ($('.brk-team-member__info').length) {
			var team_member_info = $('.brk-team-member__secondary-info');
			var vc_first_row = $('#content .vc_column-inner ').first().html();
			$('#content .vc_column-inner ').first().empty();
			team_member_info.html(vc_first_row);
		}

		// Product filter
		if ($('.brk-sc-sorting__sort-select').length) {
			$('.brk-sc-sorting__sort-select select').on('change', function () {
				var sort_value = $(this).val();
			});
		}


		//Like comments
		$(document).on('click', '.brk-forum-post__header-like', function () {

			var $this = $(this),
				count = $this.find('span').text();
			id = $this.attr('data-comment-id');
			var data = {
				action: "add_comment_like",
				id: id
			};
			jQuery.post(brs_l10n.ajaxurl, data, function (response) {

			});
			count++;
			$this.find('span').text(count);

			return false;
		});

		//Like gallery slider images
		$(document).on('click', '.gallery-like-btn', function () {

			var $this = $(this),
				count = $this.find('span').text();
			id = $this.attr('data-post-id');
			var data = {
				action: "add_post_image_like",
				id: id
			};
			jQuery.post(brs_l10n.ajaxurl, data, function (response) {

			});
			count++;
			$this.find('span').text(count);

			return false;
		});


		// Woo add to  wishlist / compare
		$(document).on('click', '.add_to_wishlist', function () {
			var $this = $(this),
				id = $this.attr('data-product-id');
			var data = {
				action: "add_to_wishlist",
				id: id
			};
			jQuery.post(brs_l10n.ajaxurl, data, function (response) {
				if (response) {
					$this.removeClass('add_to_wishlist');
					$this.addClass('remove_from_wishlist');
				}
			});

			return false;
		});

		$(document).on('click', '.remove_from_wishlist', function () {

			var $this = $(this),
				id = $this.attr('data-product-id');
			var data = {
				action: "remove_from_wishlist",
				id: id
			};
			jQuery.post(brs_l10n.ajaxurl, data, function (response) {
				if (response) {
					$this.removeClass('remove_from_wishlist');
					$this.addClass('add_to_wishlist');
				}
			});

			return false;
		});


		$(document).on('click', '.add_to_compare', function () {
			var $this = $(this),
				id = $this.attr('data-product-id');
			var data = {
				action: "add_to_compare",
				id: id
			};
			jQuery.post(brs_l10n.ajaxurl, data, function (response) {
				if (response) {
					$this.removeClass('add_to_compare');
					$this.addClass('remove_from_compare');
				}
			});

			return false;
		});

		$(document).on('click', '.remove_from_compare', function () {

			var $this = $(this),
				id = $this.attr('data-product-id');
			var data = {
				action: "remove_from_compare",
				id: id
			};
			jQuery.post(brs_l10n.ajaxurl, data, function (response) {
				if (response) {
					$this.removeClass('remove_from_compare');
					$this.addClass('add_to_compare');
				}
			});

			return false;
		});

		//CFA submit form

		$('.cfa_subscr__form').on('submit', function () {
			SubmitCFA(this);
			return false;
		});

	});

	function SubmitCFA($this) {

		$response = $($this).find(jQuery(".cfa_form_responce"));
		$response.find("ul").html("");
		$response.find("ul").removeClass();

		var data = {
			action: "cfa_submit",
			values: $($this).serialize()
		};
		jQuery.post(brs_l10n.ajaxurl, data, function (response) {
			response = jQuery.parseJSON(response);
			if (response.is_errors) {
				$($this).find(".cfa_form_responce ul").addClass("error").append('<li>' + response.is_errors + '</li>');
				$response.show(450);
			} else {
				$($this).find(".cfa_form_responce ul").addClass("success").append('<li>' + response.info + '</li>');
				$response.show(450).delay(1800).hide(400);
			}

		});

	}

}(jQuery));
