(function($){
    
    var self,
        overlay,
        instances = [],
	    fenix_lang = {
		    'apply': 'Apply',
		    'close': 'Close',
		    'update': 'Saving...',
	    },
        defaults = {
            content: '',
            title: '',
            popup_id: '',
            popup_class: '',
            open: function(){},
            close: function(){},
            save: null /* optional callback */
        },
        zindex = 99999;
    
    self = $.fenix_popup = function(options) {
        
        self.options = $.extend({}, defaults, options);
        self.instance;
        self.doc = $(document);
        self.body = $('body');
        self.init();
        
    };
    
    self.init = function() {
        
        overlay = $('.fenix-popup-overlay');
        if (overlay.length < 1) {
            self.body.append('<div class="fenix-popup-overlay"></div>');
            overlay = $('.fenix-popup-overlay');
        }
     
        self.instance = $('<div class="fenix-popup"></div>').css('z-index', zindex++);
        
        if(self.options.popup_id !== ''){
            self.instance.attr('id', self.options.popup_id);
        }
        
        if(self.options.popup_class !== ''){
            self.instance.addClass(self.options.popup_class);
        }
        
        var title = '<h3 class="fenix-popup-title">' + self.options.title + '</h3>',
            output = '';
    
        output += '<div class="fenix-popup-wrapper">\
                        <div class="fenix-popup-header">' + title + '<a href="#close" class="fenix-popup-close">X</a></div>\
                        <div class="fenix-popup-content">' + self.options.content + '</div>\
                        <div class="fenix-popup-footer">' +
                            (self.options.save ? '<a href="#save" class="fenix-popup-save button button-primary button-large">' + fenix_lang['apply'] + '</a>' : '') +
                            '<a href="#close" class="fenix-popup-close button button-primary button-large">' + fenix_lang['close'] + '</a>\
                        </div>\
                    </div>';
        
        self.body.append(self.instance);
        self.instance.append(output);
        
        var data = {
            popup: self.instance,
            onclose: self.options.close,
            onsave: self.options.save
        };
        instances.push(data);

        self.set_events_handlers();
        self.open();
        
    };
    
    self.set_events_handlers = function() {
        
        var count_instances = instances.length,
            namespace = 'fenix_popup' + count_instances;
    
        self.instance.find('.fenix-popup-close').on('click.'+namespace, function() {
            self.close();
            return false;
        });

        self.doc.on('keydown.'+namespace, function (e) {
            var keycode = e.keyCode;
            switch(keycode) {
                case 13:
                    if(!$(e.target).hasClass('wp-editor-area')){
                        setTimeout(function () {
                            var save_button = self.instance.find('.fenix-popup-save');
                            if(save_button.length){
                                save_button.trigger('click.'+namespace);
                            }
                        }, 100);
                        e.stopImmediatePropagation();
                    }
                break;
                case 27:
                    setTimeout(function () {
                        self.close();
                    }, 100);
                    e.stopImmediatePropagation();
                break;
            }
        });
        
        self.instance.find('.fenix-popup-save').on('click.'+namespace, function() {
            var _this = instances[count_instances-1],
                onsave = _this.onsave;
                
            if ($.isFunction(onsave)) {
                onsave();
            }
            self.close();
            return false;
        });

    };
    
    self.open = function() {
        
        overlay.fadeIn(200);
        self.instance.fadeIn(200);
                
        if ($.isFunction(self.options.open)) {
            self.options.open();
        }
        
        self.instance.find('select, input[type=text], input[type=checkbox], textarea').eq(0).trigger('focus');
        
    };
    
    self.close = function() {
        
        var count_instances = instances.length;
           
        if(count_instances > 0){
            var _this = instances[count_instances-1],
                namespace = 'fenix_popup' + count_instances,
                popup = _this.popup,
                onclose = _this.onclose;

            popup.find('.fenix-popup-close').off('click.'+namespace);
            popup.find('.fenix-popup-save').off('click.'+namespace);
            self.doc.off('keydown.'+namespace);
            
            popup.fadeOut(300, function() {
                if ($.isFunction(onclose)) {
                    onclose();
                }
                $(this).remove();
                if($('.fenix-popup').length < 1){
                    overlay.hide();
                }
            });
            instances.pop();
        }
        
    };
  
}(jQuery));

jQuery(function() {
	jQuery('body').append('<div class="fenix-cc-info-popup"></div>');
	jQuery('body').append('<div class="info_popup" style="display: none;"></div>');
});

function fenix_info_popup_show(text, autohide) {
	var popup = jQuery('.fenix-cc-info-popup');

	popup.text(text).fadeTo(400, 0.9);

	if(autohide){
		if(isNaN(autohide)){
			autohide = 1500;
		}
		window.setTimeout(function() {
			popup.fadeOut(600);
		}, autohide);
	}

}

function fenix_info_popup_hide() {
    jQuery(".fenix-cc-info-popup").fadeOut(400);
}

function fenix_uniqid() {
	var d = new Date(),
		uniqid = Math.random() * d.getTime();
	return Math.round(uniqid);
}