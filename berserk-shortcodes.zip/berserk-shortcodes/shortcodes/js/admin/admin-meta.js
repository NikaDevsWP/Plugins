(function($) {

	$.fn.life = function(types, data, fn) {
		"use strict";
		$(this.context).on(types, this.selector, data, fn);
		return this;
	};

})(jQuery);

var BRS__ADMIN_META = function () {

	var self = {
		html_buffer: "",
		init: function () {
			jQuery('body').append('<div id="inpost_gallery_html_buffer" style="display: none;"></div>');
			jQuery('body').append('<div id="inpost_gallery_info_popup" style="display: none;"></div>');

			self.html_buffer = jQuery("#inpost_gallery_html_buffer");

			self.check_box_visibility();
			jQuery('input[name="post_format"]:radio').change(function() {
				self.check_box_visibility();
			});

			jQuery("#gallery_item_list").sortable({
				stop: function () {
					//self.recount_slides();
				}
			});

			jQuery('.brs_button_upload').on('click', function() {
				var input_object = jQuery(this).prev('input, textarea'),
					type = jQuery(this).data('type'),
					title = wp.media.view.l10n.chooseImage;

				if (!type) {
					type = 'image';
				} else if (type === 'audio') {
					title = wp.media.view.l10n.audioAddSourceTitle;
				} else if (type === 'video') {
					title = wp.media.view.l10n.videoAddSourceTitle;
				}

				var frame = wp.media({
					title: title,
					multiple: false,
					library: { type: type }
				});

				frame.on( 'select', function() {
					var selection = frame.state().get('selection');
					selection.each(function(attachment) {
						var url = attachment.attributes.url;
						input_object.val(url).trigger('change');
					});
				});

				frame.open();

				return false;
			});

			jQuery('.js_inpost_gallery_add_slide').life('click', function (event) {
				var key = jQuery(this).attr('data-key');
				window.send_to_editor = function (html) {

					self.insert_html_in_buffer(html);
					var images = jQuery(self.html_buffer).find('img');
					var img_urls = new Array();
					jQuery.each(images, function (index, value) {
						img_urls[index] = jQuery(value).attr('src');
					});

					self.add_meta_slide_items(img_urls, 0, key);
					self.insert_html_in_buffer("");
				};

				wp.media.editor.open(null);

				return false;
			});

			jQuery(".delete_gallery_item").life('click', function () {
				var self_button = this;
				jQuery(self_button).parents('li').eq(0).hide(333, function () {
					jQuery(self_button).parents('li').eq(0).remove();
				});

				return false;
			});

			jQuery(".js_edit_gallery_item").life('click', function () {
				var unique_id = jQuery(this).data("unique-id");
				var title = jQuery(this).parent().find(".js_edit_gallery_item_title").val();
				var description = jQuery(this).parent().find(".js_edit_gallery_item_description").val();
				jQuery("[name='brs_gallery[" + unique_id + "][title]']").val(title);
				jQuery("[name='brs_gallery[" + unique_id + "][description]']").val(description);
				tb_remove();
				return true;
			});

		},
		check_box_visibility: function(){
			var post_format_value = jQuery("input:radio[name='post_format']:checked").val();
			jQuery('.brk_post_format_metabox').hide();
			switch (post_format_value){
				case "0":
						jQuery('#brk_standard').show('300');
					break;
				default:
					jQuery('#brk_'+post_format_value).show('300');
					break;
			}
		},
		add_meta_slide_items: function (img_urls, index, key) {
			//show_info_popup(tmm_l10n.loading);

			var data = {
				action: "add_gallery_item",
				imgurl: img_urls[index],
				key: key
			};
			jQuery.post(ajaxurl, data, function (response) {
				jQuery("#gallery_item_list").append(response);
				if (index < (img_urls.length - 1)) {
					self.add_meta_slide_items(img_urls, index + 1, key);
				}
			});
		},
		insert_html_in_buffer: function (html) {
			jQuery(self.html_buffer).html(html);
		}
	};

	return self;
};


var brs_admin_meta = new BRS__ADMIN_META();
jQuery(document).ready(function () {
	brs_admin_meta.init();
});

