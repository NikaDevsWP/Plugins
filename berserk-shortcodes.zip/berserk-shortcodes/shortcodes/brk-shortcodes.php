<?php
/**
 * Add Shortcodes
 *
 * @package NikaDevs
 * @subpackage Berserk Shortcodes
 * @since 1.0.0
 */

/**
 * Shortcode name
 */
function brk_add_schortcode_libraries( $atts ){ // component__countdown

	extract( shortcode_atts( array(
		'libs' => '',
	), $atts ) );

	if ( $libs ) {
		$libraries = explode( ' ', $libs );
		brs_add_libraries( $libraries );
	}

}
add_shortcode( 'brk_add_libraries', 'brk_add_schortcode_libraries' );