<?php
/**
 * This file contains shortcodes interface for Visual Composer.
 */

// ! File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once BERSERK_SHORTCODES_PATH . 'shortcodes/includes/shortcodes-ext.php';

// Overlay Style
vc_add_param( "vc_column", array(
	"heading"    => __( "Text Align", 'berserk' ),
	"param_name" => "text_align",
	"type"       => "dropdown",
	"value"      => array(
		"None"   => "none",
		"Left"   => "left",
		"Right"  => "right",
		"Center" => "center",
	),

	//"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );


/**
 * VC Row.
 */


// Full width image
vc_add_param( "vc_row", array(
	//"heading"          => __( "Row Full Width", 'berserk' ),
	"param_name"       => "full_width",
	"type"             => "checkbox",
	"value"            => array(
		"Row Full Width" => "true",
	),
	"dependency"       => array(
		"element" => "type",
		"value"   => array( 'berserk' ),
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );

// Full width image
vc_add_param( "vc_row", array(
	//"heading"          => __( "Content Full Width", 'berserk' ),
	"param_name"       => "full_width_content",
	"value"            => array(
		"Content Full Width" => "true",
	),
	"type"             => "checkbox",
	"dependency"       => array(
		"element" => "type",
		"value"   => array( 'berserk' ),
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );


// Top margin

vc_add_param( "vc_row", array(
	"heading"          => __( "Top margin", 'berserk' ),
	"param_name"       => "margin_top",
	"type"             => "textfield",
	"value"            => "",
	"edit_field_class" => "brs_vc_row-param vc_col-xs-6 vc_column hidden_field",
) );

// Light Text Content
vc_add_param( "vc_row", array(
	//"heading"          => __( "Light Text Content", 'berserk' ),
	"param_name"       => "all_light",
	"type"             => "checkbox",
	"value"            => array(
		"Light Text Content" => "true",
	),
	//"class" => "dt_image",
	"dependency"       => array(
		"element" => "type",
		"value"   => array( 'berserk' ),
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );

// Row visible
vc_add_param( "vc_row", array(
	//"heading"          => __( "Row Visible", 'berserk' ),
	"param_name"       => "row_visible",
	"value"            => array(
		"Row Visible" => "true",
	),
	"type"             => "checkbox",
	"dependency"       => array(
		"element" => "type",
		"value"   => array( 'berserk' ),
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );

// Overflow hidden
vc_add_param( "vc_row", array(
	//"heading"          => __( "Row Visible", 'berserk' ),
	"param_name"       => "hide_overflow",
	"value"            => array(
		"Hide Overflow" => "true",
	),
	"type"             => "checkbox",
	"dependency"       => array(
		"element" => "type",
		"value"   => array( 'berserk' ),
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );

// Row wave hover
vc_add_param( "vc_row", array(
	//"heading"          => __( "Wave Hover Effect", 'berserk' ),
	"param_name"       => "row_wave_hover",
	"type"             => "checkbox",
	"value"            => array(
		"Wave Hover Effect" => "true",
	),
	"dependency"       => array(
		"element" => "type",
		"value"   => array( 'berserk' ),
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );

vc_add_param( "vc_row", array(
	"heading"          => __( "Speed", 'berserk' ),
	"param_name"       => "data_speed",
	"type"             => "textfield",
	"dependency"       => array(
		"element" => "row_wave_hover",
		"value"   => array( 'true' ),
	),
	"value"            => "0.4",
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );

vc_add_param( "vc_row", array(
	//"heading"          => __( "Repeat", 'berserk' ),
	"param_name"       => "data_repeat",
	"type"             => "checkbox",
	"value"            => array(
		"Repeat" => "true",
	),
	"dependency"       => array(
		"element" => "row_wave_hover",
		"value"   => array( 'true' ),
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );

vc_add_param( "vc_row", array(
	"heading"          => __( "Delay", 'berserk' ),
	"param_name"       => "data_delay",
	"type"             => "textfield",
	"dependency"       => array(
		"element" => "row_wave_hover",
		"value"   => array( 'true' ),
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );

// Row without paddings
vc_add_param( "vc_row", array(
	"heading"    => __( "Column Padding", 'berserk' ),
	"param_name" => "column_padding",
	"type"       => "dropdown",
	"value"      => array(
		""     => "",
		"None" => "none",
		"5px"  => "brk-gutters-5",
		"10px" => "brk-gutters-10",
	),

	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );


// Row Width
vc_add_param( "vc_row", array(
	"heading"          => __( "Row Max Width", 'berserk' ),
	"param_name"       => "row_max_width",
	"type"             => "dropdown",
	"value"            => array(
		"None"     => "none",
		"Maxw-770" => "maxw-770",
		"Maxw-970" => "maxw-970",
		"Maxw-450" => "maxw-450"
	),
	"dependency"       => array(
		"element" => "type",
		"value"   => array( 'berserk' ),
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );

// Custom css
vc_add_param( "vc_row", array(
	"heading"          => __( "Custom css class name", 'berserk' ),
	"param_name"       => "custom_css",
	"type"             => "textfield",
	//"class" => "dt_image",
	"dependency"       => array(
		"element" => "type",
		"value"   => array( 'berserk' ),
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );

// Custon css
vc_add_param( "vc_row", array(
	'heading'          => esc_html__( 'Row ID', 'berserk' ),
	'param_name'       => 'row_id',
	'type'             => 'textfield',
	'dependency'       => array(
		'element' => 'type',
		'value'   => array( 'berserk' ),
	),
	'edit_field_class' => 'brs_vc_row-param vc_col-sm-6 vc_column',
) );

// Border radius
vc_add_param( "vc_row", array(
	"heading"          => __( "Border Radius (px)", 'berserk' ),
	"param_name"       => "border_radius",
	"type"             => "textfield",
	//"class" => "dt_image",
	"dependency"       => array(
		"element" => "type",
		"value"   => array( 'berserk' ),
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );

/* Background Options */

vc_add_param( "vc_row", array(
	"heading"          => __( "Background Options", 'berserk' ),
	"param_name"       => "brs_row_title_bg",
	"type"             => "brs_title",
	"edit_field_class" => "brs_vc_row-param vc_col-xs-12 vc_column",
) );

vc_add_param( "vc_row", array(
	"heading"          => __( "Background Type", 'berserk' ),
	"param_name"       => "bg_type",
	"type"             => "dropdown",
	"value"            => array(
		__( 'None', 'berserk' )                => 'none',
		__( 'Image', 'berserk' )               => 'image',
		__( 'Embedded Images', 'berserk' )     => 'images',
		__( 'Parallax Image', 'berserk' )      => 'parallax_image',
		__( 'Video', 'berserk' )               => 'video',
		__( 'Animated background', 'berserk' ) => 'animated_background'
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );

// Animated background (canvas)
vc_add_param( "vc_row", array(
	'heading'          => __( 'Background Type', 'berserk' ),
	'param_name'       => 'animated_bg_type',
	'type'             => 'brs_radio',
	"edit_field_class" => "brs_vc_row-param vc_col-xs-12 vc_column",
	'value'            => array(
		"Type 1"    => "type_1",
		"Type 2"    => "type_2",
		"Type 3"    => "type_3",
		"Type 4"    => "type_4",
		"Type 5"    => "type_5",
		"Type 6"    => "type_6",
		"Type 7"    => "type_7",
		"Type 8"    => "type_8",
		//"Type 9" => "type_9",
		"Balls"     => "balls",
		"Type_10"   => "type_10",
		"Type_11"   => "type_11",
		"Type 12.1" => "type_12_1",
		"Type 12.2" => "type_12_2",
		"Type 12.3" => "type_12_3",
	),
	'images'           => array(
		"type_1"    => 'backgrounds/001.jpg',
		"type_2"    => 'backgrounds/002.jpg',
		"type_3"    => 'backgrounds/003.jpg',
		"type_4"    => 'backgrounds/004.jpg',
		"type_5"    => 'backgrounds/005.jpg',
		"type_6"    => 'backgrounds/006.jpg',
		"type_7"    => 'backgrounds/007.jpg',
		"type_8"    => 'backgrounds/008.jpg',
		"type_9"    => 'backgrounds/009.jpg',
		"balls"     => 'backgrounds/010.jpg',
		"type_12_1" => 'backgrounds/012-1.gif',
		"type_12_2" => 'backgrounds/012-2.gif',
		"type_12_3" => 'backgrounds/012-3.gif',
	),
	'images_dim'       => array(
		'w' => '310',
		'h' => '150'
	),
	"dependency"       => array(
		"element" => "bg_type",
		"value"   => array( 'animated_background' ),
	),
) );

// Animated background (canvas)
vc_add_param( "vc_row", array(
	'heading'          => __( 'Background Type', 'berserk' ),
	'param_name'       => 'images_bg_type',
	'type'             => 'brs_radio',
	'edit_field_class' => 'brs_vc_row-param vc_col-xs-12 vc_column',
	'value'            => array(
		'Wave Backgrounds'    => 'wave',
	),
	'images'           => array(
		'wave'    => 'backgrounds/101.png',
	),
	'images_dim'       => array(
		'w' => '310',
		'h' => '150'
	),
	'dependency'       => array(
		'element' => 'bg_type',
		'value'   => array( 'images' ),
	),
) );

// Background image

$options  = array(
	'edit_field_class' => 'brs_vc_row-param brk-dependency__bg_type image images parallax_image video animated_background',
	'dependency'       => array(
		"element" => "bg_type",
		"value"   => array( 'image', 'images', 'parallax_image', 'video', 'animated_background' ),
	)
);
$patterns = berserk_shortcodes_patterns( $options );

foreach ( $patterns as $pattern ) {
	if ( is_array( $pattern ) ) {
		vc_add_param( "vc_row", $pattern );
	}
}

// Background video
vc_add_param( "vc_row", array(
	"heading"          => __( "Background Video", 'berserk' ),
	"description"      => __( "Examples: http://youtu.be/Rapz8ac7RW0 https://player.vimeo.com/video/21818894 or upload self hosted video", 'berserk' ),
	"param_name"       => "bg_video",
	"type"             => "brs_video_upload",
	"dependency"       => array(
		"element" => "bg_type",
		"value"   => array( 'video' ),
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );

// Without background on mobile device
vc_add_param( "vc_row", array(
	//"heading"          => __( "Without background on mobile device", 'berserk' ),
	"param_name"       => "without_bg_on_mobile",
	"type"             => "checkbox",
	"value"            => array(
		"Without background on mobile device" => "true",
	),
	//"class" => "dt_image",
	"dependency"       => array(
		"element" => "type",
		"value"   => array( 'berserk' ),
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );

/* Overlay */

vc_add_param( "vc_row", array(
	"heading"          => __( "Overlay", 'berserk' ),
	"param_name"       => "brs_row_title_overlay",
	"type"             => "brs_title",
	"edit_field_class" => "brs_vc_row-param vc_col-xs-12 vc_column",
) );

// Overlay Style
vc_add_param( "vc_row", array(
	"heading"          => __( "Overlay Style", 'berserk' ),
	"param_name"       => "overlay_style",
	"type"             => "dropdown",
	"value"            => array(
		"None"               => "none",
		//"Overlay White"      => "overlay__white",
		//"Overlay Dark"       => "overlay__dark",
		"Overlay Background" => "overlay__background",
		"Overlay Gradient"   => "overlay__gradient",
		//"Overlay Curve Gradient" => "overlay_curve_gradient",
		"Overlay Dot"        => "overlay__dot"
	),
	"dependency"       => array(
		"element" => "type",
		"value"   => array( 'berserk' ),
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );

// Overlay Background
vc_add_param( "vc_row", array(
	"heading"          => __( "Default Color", 'berserk' ),
	"param_name"       => "default_color",
	"type"             => "brs_color_scheme",
	'colors'           => BRS_Shortcodes_VCParams::get_bg_colors(),
	"dependency"       => array(
		"element" => "overlay_style",
		"value"   => array( 'overlay__background' ),
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );

// Custom background checkbox
vc_add_param( "vc_row", array(
	"param_name"       => "custom_background",
	"type"             => "checkbox",
	"value"            => array(
		"Use custom background" => "true",
	),
	"dependency"       => array(
		"element" => "overlay_style",
		"value"   => array( 'overlay__background' ),
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );


// Background Color
vc_add_param( "vc_row", array(
	"heading"          => __( "Background Color", 'berserk' ),
	"param_name"       => "background_color",
	"type"             => "colorpicker",
	"value"            => "#000",
	"dependency"       => array(
		"element" => "custom_background",
		"value"   => array( 'true' ),
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );

// Default gradient

vc_add_param( "vc_row", array(
	"heading"          => __( "Default Gradient Type", 'berserk' ),
	"param_name"       => "default_gradient",
	"type"             => "brs_color_scheme",
	'colors'           => BRS_Shortcodes_VCParams::get_gradients(),
	"dependency"       => array(
		"element" => "overlay_style",
		"value"   => array( 'overlay__gradient' ),
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );

vc_add_param( "vc_row", array(
	"heading"          => __( "Opacity", 'berserk' ),
	"param_name"       => "overlay_opacity",
	"type"             => "dropdown",
	"value"            => array(
		"1"   => "opacity-100",
		"0.9" => "opacity-90",
		"0.8" => "opacity-80",
		"0.7" => "opacity-70",
		"0.6" => "opacity-60",
		"0.5" => "opacity-50",
		"0.4" => "opacity-40",
		"0.3" => "opacity-30",
		"0.2" => "opacity-20",
		"0.1" => "opacity-10",

	),
	"dependency"       => array(
		"element" => "overlay_style",
		"value"   => array( 'overlay__gradient', 'overlay__background' ),
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );

// Custom gradient checkbox
vc_add_param( "vc_row", array(
	"param_name"       => "custom_gradient",
	"type"             => "checkbox",
	"value"            => array(
		"Use custom gradient" => "true",
	),
	"dependency"       => array(
		"element" => "overlay_style",
		"value"   => array( 'overlay__gradient' ),
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );

// Angel in deg
vc_add_param( "vc_row", array(
	"heading"          => __( "Angle (in deg)", 'berserk' ),
	"param_name"       => "angle",
	"type"             => "textfield",
	"value"            => '10',
	"dependency"       => array(
		"element" => "custom_gradient",
		"value"   => array( 'true' ),
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );

// Color 1
vc_add_param( "vc_row", array(
	"heading"          => __( "Color", 'berserk' ),
	"param_name"       => "color_1",
	"type"             => "colorpicker",
	"value"            => '#1158DF',
	"dependency"       => array(
		"element" => "custom_gradient",
		"value"   => array( 'true' ),
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );

// Color 2
vc_add_param( "vc_row", array(
	"heading"          => __( "Color", 'berserk' ),
	"param_name"       => "color_2",
	"type"             => "colorpicker",
	"value"            => '#7401BA',
	"dependency"       => array(
		"element" => "custom_gradient",
		"value"   => array( 'true' ),
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );

/* Inner Content */
vc_add_param( "vc_row", array(
	"heading"          => __( "Inner Content", 'berserk' ),
	"param_name"       => "brs_row_title_inner_content",
	"type"             => "brs_title",
	"edit_field_class" => "brs_vc_row-param vc_col-xs-12 vc_column",
) );

// Inner Content Custon css
vc_add_param( "vc_row", array(
	"heading"          => __( "Inner Content Custom css class name", 'berserk' ),
	"param_name"       => "inner_content_custom_css",
	"type"             => "textfield",
	"dependency"       => array(
		"element" => "type",
		"value"   => array( 'berserk' ),
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );

// Inner Content shadow
vc_add_param( "vc_row", array(
	"param_name"       => "inner_content_shadow",
	"type"             => "checkbox",
	"value"            => array(
		"Inner Content shadow" => "true",
	),
	"dependency"       => array(
		"element" => "type",
		"value"   => array( 'berserk' ),
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );

// Inner Content Background image
vc_add_param( "vc_row", array(
	"heading"          => __( "Inner Content Background image", 'berserk' ),
	"description"      => __( "Image URL.", 'berserk' ),
	"param_name"       => "inner_content_bg_image",
	"type"             => "attach_image",
	"dependency"       => array(
		"element" => "type",
		"value"   => array( 'berserk' ),
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );

/* Parallax */

vc_add_param( "vc_row", array(
	"heading"          => __( "Parallax", 'berserk' ),
	"param_name"       => "brs_row_title_parallax",
	"type"             => "brs_title",
	"edit_field_class" => "brs_vc_row-param vc_col-xs-12 vc_column",
) );

vc_add_param( "vc_row", array(
	'heading'          => __( 'Row Type', 'berserk' ),
	'param_name'       => 'row_type',
	'type'             => 'brs_radio',
	"edit_field_class" => "brs_vc_row-param vc_col-xs-12 vc_column",
	'value'            => array(
		"None"            => "none",
		"Corner"          => "corner",
		"Circle"          => "circle",
		"Triangle"        => "triangle",
		"Round"           => "round",
		"Wing"            => "wing",
		"Double Triangle" => "double_triangle",
	),
	'images'           => array(
		"corner"          => 'parallax/001.jpg',
		"circle"          => 'parallax/002.jpg',
		"triangle"        => 'parallax/003.jpg',
		"round"           => 'parallax/004.jpg',
		"wing"            => 'parallax/005.jpg',
		"double_triangle" => 'parallax/006.jpg',
	),
	'images_dim'       => array(
		'w' => '310',
		'h' => '150'
	)
) );

vc_add_param( "vc_row", array(
	"heading"          => __( "Content Position", 'berserk' ),
	"param_name"       => "slide_from",
	"type"             => "dropdown",
	"value"            => array(
		__( 'Left', 'berserk' )  => 'left',
		__( 'Right', 'berserk' ) => 'right'
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );

vc_add_param( "vc_row", array(
	"heading"          => __( "Content Background", 'berserk' ),
	"param_name"       => "content_bg",
	"type"             => "dropdown",
	"value"            => array(
		__( 'White', 'berserk' )    => 'white',
		__( 'Gradient', 'berserk' ) => 'gradient'
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );

// Color 1
vc_add_param( "vc_row", array(
	"heading"          => __( "Color", 'berserk' ),
	"param_name"       => "row_color_f",
	"type"             => "colorpicker",
	"value"            => '#0f5ae0',
	"dependency"       => array(
		"element" => "content_bg",
		"value"   => array( 'gradient' ),
		//"element" => "row_type",
		//"value"   => array( 'gradient_corner', 'gradient_circle', 'gradient_triangle', 'gradient_round', 'gradient_wing', 'double_triangle', 'gradient_double_triangle' ),
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );

// Color 2
vc_add_param( "vc_row", array(
	"heading"          => __( "Color", 'berserk' ),
	"param_name"       => "row_color_s",
	"type"             => "colorpicker",
	"value"            => '#7400ba',
	"dependency"       => array(
		"element" => "content_bg",
		"value"   => array( 'gradient' ),
		//"element" => "row_type",
		//"value"   => array( 'gradient_corner', 'gradient_circle', 'gradient_triangle', 'gradient_round', 'gradient_wing', 'double_triangle', 'gradient_double_triangle' ),
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );

vc_add_param( "vc_row", array(
	//"heading"          => __( "Row Full Height", 'berserk' ),
	"param_name"       => "row_full_height",
	"type"             => "checkbox",
	"value"            => array(
		"Row Full Height" => "true",
	),
	//"class" => "dt_image",
	"dependency"       => array(
		"element" => "type",
		"value"   => array( 'berserk' ),
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );

// Side Circles
vc_add_param( "vc_row", array(
	//"heading"          => __( "Side Circles", 'berserk' ),
	"param_name"       => "side_circles",
	"type"             => "checkbox",
	"value"            => array(
		"Side Circles" => "true",
	),
	//"class" => "dt_image",
	"dependency"       => array(
		"element" => "type",
		"value"   => array( 'berserk' ),
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );

/* Custom css class */
vc_add_param( 'vc_row', array(
	'heading'          => esc_html__( 'Row Custom Css Class', 'berserk' ),
	'param_name'       => 'row_custom_class',
	'type'             => 'textfield',
	'edit_field_class' => 'brs_vc_row-param vc_col-sm-12 vc_column',
) );

/* Delimiters */
vc_add_param( "vc_row", array(
	"heading"          => __( "Delimiters", 'berserk' ),
	"param_name"       => "brs_row_title_delimiters",
	"type"             => "brs_title",
	"edit_field_class" => "brs_vc_row-param vc_col-xs-12 vc_column",
) );

vc_add_param( "vc_row", array(
	'heading'          => __( 'Delimiter Type', 'berserk' ),
	'param_name'       => 'delimiter_type',
	'type'             => 'brs_radio',
	"edit_field_class" => "brs_vc_row-param vc_col-xs-12 vc_column",
	'value'            => array(
		"None"                           => "none",
		"Circle"                         => "circle",
		"Angle"                          => "angle",
		"Curve"                          => "curve",
		"Trapezoid"                      => "trapezoid",
		"Trapezoid Left/Right Alternate" => "trapezoid_alternate",
		"Trapezoid Top Left/Right"       => "trapezoid_top",
		"Corner"                         => "corner",
		"Rounded"                        => "rounded",
		"Flexion"                        => "flexion",
		"Curves"                         => "curves",
		"Bottom Curves"                  => "bottom_curves",
		"Trapezoid with border"          => "trapezoid_with_border",
		"Triangle"                       => "triangle",
		"Wave"                           => "wave",
		"Wave Top"                       => "wave_top",
		"Urban"                          => "urban",
		'SVG Pattern 2'                  => 'svg_pattern_2',
		'SVG Pattern 7'                  => 'svg_pattern_7',
		'SVG Pattern 9'                  => 'svg_pattern_9',
		'SVG Pattern 10'                 => 'svg_pattern_10',
		'SVG Pattern 11'                 => 'svg_pattern_11',
		'SVG Pattern 13'                 => 'svg_pattern_13',
		'SVG Pattern 14'                 => 'svg_pattern_14',
		'SVG Pattern 15'                 => 'svg_pattern_15',
	),
	'images'           => array(
		"circle"                => 'delimiters/001.jpg',
		"angle"                 => 'delimiters/002.jpg',
		"curve"                 => 'delimiters/003.jpg',
		"trapezoid"             => 'delimiters/004.jpg',
		"trapezoid_alternate"   => 'delimiters/007.jpg',
		"trapezoid_top"         => 'delimiters/008.jpg',
		"corner"                => 'delimiters/005.jpg',
		"rounded"               => 'delimiters/006.jpg',
		"flexion"               => 'delimiters/flexion.jpg',
		"curves"                => 'delimiters/curves.jpg',
		"bottom_curves"         => 'delimiters/bottom_curves.jpg',
		"trapezoid_with_border" => 'delimiters/trapezoid_with_border.jpg',
		"triangle"              => 'delimiters/triangle.jpg',
		"wave"                  => 'delimiters/wave.jpg',
		"wave_top"              => 'delimiters/wave_top.jpg',
		"urban"                 => 'delimiters/urban.jpg',
		'svg_pattern_2'         => 'svg_pattern/pattern-2.jpg',
		'svg_pattern_7'         => 'svg_pattern/pattern-7.jpg',
		'svg_pattern_9'         => 'svg_pattern/pattern-9.jpg',
		'svg_pattern_10'        => 'svg_pattern/pattern-10.jpg',
		'svg_pattern_11'        => 'svg_pattern/pattern-11.jpg',
		'svg_pattern_13'        => 'svg_pattern/pattern-13.jpg',
		'svg_pattern_14'        => 'svg_pattern/pattern-14.jpg',
		'svg_pattern_15'        => 'svg_pattern/pattern-15.jpg'
	),
	'images_dim'       => array(
		'w' => '310',
		'h' => '150'
	)
) );

// Trapezoid type
vc_add_param( "vc_row", array(
	"heading"          => __( "Trapezoid type", 'berserk' ),
	"param_name"       => "trapezoid_type",
	"type"             => "dropdown",
	"value"            => array(
		"None"  => "none",
		"Left"  => "left",
		"Right" => "right",
	),
	"dependency"       => array(
		"element" => "type",
		"value"   => array( 'berserk' ),
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column brk-dependency__delimiter_type trapezoid_alternate trapezoid_top",
) );

// Crossing type
vc_add_param( "vc_row", array(
	"heading"          => __( "Crossing type", 'berserk' ),
	"param_name"       => "crossing_type",
	"type"             => "dropdown",
	"value"            => array(
		"None"         => "none",
		"Top Triangle Center" => "top_triangle",
		"Top Triangle" => "top-triangle",
		"Bottom Triangle" => "bottom-triangle",
	),
	"dependency"       => array(
		"element" => "type",
		"value"   => array( 'berserk' ),
	),
	"edit_field_class" => "brs_vc_row-param vc_col-sm-6 vc_column",
) );

/**
 * Responsive Spacing
 */
$brk_vc_screen_sizes    = array(
	'screen',
	'desktop',
	'tablet',
	'mobile',
);
$brk_spacing_options    = array(
	'margin_top'     => esc_html__( 'Margin Top', 'berserk' ),
	'margin_bottom'  => esc_html__( 'Margin Bottom', 'berserk' ),
	'padding_top'    => esc_html__( 'Padding Top', 'berserk' ),
	'padding_bottom' => esc_html__( 'Padding Bottom', 'berserk' )
);
$brk_group_name         = esc_html__( 'Responsive Spacing', 'berserk' );
$brk_spacing_attributes = array(
	array(
		'group'            => $brk_group_name,
		'heading'          => esc_html__( 'Responsive variants to target specific viewports', 'berserk' ),
		'param_name'       => 'brs_row_title',
		'type'             => 'brs_title',
		'edit_field_class' => 'brs_vc_row-param vc_col-xs-12 vc_column',
	),
	array(
		'group'            => $brk_group_name,
		'param_name'       => 'brs_row_responsive_spacing',
		'type'             => 'brs_images',
		'images'           => array(
			'screen'  => 'screen.png',
			'desktop' => 'desktop.png',
			'tablet'  => 'tablet.png',
			'mobile'  => 'mobile.png',
		),
		'images_dim'       => array(
			'w' => '76',
			'h' => '42'
		),
		'edit_field_class' => 'brs_vc_row-param brk-xs-3 brk-xs',
	),
);

foreach ( $brk_spacing_options as $option => $option_title ) {
	$brk_spacing_attributes[] = array(
		'heading'          => $option_title,
		'group'            => $brk_group_name,
		'param_name'       => 'brs_title_' . $option,
		'type'             => 'brs_title',
		'edit_field_class' => 'brs_vc_row-param vc_col-xs-12 vc_column',
	);
	foreach ( $brk_vc_screen_sizes as $size ) {
		${'brk_vc_row_' . $option} = array(
			'param_name'       => $size . '_' . $option,
			'group'            => $brk_group_name,
			'type'             => 'dropdown',
			'value'            => BRS_Shortcodes_VCParams::get_paddings_value(),
			'edit_field_class' => 'brs_vc_row-param vc_col-xs-3 vc_column',
		);
		$brk_spacing_attributes[]  = ${'brk_vc_row_' . $option};
	}

}

vc_add_params( 'vc_row', $brk_spacing_attributes );


$vc_row_shortcode = WPBMap::getShortCode( 'vc_row' );
if ( isset( $vc_row_shortcode['params'] ) && is_array( $vc_row_shortcode['params'] ) ) {
	$params = $vc_row_shortcode['params'];

	// Output 'tupe' param first.
	array_unshift( $params, array(
		'heading'          => __( 'Row style', 'berserk' ),
		'param_name'       => 'type',
		'type'             => 'dropdown',
		'edit_field_class' => 'dt_vc_row-params_switch vc_col-xs-12 vc_column',
		'admin_label'      => true,
		'value'            => array(
			'Default Berserk' => 'berserk',
			'Default VC'      => 'vc_default',
		),
	) );

	$el_class_key = false;
	foreach ( $params as $p_key => $p_data ) {
		if ( isset( $p_data['param_name'] ) && 'el_class' === $p_data['param_name'] ) {
			$el_class_key = $p_key;
			break;
		}
	}

	// Output 'el_class' param last.
	if ( false !== $el_class_key ) {
		$el_class = $params[ $el_class_key ];
		unset( $params[ $el_class_key ] );
		$params[] = $el_class;
	}

	WPBMap::modify( 'vc_row', 'params', $params );
}

if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	class WPBakeryShortCode_Brs_Panel_Content extends WPBakeryShortCodesContainer {
	}
}
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	class WPBakeryShortCode_Brs_Single_Panel_Content extends WPBakeryShortCodesContainer {
	}
}

VcShortcodeAutoloader::getInstance()->includeClass( 'WPBakeryShortCode_VC_Tta_Section' );

class WPBakeryShortCode_BRS_Tab_Section extends WPBakeryShortCode_VC_Tta_Section {
	/**
	 * @param $width
	 * @param $i
	 *
	 * @return string
	 */
	public function mainHtmlBlockParams( $width, $i ) {
		$sortable = ( vc_user_access_check_shortcode_all( $this->shortcode ) ? 'wpb_sortable' : $this->nonDraggableClass );

		return 'data-element_type="' . $this->settings['base'] . '" class="wpb_' . $this->settings['base'] . ' ' . $sortable . ' wpb_vc_tta_section wpb_content_holder vc_shortcodes_container"' . $this->customAdminBlockParams();
	}
}