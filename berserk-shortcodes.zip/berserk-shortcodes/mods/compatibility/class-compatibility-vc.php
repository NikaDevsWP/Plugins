<?php
/**
 * Visual Composer compatibility class.
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Presscore_Modules_Compatibility_VC', false ) ) :

	class Presscore_Modules_Compatibility_VC {

		public static $fonts = array(
			'Roboto'     => '1',
			'Montserrat' => '1',
			'Raleway'    => '1'
		);

		public static function execute() {

			/*
			if ( ! class_exists( 'Vc_Manager', false ) ) {
				return;
			}*/


			if ( of_get_option( 'general-hide_plugins_notifications', true ) ) {

				// Hide activation message.
				add_action( 'vc_before_init', array( __CLASS__, 'vc_set_as_theme' ) );

				// Show design tabs.
				add_filter( 'vc_settings_page_show_design_tabs', '__return_true' );

				// Disable updater.
				if ( function_exists( 'vc_manager' ) ) {
					vc_manager()->disableUpdater();
				}
			}

			if ( function_exists( 'vc_set_default_editor_post_types' ) ) {
				vc_set_default_editor_post_types( apply_filters( 'presscore_mod_js_composer_default_editor_post_types', array(
					'page',
					'post'
				) ) );
			}

			require_once BERSERK_SHORTCODES_PATH . '/shortcodes/vc-extensions.php';

			add_action( 'wp_enqueue_scripts', array( __CLASS__, 'load_front_static' ), 11 );
			add_action( 'wp_footer', array( __CLASS__, 'load_skin_style' ), 11 );

			add_action( 'init', array( __CLASS__, 'load_bridge' ), 20 );
			add_action( 'admin_enqueue_scripts', array( __CLASS__, 'load_admin_static' ), 20 );
			add_action( 'admin_print_scripts-post.php', array( __CLASS__, 'vc_row_scripts' ), 9999 );
			add_action( 'admin_print_scripts-post-new.php', array( __CLASS__, 'vc_row_scripts' ), 9999 );
			add_action( 'admin_init', array( __CLASS__, 'remove_teaser_meta_box' ), 7 );
			add_filter( 'presscore_localized_script', array( __CLASS__, 'localize_script' ) );
		}

		public static function load_bridge() {
			$shortcodes_to_remove = apply_filters( 'presscore_js_composer_shortcodes_to_remove', array(
				"vc_gallery",
				"vc_teaser_grid",
				"vc_button",
				"vc_cta_button",
				"vc_posts_grid",
				"vc_carousel",
				"vc_images_carousel",
				"vc_posts_slider",
				"vc_cta_button2",
			) );

			foreach ( $shortcodes_to_remove as $shortcode ) {
				if ( function_exists( 'vc_remove_element' ) ) {
					vc_remove_element( $shortcode );
				}
			}

			require_once BERSERK_SHORTCODES_PATH . '/shortcodes/composer_bridge.php';

			if ( function_exists( 'vc_set_shortcodes_templates_dir' ) ) {
				vc_set_shortcodes_templates_dir( BERSERK_SHORTCODES_PATH . '/shortcodes/vc_templates' );
			}

			do_action( 'presscore_js_composer_after_bridge_loaded' );
		}

		public static function load_skin_style() {
			wp_enqueue_style( 'brs-shortcodes_base_color', BERSERK_SHORTCODES_URL . 'shortcodes/css/skins/brk-base-color.css' );

			$brk_theme_colors        = brk_theme_colors();
			$brk_theme_color_current = get_theme_mod( 'brk_theme_color', $brk_theme_colors['blue'] );
			$brk_theme_color_name    = brk_get_theme_color_name( $brk_theme_color_current );

			wp_enqueue_style( 'brs-theme-color', BERSERK_SHORTCODES_URL . 'shortcodes/css/skins/brk-' . $brk_theme_color_name . '.css' );

			wp_enqueue_script( 'brs-paper', BERSERK_SHORTCODES_URL . 'shortcodes/vendor/paper/js/paper-full.js', array( 'jquery' ), false, true );
			wp_enqueue_script( 'brs-backgrounds', BERSERK_SHORTCODES_URL . 'shortcodes/js/components/backgrounds.js', array( 'jquery' ), false, true );
		}

		public static function load_front_static() {
			wp_enqueue_style( 'brs-bootstrap', BERSERK_SHORTCODES_URL . 'shortcodes/css/assets/bootstrap.css' );
			wp_enqueue_style( 'brs-normalize', BERSERK_SHORTCODES_URL . 'shortcodes/vendor/normalize/css/normalize.css' );
			wp_enqueue_style( 'brs-assets-normalize', BERSERK_SHORTCODES_URL . 'shortcodes/css/assets/brk-normalize.css' );

			//-- assets --//
			wp_enqueue_style( 'brs-block-visibility', BERSERK_SHORTCODES_URL . 'shortcodes/css/assets/block-visibility.css' );
			wp_enqueue_style( 'brs-offsets', BERSERK_SHORTCODES_URL . 'shortcodes/css/assets/offsets.css' );
			wp_enqueue_style( 'brs-text-align', BERSERK_SHORTCODES_URL . 'shortcodes/css/assets/text-align.css' );
			//wp_enqueue_style( 'brs-text-style', BERSERK_SHORTCODES_URL . 'shortcodes/css/assets/text-style.css', array('font-awesome') );
			wp_enqueue_style( 'brs-text-style', BERSERK_SHORTCODES_URL . 'shortcodes/css/assets/text-style.css' );

			//-- main styles --//
			wp_enqueue_style( 'brs-main-style', BERSERK_SHORTCODES_URL . 'shortcodes/css/assets/style.css' );
			wp_enqueue_style( 'brs-type-styles', BERSERK_SHORTCODES_URL . 'shortcodes/css/assets/type-styles.css' );
			wp_enqueue_style( 'brs-controls', BERSERK_SHORTCODES_URL . 'shortcodes/css/assets/controls.css' );

			// These components may be used from many shortcodes - so they always should be included
			$libraries = array(
				'component__title',
				'component__button',
				//'assets__variables',
				//'font_awesome__5', // Not Used because doesn't support PRO features .fal and .far
			);
			brs_add_libraries( $libraries );

			//-- Core Scripts --//
			wp_enqueue_script( 'brs-popper', BERSERK_SHORTCODES_URL . 'shortcodes/vendor/popper/js/popper.min.js', 'jQuery', false, true );
			wp_enqueue_script( 'brs-bootstrap', BERSERK_SHORTCODES_URL . 'shortcodes/vendor/bootstrap/js/bootstrap.min.js', 'jQuery', false, true );
			wp_enqueue_script( 'brs-waypoints', BERSERK_SHORTCODES_URL . 'shortcodes/vendor/waypoints/js/jquery.waypoints.min.js', 'jQuery', false, true );
			//wp_enqueue_script( 'berserk', BERSERK_SHORTCODES_URL . 'shortcodes/js/assets/berserk.js', 'jQuery', false, false );

			wp_enqueue_script( 'brs-lazysizes', BERSERK_SHORTCODES_URL . 'shortcodes/vendor/unveilhooks/js/ls.unveilhooks.min.js', 'jQuery', false, true );
			wp_enqueue_script( 'brs-lazysizes-addon', BERSERK_SHORTCODES_URL . 'shortcodes/vendor/lazysizes/js/lazysizes.min.js', 'brs-lazysizes', false, true );

			//-- Core Calls/Inits --//
			wp_enqueue_script( 'brs-theme-js', BERSERK_SHORTCODES_URL . 'shortcodes/js/theme.js', array('berserk'), false, false );

			$translation_array = array(
				'ajaxurl'         => admin_url( 'admin-ajax.php' ),
				'shortocodes_url' => BERSERK_SHORTCODES_URL . 'shortcodes/',
			);
			wp_localize_script( 'brs-theme-js', 'brs_l10n', $translation_array );

			wp_localize_script( 'berserk', 'brs_l10n', $translation_array );


			global $post;

			if ( is_array( $post ) || is_object( $post ) ) {

				self::getPageShortcodesByContent( $post->post_content );
				$link = BRS_Font::get_google_fonts_link( self::$fonts );

				if ( ! empty( $link ) ) {
					wp_enqueue_style( 'brs_google_fonts', $link, null, false );
				}
			}
		}

		public static function vc_row_scripts() {
			if ( is_callable( 'vc_editor_post_types' ) && in_array( get_post_type(), vc_editor_post_types() ) ) {
				wp_enqueue_script( 'dt-vc_row-custom-admin', trailingslashit( BERSERK_SHORTCODES_URL ) . '/shortcodes/vc_extend/vc_row-custom-admin.js', array(), wp_get_theme()->get( 'Version' ), true );

				?>
				<script>
					var brs_live_mode = <?php echo ( get_option( 'brs_vc_live_mode' ) ) ? get_option( 'brs_vc_live_mode' ) : 'false'  ?>;
				</script>

				<?php
			}
		}

		public static function getPageShortcodesByContent( $content ) {

			$content        = shortcode_unautop( trim( $content ) ); // @todo this seems not working fine.
			$not_shortcodes = preg_split( '/' . self::shortcodesRegexp() . '/', $content );

			foreach ( $not_shortcodes as $string ) {
				$temp = str_replace( array(
					'<p>',
					'</p>',
				), '', $string ); // just to avoid autop @todo maybe do it better like vc_wpnop in js.
				if ( strlen( trim( $temp ) ) > 0 ) {
					$content = preg_replace( '/(' . preg_quote( $string, '/' ) . '(?!\[\/))/', '[vc_row][vc_column width="1/1"][vc_column_text]$1[/vc_column_text][/vc_column][/vc_row]', $content );
				}
			}

			return self::parseShortcodesString( $content );
		}

		public static function shortcodesRegexp() {
			$tagnames  = array_keys( WPBMap::getShortCodes() );
			$tagregexp = implode( '|', array_map( 'preg_quote', $tagnames ) );
			// WARNING from shortcodes.php! Do not change this regex without changing do_shortcode_tag() and strip_shortcode_tag()
			// Also, see shortcode_unautop() and shortcode.js.
			return '\\[' // Opening bracket
			       . '(\\[?)' // 1: Optional second opening bracket for escaping shortcodes: [[tag]]
			       . "($tagregexp)" // 2: Shortcode name
			       . '(?![\\w-])' // Not followed by word character or hyphen
			       . '(' // 3: Unroll the loop: Inside the opening shortcode tag
			       . '[^\\]\\/]*' // Not a closing bracket or forward slash
			       . '(?:' . '\\/(?!\\])' // A forward slash not followed by a closing bracket
			       . '[^\\]\\/]*' // Not a closing bracket or forward slash
			       . ')*?' . ')' . '(?:' . '(\\/)' // 4: Self closing tag ...
			       . '\\]' // ... and closing bracket
			       . '|' . '\\]' // Closing bracket
			       . '(?:' . '(' // 5: Unroll the loop: Optionally, anything between the opening and closing shortcode tags
			       . '[^\\[]*+' // Not an opening bracket
			       . '(?:' . '\\[(?!\\/\\2\\])' // An opening bracket not followed by the closing shortcode tag
			       . '[^\\[]*+' // Not an opening bracket
			       . ')*+' . ')' . '\\[\\/\\2\\]' // Closing shortcode tag
			       . ')?' . ')' . '(\\]?)'; // 6: Optional second closing brocket for escaping shortcodes: [[tag]]

		}

		public static function parseShortcodesString( $content, $is_container = false, $parent_id = false ) {
			$string = '';
			preg_match_all( '/' . self::shortcodesRegexp() . '/', trim( $content ), $found );
			WPBMap::addAllMappedShortcodes();
			add_shortcode( 'vc_container_anchor', 'vc_container_anchor' );

			$tag_index = 1;

			foreach ( $found[2] as $index => $s ) {
				$id        = md5( time() . '-' . $tag_index ++ );
				$content   = $found[5][ $index ];
				$shortcode = array(
					'tag'         => $s,
					'attrs_query' => $found[3][ $index ],
					'attrs'       => shortcode_parse_atts( $found[3][ $index ] ),
					'id'          => $id,
					'parent_id'   => $parent_id,
				);
				if ( false !== WPBMap::getParam( $s, 'content' ) ) {
					if ( ! is_array( $shortcode['attrs'] ) ) {
						$shortcode['attrs'] = array();
					}
					$shortcode['attrs']['content'] = $content;
				}

				if ( $s == 'brs_list' ) {
					$attrs = shortcode_parse_atts( $found[3][ $index ] );
					if ( isset( $attrs['google_fonts'] ) ) {
						$google_font             = $attrs['google_fonts'];
						$fontFamily              = BRS_Font::_vc_google_fonts_parse_attributes( '', $google_font );
						$font                    = explode( ':', $fontFamily['values']['font_family'] );
						self::$fonts[ $font[0] ] = 1;
					}
					self::$fonts['Montserrat']            = 1;
					self::$fonts['Open Sans']             = 1;
					self::$fonts['Playfair Display']      = 1;
					self::$fonts['Oxygen']                = 1;
					self::$fonts['Poppins']               = 1;
					self::$fonts['Pacifico']              = 1;
					self::$fonts['Montserrat Alternates'] = 1;
				}

				if ( $s == 'brs_call_to_action' ) {
					$attrs = shortcode_parse_atts( $found[3][ $index ] );

					if ( isset( $attrs['values'] ) ) {
						$title_values = vc_param_group_parse_atts( $attrs['values'] );

						foreach ( $title_values as $value ) {
							if ( isset( $value['label_google_font'] ) ) {
								$google_font             = $value['label_google_font'];
								$fontFamily              = BRS_Font::_vc_google_fonts_parse_attributes( '', $google_font );
								$font                    = explode( ':', $fontFamily['values']['font_family'] );
								self::$fonts[ $font[0] ] = 1;

							}
						}
					}
					self::$fonts['Montserrat']            = 1;
					self::$fonts['Open Sans']             = 1;
					self::$fonts['Playfair Display']      = 1;
					self::$fonts['Oxygen']                = 1;
					self::$fonts['Poppins']               = 1;
					self::$fonts['Pacifico']              = 1;
					self::$fonts['Montserrat Alternates'] = 1;

				}

				if ( $s == 'brs_services' ) {
					self::$fonts['Montserrat']            = 1;
					self::$fonts['Open Sans']             = 1;
					self::$fonts['Playfair Display']      = 1;
					self::$fonts['Oxygen']                = 1;
					self::$fonts['Poppins']               = 1;
					self::$fonts['Pacifico']              = 1;
					self::$fonts['Montserrat Alternates'] = 1;
				}

				if ( $s == 'brs_title' ) {
					self::$fonts['Montserrat']            = 1;
					self::$fonts['Open Sans']             = 1;
					self::$fonts['Playfair Display']      = 1;
					self::$fonts['Oxygen']                = 1;
					self::$fonts['Poppins']               = 1;
					self::$fonts['Pacifico']              = 1;
					self::$fonts['Montserrat Alternates'] = 1;
				}

				if ( $s == 'brs_title_section' ) {
					self::$fonts['Montserrat']            = 1;
					self::$fonts['Open Sans']             = 1;
					self::$fonts['Playfair Display']      = 1;
					self::$fonts['Oxygen']                = 1;
					self::$fonts['Poppins']               = 1;
					self::$fonts['Pacifico']              = 1;
					self::$fonts['Montserrat Alternates'] = 1;
				}

				if ( $s == 'brs_pricing_table' ) {
					self::$fonts['Playfair Display'] = 1;
				}
				if ( $s == 'brs_testimonials' ) {
					self::$fonts['Oxygen']           = 1;
					self::$fonts['Playfair Display'] = 1;
				}

				if ( $s == 'brs_button' ) {

					$attrs = shortcode_parse_atts( $found[3][ $index ] );

					if ( isset( $attrs['enable_font'] ) && $attrs['enable_font'] == 'y' ) {
						self::$fonts['Open Sans'] = 1;
					}

					if ( ! empty( $attrs['google_fonts'] ) ) {
						$google_font             = $attrs['google_fonts'];
						$fontFamily              = BRS_Font::_vc_google_fonts_parse_attributes( '', $google_font );
						$font                    = explode( ':', $fontFamily['values']['font_family'] );
						self::$fonts[ $font[0] ] = 1;
					}

					if ( isset( $attrs['values'] ) ) {
						$title_values = vc_param_group_parse_atts( $attrs['values'] );

						foreach ( $title_values as $value ) {
							if ( isset( $value['label_google_font'] ) ) {
								$google_font             = $value['label_google_font'];
								$fontFamily              = BRS_Font::_vc_google_fonts_parse_attributes( '', $google_font );
								$font                    = explode( ':', $fontFamily['values']['font_family'] );
								self::$fonts[ $font[0] ] = 1;

							}
						}
					}
				}

				if ( $s == 'brs_countdown' ) {
					self::$fonts['Montserrat']            = 1;
					self::$fonts['Open Sans']             = 1;
					self::$fonts['Playfair Display']      = 1;
					self::$fonts['Oxygen']                = 1;
					self::$fonts['Poppins']               = 1;
					self::$fonts['Pacifico']              = 1;
					self::$fonts['Montserrat Alternates'] = 1;
				}

				if ( $s == 'brs_progress_bar' ) {
					self::$fonts['Oxygen'] = 1;
				}

				if ( $s == 'brs_social_block' ) {
					self::$fonts['Montserrat Alternates'] = 1;
				}


				$string .= self::toString( $shortcode, $content );

			}

		}

		public static function toString( $shortcode, $content ) {
			$shortcode_obj = visual_composer()->getShortCode( $shortcode['tag'] );
			$is_container  = $shortcode_obj->settings( 'is_container' ) || ( null !== $shortcode_obj->settings( 'as_parent' ) && false !== $shortcode_obj->settings( 'as_parent' ) );
			$shortcode     = apply_filters( 'vc_frontend_editor_to_string', $shortcode, $shortcode_obj );

			$output = ( '<div class="vc_element" data-tag="' . $shortcode['tag'] . '" data-shortcode-controls="' . esc_attr( json_encode( $shortcode_obj->shortcodeClass()->getControlsList() ) ) . '" data-model-id="' . $shortcode['id'] . '"' . self::cleanStyle() . '>' . self::wrapperStart() . '[' . $shortcode['tag'] . ' ' . $shortcode['attrs_query'] . ']' . ( $is_container ? '[vc_container_anchor]' . self::parseShortcodesString( $content, $is_container, $shortcode['id'] ) : do_shortcode( $content ) ) . '[/' . $shortcode['tag'] . ']' . self::wrapperEnd() . '</div>' );

			return $output;
		}

		public static function cleanStyle() {
			return '';
		}

		/**
		 * @return string
		 */
		public static function wrapperStart() {
			return '';
		}

		/**
		 * @return string
		 */
		public static function wrapperEnd() {
			return '';
		}

		public static function load_admin_static() {
			wp_register_style( 'brs-vc-bridge', BERSERK_SHORTCODES_URL . '/shortcodes/css/composer_bridge.css', array('js_composer') );
			wp_register_style( 'brs-vc-front-bridge', BERSERK_SHORTCODES_URL . '/shortcodes/css/composer_bridge.css', array('vc_inline_css') );

			wp_enqueue_style( 'brs-vc-bridge');
			wp_enqueue_style( 'brs-vc-front-bridge');

			wp_enqueue_style( 'brs-vc-popup', BERSERK_SHORTCODES_URL . '/shortcodes/css/popup.css' );
			//wp_enqueue_style( 'brs-admin-shortcodes_base_color_blue', BERSERK_SHORTCODES_URL . 'shortcodes/css/skins/brk-blue.css' )
			wp_enqueue_style( 'brs-admin-shortcodes_base_color', BERSERK_SHORTCODES_URL . 'shortcodes/css/skins/brk-base-color.css' );

			if ( function_exists( 'brk_theme_colors' ) ) {
				$brk_theme_colors        = brk_theme_colors();
				$brk_theme_color_current = get_theme_mod( 'brk_theme_color', $brk_theme_colors['blue'] );
				$brk_theme_color_name    = brk_get_theme_color_name( $brk_theme_color_current );

				wp_enqueue_style( 'brs-theme-color', BERSERK_SHORTCODES_URL . 'shortcodes/css/skins/brk-' . $brk_theme_color_name . '.css' );
			}

			if ( function_exists( 'vc_is_inline' ) && vc_is_inline() ) {
				wp_enqueue_script( 'vc-custom-view', BERSERK_SHORTCODES_URL . '/shortcodes/js/vc-custom-view.js', 'jQuery', false, true );
			}

			wp_enqueue_script( 'vc-custom-popup', BERSERK_SHORTCODES_URL . '/shortcodes/js/popup.js', array(), false, true );

		}
		// add custom admin js
		/*
		public static function vc_row_scripts() {
			if ( is_callable( 'vc_editor_post_types' ) && in_array( get_post_type(), vc_editor_post_types() ) ) {
				wp_enqueue_script( 'brs-vc_row-custom-admin', trailingslashit( BRS_SHORTCODES_URI ) . 'vc_extend/vc_row-custom-admin.js', array(), wp_get_theme()->get( 'Version' ), true );
			}
		}*/

		public static function remove_teaser_meta_box() {
			global $vc_teaser_box;
			if ( is_callable( 'vc_editor_post_types' ) && ! empty( $vc_teaser_box ) ) {
				$pt_array = vc_editor_post_types();
				foreach ( $pt_array as $pt ) {
					remove_meta_box( 'vc_teaser', $pt, 'side' );
				}
				remove_action( 'save_post', array( &$vc_teaser_box, 'saveTeaserMetaBox' ) );
			}
		}

		public static function vc_set_as_theme() {
			if ( function_exists( 'vc_set_as_theme' ) ) {
				vc_set_as_theme();
			}
		}

		/**
		 * Export VC settings to js.
		 *
		 * @param array $var
		 *
		 * @return array
		 */
		public static function localize_script( $var = array() ) {
			$var['VCMobileScreenWidth'] = get_option( 'wpb_js_responsive_max', '768' );

			return $var;
		}
	}

	Presscore_Modules_Compatibility_VC::execute();

endif;
