<?php
/**
 * Compatibility module.
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) { exit; }

// if visual composer class esixts
//if( class_exists('WPBMap') ) {

	if ( ! class_exists( 'Presscore_Modules_ComparibilityModule', false ) ) :

		class Presscore_Modules_ComparibilityModule {

			/**
			 * Execute module.
			 */
			public static function execute() {
				$path = trailingslashit( dirname( __FILE__ ) );

				include $path . 'class-compatibility-vc.php';
			}
		}


		Presscore_Modules_ComparibilityModule::execute();

	endif;

//} // if visual composer class esixts
